# 🔐 Complete RBAC Workflow: Menu → Role → User → Access Control

This document describes the complete end-to-end workflow from menu creation to user access control, showing how all components work together in the RBAC system.

## 📋 **Overview: The Complete Flow**

```
Menu Creation → Permission Definition → Role Assignment → User Assignment → JWT Token → API Access → Permission Check
```

## 🏗️ **Step-by-Step Workflow**

### **Step 1: Menu Creation** 🎛️

**Menus are automatically created by the seeder from `DEFAULT_MENUS` configuration**

**At application startup:**
```python
# services/auth/app/main.py - lifespan()
@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    seeder = DatabaseSeeder()
    seeder.seed_all()  # ← Creates all menus from DEFAULT_MENUS
    yield
```

**Menu Configuration in Seeder:**
```python
# services/auth/app/core/seeder.py
DEFAULT_MENUS = [
    # Administration menus (critical for RBAC)
    {"name": "Administration", "icon": "🔧", "parent_id": None, "path": "/admin", "order": 9},
    {"name": "Users", "icon": "👥", "parent_id": "Administration", "path": "/admin/users", "order": 1},
    {"name": "Permissions", "icon": "🔐", "parent_id": "Administration", "path": "/admin/permissions", "order": 2},
    
    # Business menus
    {"name": "Dashboard", "icon": "📊", "parent_id": None, "path": "/dashboard", "order": 1},
    {"name": "Forecast", "icon": "🔮", "parent_id": None, "path": "/forecast", "order": 3},
    {"name": "Supply", "icon": "⚡", "parent_id": None, "path": "/supply", "order": 4},
    # ... 30+ predefined menus for EPMS
]
```

**Database Action:**
```json
// menus collection - Auto-created on startup
{
  "_id": "menu_001", 
  "name": "Users",
  "icon": "👥",
  "path": "/admin/users",
  "parent_id": "administration_menu_id",
  "order": 1,
  "is_active": true,
  "created_at": "2024-01-01T10:00:00Z"
}
```

**Code Path:**
- `DatabaseSeeder.seed_menus()` → Creates all DEFAULT_MENUS at startup
- `MenuRepository.create_menu()` → Stores each menu in `menus` collection
- Hierarchical structure: parent-child relationships resolved automatically
- All menus become available for permission assignment

---

### **Step 2: Permission Definition** 📝

**System defines what permissions are available for this menu**

For a "Users" menu, available permissions typically are:
- `users:read` - View users
- `users:write` - Edit users  
- `users:create` - Create new users
- `users:delete` - Delete users

**These permissions are:**
- **Convention-based**: Generated from menu name + standard actions
- **Stored in**: Permission catalog (`libs/core/authz/permissions_catalog.py`)
- **Format**: `{resource}:{action}` (e.g., `users:read`)

---

### **Step 3: Role Creation** 👥

**Admin creates roles that will hold permissions**

```http
POST /api/v1/roles
Authorization: Bearer {admin_token}
Content-Type: application/json

{
  "name": "Manager",
  "description": "User management role"
}
```

**Database Action:**
```json
// roles collection
{
  "_id": "role_001",
  "name": "Manager", 
  "description": "User management role",
  "permissions": [], // Initially empty
  "is_active": true,
  "created_at": "2024-01-01T10:05:00Z"
}
```

**Code Path:**
- `RoleRepository.create_role()` → stores role with empty permissions
- Role is ready to receive menu permissions

---

### **Step 4: Menu-Permission Assignment to Role** 🔗

**This is the KEY step where permissions flow from menu to role**

```http
POST /api/v1/menu-roles/roles/role_001/menus
Authorization: Bearer {admin_token}
Content-Type: application/json

{
  "menu_id": "menu_001",
  "permissions": ["read", "write", "create"]
}
```

**Database Actions:**

1. **Create menu-role relationship:**
```json
// menu_roles collection
{
  "_id": "menu_role_001",
  "menu_id": "menu_001",
  "role_id": "role_001", 
  "permissions": ["read", "write", "create"],
  "is_active": true,
  "created_at": "2024-01-01T10:10:00Z"
}
```

2. **Auto-sync role permissions** (CRITICAL):
```json
// roles collection - UPDATED
{
  "_id": "role_001",
  "name": "Manager",
  "permissions": [
    "users:read",    // Generated from menu_name:permission
    "users:write", 
    "users:create"
  ],
  "updated_at": "2024-01-01T10:10:00Z"
}
```

**Code Path:**
- `MenuRoleRepository.grant_role_menu_access()`
- Auto-syncs permissions to role using format: `{menu_name.lower()}:{permission}`
- Role now has concrete permissions that can be checked

---

### **Step 5: Role Assignment to User** 👤

**Admin assigns the role to a user**

```http
PUT /api/v1/users/user_123/roles
Authorization: Bearer {admin_token}
Content-Type: application/json

{
  "roles": ["Manager"]
}
```

**Database Action:**
```json
// users collection - UPDATED
{
  "_id": "user_123",
  "username": "john.doe",
  "email": "john@company.com",
  "roles": ["Manager"], // Role assigned
  "permissions": [], // Direct permissions (usually empty)
  "updated_at": "2024-01-01T10:15:00Z"
}
```

**Code Path:**
- `UserRepository.assign_roles_to_user()`
- User now inherits all permissions from assigned roles

---

### **Step 6: User Authentication & JWT Token** 🎫

**User logs in and receives JWT token with permissions**

```http
POST /auth/login
Content-Type: application/json

{
  "username": "john.doe",
  "password": "secure_password"
}
```

**JWT Token Generation Process:**

1. **Validate credentials** → `AuthService.authenticate()`
2. **Load user with permissions** → `UserRepository.get_user_with_permissions()`
3. **Compute effective permissions** → Union of all role permissions
4. **Generate JWT token** → Include permissions in payload

**JWT Token Payload:**
```json
{
  "user_id": "user_123",
  "username": "john.doe", 
  "email": "john@company.com",
  "roles": ["Manager"],
  "permissions": ["users:read", "users:write", "users:create"],
  "exp": 1640995200,
  "iat": 1640908800
}
```

**Code Path:**
- `AuthService.login()` → generates JWT with computed permissions
- Token contains all permissions user has through roles

---

### **Step 7: API Request with Token** 🌐

**User makes API request to access protected resource**

```http
GET /api/v1/users
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**This triggers the centralized RBAC system:**

1. **Request hits FastAPI endpoint**
2. **Centralized guard activated** → `global_authz_guard` dependency
3. **Authentication flow begins**

---

### **Step 8: Centralized Permission Checking** 🔍

**The centralized RBAC system processes the request:**

#### **Phase 1: Authentication** 
```python
# libs/core/authz/guard.py - get_current_user()

# 1. Extract token from Authorization header
token = _bearer(request)  # "Bearer xyz..." → "xyz..."

# 2. Validate JWT token
payload, err = jwt_validator.validate_token_with_details(token)
# Returns: TokenPayload with user_id, roles, permissions

# 3. Load user from database
user_doc = await _load_user_doc(db, payload.user_id)
# Gets: Fresh user data with current roles/permissions

# 4. Compute effective permissions (union of sources)
db_perms = await compute_effective_permissions(user_doc, tenant_id, db)
token_perms = set(payload.permissions or [])
effective_perms = db_perms | token_perms

# 5. Create UserPrincipal object
user = UserPrincipal(
    user_id=payload.user_id,
    tenant_id="default",
    is_super_admin=is_super_admin,
    effective_permissions=effective_perms
)
```

#### **Phase 2: Authorization**
```python
# libs/core/authz/guard.py - global_authz_guard()

# 1. Check if super admin (bypass all checks)
if user.is_super_admin:
    return  # Allow access

# 2. Extract route information
route = request.scope.get("route")
path_template = route.path_format  # "/api/v1/users"
method = request.method.upper()    # "GET"

# 3. Determine required permissions
required = await required_permissions_for(db, method, path_template)
# GET /api/v1/users → ["users:read"]

# 4. Check if public route
if not required:
    return  # Public route, allow access

# 5. Check user permissions
have = user.effective_permissions  # ["users:read", "users:write", "users:create"]
missing = [p for p in required if p not in have]

# 6. Grant or deny access
if missing:
    raise HTTPException(403, f"Missing permissions: {', '.join(missing)}")
# No missing permissions → Access granted
```

---

### **Step 9: Route-to-Permission Mapping** 🗺️

**How routes automatically map to permissions:**

```python
# libs/core/authz/config.py

# Automatic mapping rules:
METHOD_ACTION = {
    "GET": "read",      # GET /users → users:read
    "POST": "create",   # POST /users → users:create  
    "PUT": "update",    # PUT /users/{id} → users:update
    "DELETE": "delete"  # DELETE /users/{id} → users:delete
}

def _resource_from_path(path_template: str) -> str:
    # "/api/v1/users" → "users"
    # "/api/v1/admin/settings" → "admin.settings"
    parts = [p for p in path_template.strip("/").split("/") if p and not p.startswith("{")]
    return ".".join(parts[:max_segments]).lower() or "root"

def _action_from_path(method: str, path_template: str) -> str:
    # Check for special keywords first
    # "approve", "status", "schedule", "upload" → specific actions
    # Otherwise use METHOD_ACTION mapping
    return METHOD_ACTION.get(method.upper(), "read")

# Final permission: f"{resource}:{action}"
# GET /api/v1/users → "users:read"
# POST /api/v1/users → "users:create"
```

---

### **Step 10: Access Decision** ✅❌

**Final decision based on permission check:**

#### **✅ Access Granted (200 OK)**
```python
# User has "users:read" permission
# Route requires "users:read" permission
# Match found → Access granted
return await endpoint_function()
```

#### **❌ Access Denied (403 Forbidden)**
```python
# User has ["users:read"] permissions
# Route requires ["users:write"] permission  
# Missing permission → Access denied
raise HTTPException(403, "Missing permissions: users:write")
```

---

## 🔄 **Permission Computation Details**

### **How User Permissions are Computed**

```python
# libs/core/authz/principal.py - compute_effective_permissions()

async def compute_effective_permissions(user_doc: dict, tenant_id: str, db) -> Set[str]:
    # 1. Get direct permissions from user
    direct_perms = set(user_doc.get("permissions", []))
    
    # 2. Get role names from user
    role_names = user_doc.get("roles", [])  # ["Manager", "Viewer"]
    
    # 3. Load role documents from database
    role_docs = await db.roles.find({"name": {"$in": role_names}}).to_list(None)
    
    # 4. Collect all permissions from roles
    role_perms = set()
    for role_doc in role_docs:
        role_perms.update(role_doc.get("permissions", []))
    
    # 5. Union all permission sources
    all_perms = role_perms | direct_perms  # Role perms + Direct perms
    
    # 6. Handle wildcard expansion
    if "*" in all_perms:
        # Expand to full permission catalog
        catalog = await db.permissions_catalog.find_one({})
        return set(catalog.get("permissions", []))
    
    return all_perms
```

### **Permission Sources (Union)**

1. **Role Permissions** (Primary source)
   - Computed from menu-role assignments
   - Format: `menu_name:permission` (e.g., `users:read`)
   - Auto-synced when menus assigned to roles

2. **Direct User Permissions** (Secondary source) 
   - Permissions assigned directly to user
   - Usually empty in menu-based RBAC
   - Used for special cases/overrides

3. **JWT Token Permissions** (Cached source)
   - Permissions embedded in JWT at login time
   - Union with fresh database permissions
   - Ensures consistency between token and database

---

## 🎯 **Key Integration Points**

### **1. Menu → Permission Mapping**
```python
# When menu assigned to role:
menu_name = "Users"
permissions = ["read", "write"] 
# Generates: ["users:read", "users:write"]

role.permissions.extend([f"{menu_name.lower()}:{perm}" for perm in permissions])
```

### **2. Route → Permission Mapping**
```python
# When user hits endpoint:
route = "GET /api/v1/users"
# Generates: ["users:read"]

required_permissions = [f"{resource}:{action}"]
```

### **3. Permission Checking**
```python
# Final check:
user_permissions = ["users:read", "users:write"]  # From roles
required_permissions = ["users:read"]              # From route
has_access = all(perm in user_permissions for perm in required_permissions)
```

---

## ⚡ **Performance Optimizations**

### **1. Single Database Lookup**
- User permissions computed once per request
- Cached in `UserPrincipal` object
- No repeated database queries

### **2. Route Permission Caching**
- Route-to-permission mapping cached (60s TTL)
- Avoids re-computing for same routes
- Database overrides cached

### **3. JWT Token Efficiency**
- Permissions embedded in token at login
- Reduces database lookups on every request
- Union with fresh data for consistency

### **4. Wildcard Optimization**
- Wildcard expansion only when needed
- Permission catalog cached
- Super admin bypass (no permission checks)

---

## 🔧 **Configuration Points**

### **1. Public Routes** (No Authentication)
```python
# libs/core/authz/config.py
PUBLIC = [
    ("GET", "/health"),
    ("POST", "/auth/login"),
    ("POST", "/auth/refresh"),
]
```

### **2. Admin Routes** (Require admin:*)
```python
ADMIN_PREFIXES = ["/admin"]
# Any route starting with /admin/* requires "admin:*" permission
```

### **3. Custom Route Overrides**
```json
// endpoint_overrides collection
{
  "method": "GET",
  "path": "/api/v1/special-report", 
  "required_permissions": ["reports:advanced", "admin:read"]
}
```

---

## 🧪 **Testing the Complete Flow**

### **Test Menu Creation to Access**

```python
async def test_complete_rbac_flow():
    # 1. Create menu
    menu = await menu_repo.create_menu(MenuCreate(
        name="TestMenu",
        path="/test",
        icon="test"
    ))
    
    # 2. Create role 
    role = await role_repo.create_role(RoleCreate(
        name="TestRole",
        description="Test role"
    ))
    
    # 3. Assign menu to role
    await menu_role_repo.grant_role_menu_access(
        role_id=role.id,
        menu_id=menu.id, 
        permissions=["read", "write"]
    )
    
    # 4. Verify role permissions updated
    updated_role = await role_repo.get_role_by_id(role.id)
    assert "testmenu:read" in updated_role.permissions
    assert "testmenu:write" in updated_role.permissions
    
    # 5. Assign role to user
    await user_repo.assign_roles_to_user(user_id, [role.name])
    
    # 6. Test API access
    response = await client.get("/api/v1/testmenu", 
                              headers={"Authorization": f"Bearer {user_token}"})
    assert response.status_code == 200  # Should have access
    
    response = await client.delete("/api/v1/testmenu/1",
                                  headers={"Authorization": f"Bearer {user_token}"}) 
    assert response.status_code == 403  # Should be denied (no delete permission)
```

---

## 📊 **Database Schema Summary**

### **Core Collections**

```javascript
// menus - Menu definitions
{
  "_id": ObjectId,
  "name": "Users",
  "path": "/users", 
  "icon": "users",
  "parent_id": ObjectId | null,
  "order": 1,
  "is_active": true
}

// roles - Role definitions  
{
  "_id": ObjectId,
  "name": "Manager",
  "description": "Management role",
  "permissions": ["users:read", "users:write"], // Auto-synced
  "is_active": true
}

// menu_roles - Menu-Role relationships
{
  "_id": ObjectId,
  "menu_id": ObjectId,
  "role_id": ObjectId, 
  "permissions": ["read", "write"], // Available permissions for this menu-role
  "is_active": true
}

// users - User definitions
{
  "_id": ObjectId,
  "username": "john.doe",
  "roles": ["Manager"], // Role names
  "permissions": [], // Direct permissions (usually empty)
  "is_active": true
}

// permissions_catalog - Available permissions (Optional)
{
  "permissions": ["users:read", "users:write", "admin:*", "..."],
  "version": 1
}

// endpoint_overrides - Custom route permissions (Optional)
{
  "method": "GET",
  "path": "/api/v1/special",
  "required_permissions": ["special:access"]
}
```

---

## 🎉 **Summary: Complete Integration**

The RBAC system provides **seamless integration** from menu creation to access control:

1. **📝 Menu Creation** → Defines resources available in system
2. **🔧 Permission Definition** → Establishes what actions are possible  
3. **👥 Role Creation** → Groups permissions into manageable units
4. **🔗 Menu-Role Assignment** → Links menus to roles with specific permissions
5. **👤 User-Role Assignment** → Grants users access through role membership
6. **🎫 JWT Token Generation** → Embeds permissions for efficient checking
7. **🌐 API Request Processing** → Uses centralized guard for consistent enforcement
8. **🔍 Permission Checking** → Validates access using unified permission logic

**The result**: A single place to check permissions with automatic route mapping, consistent enforcement, and comprehensive testing coverage. All authorization logic flows through the centralized RBAC system, eliminating duplicate code and ensuring security consistency across the entire application.

---

**🔐 Zero Duplicate Authorization Logic - Everything Flows Through One System!**
