# Page-Based Access Control Implementation

## Overview

This document explains how page-based access control is implemented across all services in the EPMS backend system.

## Architecture

### 1. Auth Service (Central Authority)
- **Database Models**: Pages are stored in MongoDB with `role_ids` for access control
- **RBAC Functions**: `has_page_access()` and `get_user_accessible_pages()` in `services/auth/app/core/rbac.py`
- **API Endpoints**: 
  - `POST /auth/check-page-access` - Check if user roles have access to a page
  - `POST /auth/accessible-pages` - Get list of accessible pages for user roles

### 2. Other Services (Processing, Ingestion, Scheduler)
- **Auth Client**: HTTP client to communicate with auth service
- **Page Access Middleware**: FastAPI dependencies for checking page access
- **Route Protection**: All endpoints protected by `require_page_access("Page Name")`

## Implementation Details

### Auth Service Components

#### 1. Page Model (`services/auth/app/models/pages.py`)
```python
class PageInDB(BaseModel):
    id: str = Field(default_factory=str, alias="_id")
    name: str
    module_id: str
    guard_name: str = "web"
    role_ids: List[str] = []  # Direct role assignment
    created_at: datetime
    updated_at: datetime
```

#### 2. RBAC Functions (`services/auth/app/core/rbac.py`)
```python
def has_page_access(user_roles: List[str], page_name: str) -> bool:
    """Check if user has access to a page based on their roles"""
    
def get_user_accessible_pages(user_roles: List[str]) -> List[str]:
    """Get list of pages that a user can access based on their roles"""
```

#### 3. API Endpoints (`services/auth/app/api/v1/routes/user_management.py`)
```python
@router.post("/check-page-access")
async def check_page_access(data: Dict[str, Any]):
    """Check if user roles have access to a specific page"""

@router.post("/accessible-pages")
async def get_accessible_pages_for_roles(data: Dict[str, Any]):
    """Get list of pages accessible to user roles"""
```

### Other Services Components

#### 1. Auth Client (`services/{service}/app/services/auth_client.py`)
```python
class AuthClient:
    async def validate_token_and_get_user(self, token: str) -> Optional[Dict[str, Any]]
    async def check_page_access(self, user_roles: List[str], page_name: str, token: str) -> bool
    async def get_user_accessible_pages(self, user_roles: List[str], token: str) -> List[str]
```

#### 2. Page Access Middleware (`services/{service}/app/middleware/page_access.py`)
```python
async def get_current_user(request: Request) -> Dict[str, Any]:
    """Extract and validate user from Authorization header"""

def require_page_access(page_name: str):
    """FastAPI dependency to check page access"""
    async def checker(current_user: Dict[str, Any] = Depends(get_current_user)):
        # Check access via auth service
        has_access = await auth_client.check_page_access(user_roles, page_name, token)
        if not has_access:
            raise HTTPException(status_code=403, detail=f"Access denied to page: {page_name}")
        return current_user
    return checker
```

#### 3. Protected Routes (Example from Processing Service)
```python
@router.post("/data")
async def process_data(
    request: ProcessingRequest,
    current_user: Dict[str, Any] = Depends(require_page_access("Data Processing"))
):
    """Process data endpoint - requires access to Data Processing page"""
```

## Access Flow

1. **Client Request**: User makes API request with JWT token in Authorization header
2. **Token Validation**: Service extracts token and validates it with auth service
3. **User Info Retrieval**: Service gets user info including roles from auth service
4. **Page Access Check**: Service calls auth service to check if user's roles have access to the required page
5. **Authorization Decision**: 
   - If access granted: Request proceeds to endpoint logic
   - If access denied: HTTP 403 error returned

## Example Usage

### Processing Service Endpoint
```python
# User with roles ["admin", "operator"] requests data processing
# 1. Token validated → user info retrieved
# 2. Auth service checks: does ["admin", "operator"] have access to "Data Processing"?
# 3. Auth service queries database: does "Data Processing" page contain "admin" or "operator" in role_ids?
# 4. If yes → access granted, if no → 403 error

@router.post("/data")
async def process_data(
    request: ProcessingRequest,
    current_user: Dict[str, Any] = Depends(require_page_access("Data Processing"))
):
    # This endpoint is only accessible if user's roles are in "Data Processing" page's role_ids
    return await process_data_logic(request)
```

### Ingestion Service Endpoint
```python
@router.post("/data")
async def ingest_data(
    request: DataIngestionRequest,
    current_user: Dict[str, Any] = Depends(require_page_access("Data Ingestion"))
):
    # This endpoint is only accessible if user's roles are in "Data Ingestion" page's role_ids
    return await ingest_data_logic(request)
```

## Page Configuration

Pages are seeded into the database with the following structure:

```python
DEFAULT_PAGES = [
    {"name": "Home", "module_id": "6073ee4dfca6b62a5b47c842"},
    {"name": "User Management", "module_id": "614c6835f89e93154e781072"},
    {"name": "Role Management", "module_id": "614c6835f89e93154e781072"},
    {"name": "Data Processing", "module_id": "610d1ea5f22e9e73aa537b92"},
    {"name": "Data Ingestion", "module_id": "610d1eb5afb37c7fd50f12a2"},
    {"name": "Reports", "module_id": "614c681dc4aef12a7d244495"},
    {"name": "Settings", "module_id": "614c6835f89e93154e781072"}
]
```

## Benefits

1. **Centralized Access Control**: All access decisions made by auth service
2. **Consistent Authorization**: Same access logic across all services
3. **Page-Level Granularity**: Users get access to entire functional areas (pages) rather than individual endpoints
4. **Database-Driven**: Access control rules stored in database, can be modified without code changes
5. **Service Independence**: Each service only needs to know the page name, not complex permission logic

## Security Considerations

1. **Token Validation**: All services validate tokens with auth service before checking page access
2. **Service Communication**: Inter-service communication secured via HTTP(S)
3. **Fallback Behavior**: If auth service is unavailable, access is denied by default
4. **Error Handling**: Detailed error logging while providing generic error messages to clients
