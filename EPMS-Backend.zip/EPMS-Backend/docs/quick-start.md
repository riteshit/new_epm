# 🚀 Quick Start Guide

Get your audit logging system up and running in 5 minutes with automatic PII protection.

## 📦 **Installation**

```bash
# The audit logging system is already integrated into your project
# No additional installation required
```

## 🔧 **Basic Usage**

### **1. Import the Logger**

```python
from libs.audit_queue.simple_logger import audit_logger
```

### **2. Log User Actions**

```python
# User activities (6 months retention by default)
audit_logger.log_user_action(
    service="your_service",
    user_id="user123",
    action="profile_update",
    message="User updated their profile",
    session_id="session456",
    user_email="john.doe@company.com"  # Automatically masked
)
```

### **3. Log Security Events**

```python
# Security events (6 months retention by default)
audit_logger.log_security_event(
    service="auth",
    event_type="login_success",
    message="User login successful",
    user_id="user123",
    client_ip="192.168.1.100",  # Automatically masked
    username="john.doe@company.com"  # Automatically masked
)
```

### **4. Log System Operations**

```python
# System operations (3 months retention by default)
audit_logger.log_system_operation(
    service="your_service",
    operation="data_validation",
    message="Data validation completed",
    correlation_id="job123",
    records_processed=150
)
```

### **5. Log Errors**

```python
# Error events (6 months retention by default)
audit_logger.log_error_event(
    service="your_service",
    error_name="ValidationError",
    error_message="Invalid data format detected",
    user_id="user123",
    correlation_id="job123"
)
```

### **6. Log Scheduled Jobs**

```python
# Scheduled jobs (3 months retention by default)
audit_logger.log_scheduled_job(
    service="your_service",
    job_id="cleanup_job_20241221",
    status="completed",
    message="Data cleanup completed successfully",
    duration_ms=5000
)
```

## 🔒 **Automatic PII Protection**

The system automatically masks sensitive data:

```python
# Input with PII
audit_logger.log_user_action(
    service="auth",
    user_id="user123",
    action="login",
    message="User john.doe@company.com logged in from 192.168.1.100",
    user_email="john.doe@company.com",
    client_ip="192.168.1.100",
    phone="555-123-4567"
)

# Logged output (automatically sanitized)
# message: "User jo***@*****.com logged in from xxx.xxx.xxx.xxx"
# user_email: "jo***@*****.com"
# client_ip: "xxx.xxx.xxx.xxx"
# phone: "***-***-****"
```

## 📊 **Verification**

### **Test the System**

```bash
# Run basic tests
python tests/test_audit_logging.py

# Check database logs
python tests/check_audit_logs.py

# Test API endpoints
python tests/test_auth_endpoints.py
```

### **Check MongoDB**

```javascript
// View recent logs
db.audit_logs.find().sort({timestamp: -1}).limit(5)

// Check PII protection
db.audit_logs.find({message: /\*\*\*/}).limit(3)
```

## 🎯 **Priority Levels**

The system uses retention-based priorities:

```python
from libs.audit_queue.simple_logger import AuditLogLevel

# CRITICAL = Never expires (permanent retention)
audit_logger.log_security_event(..., level=AuditLogLevel.CRITICAL)

# HIGH = 1 year retention
audit_logger.log_security_event(..., level=AuditLogLevel.HIGH)

# MEDIUM = 6 months retention (DEFAULT for user/security events)
audit_logger.log_user_action(...)  # Uses MEDIUM by default

# LOW = 3 months retention (DEFAULT for system operations)
audit_logger.log_system_operation(...)  # Uses LOW by default
```

## 🔧 **Convenience Functions**

For even simpler usage:

```python
from libs.audit_queue.simple_logger import (
    log_user_action, log_security_event, log_system_operation,
    log_error_event, log_scheduled_job
)

# Quick logging
log_user_action("service", "user123", "action", "message")
log_security_event("auth", "login_success", "User logged in")
log_error_event("service", "ErrorType", "Error occurred")
```

## ✅ **Success Indicators**

You'll know it's working when:

- ✅ Functions return log IDs (not empty strings)
- ✅ MongoDB contains new audit_logs entries
- ✅ PII data is masked with `***`
- ✅ Priority levels are set correctly
- ✅ No performance impact on your application

## 📚 **Next Steps**

1. **Read the [Integration Guide](./integration-guide.md)** for detailed implementation
2. **Review [PII Protection Guide](./pii-protection.md)** for security details
3. **Check [Priority Guidelines](./priority-guidelines.md)** for retention policies
4. **Set up [Monitoring](./monitoring.md)** for production use

## 🚨 **Important Notes**

- **PII Protection is ON by default** - All sensitive data is automatically masked
- **MEDIUM priority by default** - User and security events get 6 months retention
- **No configuration required** - Works out of the box with secure defaults
- **Performance optimized** - Minimal impact on application performance

---

**🎉 You're ready to go!** The audit logging system is now protecting your data while providing comprehensive audit trails.