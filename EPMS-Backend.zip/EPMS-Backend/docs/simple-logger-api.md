# 🔧 Simple Logger API Reference

Complete API documentation for the enterprise audit logging system with automatic PII protection.


## 🚫 Removed Legacy Methods

The following methods have been **permanently removed** as part of the audit logging optimization:

- `log_user_activity()` → Use `audit_logger.log_user_action()`
- `log_cron_job()` → Use `audit_logger.log_system_operation()`
- `log_smart()` → Use `audit_logger.log_system_operation()`
- `log_error()` → Use `audit_logger.log_error_event()`
- `audit_log.log_event()` → Use appropriate `audit_logger` method

**Migration completed**: All services now use the new standardized methods.


## 📚 **Core Classes**

### **AuditLogger**

The main audit logging class with built-in PII protection and clean architecture.

```python
from libs.audit_queue.simple_logger import audit_logger, AuditLogLevel
```

## 🎯 **Priority Levels**

```python
class AuditLogLevel(str, Enum):
    LOW = "Low"        # 3 months retention
    MEDIUM = "Medium"  # 6 months retention  
    HIGH = "High"      # 1 year retention
    CRITICAL = "Critical"  # Never expires
```

## 📋 **Core Methods**

### **1. log_user_action()**

Log user-initiated actions with automatic PII protection.

```python
def log_user_action(
    service: str,
    user_id: str,
    action: str,
    message: str,
    session_id: Optional[str] = None,
    success: bool = True,
    level: AuditLogLevel = AuditLogLevel.MEDIUM,  # 6 months default
    **additional_data
) -> str
```

**Parameters:**
- `service` (str): Service name (e.g., "auth", "ingestion")
- `user_id` (str): User identifier (will be sanitized)
- `action` (str): Action performed (e.g., "profile_update", "data_export")
- `message` (str): Human-readable description (will be sanitized)
- `session_id` (Optional[str]): Session ID for correlation
- `success` (bool): Whether action succeeded (default: True)
- `level` (AuditLogLevel): Priority level (default: MEDIUM)
- `**additional_data`: Additional context data (will be sanitized)

**Returns:** `str` - Unique log entry ID

**Example:**
```python
log_id = audit_logger.log_user_action(
    service="ingestion",
    user_id="user123",
    action="provider_create",
    message="User created new data provider",
    session_id="session456",
    provider_name="Test Provider",
    user_email="john.doe@company.com"  # Automatically masked
)
```

### **2. log_security_event()**

Log security-related events with enhanced protection.

```python
def log_security_event(
    service: str,
    event_type: str,
    message: str,
    user_id: Optional[str] = None,
    client_ip: Optional[str] = None,
    success: bool = True,
    level: AuditLogLevel = AuditLogLevel.MEDIUM,  # 6 months default
    **additional_data
) -> str
```

**Parameters:**
- `service` (str): Service name
- `event_type` (str): Security event type (e.g., "login_success", "mfa_failed")
- `message` (str): Human-readable description (will be sanitized)
- `user_id` (Optional[str]): User identifier (will be sanitized)
- `client_ip` (Optional[str]): Client IP address (will be masked)
- `success` (bool): Whether event was successful (default: True)
- `level` (AuditLogLevel): Priority level (default: MEDIUM)
- `**additional_data`: Additional security context (will be sanitized)

**Returns:** `str` - Unique log entry ID

**Example:**
```python
log_id = audit_logger.log_security_event(
    service="auth",
    event_type="login_success",
    message="User authentication successful",
    user_id="user123",
    client_ip="192.168.1.100",  # Automatically masked
    username="john.doe@company.com",  # Automatically masked
    authentication_method="password+mfa"
)
```

### **3. log_system_operation()**

Log internal system operations and processes.

```python
def log_system_operation(
    service: str,
    operation: str,
    message: str,
    correlation_id: Optional[str] = None,
    success: bool = True,
    level: AuditLogLevel = AuditLogLevel.LOW,  # 3 months default
    **additional_data
) -> str
```

**Parameters:**
- `service` (str): Service name
- `operation` (str): Operation type (e.g., "data_validation", "file_processing")
- `message` (str): Human-readable description
- `correlation_id` (Optional[str]): Unique ID for operation correlation
- `success` (bool): Whether operation succeeded (default: True)
- `level` (AuditLogLevel): Priority level (default: LOW)
- `**additional_data`: Additional operation context

**Returns:** `str` - Unique log entry ID

**Example:**
```python
log_id = audit_logger.log_system_operation(
    service="ingestion",
    operation="file_processing",
    message="Processing uploaded CSV file",
    correlation_id="job123",
    file_name="data.csv",
    records_processed=150,
    processing_duration_ms=2500
)
```

### **4. log_error_event()**

Log error events and exceptions with context preservation.

```python
def log_error_event(
    service: str,
    error_name: str,
    error_message: str,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    correlation_id: Optional[str] = None,
    level: AuditLogLevel = AuditLogLevel.MEDIUM,  # 6 months default
    **error_context
) -> str
```

**Parameters:**
- `service` (str): Service name where error occurred
- `error_name` (str): Error type or exception class name
- `error_message` (str): Detailed error description (will be sanitized)
- `user_id` (Optional[str]): User ID if error relates to user action
- `session_id` (Optional[str]): Session ID for user correlation
- `correlation_id` (Optional[str]): Unique ID for operation correlation
- `level` (AuditLogLevel): Error severity level (default: MEDIUM)
- `**error_context`: Additional error context (will be sanitized)

**Returns:** `str` - Unique log entry ID

**Example:**
```python
log_id = audit_logger.log_error_event(
    service="ingestion",
    error_name="ValidationError",
    error_message="Invalid CSV format detected in user file",
    user_id="user123",
    session_id="session456",
    correlation_id="upload_job_789",
    file_name="customer_data.csv",
    validation_rule="email_format"
)
```

### **5. log_scheduled_job()**

Log scheduled job events with performance metrics.

```python
def log_scheduled_job(
    service: str,
    job_id: str,
    status: str,
    message: str,
    job_name: Optional[str] = None,
    duration_ms: Optional[int] = None,
    level: AuditLogLevel = AuditLogLevel.LOW,  # 3 months default
    **additional_data
) -> str
```

**Parameters:**
- `service` (str): Service name where job executed
- `job_id` (str): Unique job execution identifier
- `status` (str): Job status (started, completed, failed, etc.)
- `message` (str): Human-readable description of job event
- `job_name` (Optional[str]): Descriptive job name
- `duration_ms` (Optional[int]): Job execution duration in milliseconds
- `level` (AuditLogLevel): Priority level (default: LOW)
- `**additional_data`: Additional job context

**Returns:** `str` - Unique log entry ID

**Example:**
```python
log_id = audit_logger.log_scheduled_job(
    service="ingestion",
    job_id="cleanup_job_20241221_160000",
    status="completed",
    message="Data cleanup completed successfully",
    job_name="Daily Data Cleanup",
    duration_ms=45000,
    processed_records=1500,
    deleted_records=50
)
```

## 🚀 **Convenience Functions**

For simplified usage without class instantiation:

```python
from libs.audit_queue.simple_logger import (
    log_user_action, log_security_event, log_system_operation,
    log_error_event, log_scheduled_job
)

# Quick logging functions
log_user_action(service, user_id, action, message, **kwargs)
log_security_event(service, event_type, message, **kwargs)
log_system_operation(service, operation, message, **kwargs)
log_error_event(service, error_name, error_message, **kwargs)
log_scheduled_job(service, job_id, status, message, **kwargs)
```

## 🔒 **PII Protection Features**

### **Automatic Sanitization**

The system automatically masks sensitive data:

```python
# Email addresses
"john.doe@company.com" → "jo***@*****.com"

# Phone numbers
"555-123-4567" → "***-***-****"

# IP addresses
"192.168.1.100" → "xxx.xxx.xxx.xxx"

# SSN
"123-45-6789" → "***-**-****"

# Credit cards
"4111-1111-1111-1111" → "****-****-****-****"

# Known PII fields
{"user_email": "test@example.com"} → {"user_email": "***MASKED***"}
```

### **PII Field Detection**

Fields automatically masked:
- `email`, `email_address`, `user_email`, `contact_email`
- `phone`, `phone_number`, `mobile`, `telephone`
- `ssn`, `social_security_number`, `tax_id`
- `password`, `passwd`, `secret`, `token`, `api_key`
- `credit_card`, `card_number`, `cc_number`

## ⚙️ **Configuration Options**

### **Custom Logger Instance**

```python
from libs.audit_queue.simple_logger import AuditLogger

# Logger with PII protection (default)
secure_logger = AuditLogger(enable_pii_protection=True)

# Logger without PII protection (internal use only)
internal_logger = AuditLogger(enable_pii_protection=False)
```

### **Global Instances**

```python
from libs.audit_queue.simple_logger import audit_logger, internal_audit_logger

# Default instance with PII protection
audit_logger.log_user_action(...)

# Internal instance without PII protection
internal_audit_logger.log_system_operation(...)
```

## 📊 **Return Values & Error Handling**

### **Success Response**
```python
log_id = audit_logger.log_user_action(...)
# Returns: "507f1f77bcf86cd799439011" (MongoDB ObjectId as string)
```

### **Error Response**
```python
log_id = audit_logger.log_user_action(...)
# Returns: "" (empty string on error)
```

### **Error Handling Best Practice**
```python
try:
    log_id = audit_logger.log_user_action(
        service="myservice",
        user_id="user123",
        action="data_export",
        message="User exported sensitive data"
    )
    
    if log_id:
        print(f"Audit logged successfully: {log_id}")
    else:
        print("Audit logging failed")
        
except Exception as e:
    print(f"Audit logging error: {e}")
    # Continue with business logic - don't fail on audit errors
```

## 🎯 **Best Practices**

### **1. Use Appropriate Methods**
```python
# User actions → log_user_action()
audit_logger.log_user_action("service", "user123", "profile_update", "User updated profile")

# Security events → log_security_event()
audit_logger.log_security_event("auth", "login_success", "User logged in")

# System processes → log_system_operation()
audit_logger.log_system_operation("service", "data_validation", "Validated user input")

# Errors → log_error_event()
audit_logger.log_error_event("service", "ValidationError", "Invalid data format")

# Background jobs → log_scheduled_job()
audit_logger.log_scheduled_job("service", "job123", "completed", "Job finished")
```

### **2. Provide Rich Context**
```python
# Good - Rich context
audit_logger.log_user_action(
    service="ingestion",
    user_id="user123",
    action="data_export",
    message="User exported customer data",
    session_id="session456",
    export_format="CSV",
    record_count=1500,
    file_size_mb=2.5,
    export_filters={"date_range": "2024-01-01 to 2024-12-31"}
)

# Avoid - Minimal context
audit_logger.log_user_action("service", "user123", "export", "Export done")
```

### **3. Use Correlation IDs**
```python
correlation_id = "batch_job_20241221_160000"

# Start
audit_logger.log_scheduled_job("service", correlation_id, "started", "Batch job started")

# Progress
audit_logger.log_system_operation("service", "processing", "Processing batch", 
                                 correlation_id=correlation_id)

# Complete
audit_logger.log_scheduled_job("service", correlation_id, "completed", "Batch job completed")
```

### **4. Handle Errors Gracefully**
```python
def process_user_data(user_id, data):
    try:
        # Business logic
        result = validate_and_process(data)
        
        # Log success
        audit_logger.log_user_action(
            service="data_processor",
            user_id=user_id,
            action="data_processing",
            message="User data processed successfully",
            records_processed=len(result)
        )
        
        return result
        
    except ValidationError as e:
        # Log error but don't fail business logic on audit failure
        audit_logger.log_error_event(
            service="data_processor",
            error_name="ValidationError",
            error_message=str(e),
            user_id=user_id
        )
        raise  # Re-raise business exception
```

---

**🔒 Security Note**: All methods automatically sanitize PII data. The system is designed to be secure by default while providing comprehensive audit trails for compliance and security monitoring.