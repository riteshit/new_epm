# EPMS Backend Development Setup

This document explains how to set up and run the EPMS Backend services with automatic dependency management.

## 🚀 Quick Start

### Option 1: One-Command Setup
```bash
# Install everything and get started
python setup_dev.py
```

### Option 2: Manual Setup
```bash
# Install project dependencies (includes libs package)
pip install -e .

# Run any service
python run_services.py ingestion
python run_services.py scheduler
python run_services.py auth
python run_services.py processing
```

### Option 3: Direct uvicorn (DevOps-friendly)
```bash
# Services auto-install dependencies when run directly
uvicorn services.auth.app.main:app --host 0.0.0.0 --port 8001
uvicorn services.ingestion.app.main:app --host 0.0.0.0 --port 8002
uvicorn services.processing.app.main:app --host 0.0.0.0 --port 8003
uvicorn services.scheduler.app.main:app --host 0.0.0.0 --port 8004
```

## 📦 How Auto-Installation Works

The system automatically installs the `libs` package everywhere it's needed:

1. **Development Mode**: `pip install -e .` installs the project in editable mode
2. **Service Scripts**: Each service has a `start_service.py` that auto-installs dependencies
3. **Docker**: All Dockerfiles install the project with `pip install -e .`
4. **CI/CD**: The same installation process works in deployment

## 🛠️ Available Commands

### Service Management
```bash
# Run individual services
python run_services.py auth          # Auth service (port 8001)
python run_services.py ingestion     # Ingestion service (port 8002)
python run_services.py processing    # Processing service (port 8003)
python run_services.py scheduler     # Scheduler service (port 8004)

# Install dependencies only
python run_services.py --install-only
```

### Docker Commands
```bash
# Build and run with Docker Compose
docker-compose -f docker-compose.auth.yml up
docker-compose -f docker-compose.ingestion.yml up
docker-compose -f docker-compose.processing.yml up
docker-compose -f docker-compose.scheduler.yml up

# Build individual services
docker build -f services/auth/Dockerfile -t epms-auth .
docker build -f services/ingestion/Dockerfile -t epms-ingestion .
docker build -f services/processing/Dockerfile -t epms-processing .
docker build -f services/scheduler/Dockerfile -t epms-scheduler .
```

### DevOps Commands
```bash
# Direct uvicorn (auto-installs dependencies)
uvicorn services.auth.app.main:app --host 0.0.0.0 --port 8001
uvicorn services.ingestion.app.main:app --host 0.0.0.0 --port 8002
uvicorn services.processing.app.main:app --host 0.0.0.0 --port 8003
uvicorn services.scheduler.app.main:app --host 0.0.0.0 --port 8004

# With environment variables
MONGODB_URI=mongodb://localhost:27017 uvicorn services.auth.app.main:app --host 0.0.0.0 --port 8001

# Production mode (no reload)
uvicorn services.auth.app.main:app --host 0.0.0.0 --port 8001 --workers 4
```

### Development Tools
```bash
# Run tests
python run_tests.py

# Check build
python test_build.py

# Monitor logs
python monitor_logs.py
```

## 🏗️ Project Structure

```
EPMS-Backend/
├── libs/                          # Shared libraries (auto-installed)
│   ├── core/                      # Core functionality
│   ├── models/                    # Data models
│   ├── services/                  # Shared services
│   └── setup.py                   # Libs package setup
├── services/                      # Individual services
│   ├── auth/                      # Authentication service
│   ├── ingestion/                 # Data ingestion service
│   ├── processing/                # Data processing service
│   └── scheduler/                 # Job scheduling service
├── setup.py                       # Main project setup
├── requirements.txt               # Main dependencies
├── run_services.py               # Service runner
└── setup_dev.py                  # Development setup
```

## 🔧 Configuration

### Environment Variables
Each service has its own environment file:
- `env_examples/auth.env.example`
- `env_examples/ingestion.env.example`
- `env_examples/processing.env.example`
- `env_examples/scheduler.env.example`

### Service Ports
- Auth: 8001
- Ingestion: 8002
- Processing: 8003
- Scheduler: 8004

## 🐳 Docker Development

All Dockerfiles now automatically install the `libs` package:

```dockerfile
# Copy project files for installation
COPY setup.py .
COPY requirements.txt .
COPY libs/ ./libs/
COPY services/[service]/ ./services/[service]/

# Install the project in development mode (includes libs)
RUN pip install --upgrade pip && \
    pip install --no-cache-dir -e .
```

## 🚀 Deployment

### Development Deployment
```bash
# Start all services
python setup_dev.py

# Or start individually
python run_services.py ingestion
```

### Production Deployment
```bash
# Using Docker Compose
docker-compose -f docker-compose.ingestion.yml up -d

# Or build and run individual containers
docker build -f services/ingestion/Dockerfile -t epms-ingestion .
docker run -p 8002:8002 epms-ingestion
```

## 🔍 Troubleshooting

### Import Errors
If you get import errors for `libs`:
```bash
# Reinstall the project
pip install -e .

# Or run the service script (auto-installs)
python services/ingestion/start_service.py
```

### Docker Build Issues
```bash
# Clean Docker cache
docker system prune -a

# Rebuild without cache
docker build --no-cache -f services/ingestion/Dockerfile -t epms-ingestion .
```

### Service Won't Start
```bash
# Check if dependencies are installed
python -c "import libs.core.cron_manager; print('OK')"

# Install manually if needed
pip install -e .
```

## 📝 Development Workflow

1. **Make changes** to any service or libs
2. **Test locally** with `python run_services.py [service]`
3. **Test with Docker** using docker-compose
4. **Deploy** using the same commands

The `libs` package is automatically available everywhere without manual path manipulation!

## 🎯 Benefits

- ✅ **No more path manipulation code** in every file
- ✅ **Automatic dependency installation** everywhere
- ✅ **Consistent development and deployment** experience
- ✅ **Docker support** out of the box
- ✅ **Easy onboarding** for new developers
- ✅ **CI/CD ready** with the same installation process
