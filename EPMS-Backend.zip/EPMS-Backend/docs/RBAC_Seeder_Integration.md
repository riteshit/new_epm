# 🚀 RBAC with Seeder Integration - Complete Workflow

## 📋 **Updated Workflow: Seeder-Based Menu & Role Creation**

The RBAC system is integrated with the `DatabaseSeeder` which automatically creates menus and roles at application startup from predefined configurations.

## 🏗️ **The Complete 10-Step Process**

### **1. 🎛️ Menu Creation (Automated via Seeder)**
**At application startup, menus are automatically created from `DEFAULT_MENUS`**

```python
# services/auth/app/main.py
@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    seeder = DatabaseSeeder()
    seeder.seed_all()  # ← Creates ALL menus automatically
    yield
```

**30+ Predefined EPMS Menus:**
```python
DEFAULT_MENUS = [
    # Root menus
    {"name": "Dashboard", "icon": "📊", "parent_id": None, "path": "/dashboard", "order": 1},
    {"name": "Forecast", "icon": "🔮", "parent_id": None, "path": "/forecast", "order": 3},
    {"name": "Supply", "icon": "⚡", "parent_id": None, "path": "/supply", "order": 4},
    {"name": "Administration", "icon": "🔧", "parent_id": None, "path": "/admin", "order": 9},
    
    # Admin sub-menus (critical for RBAC)
    {"name": "Users", "icon": "👥", "parent_id": "Administration", "path": "/admin/users", "order": 1},
    {"name": "Permissions", "icon": "🔐", "parent_id": "Administration", "path": "/admin/permissions", "order": 2},
    {"name": "Audit Logs", "icon": "📝", "parent_id": "Administration", "path": "/admin/audit", "order": 3},
    
    # Business sub-menus
    {"name": "Forecast Analysis", "icon": "📊", "parent_id": "Forecast", "path": "/forecast/analysis", "order": 1},
    {"name": "DAM Scheduling", "icon": "⏰", "parent_id": "Day Ahead Marketing", "path": "/dam/scheduling", "order": 1},
    # ... 20+ more menus
]
```

### **2. 👥 Role Creation (Automated via Seeder)**
**Roles are also auto-created from `DEFAULT_ROLES`**

```python
DEFAULT_ROLES = [
    {"name": "admin", "description": "System administrator"},
    {"name": "operator", "description": "System operator"},  
    {"name": "user", "description": "Regular user"},
    {"name": "viewer", "description": "Read-only user"}
]
```

### **3. 📝 Permission Definition (Convention-Based)**
**System automatically defines permissions based on menu names:**

For menu "Users" → Available permissions:
- `users:read` - View users
- `users:write` - Edit users
- `users:create` - Create users
- `users:delete` - Delete users

For menu "Forecast Analysis" → Available permissions:
- `forecast_analysis:read`
- `forecast_analysis:write`
- `forecast_analysis:create`
- `forecast_analysis:delete`

### **4. 🔗 Menu-Permission Assignment to Role**
**Admin assigns menus + permissions to roles (Manual Step)**

```http
POST /api/v1/menu-roles/roles/{role_id}/menus
Authorization: Bearer {admin_token}

{
  "menu_id": "users_menu_id",
  "permissions": ["read", "write", "create"]
}
```

**Auto-Sync Result:**
```json
// Role permissions automatically updated
{
  "_id": "admin_role_id",
  "name": "admin",
  "permissions": [
    "users:read",
    "users:write", 
    "users:create"
  ]
}
```

### **5. 👤 User-Role Assignment**
**Admin assigns roles to users (Manual Step)**

```http
PUT /api/v1/users/{user_id}/roles
Authorization: Bearer {admin_token}

{
  "roles": ["admin"]
}
```

### **6. 🎫 User Login & JWT Generation**
**User logs in → JWT contains computed permissions**

```json
// JWT Payload
{
  "user_id": "user_123",
  "username": "john.doe",
  "roles": ["admin"],
  "permissions": ["users:read", "users:write", "users:create", ...],
  "exp": 1640995200
}
```

### **7-10. API Request → Centralized RBAC → Access Decision**
Same as before - centralized permission checking through `global_authz_guard`.

---

## 🔄 **Seeder Integration Benefits**

### **✅ Consistent Menu Structure**
- All environments get same menu structure
- No manual menu creation needed
- Hierarchical relationships preserved

### **✅ Development Efficiency**  
- New developers get full menu structure immediately
- No need to manually recreate menus
- Consistent permission naming across environments

### **✅ Production Reliability**
- Guaranteed menu availability
- No missing menus that break permission assignments
- Atomic seeding process

### **✅ Easy Menu Updates**
```python
# To add new menu, just update DEFAULT_MENUS
DEFAULT_MENUS.append({
    "name": "New Feature", 
    "icon": "🆕", 
    "parent_id": "Administration", 
    "path": "/admin/new-feature", 
    "order": 5
})

# Restart service → Menu automatically created
```

---

## 🎯 **How Seeder + RBAC Work Together**

### **Startup Sequence:**
```python
# 1. Application starts
# 2. Seeder runs: seed_all()
#    ├── seed_roles() → Creates admin, operator, user, viewer
#    ├── ensure_admin_user() → Creates admin user with admin role  
#    └── seed_menus() → Creates all 30+ EPMS menus

# 3. Admin user can now:
#    ├── Assign menu permissions to roles
#    ├── Assign roles to users
#    └── Users get access based on their role permissions
```

### **Menu-to-Permission Flow:**
```
Seeded Menu "Users" 
    ↓
Admin assigns "Users" + ["read", "write"] to "operator" role
    ↓  
Role.permissions = ["users:read", "users:write"] (auto-synced)
    ↓
User assigned "operator" role  
    ↓
User inherits ["users:read", "users:write"] permissions
    ↓
API request: GET /admin/users → requires "users:read"
    ↓
Centralized RBAC: User has "users:read" → ✅ Access granted
```

---

## 📊 **Predefined EPMS Menu Structure**

### **Root Menus (9 main sections):**
1. **Dashboard** (`/dashboard`) - Overview and metrics
2. **Overview** (`/overview`) - Management snapshots, DSM overview  
3. **Forecast** (`/forecast`) - Demand forecasting and analysis
4. **Supply** (`/supply`) - Renewable/non-renewable supply management
5. **Day Ahead Marketing** (`/dam`) - DAM scheduling, bidding
6. **Real Time Market** (`/rtm`) - RTM scheduling, bidding
7. **Weather** (`/weather`) - Weather data and forecasting
8. **Masters** (`/masters`) - Plant details, limit values
9. **Administration** (`/admin`) - Users, permissions, audit logs
10. **Reports** (`/reports`) - Standard and custom reports

### **Permission Examples:**
```
dashboard:read, dashboard:write
forecast:read, forecast:write, forecast:create
supply:read, supply:write
users:read, users:write, users:create, users:delete
audit_logs:read
plant_detail:read, plant_detail:write
```

---

## 🔧 **Configuration & Customization**

### **Adding New Menu:**
```python
# services/auth/app/core/seeder.py
DEFAULT_MENUS.append({
    "name": "Custom Module",
    "icon": "⚙️", 
    "parent_id": None,  # Root menu
    "path": "/custom",
    "order": 11
})
```

### **Adding Submenu:**
```python
DEFAULT_MENUS.append({
    "name": "Custom Settings",
    "icon": "🔧",
    "parent_id": "Custom Module",  # Parent menu name
    "path": "/custom/settings", 
    "order": 1
})
```

### **Force Reload Menus:**
```python
# For development/testing
def reload_menus():
    seeder = DatabaseSeeder()
    return seeder.seed_menus(force_reload=True)
```

---

## 🎉 **Summary: Seeder + Centralized RBAC**

### **What's Automated:**
- ✅ **Menu Creation** - 30+ EPMS menus seeded at startup
- ✅ **Role Creation** - admin, operator, user, viewer roles created
- ✅ **Admin User** - Default admin user with admin role
- ✅ **Permission Checking** - Centralized RBAC for all API requests

### **What's Manual (Admin Tasks):**
- 🔧 **Menu-Role Assignment** - Assign menus + permissions to roles
- 🔧 **User-Role Assignment** - Assign roles to users  
- 🔧 **Custom Permissions** - Override default route permissions if needed

### **What's Automatic (Runtime):**
- ⚡ **Permission Sync** - Role permissions auto-updated from menu assignments
- ⚡ **JWT Generation** - User permissions computed from roles
- ⚡ **Access Control** - Every API request checked via centralized RBAC
- ⚡ **Route Mapping** - Routes automatically mapped to permissions

**Result**: Complete RBAC system with zero manual setup, consistent menu structure, and centralized permission enforcement! 🚀

---

**🔐 Full EPMS Integration: Seeder provides structure, Admin configures access, RBAC enforces security!**
