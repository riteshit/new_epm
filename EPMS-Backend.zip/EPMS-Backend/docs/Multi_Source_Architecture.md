# Multi-Source Data Ingestion Architecture

## Overview

The EPMS Backend now supports a flexible multi-source data ingestion architecture with **3 main ingestion methods** and **multiple data sources** for each method.

## Architecture Components

### 1. Ingestion Methods

#### **UPLOAD** - File Upload
- **Test Data Upload** (`DataSource.TEST_DATA`)
  - Manual CSV file uploads
  - Current implementation for testing
  - Supports: `.csv`, `.json`, `.xml`, `.xlsx`

- **SCADA Upload** (`DataSource.SCADA_UPLOAD`)
  - SCADA data via file upload
  - Future implementation for SCADA systems
  - Supports: `.csv`, `.txt`, `.dat`

#### **API** - REST/GraphQL APIs
- **External API** (`DataSource.EXTERNAL_API`)
  - Third-party APIs
  - Configuration: `base_url`, `api_key`, `headers`

- **Internal API** (`DataSource.INTERNAL_API`)
  - Internal system APIs
  - Configuration: `base_url`, `auth_token`, `endpoints`

- **SCADA API** (`DataSource.SCADA_API`)
  - SCADA system APIs
  - Configuration: `scada_endpoint`, `protocol`, `credentials`

#### **FTP** - File Transfer Protocol
- **SCADA FTP** (`DataSource.SCADA_FTP`)
  - SCADA FTP servers
  - Configuration: `host`, `port`, `username`, `password`, `remote_path`

- **External FTP** (`DataSource.EXTERNAL_FTP`)
  - External FTP servers
  - Configuration: `host`, `credentials`, `file_patterns`

- **Internal FTP** (`DataSource.INTERNAL_FTP`)
  - Internal FTP servers
  - Configuration: `host`, `internal_credentials`, `sync_schedule`

## Data Flow

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   UPLOAD        │    │      API        │    │      FTP        │
│                 │    │                 │    │                 │
│ ┌─────────────┐ │    │ ┌─────────────┐ │    │ ┌─────────────┐ │
│ │ Test Data   │ │    │ │ External    │ │    │ │ SCADA FTP   │ │
│ │ SCADA Upload│ │    │ │ Internal    │ │    │ │ External    │ │
│ └─────────────┘ │    │ │ SCADA API   │ │    │ │ Internal    │ │
└─────────────────┘    │ └─────────────┘ │    │ └─────────────┘ │
         │              └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
                    ┌─────────────────┐
                    │ Raw Data        │
                    │ Collections     │
                    │                 │
                    │ • test_demand_  │
                    │   raw_data      │
                    │ • test_supply_  │
                    │   raw_data      │
                    │ • scada_demand_ │
                    │   raw_data      │
                    │ • scada_supply_ │
                    │   raw_data      │
                    └─────────────────┘
                                 │
                    ┌─────────────────┐
                    │ Raw Data        │
                    │ Processor       │
                    │ (Cron Job)      │
                    └─────────────────┘
                                 │
                    ┌─────────────────┐
                    │ Serve Services  │
                    │                 │
                    │ • Demand Serve  │
                    │ • Supply Serve  │
                    └─────────────────┘
                                 │
                    ┌─────────────────┐
                    │ Serve           │
                    │ Collections     │
                    │                 │
                    │ • demand_serve  │
                    │ • supply_serve  │
                    └─────────────────┘
```

## Provider Factory Usage

### Creating Providers

```python
from services.ingestion.app.providers.provider_factory import RawDataProviderFactory
from services.ingestion.app.interfaces.raw_data_provider import DataIngestionMethod, DataSource

# Test data upload (current)
test_provider = RawDataProviderFactory.create_provider(
    ingestion_method=DataIngestionMethod.UPLOAD,
    data_source=DataSource.TEST_DATA
)

# SCADA upload (future)
scada_upload_provider = RawDataProviderFactory.create_provider(
    ingestion_method=DataIngestionMethod.UPLOAD,
    data_source=DataSource.SCADA_UPLOAD,
    config={"scada_system": "system1"}
)

# External API
api_provider = RawDataProviderFactory.create_provider(
    ingestion_method=DataIngestionMethod.API,
    data_source=DataSource.EXTERNAL_API,
    config={
        "base_url": "https://api.example.com",
        "api_key": "your_key",
        "headers": {"Content-Type": "application/json"}
    }
)

# SCADA FTP
ftp_provider = RawDataProviderFactory.create_provider(
    ingestion_method=DataIngestionMethod.FTP,
    data_source=DataSource.SCADA_FTP,
    config={
        "host": "scada.ftp.example.com",
        "username": "scada_user",
        "password": "scada_pass",
        "remote_path": "/scada/data"
    }
)
```

### Getting Supported Sources

```python
# Get supported data sources for UPLOAD
upload_sources = RawDataProviderFactory.get_supported_data_sources(
    DataIngestionMethod.UPLOAD
)
# Returns: [DataSource.TEST_DATA, DataSource.SCADA_UPLOAD]

# Get configuration template
config_template = RawDataProviderFactory.get_provider_config_template(
    DataIngestionMethod.UPLOAD,
    DataSource.SCADA_UPLOAD
)
```

## Collection Structure

### Raw Data Collections (by Source)

- **Test Data**: `test_demand_raw_data`, `test_supply_raw_data`
- **SCADA Upload**: `scada_demand_raw_data`, `scada_supply_raw_data`
- **External API**: `external_api_demand_raw_data`, `external_api_supply_raw_data`
- **SCADA FTP**: `scada_ftp_demand_raw_data`, `scada_ftp_supply_raw_data`

### Serve Collections (Unified)

- **Demand**: `demand_serve`, `demand_serve_historical`
- **Supply**: `supply_serve`, `supply_serve_historical`

## Configuration Examples

### Test Data Upload (Current)
```json
{
  "ingestion_method": "upload",
  "data_source": "test_data",
  "supported_file_types": [".csv", ".json", ".xml", ".xlsx"],
  "max_file_size_mb": 100,
  "validation_rules": {
    "required_columns": ["timeblock", "value"],
    "data_types": ["demand", "supply"]
  }
}
```

### SCADA Upload (Future)
```json
{
  "ingestion_method": "upload",
  "data_source": "scada_upload",
  "scada_system": "system1",
  "supported_file_types": [".csv", ".txt", ".dat"],
  "validation_rules": {
    "required_columns": ["timeblock", "value"],
    "scada_indicators": ["timestamp", "point_id", "measurement"]
  }
}
```

### External API
```json
{
  "ingestion_method": "api",
  "data_source": "external_api",
  "base_url": "https://api.example.com",
  "api_key": "your_api_key",
  "headers": {
    "Content-Type": "application/json",
    "Accept": "application/json"
  },
  "timeout": 30,
  "data_endpoint": "/data"
}
```

### SCADA FTP
```json
{
  "ingestion_method": "ftp",
  "data_source": "scada_ftp",
  "host": "scada.ftp.example.com",
  "port": 21,
  "username": "scada_user",
  "password": "scada_password",
  "remote_path": "/scada/data",
  "file_pattern": "*.csv"
}
```

## Benefits

1. **Scalability**: Easy to add new data sources for each ingestion method
2. **Flexibility**: Different configurations for different sources
3. **Maintainability**: Clear separation of concerns
4. **Extensibility**: Simple to add new ingestion methods
5. **Unified Processing**: All sources feed into the same serve services

## Future Extensions

- **Message Queue**: Kafka, RabbitMQ for real-time data
- **Database Sync**: Direct database connections
- **Streaming**: WebSocket, SSE for real-time data
- **IoT Sensors**: Direct sensor data ingestion
