# Provider Management System

## Overview

The Provider Management System allows you to create, manage, and configure data providers for different ingestion types and data types. This system provides a flexible way to define how data should be ingested, validated, and mapped to serve tables.

## Key Features

- **Multiple Ingestion Types**: Support for UPLOAD (CSV), API, FTP, and SCRAPE
- **Multiple Data Types**: Support for DEMAND, SUPPLY, EXCHANGE, and BID data
- **Flexible Schema Definition**: Define field types, validation rules, and requirements
- **Field Mapping**: Map provider fields to serve table fields
- **CRUD Operations**: Full create, read, update, and delete functionality
- **Enable/Disable**: Toggle providers on/off without deletion
- **Data Type to Serve Table Mapping**: Automatic mapping based on data type

## Data Types and Serve Tables

| Data Type | Serve Table | Description |
|-----------|-------------|-------------|
| DEMAND    | demand_serve | Demand data for power consumption |
| SUPPLY    | supply_serve | Supply data for power generation |
| EXCHANGE  | exchange_serve | Exchange data for power trading |
| BID       | bid_serve | Bid data for power market |

## Ingestion Types

| Ingestion Type | Description |
|----------------|-------------|
| UPLOAD | CSV file upload through web interface |
| API | REST API data ingestion |
| FTP | FTP file transfer |
| SCRAPE | Web scraping data collection |

## API Endpoints

### Provider Management

#### GET /providers
Get all providers with optional filters.

**Query Parameters:**
- `ingestion_type` (optional): Filter by ingestion type (UPLOAD, API, FTP, SCRAPE)
- `data_type` (optional): Filter by data type (DEMAND, SUPPLY, EXCHANGE, BID)
- `enabled` (optional): Filter by enabled status (true/false)
- `skip` (optional): Number of records to skip (default: 0)
- `limit` (optional): Maximum number of records to return (default: 100, max: 1000)

**Response:**
```json
{
  "providers": [
    {
      "id": "provider_id",
      "name": "Provider Name",
      "code": "PROVIDER_CODE",
      "enabled": true,
      "ingestion_type": "UPLOAD",
      "data_type": "DEMAND",
      "description": "Provider description",
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-01T00:00:00Z"
    }
  ],
  "total": 1
}
```

#### GET /providers/{provider_id}
Get provider information by ID.

**Response:**
```json
{
  "id": "provider_id",
  "name": "Provider Name",
  "code": "PROVIDER_CODE",
  "enabled": true,
  "ingestion_type": "UPLOAD",
  "data_type": "DEMAND",
  "fields": [...],
  "unique_columns": [...],
  "mapping": [...],
  "description": "Provider description",
  "version": "1.0.0",
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T00:00:00Z",
  "created_by": "user_id"
}
```

#### POST /providers
Create a new provider.

**Request Body:**
```json
{
  "name": "Provider Name",
  "code": "PROVIDER_CODE",
  "enabled": true,
  "ingestion_type": "UPLOAD",
  "data_type": "DEMAND",
  "fields": [
    {
      "field_name": "time_block",
      "field_type": "integer",
      "is_required": true,
      "validation": [
        {
          "rule": "min_value",
          "value": 1,
          "message": "Time block must be at least 1"
        },
        {
          "rule": "max_value",
          "value": 48,
          "message": "Time block cannot exceed 48"
        }
      ],
      "description": "Time block number (1-48)",
      "default_value": null
    }
  ],
  "unique_columns": ["time_block", "schedule_date"],
  "mapping": [
    {
      "provider_field": "time_block",
      "serve_field": "timeblock",
      "transformation": null
    }
  ],
  "description": "Provider description"
}
```

**Response:**
```json
{
  "message": "Provider created successfully",
  "provider_id": "provider_id",
  "provider_code": "PROVIDER_CODE"
}
```

#### PUT /providers/{provider_id}
Update provider information (partial update supported).

**Request Body:**
```json
{
  "name": "Updated Provider Name",
  "enabled": false,
  "description": "Updated description"
}
```

**Response:**
```json
{
  "message": "Provider updated successfully",
  "provider_id": "provider_id"
}
```

#### PATCH /providers/{provider_id}/enable-disable
Enable or disable provider.

**Request Body:**
```json
{
  "enabled": false
}
```

**Response:**
```json
{
  "message": "Provider disabled successfully",
  "provider_id": "provider_id",
  "enabled": false
}
```

#### DELETE /providers/{provider_id}
Delete provider.

**Response:**
```json
{
  "message": "Provider deleted successfully",
  "provider_id": "provider_id"
}
```

### Utility Endpoints

#### GET /providers/by-code/{code}
Get provider information by code.

#### GET /providers/by-ingestion-type/{ingestion_type}
Get providers by ingestion type.

#### GET /providers/by-data-type/{data_type}
Get providers by data type.

#### GET /providers/enabled/list
Get all enabled providers.

#### GET /providers/{provider_id}/serve-table
Get the serve table name for a provider.

**Response:**
```json
{
  "provider_id": "provider_id",
  "serve_table": "demand_serve"
}
```

#### GET /providers/ingestion-types/list
Get list of available ingestion types.

**Response:**
```json
[
  {
    "value": "UPLOAD",
    "description": "CSV file upload"
  },
  {
    "value": "API",
    "description": "API data ingestion"
  },
  {
    "value": "FTP",
    "description": "FTP file transfer"
  },
  {
    "value": "SCRAPE",
    "description": "Web scraping"
  }
]
```

#### GET /providers/data-types/list
Get list of available data types.

**Response:**
```json
[
  {
    "value": "DEMAND",
    "description": "Demand data",
    "serve_table": "demand_serve"
  },
  {
    "value": "SUPPLY",
    "description": "Supply data",
    "serve_table": "supply_serve"
  },
  {
    "value": "EXCHANGE",
    "description": "Exchange data",
    "serve_table": "exchange_serve"
  },
  {
    "value": "BID",
    "description": "Bid data",
    "serve_table": "bid_serve"
  }
]
```

## Schema Definition

### Field Types

| Field Type | Description |
|------------|-------------|
| string | Text data |
| integer | Whole numbers |
| float | Decimal numbers |
| datetime | Date and time |
| boolean | True/false values |
| date | Date only |
| time | Time only |

### Validation Rules

| Rule | Description | Value Type |
|------|-------------|------------|
| required | Field is required | boolean |
| min_length | Minimum string length | integer |
| max_length | Maximum string length | integer |
| min_value | Minimum numeric value | number |
| max_value | Maximum numeric value | number |
| pattern | Regular expression pattern | string |
| email | Email format validation | boolean |
| url | URL format validation | boolean |
| custom | Custom validation rule | any |

### Example Schema

```json
{
  "field_name": "time_block",
  "field_type": "integer",
  "is_required": true,
  "validation": [
    {
      "rule": "min_value",
      "value": 1,
      "message": "Time block must be at least 1"
    },
    {
      "rule": "max_value",
      "value": 48,
      "message": "Time block cannot exceed 48"
    }
  ],
  "description": "Time block number (1-48)",
  "default_value": null
}
```

## Field Mapping

Field mapping defines how provider fields are mapped to serve table fields:

```json
{
  "provider_field": "time_block",
  "serve_field": "timeblock",
  "transformation": null
}
```

- `provider_field`: The field name in the provider data
- `serve_field`: The corresponding field name in the serve table
- `transformation`: Optional transformation rule (e.g., "uppercase", "lowercase")

## Error Handling

The API returns appropriate HTTP status codes:

- `200 OK`: Successful operation
- `400 Bad Request`: Validation error or invalid request
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Server error

Error responses include a `detail` field with the error message:

```json
{
  "detail": "Provider code 'TEST_PROVIDER' already exists"
}
```

## Authentication

All endpoints require authentication via the `require_page_access` middleware with "Provider Management" permission.

## Usage Examples

### Creating a CSV Upload Provider for Demand Data

```bash
curl -X POST "http://localhost:8002/api/v1/providers" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your_token" \
  -d '{
    "name": "CSV Demand Provider",
    "code": "CSV_DEMAND",
    "enabled": true,
    "ingestion_type": "UPLOAD",
    "data_type": "DEMAND",
    "fields": [
      {
        "field_name": "time_block",
        "field_type": "integer",
        "is_required": true,
        "validation": [
          {"rule": "min_value", "value": 1},
          {"rule": "max_value", "value": 48}
        ]
      },
      {
        "field_name": "schedule_date",
        "field_type": "datetime",
        "is_required": true,
        "validation": [{"rule": "required", "value": true}]
      },
      {
        "field_name": "actual_demand",
        "field_type": "float",
        "is_required": true,
        "validation": [
          {"rule": "required", "value": true},
          {"rule": "min_value", "value": 0}
        ]
      }
    ],
    "unique_columns": ["time_block", "schedule_date"],
    "mapping": [
      {"provider_field": "time_block", "serve_field": "timeblock"},
      {"provider_field": "schedule_date", "serve_field": "schedule_date"},
      {"provider_field": "actual_demand", "serve_field": "actual_demand"}
    ],
    "description": "Provider for CSV uploads of demand data"
  }'
```

### Getting All Enabled Providers

```bash
curl -X GET "http://localhost:8002/api/v1/providers?enabled=true" \
  -H "Authorization: Bearer your_token"
```

### Disabling a Provider

```bash
curl -X PATCH "http://localhost:8002/api/v1/providers/provider_id/enable-disable" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your_token" \
  -d '{"enabled": false}'
```

## Testing

The system includes comprehensive unit tests covering:

- Provider service business logic
- Repository database operations
- API endpoint functionality
- Error handling and validation

Run tests with:
```bash
python -m pytest tests/ingestion/test_provider_*.py -v
```

## Database Schema

Providers are stored in the `providers` collection with the following structure:

```json
{
  "_id": "ObjectId",
  "name": "Provider Name",
  "code": "PROVIDER_CODE",
  "enabled": true,
  "ingestion_type": "UPLOAD",
  "data_type": "DEMAND",
  "fields": [...],
  "unique_columns": [...],
  "mapping": [...],
  "description": "Provider description",
  "version": "1.0.0",
  "created_at": "ISODate",
  "updated_at": "ISODate",
  "created_by": "user_id"
}
```

## Best Practices

1. **Unique Codes**: Use descriptive, unique provider codes
2. **Schema Validation**: Define comprehensive validation rules
3. **Field Mapping**: Ensure all required fields are mapped
4. **Version Control**: Use version numbers for schema changes
5. **Documentation**: Provide clear descriptions for providers and fields
6. **Testing**: Test providers with sample data before production use
7. **Monitoring**: Monitor provider performance and data quality
