# EPMS Job Tracing System

## Overview

The EPMS Job Tracing System provides comprehensive real-time monitoring and tracing capabilities for all jobs running across the EPMS platform. This system allows administrators and developers to track job execution, monitor progress, and troubleshoot issues in real-time.

## Features

### 🔍 **Real-time Job Monitoring**
- **Live Job Status**: Track all currently running jobs across all services
- **Progress Tracking**: Monitor job progress with percentage completion and current step
- **Runtime Monitoring**: View how long jobs have been running
- **Service-based Filtering**: Filter jobs by specific services

### 📊 **Comprehensive Statistics**
- **Success Rates**: Track job success rates over time periods
- **Execution Times**: Monitor average execution times
- **Service Breakdown**: View job statistics by service
- **Historical Data**: Access historical job execution data

### 🎯 **Detailed Job Tracing**
- **Execution History**: View complete execution history for any job
- **Performance Metrics**: Track success rates and execution times
- **Error Analysis**: Detailed error information and retry attempts
- **Job Dependencies**: Understand job relationships and dependencies

### 🖥️ **Web Dashboard**
- **Real-time Updates**: Auto-refreshing dashboard with live data
- **Visual Progress Bars**: Easy-to-read progress indicators
- **Responsive Design**: Works on desktop and mobile devices
- **Interactive Interface**: Click to drill down into job details

## API Endpoints

### Job Monitoring Endpoints

#### `GET /jobs/running`
Get all currently running jobs with real-time status.

**Response:**
```json
{
  "status": "success",
  "running_jobs": [
    {
      "job_id": "uuid-1234",
      "job_name": "Data Migration",
      "service": "scheduler",
      "execution_start": "2025-09-19T14:52:18Z",
      "progress": 75,
      "current_step": "Migrating historical data",
      "runtime_seconds": 1800,
      "runtime_formatted": "30m 0s"
    }
  ],
  "count": 1,
  "timestamp": "2025-09-19T14:52:18Z"
}
```

#### `GET /jobs/trace/{job_id}`
Get detailed execution trace for a specific job.

**Response:**
```json
{
  "status": "success",
  "job_trace": {
    "job_id": "uuid-1234",
    "current_status": "running",
    "current_execution": {
      "started_at": "2025-09-19T14:52:18Z",
      "runtime_seconds": 1800,
      "progress": 75,
      "current_step": "Processing batch 3 of 4",
      "estimated_completion": "2025-09-19T15:22:18Z"
    },
    "execution_history": [...],
    "statistics": {
      "total_executions": 15,
      "successful_executions": 14,
      "success_rate": 93.33,
      "average_execution_time": 1650.5
    }
  }
}
```

#### `GET /jobs/service/{service_name}`
Get jobs for a specific service.

**Parameters:**
- `service_name`: Name of the service (auth, ingestion, processing, scheduler)
- `limit`: Maximum number of jobs to return (default: 50, max: 1000)

#### `GET /jobs/statistics`
Get job execution statistics for a specified time period.

**Parameters:**
- `hours`: Number of hours to look back (1-168, default: 24)

**Response:**
```json
{
  "status": "success",
  "statistics": {
    "time_period_hours": 24,
    "total_jobs": 150,
    "successful_jobs": 142,
    "failed_jobs": 8,
    "running_jobs": 3,
    "success_rate": 94.67,
    "average_execution_time": 1250.5,
    "service_breakdown": {
      "scheduler": {
        "total": 50,
        "successful": 48,
        "failed": 2,
        "success_rate": 96.0
      }
    }
  }
}
```

#### `PUT /jobs/progress/{job_id}`
Update job progress and current step.

**Parameters:**
- `job_id`: ID of the job to update
- `progress`: Progress percentage (0-100)
- `current_step`: Current execution step description
- `estimated_completion`: Estimated completion time (optional)

#### `GET /jobs/dashboard`
Get comprehensive dashboard data including running jobs, statistics, and recent activity.

#### `GET /jobs/health`
Get job system health status with stuck job detection and performance metrics.

## Web Dashboard

### Accessing the Dashboard

1. **Direct URL**: `http://localhost:8004/dashboard`
2. **Static File**: `http://localhost:8004/static/job_dashboard.html`

### Dashboard Features

#### 📈 **Overview Statistics**
- **Running Jobs Count**: Number of currently executing jobs
- **Total Jobs (24h)**: Jobs executed in the last 24 hours
- **Success Rate**: Percentage of successful job executions
- **Average Execution Time**: Mean execution time across all jobs

#### 🔄 **Real-time Updates**
- **Auto-refresh**: Dashboard updates every 5 seconds
- **Live Progress**: Real-time progress bars for running jobs
- **Runtime Tracking**: Live runtime counters for active jobs

#### 📋 **Running Jobs List**
- **Job Details**: Name, service, progress, current step
- **Progress Bars**: Visual progress indicators
- **Runtime Information**: How long each job has been running
- **Status Indicators**: Clear visual status indicators

## Implementation Details

### Database Schema

#### Job Detail Collection (`job_detail`)
```json
{
  "_id": "ObjectId",
  "job_id": "string",
  "job_name": "string",
  "service": "string",
  "status": "running|completed|failed",
  "success": "boolean",
  "execution_start": "datetime",
  "execution_end": "datetime",
  "execution_duration": "number",
  "progress": "number (0-100)",
  "current_step": "string",
  "estimated_completion": "datetime",
  "error_message": "string",
  "job_metadata": {
    "job_id": "string",
    "job_name": "string",
    "service": "string",
    "status": "string",
    "success": "boolean"
  }
}
```

#### Historical Collection (`job_detail_historical`)
- Same schema as `job_detail`
- Used for storing completed job history
- TTL indexes for automatic cleanup

### Progress Tracking

Jobs can update their progress using the `update_job_progress` method:

```python
# Update job progress
job_detail_repository.update_job_progress(
    job_id="uuid-1234",
    progress=75,
    current_step="Processing batch 3 of 4",
    estimated_completion=datetime.utcnow() + timedelta(minutes=10)
)
```

### Integration with Cron Jobs

The cron manager automatically tracks job execution:

```python
# Job start tracking
start_time = self._record_job_start(job_id, job_name)

# Progress updates during execution
self._update_job_progress(job_id, 25, "Initializing data processing")
self._update_job_progress(job_id, 50, "Processing data batches")
self._update_job_progress(job_id, 75, "Finalizing results")

# Job completion tracking
self._record_job_completion(job_id, success, execution_duration)
```

## Usage Examples

### 1. Check Running Jobs
```bash
curl http://localhost:8004/jobs/running
```

### 2. Get Job Statistics
```bash
curl http://localhost:8004/jobs/statistics?hours=24
```

### 3. Trace Specific Job
```bash
curl http://localhost:8004/jobs/trace/uuid-1234
```

### 4. Update Job Progress (from within job)
```python
from services.scheduler.app.repository.job_detail_repository import job_detail_repository

# Update progress
job_detail_repository.update_job_progress(
    job_id="my-job-id",
    progress=50,
    current_step="Halfway through processing"
)
```

### 5. Get Service-specific Jobs
```bash
curl http://localhost:8004/jobs/service/scheduler?limit=20
```

## Monitoring Best Practices

### 1. **Regular Health Checks**
- Monitor the `/jobs/health` endpoint for system health
- Set up alerts for stuck jobs (running > 2 hours)
- Track success rates and set thresholds

### 2. **Performance Monitoring**
- Monitor average execution times
- Track success rates by service
- Identify performance bottlenecks

### 3. **Error Analysis**
- Review failed jobs regularly
- Analyze error patterns
- Implement retry strategies

### 4. **Capacity Planning**
- Monitor job queue sizes
- Track resource utilization
- Plan for scaling based on job volumes

## Troubleshooting

### Common Issues

#### 1. **Jobs Appear Stuck**
- Check if job is actually running (process status)
- Review job logs for errors
- Consider restarting the job if necessary

#### 2. **High Failure Rates**
- Review error messages in job traces
- Check system resources (memory, disk, network)
- Verify external dependencies

#### 3. **Slow Job Execution**
- Monitor system resources
- Check for database performance issues
- Review job logic for optimization opportunities

#### 4. **Dashboard Not Updating**
- Check browser console for JavaScript errors
- Verify API endpoints are accessible
- Ensure scheduler service is running

### Debug Commands

```bash
# Check running jobs
curl http://localhost:8004/jobs/running

# Get system health
curl http://localhost:8004/jobs/health

# View recent scheduler jobs
curl http://localhost:8004/jobs/service/scheduler?limit=10

# Get 24-hour statistics
curl http://localhost:8004/jobs/statistics?hours=24
```

## Security Considerations

- **Access Control**: Implement authentication for production use
- **Rate Limiting**: Add rate limiting to prevent API abuse
- **Data Privacy**: Ensure sensitive job data is not exposed
- **Audit Logging**: Log all job monitoring access

## Future Enhancements

- **Job Scheduling**: Visual job scheduling interface
- **Alert System**: Email/SMS notifications for job failures
- **Performance Analytics**: Advanced performance metrics and trends
- **Job Dependencies**: Visual job dependency graphs
- **Resource Monitoring**: CPU, memory, and disk usage tracking
- **Custom Dashboards**: User-configurable dashboard layouts

## Conclusion

The EPMS Job Tracing System provides comprehensive monitoring and tracing capabilities that enable administrators and developers to maintain system health, troubleshoot issues, and optimize performance. With real-time monitoring, detailed tracing, and an intuitive web dashboard, the system ensures reliable job execution across the entire EPMS platform.
