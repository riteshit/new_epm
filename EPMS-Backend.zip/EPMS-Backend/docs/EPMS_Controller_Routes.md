# EPMS Controller Routes - Based on DEFAULT_MENUS

This document outlines the high-level routes that need controller endpoints implementation based on the menu structure defined in `services/auth/app/core/seeder.py`.

## Overview

The EPMS application has a hierarchical menu structure with **10 root-level routes** and **21 sub-level routes**, totaling **31 unique route paths** that require corresponding controller endpoints.

## Root Level Routes (Main Menu Items)

| Order | Icon | Route | Menu Name | Description |
|-------|------|-------|-----------|-------------|
| 1 | 📊 | `/dashboard` | Dashboard | Main dashboard and overview |
| 2 | 👁️ | `/overview` | Overview | System overview and snapshots |
| 3 | 🔮 | `/forecast` | Forecast | Forecasting and analysis |
| 4 | ⚡ | `/supply` | Supply | Supply management |
| 5 | 📅 | `/dam` | Day Ahead Marketing | Day ahead market operations |
| 6 | ⚡ | `/rtm` | Real Time Market | Real-time market operations |
| 7 | 🌤️ | `/weather` | Weather | Weather data and forecasting |
| 8 | ⚙️ | `/masters` | Masters | Master data configuration |
| 9 | 🔧 | `/admin` | Administration | System administration |
| 10 | 📋 | `/reports` | Reports | Reporting and analytics |

## Detailed Route Structure

### 1. Dashboard (📊)
**Root Route**: `/dashboard`
- Single route for main dashboard functionality

### 2. Overview (👁️)
**Root Route**: `/overview`

| Sub-Route | Menu Name | Description |
|-----------|-----------|-------------|
| `/overview/snapshot` | Management Snapshot | Management overview data |
| `/overview/dsm` | DSM Overview | Demand Side Management overview |
| `/overview/market` | Market Integrator | Market integration status |

### 3. Forecast (🔮)
**Root Route**: `/forecast`

| Sub-Route | Menu Name | Description |
|-----------|-----------|-------------|
| `/forecast/analysis` | Forecast Analysis | Forecast analysis and trends |
| `/forecast/demand` | Demand Forecast | Demand forecasting operations |

### 4. Supply (⚡)
**Root Route**: `/supply`

| Sub-Route | Menu Name | Description |
|-----------|-----------|-------------|
| `/supply/non-renewable` | Non-Renewable Supply | Non-renewable energy sources |
| `/supply/renewable` | Renewable Supply | Renewable energy sources |
| `/supply/urs` | URS | Unscheduled Interchange |

### 5. Day Ahead Marketing (📅)
**Root Route**: `/dam`

| Sub-Route | Menu Name | Description |
|-----------|-----------|-------------|
| `/dam/scheduling` | DAM Scheduling | Day ahead scheduling |
| `/dam/block-bid` | DAM Block Bid | Block bidding operations |
| `/dam/single-bid` | DAM Single Bid | Single bidding operations |
| `/dam/bid-status` | DAM Bid Status | Bid status tracking |

### 6. Real Time Market (⚡)
**Root Route**: `/rtm`

| Sub-Route | Menu Name | Description |
|-----------|-----------|-------------|
| `/rtm/scheduling` | RTM Scheduling | Real-time scheduling |
| `/rtm/block-bid` | RTM Block Bid | Real-time block bidding |
| `/rtm/single-bid` | RTM Single Bid | Real-time single bidding |
| `/rtm/bid-status` | RTM Bid Status | Real-time bid status |

### 7. Weather (🌤️)
**Root Route**: `/weather`
- Single route for weather data and forecasting

### 8. Masters (⚙️)
**Root Route**: `/masters`

| Sub-Route | Menu Name | Description |
|-----------|-----------|-------------|
| `/masters/plant` | Plant Detail | Power plant configuration |
| `/masters/dam-limits` | DAM Limit Values | Day ahead market limits |
| `/masters/rtm-limits` | RTM Limit Values | Real-time market limits |

### 9. Administration (🔧)
**Root Route**: `/admin`

| Sub-Route | Menu Name | Status | Description |
|-----------|-----------|--------|-------------|
| `/admin/users` | Users | ✅ Implemented | User management |
| `/admin/permissions` | Permissions | ✅ Implemented | Permission management |
| `/admin/audit` | Audit Logs | ❌ Missing | System audit logging |
| `/admin/setup` | Setup | ❌ Missing | System setup and configuration |

### 10. Reports (📋)
**Root Route**: `/reports`

| Sub-Route | Menu Name | Description |
|-----------|-----------|-------------|
| `/reports/standard` | Standard Reports | Standard report generation |

## Implementation Guidelines

### Controller Endpoint Pattern
Each route should implement standard REST operations:

```python
# Example for /forecast/demand
GET    /api/v1/forecast/demand           # List/retrieve data
POST   /api/v1/forecast/demand           # Create new resource
PUT    /api/v1/forecast/demand/{id}      # Update existing resource
DELETE /api/v1/forecast/demand/{id}      # Delete resource
```

### Service Distribution

| Service | Responsible Routes |
|---------|-------------------|
| **Auth Service** | `/admin/*` (Users, Permissions, Audit, Setup) |
| **Processing Service** | `/dashboard`, `/overview/*`, `/forecast/*`, `/supply/*`, `/dam/*`, `/rtm/*`, `/masters/*`, `/reports/*` |
| **Ingestion Service** | Data ingestion related operations |
| **Scheduler Service** | Job scheduling operations |
| **Weather Service** | `/weather` (if separate service) |

### Authentication & Authorization
All endpoints must integrate with the menu-based RBAC system:

```python
@router.get("/forecast/demand")
async def get_demand_forecast(
    current_user = Depends(require_menu_access("Demand Forecast", "read"))
):
    # Implementation
```

## Implementation Priority

### Phase 1: Core Business Logic
1. **Dashboard** (`/dashboard`)
2. **Overview** (`/overview/*`)
3. **Supply** (`/supply/*`)
4. **Forecast** (`/forecast/*`)

### Phase 2: Market Operations
1. **DAM Operations** (`/dam/*`)
2. **RTM Operations** (`/rtm/*`)
3. **Weather** (`/weather`)

### Phase 3: Configuration & Administration
1. **Masters** (`/masters/*`)
2. **Reports** (`/reports/*`)
3. **Missing Admin** (`/admin/audit`, `/admin/setup`)

## Notes

- **Total Routes**: 31 unique paths requiring controller implementation
- **Current Status**: Auth service routes mostly implemented, Processing service needs major development
- **Menu Integration**: All routes must align with the menu-based permission system
- **Consistency**: Follow existing patterns from implemented auth service endpoints

---

*Generated from: `services/auth/app/core/seeder.py` - DEFAULT_MENUS configuration*
