# Future Provider Implementation Guide

## Overview

This guide explains how to add new data providers and processors when needed. The current implementation focuses on **test data only**, but the architecture is designed for easy expansion.

## Current Implementation

### ✅ **Currently Working**
- **Test Data Upload** (`DataSource.TEST_DATA`)
  - Provider: `TestDataUploadProvider`
  - Processor: `TestRawDataProcessor`
  - Repository: `TestRawDataRepository`
  - Collections: `test_demand_raw_data`, `test_supply_raw_data`

### 🔮 **Future Ready (To Be Implemented)**
- **SCADA Upload** (`DataSource.SCADA_UPLOAD`)
- **External API** (`DataSource.EXTERNAL_API`)
- **Internal API** (`DataSource.INTERNAL_API`)
- **SCADA API** (`DataSource.SCADA_API`)
- **SCADA FTP** (`DataSource.SCADA_FTP`)
- **External FTP** (`DataSource.EXTERNAL_FTP`)
- **Internal FTP** (`DataSource.INTERNAL_FTP`)

**Note**: These files were removed to keep the codebase clean. They will be created when needed.

## How to Add a New Provider

### Step 1: Create the Provider
```python
# services/ingestion/app/providers/new_provider.py
class NewDataProvider(RawDataProvider):
    def __init__(self):
        super().__init__(
            ingestion_method=DataIngestionMethod.UPLOAD,  # or API, FTP
            data_source=DataSource.NEW_SOURCE
        )
        # Initialize provider-specific repositories
    
    def get_pending_data(self, limit: int = 100) -> List[Dict[str, Any]]:
        # Implement data fetching logic
        pass
    
    def mark_as_processing(self, raw_data_id: str) -> bool:
        # Implement status update logic
        pass
    
    # ... implement other required methods
```

### Step 2: Create the Processor
```python
# services/ingestion/app/processors/new_raw_data_processor.py
class NewRawDataProcessor:
    def __init__(self):
        self.processor_type = "new_data"
    
    def translate_raw_data_to_serve_format(self, raw_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        # Implement data translation logic
        pass
    
    def validate_new_data_format(self, raw_data: Dict[str, Any]) -> bool:
        # Implement validation logic
        pass
```

### Step 3: Create the Repository
```python
# services/ingestion/app/repositories/new_raw_data_repository.py
class NewRawDataRepository(BaseRepository):
    def __init__(self, mongodb_uri: str, database_name: str):
        super().__init__(mongodb_uri, database_name)
        self.demand_collection_name = "new_demand_raw_data"
        self.supply_collection_name = "new_supply_raw_data"
    
    # Implement repository methods
```

### Step 4: Update the Factory
```python
# services/ingestion/app/providers/provider_factory.py
from services.ingestion.app.providers.new_provider import NewDataProvider

PROVIDER_MAPPING = {
    DataSource.TEST_DATA: TestDataUploadProvider,
    DataSource.NEW_SOURCE: NewDataProvider,  # Add new provider
}

# Update create_provider method
if data_source == DataSource.NEW_SOURCE:
    return NewDataProvider()
```

### Step 5: Update the Processor Factory
```python
# services/ingestion/app/processors/raw_data_processor_factory.py
from services.ingestion.app.processors.new_raw_data_processor import NewRawDataProcessor

PROCESSOR_MAPPING = {
    DataSource.TEST_DATA: TestRawDataProcessor,
    DataSource.NEW_SOURCE: NewRawDataProcessor,  # Add new processor
}

# Update validation method
elif hasattr(processor, 'validate_new_data_format'):
    return processor.validate_new_data_format(raw_data)
```

### Step 6: Update Configuration
```python
# services/ingestion/app/core/config.py
class Settings:
    # Add new collection names
    MONGODB_NEW_DEMAND_RAW_DATA_COLLECTION: str = "new_demand_raw_data"
    MONGODB_NEW_SUPPLY_RAW_DATA_COLLECTION: str = "new_supply_raw_data"
```

## File Structure for New Providers

```
services/ingestion/app/
├── providers/
│   ├── test_raw_data_provider.py          # ✅ Implemented
│   ├── new_provider.py                    # 🔮 To be implemented
│   └── provider_factory.py                # ✅ Update mapping
├── processors/
│   ├── test_raw_data_processor.py         # ✅ Implemented
│   ├── new_raw_data_processor.py          # 🔮 To be implemented
│   └── raw_data_processor_factory.py      # ✅ Update mapping
├── repositories/
│   ├── test_raw_data_repository.py        # ✅ Implemented
│   ├── new_raw_data_repository.py         # 🔮 To be implemented
│   └── serve_data_repository.py           # ✅ Time-series for serve data
└── interfaces/
    └── raw_data_provider.py               # ✅ Base interface
```

## Testing New Providers

### Unit Tests
```python
# tests/ingestion/test_new_provider.py
def test_new_provider_creation():
    provider = RawDataProviderFactory.create_provider(
        DataIngestionMethod.UPLOAD,
        DataSource.NEW_SOURCE
    )
    assert provider is not None
    assert provider.data_source == DataSource.NEW_SOURCE

def test_new_processor_translation():
    processor = RawDataProcessorFactory.create_processor(DataSource.NEW_SOURCE)
    translated_data = processor.translate_raw_data_to_serve_format(raw_data)
    assert len(translated_data) > 0
```

### Integration Tests
```python
# tests/ingestion/test_new_integration.py
def test_new_provider_end_to_end():
    # Test complete flow: Provider -> Repository -> Processor -> Serve Service
    pass
```

## Configuration Templates

### Provider Configuration
```json
{
  "ingestion_method": "upload",
  "data_source": "new_source",
  "description": "New data source configuration",
  "required_fields": ["field1", "field2"],
  "optional_fields": ["field3"],
  "validation_rules": {
    "required_columns": ["timeblock", "value"],
    "data_types": ["demand", "supply"]
  }
}
```

## Benefits of This Architecture

1. **✅ Easy Extension**: Add new providers without changing existing code
2. **✅ Consistent Interface**: All providers follow the same pattern
3. **✅ Independent Testing**: Test each provider separately
4. **✅ Gradual Implementation**: Implement providers as needed
5. **✅ Backward Compatibility**: Existing providers continue to work

## When to Add New Providers

- **New Data Sources**: When you need to ingest data from new systems
- **Different Formats**: When data format requires different processing
- **Different Authentication**: When new auth methods are needed
- **Different Validation**: When new validation rules are required
- **Performance Requirements**: When specific optimizations are needed

## Example: Adding SCADA Upload Provider

1. **Create** `ScadaUploadProvider` in `services/ingestion/app/providers/scada_upload_provider.py`
2. **Create** `ScadaRawDataProcessor` in `services/ingestion/app/processors/scada_raw_data_processor.py`
3. **Create** `ScadaRawDataRepository` in `services/ingestion/app/repositories/scada_raw_data_repository.py`
4. **Update** `provider_factory.py` to include the new provider
5. **Update** `raw_data_processor_factory.py` to include the new processor
6. **Test** the complete flow
7. **Deploy** when ready

This architecture ensures that adding new providers is straightforward and doesn't break existing functionality! 🚀
