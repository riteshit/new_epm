# EPMS Queue Implementation Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           EPMS Queue Architecture                              │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Auth Service  │    │ Ingestion       │    │ Processing      │    │ Scheduler       │
│   (Port 8001)   │    │ Service         │    │ Service         │    │ Service         │
│                 │    │ (Port 8002)     │    │ (Port 8003)     │    │ (Port 8004)     │
└─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘
          │                      │                      │                      │
          │                      │                      │                      │
          ▼                      ▼                      ▼                      ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    Unified Queue Service Interface                             │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  • log_audit_event()     • log_data_operation()                        │   │
│  │  • log_system_operation()    • get_queue_status()                          │   │
│  │  • health_check()        • Convenience Functions                       │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        MongoDB Audit Queue Manager                            │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  • Multi-Worker Architecture (3 Workers)                               │   │
│  │  • Connection Pooling (maxPoolSize: 10)                                │   │
│  │  • Retry Logic (MAX_RETRY_COUNT: 3)                                    │   │
│  │  • Error Handling & Recovery                                           │   │
│  │  • Performance Metrics Tracking                                        │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           MongoDB Database                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  Database: audit_db                                                     │   │
│  │  ┌─────────────────────────────────────────────────────────────────┐   │   │
│  │  │  Collection: audit_queue_jobs                                   │   │   │
│  │  │  • Job Status Tracking (SAVED, PROCESSING, COMPLETED, FAILED)  │   │   │
│  │  │  • Retry Count & Error Messages                                 │   │   │
│  │  │  • Timestamps (created_at, updated_at)                          │   │   │
│  │  │  • TTL Indexes for Automatic Cleanup                            │   │   │
│  │  └─────────────────────────────────────────────────────────────────┘   │   │
│  │  ┌─────────────────────────────────────────────────────────────────┐   │   │
│  │  │  Collection: audit_logs                                         │   │   │
│  │  │  • Final Audit Log Entries                                      │   │   │
│  │  │  • Service-Specific Data                                        │   │   │
│  │  │  • Event Types & Details                                        │   │   │
│  │  └─────────────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. Service Layer
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              EPMS Services                                     │
├─────────────────┬─────────────────┬─────────────────┬─────────────────────────┤
│   Auth Service  │ Ingestion       │ Processing      │ Scheduler Service       │
│                 │ Service         │ Service         │                         │
│ • User Login    │ • File Upload   │ • Data          │ • Cron Job              │
│ • Logout        │ • Data          │   Processing    │   Management            │
│ • Password      │   Validation    │ • Validation    │ • System Cleanup        │
│   Changes       │ • Provider      │ • Transformation│ • Data Migration        │
│ • MFA           │   Management    │ • Export        │ • Retry Logic           │
└─────────────────┴─────────────────┴─────────────────┴─────────────────────────┘
```

### 2. Unified Queue Service Interface
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    UnifiedQueueService Class                                   │
├─────────────────────────────────────────────────────────────────────────────────┤
│  Methods:                                                                       │
│  • log_audit_event(event_type, service_name, user_id, ...)                     │
│  • log_data_operation(operation_type, service_name, data_type, ...)            │
│  • log_system_operation(event_type, service_name, details, ...)                    │
│  • get_queue_status() → Dict[str, Any]                                         │
│  • health_check() → Dict[str, Any]                                             │
├─────────────────────────────────────────────────────────────────────────────────┤
│  Features:                                                                      │
│  • Consistent Interface Across All Services                                    │
│  • Service-Specific Event Types                                                │
│  • Automatic Data Validation & Sanitization                                    │
│  • Error Handling & Fallback Logging                                           │
│  • Health Monitoring & Metrics                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 3. MongoDB Audit Queue Manager
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        MongoAuditQueue Class                                   │
├─────────────────────────────────────────────────────────────────────────────────┤
│  Architecture:                                                                  │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  Multi-Worker Thread Pool (3 Workers)                                  │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                    │   │
│  │  │ Worker-1    │  │ Worker-2    │  │ Worker-3    │                    │   │
│  │  │ (Daemon)    │  │ (Daemon)    │  │ (Daemon)    │                    │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘                    │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
├─────────────────────────────────────────────────────────────────────────────────┤
│  Features:                                                                      │
│  • Connection Pooling (maxPoolSize: 10, timeouts: 5s)                         │
│  • Retry Logic (MAX_RETRY_COUNT: 3, RETRY_DELAY: 60s)                         │
│  • Performance Metrics (jobs_processed, jobs_failed, jobs_retried)            │
│  • Graceful Shutdown with Worker Cleanup                                       │
│  • MongoDB Indexes (status, created_at, source_service, TTL)                   │
│  • Error Recovery & Job Restart on System Reboot                               │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 4. Data Flow Architecture
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              Data Flow                                         │
├─────────────────────────────────────────────────────────────────────────────────┤
│  1. Service Event → UnifiedQueueService.log_audit_event()                      │
│  2. Job Creation → MongoDB audit_queue_jobs collection                         │
│  3. Queue Addition → Python Queue (thread-safe)                               │
│  4. Worker Processing → Background thread picks up job                         │
│  5. Status Update → Job status: SAVED → PROCESSING → COMPLETED/FAILED         │
│  6. Final Logging → LoggerService.log_audit_data()                            │
│  7. Audit Storage → MongoDB audit_logs collection                              │
│  8. Cleanup → TTL indexes automatically remove old completed jobs              │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 5. Queue Health Monitoring
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        Queue Health Endpoints                                  │
├─────────────────────────────────────────────────────────────────────────────────┤
│  GET /queue/health     → Queue system health status                            │
│  GET /queue/stats      → Detailed queue statistics & metrics                   │
│  POST /queue/cleanup   → Clean up old completed jobs                           │
│  GET /queue/pending    → Get pending jobs for debugging                        │
├─────────────────────────────────────────────────────────────────────────────────┤
│  Health Metrics:                                                                 │
│  • Workers Alive/Total Count                                                    │
│  • Queue Size (pending jobs)                                                    │
│  • Jobs Processed/Failed/Retried                                                │
│  • Last Processed Timestamp                                                     │
│  • MongoDB Connection Status                                                     │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 6. Error Handling & Recovery
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        Error Handling Strategy                                 │
├─────────────────────────────────────────────────────────────────────────────────┤
│  Job Processing Errors:                                                         │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  1. Retry Logic (up to 3 attempts with 60s delay)                     │   │
│  │  2. Exponential Backoff for Failed Jobs                                │   │
│  │  3. Dead Letter Queue for Permanently Failed Jobs                      │   │
│  │  4. Fallback to Standard Logging if Queue Fails                        │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
├─────────────────────────────────────────────────────────────────────────────────┤
│  System Recovery:                                                                │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  1. Restart Interrupted Jobs on System Reboot                          │   │
│  │  2. Requeue Pending Jobs from MongoDB                                  │   │
│  │  3. Health Check Validation on Startup                                 │   │
│  │  4. Graceful Shutdown with Worker Cleanup                              │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## Performance Characteristics

### Throughput & Scalability
- **Multi-Worker Processing**: 3 concurrent workers (configurable)
- **Connection Pooling**: 10 MongoDB connections with 5s timeouts
- **Queue Capacity**: Unlimited (memory-based Python Queue)
- **Processing Rate**: ~100-500 jobs/second (depending on log complexity)

### Reliability Features
- **At-Least-Once Delivery**: Jobs are persisted to MongoDB before processing
- **Retry Mechanism**: 3 retry attempts with 60-second delays
- **Crash Recovery**: Automatic job restart on system reboot
- **Health Monitoring**: Real-time queue health and metrics
- **Graceful Degradation**: Fallback to standard logging if queue fails

### Data Persistence
- **MongoDB Storage**: All jobs persisted in audit_queue_jobs collection
- **TTL Cleanup**: Automatic removal of old completed jobs
- **Index Optimization**: Compound indexes for efficient querying
- **Audit Trail**: Complete audit log in audit_logs collection

## Integration Points

### Service Integration
```python
# Example usage in any EPMS service
from libs.audit_queue.unified_queue_service import unified_queue_service

# Log audit event
job_id = unified_queue_service.log_audit_event(
    event_type="user_login",
    service_name="auth",
    user_id="user123",
    success=True
)

# Log data operation
job_id = unified_queue_service.log_data_operation(
    operation_type="upload",
    service_name="ingestion",
    data_type="csv",
    record_count=1000
)
```

### Health Monitoring Integration
```python
# Health check endpoint
health_status = unified_queue_service.health_check()
# Returns: {"status": "healthy", "workers_alive": 3, "queue_size": 0, ...}
```

This architecture provides a robust, scalable, and maintainable queue system for audit logging across the entire EPMS platform.
