# 🧪 Testing Scripts Documentation

This document describes the automated testing scripts available for verifying the audit logging system.

## 📋 **Available Test Scripts**

### **1. test_audit_logging.py**
**Purpose:** Direct testing of audit logger functions  
**Usage:** `python test_audit_logging.py`

Tests all 5 core audit logging methods with PII data to verify:
- ✅ Function execution without errors
- ✅ Log ID generation
- ✅ PII masking functionality
- ✅ Default priority levels

**Sample Output:**
```
🔍 Testing Secure Audit Logging System
==================================================

1. Testing User Action Logging...
✅ User Action Log ID: 507f1f77bcf86cd799439011

2. Testing Security Event Logging...
✅ Security Event Log ID: 507f1f77bcf86cd799439012

3. Testing System Operation Logging...
✅ System Operation Log ID: 507f1f77bcf86cd799439013

4. Testing Error Event Logging...
✅ Error Event Log ID: 507f1f77bcf86cd799439014

5. Testing Scheduled Job Logging...
✅ Scheduled Job Log ID: 507f1f77bcf86cd799439015

🎉 Audit Logging Test Completed
```

### **2. test_auth_endpoints.py**
**Purpose:** API endpoint testing through HTTP calls  
**Usage:** `python test_auth_endpoints.py`  
**Requires:** Running auth service

Tests actual API endpoints to verify end-to-end logging:
- ✅ Login endpoint audit logging
- ✅ Password validation logging
- ✅ Password policy access logging
- ✅ Error handling and logging

**Sample Output:**
```
🧪 Testing Auth Service Audit Logging
==================================================
Target URL: http://localhost:8000

🔐 Testing Login Endpoint Audit Logging...
Login Response Status: 401
✅ Login failed (expected) - check logs for security event

🔒 Testing Password Validation Endpoint...
Password Validation Status: 200
✅ Check logs for system operation with masked user_id

📋 Testing Password Policy Endpoint...
Password Policy Status: 200
✅ Check logs for system operation
```

### **3. check_audit_logs.py**
**Purpose:** MongoDB database verification  
**Usage:** `python check_audit_logs.py`  
**Requires:** MongoDB connection

Verifies audit logs in the database:
- ✅ Recent log entries
- ✅ PII protection verification
- ✅ Log categorization
- ✅ Service-specific logs

**Sample Output:**
```
🔍 Audit Logging Verification Tool
==================================================

📊 Checking audit logs from last 24 hour(s)...

--- Log Entry 1 ---
Service: auth
Type: security
Message: User login successful: jo***@*****.com
Priority: Medium
Status: success
Data fields:
  ✅ username: jo***@*****.com (EMAIL MASKED)
  ✅ client_ip: xxx.xxx.xxx.xxx (IP MASKED)
  📝 login_method: password

✅ Found 5 recent audit log entries
```

### **4. check_log_files.py**
**Purpose:** Log file verification  
**Usage:** `python check_log_files.py`

Checks audit log files for entries and PII protection:
- ✅ Log file discovery
- ✅ Audit entry detection
- ✅ PII masking verification
- ✅ JSON format validation

**Sample Output:**
```
📁 Log File Audit Verification
==================================================

📄 Checking: logs/audit/auth.log
Total lines: 150
  📊 Audit entries: 25
  🔒 PII protected entries: 8
  ✅ PII protected entry found
  ✅ Masked data in plain text log

📈 Summary:
  📁 Log files checked: 3
  📊 Total audit entries: 75
  🔒 PII protected entries: 20
  📊 PII protection rate: 26.7%
```

## 🔧 **Script Configuration**

### **Connection Settings**
Update these settings in the scripts as needed:

```python
# test_auth_endpoints.py
BASE_URL = "http://localhost:8000"  # Your auth service URL

# check_audit_logs.py
client = MongoClient("mongodb://localhost:27017/")  # MongoDB connection
db = client["audit_db"]  # Database name
collection = db["audit_logs"]  # Collection name
```

### **Test Data Customization**
Modify test data in scripts to match your environment:

```python
# Example test data with PII
test_data = {
    "username": "test.user@example.com",  # Will be masked
    "password": "testpassword123",
    "user_email": "john.doe@company.com",  # Will be masked
    "phone_number": "555-123-4567",  # Will be masked
    "client_ip": "192.168.1.100"  # Will be masked
}
```

## 🚀 **Running All Tests**

### **Complete Test Suite**
```bash
# Run all tests in sequence
python test_audit_logging.py && \
python check_audit_logs.py && \
python test_auth_endpoints.py && \
python check_log_files.py
```

### **Quick Verification**
```bash
# Basic functionality test
python test_audit_logging.py

# Database verification
python check_audit_logs.py
```

## 📊 **Expected Results**

### **Success Indicators**
- ✅ All scripts complete without errors
- ✅ Log IDs returned from audit functions
- ✅ Database entries created with proper structure
- ✅ PII data masked in all outputs
- ✅ Proper categorization and priority levels

### **Failure Indicators**
- ❌ Empty log IDs returned
- ❌ No database entries created
- ❌ Unmasked PII in logs
- ❌ Connection errors
- ❌ Missing audit entries

## 🔍 **Troubleshooting Test Issues**

### **test_audit_logging.py Failures**
```bash
# Common issues:
1. Import errors → Check Python path and dependencies
2. Empty log IDs → Check MongoDB connection and audit queue service
3. PII not masked → Verify PIISanitizer configuration
```

### **test_auth_endpoints.py Failures**
```bash
# Common issues:
1. Connection refused → Ensure auth service is running
2. 404 errors → Check endpoint URLs and service configuration
3. No logs generated → Verify audit logging integration in endpoints
```

### **check_audit_logs.py Failures**
```bash
# Common issues:
1. MongoDB connection error → Check connection string and credentials
2. No logs found → Run test_audit_logging.py first
3. Collection not found → Verify database and collection names
```

### **check_log_files.py Failures**
```bash
# Common issues:
1. No log files found → Check file logging configuration
2. Permission denied → Verify file system permissions
3. No audit entries → Check if file logging is enabled
```

## 📈 **Performance Testing**

### **Load Testing Script**
```python
import time
from libs.audit_queue.simple_logger import audit_logger

def performance_test(iterations=1000):
    start_time = time.time()
    
    for i in range(iterations):
        audit_logger.log_user_action(
            service="test",
            user_id=f"user{i}",
            action="performance_test",
            message=f"Performance test iteration {i}"
        )
    
    end_time = time.time()
    total_time = end_time - start_time
    avg_time = total_time / iterations
    
    print(f"Performance Test Results:")
    print(f"  Total time: {total_time:.3f} seconds")
    print(f"  Average per log: {avg_time*1000:.3f} ms")
    print(f"  Logs per second: {iterations/total_time:.1f}")

# Run performance test
performance_test(1000)
```

## 🎯 **Continuous Integration**

### **CI/CD Integration**
```yaml
# Example GitHub Actions workflow
name: Audit Logging Tests
on: [push, pull_request]

jobs:
  test-audit-logging:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.9'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Start MongoDB
        uses: supercharge/mongodb-github-action@1.7.0
      - name: Test Audit Logging
        run: |
          python test_audit_logging.py
          python check_audit_logs.py
```

### **Test Automation**
```bash
#!/bin/bash
# automated_test.sh

echo "🧪 Running Audit Logging Test Suite"

# Test 1: Basic functionality
echo "Testing basic functionality..."
python test_audit_logging.py || exit 1

# Test 2: Database verification
echo "Checking database logs..."
python check_audit_logs.py || exit 1

# Test 3: File verification
echo "Checking log files..."
python check_log_files.py || exit 1

echo "✅ All tests passed!"
```

---

**💡 Tip**: Run these tests regularly to ensure your audit logging system continues to work correctly as your application evolves. The scripts are designed to be safe and can be run in any environment without affecting production data.