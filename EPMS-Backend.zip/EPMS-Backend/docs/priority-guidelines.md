# 🎯 Audit Log Priority Guidelines

This document defines the retention-based priority system for audit logs and provides guidelines for when to use each level.

## 📅 **Priority Levels & Retention**

```
CRITICAL = Never expires (Permanent retention)
HIGH     = 1 year retention  
MEDIUM   = 6 months retention (DEFAULT for user activities)
LOW      = 3 months retention
```

## 🎯 **Current Default Assignments**

### **MEDIUM (6 months) - DEFAULT**
```
✅ Security Events:
   - Login success/failure
   - MFA verification
   - Logout events
   - Token refresh

✅ User Activities:
   - Profile modifications
   - Data access/creation
   - Role assignments (by users)
   - Most user interactions

✅ Error Events:
   - Application errors
   - Authentication failures
   - System exceptions
```

### **LOW (3 months)**
```
✅ System Operations:
   - Password validation
   - Policy queries
   - Health checks
   - Configuration reads

✅ Scheduled Jobs:
   - Routine maintenance
   - Data cleanup
   - Report generation
```

## 🔄 **Future Refinement Strategy**

As we identify specific business needs, we can elevate certain activities:

### **CRITICAL (Never expire) - Future Candidates**
```
🎯 Compliance-Critical Events:
   - Admin privilege escalations
   - Security policy changes
   - Audit configuration changes
   - Regulatory compliance events

🎯 High-Risk Security Events:
   - Multiple failed login attempts (brute force)
   - Privilege abuse detection
   - Suspicious access patterns
   - Security incident responses
```

### **HIGH (1 year) - Future Candidates**
```
🎯 Account Lifecycle Events:
   - Account creation/deletion
   - Password changes
   - MFA setup/disable
   - Role/permission changes

🎯 Data Governance Events:
   - Sensitive data access
   - Data export/download
   - Configuration changes
   - Admin actions
```

## 📋 **Decision Framework**

When deciding priority levels, consider:

### **CRITICAL Priority When:**
- Required for regulatory compliance (SOX, PCI, etc.)
- Critical for security incident investigation
- Needed for legal/forensic purposes
- High business impact if lost

### **HIGH Priority When:**
- Important for security monitoring
- Needed for annual compliance audits
- Significant operational impact
- User account security events

### **MEDIUM Priority When:**
- Standard user activities
- Regular security events
- Operational monitoring needs
- 6-month investigation window sufficient

### **LOW Priority When:**
- High-volume, low-risk events
- System health monitoring
- Short-term operational needs
- Cost optimization important

## 🔧 **Implementation Examples**

### **Upgrading to CRITICAL**
```python
# For critical security events
audit_logger.log_security_event(
    service="auth",
    event_type="admin_privilege_escalation",
    message="Admin privileges granted to user",
    level=AuditLogLevel.CRITICAL  # Never expires
)
```

### **Upgrading to HIGH**
```python
# For important account changes
audit_logger.log_security_event(
    service="auth",
    event_type="password_change",
    message="User password changed",
    level=AuditLogLevel.HIGH  # 1 year retention
)
```

### **Using Default MEDIUM**
```python
# Most user activities (no level specified)
audit_logger.log_user_action(
    service="auth",
    user_id="user123",
    action="profile_update",
    message="User updated profile"
    # Uses default MEDIUM (6 months)
)
```

### **Downgrading to LOW**
```python
# For high-volume, low-risk events
audit_logger.log_system_operation(
    service="auth",
    operation="password_validation",
    message="Password strength validated",
    level=AuditLogLevel.LOW  # 3 months retention
)
```

## 📊 **Monitoring & Review**

### **Regular Review Process**
1. **Monthly**: Review log volumes and storage costs
2. **Quarterly**: Assess if priority levels meet business needs
3. **Annually**: Compliance and regulatory requirement review
4. **As-needed**: Incident response and investigation needs

### **Key Metrics to Track**
- Log volume by priority level
- Storage costs by retention period
- Investigation/compliance query patterns
- Incident response log usage

### **Adjustment Triggers**
- Compliance requirement changes
- Security incident lessons learned
- Storage cost optimization needs
- Investigation pattern changes

## 🎯 **Best Practices**

### **Start Conservative**
- Use MEDIUM as default for user activities
- Only elevate to HIGH/CRITICAL when justified
- Monitor actual usage patterns

### **Document Decisions**
- Record why specific events need longer retention
- Track compliance requirements driving decisions
- Document cost vs. value trade-offs

### **Regular Optimization**
- Review and adjust based on actual needs
- Balance compliance, security, and cost
- Consider data lifecycle management

---

**💡 Remember**: Priority levels are about retention, not importance. Even LOW priority events are captured and available for immediate analysis - they just don't need long-term storage.