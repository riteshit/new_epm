# 🔍 Audit Logging Verification Guide

This guide helps you verify that the secure audit logging system is working correctly in your auth service.

## 🚀 Quick Start Verification

### Step 1: Run Basic Tests
```bash
# Test the audit logging system directly
python test_audit_logging.py

# Test through API endpoints (requires running auth service)
python test_auth_endpoints.py
```

### Step 2: Check Database Logs
```bash
# Check MongoDB audit logs
python check_audit_logs.py
```

### Step 3: Check File Logs
```bash
# Check log files
python check_log_files.py
```

## 📊 What to Look For

### ✅ **Successful Audit Logging Indicators:**

1. **Log Entries Created**
   - New entries in MongoDB `audit_logs` collection
   - New entries in log files (if file logging enabled)
   - Log IDs returned from audit functions

2. **PII Protection Working**
   - Emails masked: `jo***@*****.com`
   - IP addresses masked: `xxx.xxx.xxx.xxx`
   - Phone numbers masked: `***-***-****`
   - SSN masked: `***-**-****`
   - Known PII fields show: `***MASKED***`

3. **Proper Categorization**
   - `record_type`: "api", "security", "app", "job"
   - `service`: "auth"
   - `priority`: "Low", "Medium", "High", "Critical"
   - `status`: "success", "failed", "pending"

4. **Rich Context Data**
   - User IDs, usernames (sanitized)
   - Client IP addresses (masked)
   - User agents
   - Correlation IDs
   - Timestamps

## 🔧 Manual Testing Steps

### Test 1: Login Endpoint
```bash
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "test.user@example.com", "password": "wrongpassword"}'
```
**Expected:** Security event logged with masked email

### Test 2: Password Validation
```bash
curl -X POST http://localhost:8000/api/v1/auth/validate-password \
  -H "Content-Type: application/json" \
  -d '{"password": "test123", "user_id": "user@domain.com"}'
```
**Expected:** System operation logged with masked user_id

### Test 3: Password Policy
```bash
curl -X GET http://localhost:8000/api/v1/auth/password-policy
```
**Expected:** System operation logged

## 🗄️ Database Queries

### MongoDB Queries to Verify Logs

```javascript
// Check recent audit logs
db.audit_logs.find().sort({timestamp: -1}).limit(10)

// Check for PII protection
db.audit_logs.find({
  $or: [
    {"message": /\*\*\*/},
    {"data.username": /\*\*\*/},
    {"data.client_ip": /xxx\.xxx\.xxx\.xxx/}
  ]
})

// Check log categories
db.audit_logs.aggregate([
  {$group: {_id: "$record_type", count: {$sum: 1}}},
  {$sort: {count: -1}}
])

// Check auth service logs
db.audit_logs.find({"service": "auth"}).sort({timestamp: -1}).limit(5)

// Check security events
db.audit_logs.find({"record_type": "security"}).sort({timestamp: -1}).limit(5)
```

## 📁 Log File Verification

### Check Log Files
```bash
# Find audit log files
find . -name "*.log" -type f | grep -i audit

# Check recent entries
tail -n 50 logs/audit/auth.log | grep -i "audit\|login\|user"

# Check for PII masking
grep -E "\*\*\*|masked" logs/audit/auth.log
```

## 🚨 Troubleshooting

### Issue: No Logs Generated
**Solutions:**
1. Check if audit queue service is running
2. Verify MongoDB connection
3. Check file permissions for log directories
4. Review audit logger configuration

### Issue: PII Not Masked
**Solutions:**
1. Verify `enable_pii_protection=True` in audit logger
2. Check PII patterns in `PIISanitizer` class
3. Test with known PII data patterns
4. Review sanitization logic

### Issue: Missing Context Data
**Solutions:**
1. Check if request object is properly passed
2. Verify client IP extraction logic
3. Ensure user agent headers are captured
4. Review correlation ID generation

## 📈 Performance Monitoring

### Check Audit System Performance
```python
# Monitor audit logging performance
import time
start_time = time.time()

# Run audit logging
audit_logger.log_user_action(...)

end_time = time.time()
print(f"Audit logging took: {end_time - start_time:.3f} seconds")
```

### Expected Performance
- **Direct logging**: < 10ms
- **Database logging**: < 50ms
- **File logging**: < 5ms
- **PII sanitization**: < 1ms

## ✅ Verification Checklist

- [ ] Audit logs are created in database
- [ ] Audit logs are created in files (if enabled)
- [ ] PII data is properly masked
- [ ] All endpoint types are logged
- [ ] Error conditions are captured
- [ ] Performance is acceptable
- [ ] Log retention policies work
- [ ] Security events are prioritized correctly
- [ ] Correlation IDs enable tracing
- [ ] No sensitive data in plain text

## 🎯 Success Criteria

Your audit logging system is working correctly when:

1. ✅ **All API calls generate audit logs**
2. ✅ **PII data is automatically masked**
3. ✅ **Security events are properly categorized**
4. ✅ **Error conditions are captured with context**
5. ✅ **Performance impact is minimal**
6. ✅ **Logs are searchable and correlatable**
7. ✅ **Compliance requirements are met**

## 📞 Support

If you encounter issues:
1. Check the verification scripts output
2. Review MongoDB and log files
3. Verify configuration settings
4. Test with simple audit calls first
5. Check network connectivity and permissions

---

**🔒 Remember:** The audit logging system is designed to be secure by default with automatic PII protection. All sensitive data should be masked in the logs while maintaining operational visibility.