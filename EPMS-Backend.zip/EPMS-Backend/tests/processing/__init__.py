"""
Processing service tests
""" 