"""
Ingestion service tests
""" 