"""
Core tests for shared components
""" 