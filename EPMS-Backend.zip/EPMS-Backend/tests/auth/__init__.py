"""
Auth service tests
""" 