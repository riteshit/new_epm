"""
Scheduler service tests
""" 