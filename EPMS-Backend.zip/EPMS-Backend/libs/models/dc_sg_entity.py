"""
Dc Sg Entity Models
Defines the data structures for dc sg collections
"""

from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, Field, ConfigDict


class DCSgEntity(BaseModel):
    """
    Dc Sg Entity
    
    This entity represents the processed supply data that is actively served
    to the frontend applications.
    """
    
    model_config = ConfigDict(
        validate_by_name=True,
        arbitrary_types_allowed=True,
        json_encoders={
            datetime: lambda v: v.isoformat()
        },
        json_schema_extra={
            "example": {
                "scheduled_at": "2025-01-15T10:00:00",
                "plant_name": "Thermal Plant A",
                "dc_sg": "DC",
                "volume": 500.0,
                "fc_price": 2.5,
                "px_price": 3.2,
                "vc_price": 1.8,
                "category": "Thermal",
                "technology": "Coal",
                "price_group": "A",
                "c_s": "Central",
                "archived_at": "2025-01-19T10:00:00"
            }
        }
    )
    
    # Time-related fields
    scheduled_at: datetime = Field(..., description="Schedule date and time")
    time_block: Optional[int] = Field(None, description="Time block identifier")
    
    # Plant and supply information
    plant_id: Optional[str] = Field(None, description="Plant ID")
    dc_sg: Optional[str] = Field(None, description="DC/SG type (DC/SG)")
    volume: Optional[float] = Field(None, description="Supply volume")
    
    # Price information
    fc_price: Optional[float] = Field(None, description="FC (Fixed Cost) price")
    px_price: Optional[float] = Field(None, description="PX (Power Exchange) price")
    vc_price: Optional[float] = Field(None, description="VC (Variable Cost) price")
    
    # Categorization fields
    price_group: Optional[str] = Field(None, description="Price group identifier")
    
    # Additional fields
    tm: float = Field(default=0.0, description="TM value")
    multiplier: str = Field(default="", description="Multiplier value")
    ramping: str = Field(default="", description="Ramping information")
    
    # Source tracking
    source: Optional[str] = Field(None, description="Data source identifier")
