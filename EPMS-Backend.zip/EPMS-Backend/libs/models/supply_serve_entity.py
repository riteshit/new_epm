"""
Supply Serve Entity Models
Defines the data structures for supply serve and historical collections
"""

from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, Field, ConfigDict, field_validator
from bson import ObjectId
from libs.enum.updated_flag import UpdatedFlag


class SupplyServeEntity(BaseModel):
    """
    Supply Serve Entity - Active time series data (4-day window)
    
    This entity represents the processed supply data that is actively served
    to the frontend applications. It contains a 4-day rolling window of data.
    """
    
    model_config = ConfigDict(
        validate_by_name=True,
        arbitrary_types_allowed=True,
        json_encoders={
            ObjectId: str,
            datetime: lambda v: v.isoformat()
        },
        json_schema_extra={
            "example": {
                "scheduled_at": "2025-01-15T10:00:00",
                "plant_name": "Thermal Plant A",
                "dc_sg": "DC",
                "volume": 500.0,
                "fc_price": 2.5,
                "px_price": 3.2,
                "vc_price": 1.8,
                "category": "Thermal",
                "technology": "Coal",
                "price_group": "A",
                "c_s": "Central",
                "archived_at": "2025-01-19T10:00:00"
            }
        }
    )
    
    # MongoDB ID
    id: Optional[Any] = Field(default_factory=ObjectId, alias="_id")
    # Time-related fields
    scheduled_at: datetime = Field(..., description="Schedule date and time")
    time_block: Optional[int] = Field(None, description="Time block identifier")
    
    # Plant and supply information
    plant_id: Optional[str] = Field(None, description="Plant ID")
    dc_sg: Optional[str] = Field(None, description="DC/SG type (DC/SG)")
    volume: Optional[float] = Field(None, description="Supply volume")
    
    # Price information
    fc_price: Optional[float] = Field(None, description="FC (Fixed Cost) price")
    px_price: Optional[float] = Field(None, description="PX (Power Exchange) price")
    vc_price: Optional[float] = Field(None, description="VC (Variable Cost) price")
    
    # Categorization fields
    price_group: Optional[str] = Field(None, description="Price group identifier")
    
    # Additional fields
    tm: float = Field(default=0.0, description="TM value")
    multiplier: str = Field(default="", description="Multiplier value")
    ramping: str = Field(default="", description="Ramping information")
    
    # Source tracking
    source: Optional[str] = Field(None, description="Data source identifier")
    
    # Processing timestamps
    inserted_at: datetime = Field(default_factory=datetime.now, description="Insertion timestamp")
    updated_at: datetime = Field(default_factory=datetime.now, description="Last update timestamp")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation timestamp")
    processed_at: datetime = Field(default_factory=datetime.now, description="Processing timestamp")
    timestamp: datetime = Field(default_factory=datetime.now, description="Time series indexing timestamp")
    updated_flag: UpdatedFlag = Field(default=UpdatedFlag.UPDATED, description="Flag indicating if data was updated")


class SupplyServeHistoricalEntity(BaseModel):
    """
    Supply Serve Historical Entity - Archived time series data
    
    This entity represents the historical supply data that has been archived
    from the active supply_serve collection. It preserves the original _id
    for tracking purposes.
    """
    
    model_config = ConfigDict(
        validate_by_name=True,
        arbitrary_types_allowed=True,
        json_encoders={
            ObjectId: str,
            datetime: lambda v: v.isoformat()
        },
        json_schema_extra={
            "example": {
                "scheduled_at": "2025-01-15T10:00:00",
                "plant_name": "Thermal Plant A",
                "dc_sg": "DC",
                "volume": 500.0,
                "fc_price": 2.5,
                "px_price": 3.2,
                "vc_price": 1.8,
                "category": "Thermal",
                "technology": "Coal",
                "price_group": "A",
                "c_s": "Central",
                "archived_at": "2025-01-19T10:00:00"
            }
        }
    )
    
    # MongoDB ID (preserved from original)
    id: Optional[Any] = Field(default_factory=ObjectId, alias="_id")
    # All fields from SupplyServeEntity
    scheduled_at: datetime = Field(..., description="Schedule date and time")
    time_block: Optional[int] = Field(None, description="Time block identifier")
    
    # Plant and supply information
    plant_id: Optional[str] = Field(None, description="Plant ID")
    dc_sg: Optional[str] = Field(None, description="DC/SG type (DC/SG)")
    volume: Optional[float] = Field(None, description="Supply volume")
    
    # Price information
    fc_price: Optional[float] = Field(None, description="FC (Fixed Cost) price")
    px_price: Optional[float] = Field(None, description="PX (Power Exchange) price")
    vc_price: Optional[float] = Field(None, description="VC (Variable Cost) price")
    
    # Categorization fields
    price_group: Optional[str] = Field(None, description="Price group identifier")
    
    # Additional fields
    tm: float = Field(default=0.0, description="TM value")
    multiplier: str = Field(default="", description="Multiplier value")
    ramping: str = Field(default="", description="Ramping information")
    
    # Original processing timestamps (preserved)
    inserted_at: datetime = Field(..., description="Original insertion timestamp")
    updated_at: datetime = Field(..., description="Original last update timestamp")
    created_at: datetime = Field(..., description="Original creation timestamp")
    processed_at: datetime = Field(..., description="Original processing timestamp")
    timestamp: datetime = Field(..., description="Original time series indexing timestamp")
    updated_flag: UpdatedFlag = Field(..., description="Original updated flag")
    
    # Archive-specific timestamps
    archived_at: datetime = Field(default_factory=datetime.now, description="Archive timestamp")
    archived_timestamp: datetime = Field(default_factory=datetime.now, description="Archive timestamp for time series indexing")