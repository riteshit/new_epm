"""
Plant Entity Model
Represents power plant information
"""

from datetime import datetime
from typing import Optional, Any, List, Dict
from pydantic import BaseModel, Field, ConfigDict, field_validator, model_validator
from bson import ObjectId


class PlantEntity(BaseModel):
    """Plant entity model"""
    
    id: Optional[Any] = Field(default_factory=ObjectId, alias="_id")
    # Plant information
    plant_name: str = Field(..., description="Name of the power plant")
    c_s: Optional[str] = Field(default=None, description="Central/State")
    category: Optional[str] = Field(default=None, description="Category")
    technology: Optional[str] = Field(default=None, description="Technology")
    price_group: Optional[str] = Field(default=None, description="Price group")
    ramping: Optional[float] = Field(default=None, description="Ramping")
    tm: Optional[float] = Field(default=None, description="TM")
    fc_price: Optional[float] = Field(default=None, description="FC price")
    px_price: Optional[float] = Field(default=None, description="PX price")
    vc_price: Optional[float] = Field(default=None, description="VC price")
    multiplier: Optional[float] = Field(default=None, description="Multiplier")
    volume: Optional[float] = Field(default=None, description="Volume")
    ppa: Optional[str] = Field(default=None, description="PPA")
    plant_id: Optional[str] = Field(default=None, description="Plant ID")

    # Processing timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation timestamp")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Last update timestamp")
    
    # Model configuration
    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        json_encoders={
            ObjectId: str,
            datetime: lambda v: v.isoformat()
        },
        json_schema_extra={
            "example": {
                "plant_name": "Sample Power Plant",
                "c_s": "Central",
                "category": "Thermal",
                "technology": "Coal",
                "price_group": "A",
                "ramping": 100.0,
                "tm": 50.0,
                "fc_price": 2.5,
                "px_price": 3.2,
                "vc_price": 1.8,
                "multiplier": 1.0,
                "volume": 500.0,
                "ppa": "PPA123",
                "plant_id": "SPP",
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z"
            }
        }
    )