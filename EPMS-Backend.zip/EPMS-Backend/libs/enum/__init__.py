"""
Enum definitions for EPMS
"""

from .raw_data_status import RawDataStatus
from .updated_flag import UpdatedFlag

__all__ = ['RawDataStatus', 'UpdatedFlag']
