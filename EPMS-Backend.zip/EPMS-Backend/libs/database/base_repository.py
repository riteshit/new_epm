"""
Base repository with common database operations
"""

from typing import Optional, List, Dict, Any, Callable
from datetime import datetime
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database
from bson import ObjectId
import logging
from pymongo import ReturnDocument

logger = logging.getLogger(__name__)


class BaseRepository:
    """Base repository with common CRUD operations"""
    
    def __init__(self, collection_name: str, mongodb_uri: str, database_name: str):
        """
        Initialize the repository with MongoDB connection
        
        Args:
            collection_name: Name of the collection
            mongodb_uri: MongoDB connection URI
            database_name: Database name
        """
        self.client: MongoClient = MongoClient(mongodb_uri)
        self.db_name = database_name
        self.db: Database = self.client[database_name]
        self.collection: Collection = self.db[collection_name]
        self.collection_name = collection_name
    
    def _create_collection_if_not_exists(self):
        """Create collection if it does not exist"""
        if self.collection_name not in self.db.list_collection_names():
            self.db.create_collection(self.collection_name)
            logger.info(f"Created collection: {self.collection_name}")
        

    def create(self, data: Dict[str, Any], add_timestamps: bool = True) -> str:
        """Create a new document"""
        try:
            if add_timestamps:
                data["created_at"] = datetime.utcnow()
                data["updated_at"] = datetime.utcnow()
            result = self.collection.insert_one(data)
            logger.info(f"Created document in {self.collection_name} with ID: {result.inserted_id}")
            return str(result.inserted_id)
        except Exception as e:
            logger.error(f"Error creating document in {self.collection_name}: {e}")
            raise
    
    def find_by_id(self, id: str) -> Optional[Dict[str, Any]]:
        """Find document by ID"""
        try:
            if not ObjectId.is_valid(id):
                return None
            doc = self.collection.find_one({"_id": ObjectId(id)})
            return doc
        except Exception as e:
            logger.error(f"Error finding document by ID in {self.collection_name}: {e}")
            return None
    
    def find_one(self, filter: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Find one document by filter"""
        try:
            doc = self.collection.find_one(filter)
            return doc
        except Exception as e:
            logger.error(f"Error finding document in {self.collection_name}: {e}")
            return None
    
    def find_many(self, filter: Dict[str, Any], limit: int = 100) -> List[Dict[str, Any]]:
        """Find multiple documents by filter"""
        try:
            cursor = self.collection.find(filter).limit(limit)
            return list(cursor)
        except Exception as e:
            logger.error(f"Error finding documents in {self.collection_name}: {e}")
            return []
    
    def update(self, id: str, data: Dict[str, Any], add_timestamps: bool = True) -> Optional[Dict[str, Any]]:
        """Update document by ID and return the updated document"""
        try:
            if not ObjectId.is_valid(id):
                return None
            if add_timestamps:
                data["updated_at"] = datetime.utcnow()
            
            # Use findOneAndUpdate to get the updated document
            result = self.collection.find_one_and_update(
                {"_id": ObjectId(id)},
                {"$set": data},
                return_document=ReturnDocument.AFTER
            )
            
            if result:
                logger.info(f"Updated document in {self.collection_name} with ID: {id}")
            return result
        except Exception as e:
            logger.error(f"Error updating document in {self.collection_name}: {e}")
            return None
    
    def delete(self, id: str) -> bool:
        """Delete document by ID"""
        try:
            if not ObjectId.is_valid(id):
                return False
            result = self.collection.delete_one({"_id": ObjectId(id)})
            success = result.deleted_count > 0
            if success:
                logger.info(f"Deleted document in {self.collection_name} with ID: {id}")
            return success
        except Exception as e:
            logger.error(f"Error deleting document in {self.collection_name}: {e}")
            return False
    
    def soft_delete(self, id: str) -> bool:
        """Soft delete document by setting is_deleted flag"""
        try:
            if not ObjectId.is_valid(id):
                return False
            result = self.collection.update_one(
                {"_id": ObjectId(id)},
                {
                    "$set": {
                        "is_deleted": True,
                        "deleted_at": datetime.utcnow(),
                        "updated_at": datetime.utcnow()
                    }
                }
            )
            success = result.modified_count > 0
            if success:
                logger.info(f"Soft deleted document in {self.collection_name} with ID: {id}")
            return success
        except Exception as e:
            logger.error(f"Error soft deleting document in {self.collection_name}: {e}")
            return False
    
    def exists(self, filter: Dict[str, Any]) -> bool:
        """Check if document exists"""
        try:
            count = self.collection.count_documents(filter, limit=1)
            return count > 0
        except Exception as e:
            logger.error(f"Error checking document existence in {self.collection_name}: {e}")
            return False
    
    def count(self, filter: Dict[str, Any]) -> int:
        """Count documents by filter"""
        try:
            return self.collection.count_documents(filter)
        except Exception as e:
            logger.error(f"Error counting documents in {self.collection_name}: {e}")
            return 0
    
    def find_with_pagination(self, filter: Dict[str, Any], skip: int = 0, limit: int = 100) -> List[Dict[str, Any]]:
        """Find documents with pagination"""
        try:
            cursor = self.collection.find(filter).skip(skip).limit(limit)
            return list(cursor)
        except Exception as e:
            logger.error(f"Error finding documents with pagination in {self.collection_name}: {e}")
            return []
    
    def aggregate(self, pipeline: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Execute aggregation pipeline"""
        try:
            cursor = self.collection.aggregate(pipeline)
            return list(cursor)
        except Exception as e:
            logger.error(f"Error executing aggregation in {self.collection_name}: {e}")
            return []
    
    def create_index(self, index_spec: List[tuple], unique: bool = False) -> bool:
        """Create index on collection"""
        try:
            self.collection.create_index(index_spec, unique=unique)
            logger.info(f"Created index on {self.collection_name}: {index_spec}")
            return True
        except Exception as e:
            logger.error(f"Error creating index on {self.collection_name}: {e}")
            return False
    
    def bulk_upsert(self, documents: List[Dict[str, Any]], filter_criteria: Callable[[Dict[str, Any]], Dict[str, Any]], add_timestamps: bool = True) -> Dict[str, int]:
        """
        Bulk upsert documents based on custom filter criteria
        
        Args:
            documents: List of documents to upsert
            filter_criteria: Function that takes a document and returns the filter query for finding existing documents
            add_timestamps: Whether to add created_at and updated_at timestamps
            
        Returns:
            Dictionary with counts of inserted and updated documents
        """
        try:
            inserted_count = 0
            updated_count = 0
            
            for doc in documents:
                if add_timestamps:
                    current_time = datetime.utcnow()
                    doc["updated_at"] = current_time
                
                # Use custom filter criteria to check if document exists
                filter_query = filter_criteria(doc)
                existing_doc = self.collection.find_one(filter_query)
                
                if existing_doc:
                    # Update existing document
                    if add_timestamps:
                        doc["updated_at"] = current_time
                    result = self.collection.update_one(
                        filter_query,
                        {"$set": doc}
                    )
                    if result.modified_count > 0:
                        updated_count += 1
                else:
                    # Insert new document
                    if add_timestamps:
                        doc["created_at"] = current_time
                        doc["updated_at"] = current_time
                    self.collection.insert_one(doc)
                    inserted_count += 1
            
            logger.info(f"Bulk upsert completed in {self.collection_name}: {inserted_count} inserted, {updated_count} updated")
            return {
                "inserted": inserted_count,
                "updated": updated_count,
                "total": inserted_count + updated_count
            }
        except Exception as e:
            logger.error(f"Error in bulk upsert for {self.collection_name}: {e}")
            raise
    
    def close(self):
        """Close database connection"""
        try:
            self.client.close()
            logger.info(f"Closed connection for {self.collection_name}")
        except Exception as e:
            logger.error(f"Error closing connection for {self.collection_name}: {e}") 