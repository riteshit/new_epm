# Enhanced Audit Logging System

A comprehensive, enterprise-grade audit logging system with TTL (Time To Live) support, structured data models, and priority-based retention policies.

## 🏗️ Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Application   │───▶│  Audit Queue     │───▶│   MongoDB       │
│    Services     │    │   Manager        │    │   audit_logs    │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                              │
                              ▼
                       ┌──────────────────┐
                       │  TTL Indexes     │
                       │  (Auto Expiry)   │
                       └──────────────────┘
```

## 📁 File Structure

```
libs/audit_queue/
├── models.py              # Basic queue models and LogPriority enum
├── audit_models.py        # Enhanced structured audit models
├── audit_repository.py    # MongoDB repository for audit logs
├── queue_manager.py       # Queue management with TTL support
├── unified_queue_service.py # Unified service interface
├── config.py              # Configuration settings
└── README.md              # This documentation
```

## 🚀 Quick Start

### Basic Usage

```python
from audit_queue.unified_queue_service import create_and_log_audit

# Simple audit log
job_id = create_and_log_audit(
    service="auth",
    log_type="api", 
    message="User login successful",
    priority="High",
    status="success"
)
```

### Structured Logging

```python
from audit_queue.audit_models import create_audit_log, Actor, Trace
from audit_queue.unified_queue_service import log_structured_audit

# Create structured audit log
actor = Actor(
    id="user123",
    name="John Doe", 
    email="john@example.com",
    ip_address="192.168.1.100"
)

trace = Trace(
    traceId="trace_abc123",
    jobId="job_456",
    requestId="req_789"
)

audit_log = create_audit_log(
    service="trading",
    log_type="api",
    message="Trade order placed",
    priority="High",
    actor=actor,
    trace=trace,
    status="success",
    duration_ms=150,
    data={"order_id": "12345", "amount": 1000.0}
)

job_id = log_structured_audit(audit_log)
```

### Error Logging

```python
from audit_queue.unified_queue_service import create_and_log_error

job_id = create_and_log_error(
    service="processing",
    error_name="ValidationError",
    error_message="Invalid data format",
    error_code="VAL_001",
    priority="Medium",
    stack_trace="Traceback..."
)
```

## 🎯 Priority Levels & TTL

| Priority | TTL Expiry | Use Case |
|----------|------------|----------|
| **Critical** | No expiry | Security breaches, compliance events |
| **High** | 1 year | User actions, business transactions |
| **Medium** | 6 months | System operations, API calls |
| **Low** | 3 months | Debug info, analytics |

## 📊 Data Models

### Core Models

- **`AuditLogDoc`**: Main audit log document
- **`Meta`**: Service and context metadata
- **`Trace`**: Distributed tracing context
- **`Actor`**: User/system information
- **`ErrorInfo`**: Detailed error information
- **`Approval`**: Approval workflow data

### Business Context Models

- **`Bid`**: Trading bid information
- **`Trade`**: Trade execution details
- **`ApprovalSubject`**: What is being approved

## 🔍 Querying Audit Logs

```python
from audit_queue.unified_queue_service import (
    get_audit_logs_by_service,
    get_audit_logs_by_trace,
    search_audit_logs,
    get_audit_statistics
)

# Get logs by service
logs = get_audit_logs_by_service("auth", limit=100)

# Get logs by trace ID
trace_logs = get_audit_logs_by_trace("trace_abc123")

# Search logs
results = search_audit_logs("authentication failed")

# Get statistics
stats = get_audit_statistics(service="auth")
```

## 🗄️ MongoDB Collections

### `audit_logs` Collection

```javascript
{
  "_id": ObjectId("..."),
  "ts": ISODate("2025-01-20T10:30:00Z"),
  "meta": {
    "service": "auth",
    "type": "api",
    "priority": "High",
    "correlationId": "req_123"
  },
  "message": "User authentication successful",
  "status": "success",
  "durationMs": 150,
  "actor": {
    "id": "user123",
    "name": "John Doe",
    "email": "john@example.com",
    "ip_address": "192.168.1.100"
  },
  "trace": {
    "traceId": "trace_abc123",
    "jobId": "job_456"
  },
  "ttl_expiry_date": ISODate("2026-01-20T10:30:00Z"),
  "retention_policy": "standard",
  "created_at": ISODate("2025-01-20T10:30:00Z")
}
```

### `audit_queue_jobs` Collection

```javascript
{
  "_id": ObjectId("..."),
  "job_id": "uuid-123",
  "log_data": { /* audit log data */ },
  "source_service": "auth",
  "job_type": "audit",
  "priority": "high",
  "status": "completed",
  "created_at": ISODate("2025-01-20T10:30:00Z")
}
```

## 📈 Indexes

### Time-Series Indexes
- `ts: -1` (Primary time index)
- `meta.service: 1, ts: -1` (Service queries)
- `meta.type: 1, ts: -1` (Type queries)

### TTL Indexes
- `ttl_expiry_date: 1` with priority filters (Auto-deletion)
- Separate indexes for High/Medium/Low priorities

### Query Optimization
- `meta.priority: 1, ts: -1` (Priority queries)
- `trace.traceId: 1` (Trace queries)
- `actor.id: 1, ts: -1` (Actor queries)
- `message: "text"` (Full-text search)

## ⚙️ Configuration

```python
# config.py
MONGODB_URI = "mongodb://localhost:27017"
AUDIT_DB_NAME = "audit_db"
AUDIT_COLLECTION_NAME = "audit_logs"
QUEUE_COLLECTION_NAME = "audit_queue_jobs"
MAX_WORKERS = 1  # Sequential processing per service
```

## 🧪 Testing

```bash
# Run comprehensive tests
python test_structured_audit.py

# Run TTL-specific tests  
python test_ttl_logging.py
```

## 🔧 Integration Examples

### FastAPI Middleware

```python
from fastapi import FastAPI, Request
from audit_queue.unified_queue_service import create_and_log_audit

app = FastAPI()

@app.middleware("http")
async def audit_middleware(request: Request, call_next):
    start_time = time.time()
    
    response = await call_next(request)
    
    duration_ms = int((time.time() - start_time) * 1000)
    
    create_and_log_audit(
        service="api_gateway",
        log_type="api",
        message=f"{request.method} {request.url.path}",
        priority="Medium",
        status="success" if response.status_code < 400 else "failed",
        duration_ms=duration_ms,
        actor_kwargs={
            "id": request.headers.get("user-id", "anonymous"),
            "ip_address": request.client.host
        }
    )
    
    return response
```

### Error Handling

```python
from audit_queue.unified_queue_service import create_and_log_error

try:
    # Business logic
    process_trade_order(order_data)
except Exception as e:
    create_and_log_error(
        service="trading",
        error_name=type(e).__name__,
        error_message=str(e),
        priority="High",
        stack_trace=traceback.format_exc()
    )
    raise
```

### Job Monitoring

```python
from audit_queue.audit_models import Trace, create_audit_log
from audit_queue.unified_queue_service import log_structured_audit

def execute_job(job_id: str):
    trace = Trace(jobId=job_id, requestId=f"req_{job_id}")
    
    # Job start
    audit_log = create_audit_log(
        service="scheduler",
        log_type="job",
        message="Job execution started",
        priority="Medium",
        trace=trace,
        status="started"
    )
    log_structured_audit(audit_log)
    
    try:
        # Job execution
        result = perform_job_work()
        
        # Job success
        audit_log = create_audit_log(
            service="scheduler", 
            log_type="job",
            message="Job execution completed",
            priority="Medium",
            trace=trace,
            status="completed",
            duration_ms=5000
        )
        log_structured_audit(audit_log)
        
    except Exception as e:
        # Job failure
        audit_log = create_audit_log(
            service="scheduler",
            log_type="job", 
            message="Job execution failed",
            priority="High",
            trace=trace,
            status="failed"
        )
        log_structured_audit(audit_log)
        raise
```

## 🚨 Monitoring & Alerts

### Queue Health
```python
from audit_queue.unified_queue_service import get_queue_status

status = get_queue_status()
print(f"Queue size: {status['queue_size']}")
print(f"Active workers: {status['active_workers']}")
```

### Audit Statistics
```python
from audit_queue.unified_queue_service import get_audit_statistics

stats = get_audit_statistics(service="auth")
print(f"Total logs: {stats['total_logs']}")
print(f"Error rate: {stats['error_count'] / stats['total_logs'] * 100:.2f}%")
```

## 🔒 Security Considerations

1. **Sensitive Data**: Never log passwords, tokens, or PII in plain text
2. **Data Masking**: Use data masking for sensitive fields
3. **Access Control**: Implement proper RBAC for audit log access
4. **Encryption**: Enable MongoDB encryption at rest
5. **Retention**: Follow compliance requirements for log retention

## 📋 Best Practices

1. **Structured Logging**: Always use structured data models
2. **Appropriate Priority**: Choose correct priority levels
3. **Trace Context**: Include trace IDs for distributed systems
4. **Error Details**: Provide comprehensive error information
5. **Performance**: Use async logging to avoid blocking
6. **Validation**: Validate data before logging
7. **Monitoring**: Monitor queue health and processing rates

## 🆘 Troubleshooting

### Common Issues

1. **Queue Backlog**: Increase worker count or optimize processing
2. **TTL Not Working**: Check MongoDB TTL index creation
3. **Validation Errors**: Review data model requirements
4. **Performance Issues**: Check MongoDB indexes and queries

### Debug Commands

```bash
# Check queue status
python -c "from audit_queue.unified_queue_service import get_queue_status; print(get_queue_status())"

# View recent logs
python -c "from audit_queue.unified_queue_service import get_audit_logs_by_service; print(len(get_audit_logs_by_service('auth', limit=10)))"
```

## 🔄 Migration Guide

### From Basic Logging

```python
# Old way
logger.info("User login: %s", username)

# New way  
create_and_log_audit(
    service="auth",
    log_type="app",
    message=f"User login: {username}",
    priority="Medium",
    actor_kwargs={"id": user_id, "name": username}
)
```

### From Simple Audit

```python
# Old way
audit_data = {
    "event": "login",
    "user": user_id,
    "timestamp": datetime.now()
}

# New way
audit_log = create_audit_log(
    service="auth",
    log_type="audit", 
    message="User authentication",
    priority="High",
    actor=Actor(id=user_id, name=username),
    status="success"
)
```

---

**🎉 You now have a comprehensive, enterprise-grade audit logging system with TTL support, structured data models, and priority-based retention policies!**
