"""
Simplified Audit Logging Interface

A clean, secure, and industry-standard audit logging system that follows
clean architecture principles and protects PII data.

This module provides a unified interface for all audit logging needs with
built-in PII protection and standardized logging patterns.
"""

import logging
import re
from typing import Dict, Any, Optional, Union
from datetime import datetime
from enum import Enum
from dataclasses import dataclass

# Import timezone utilities
from .timezone_utils import now_ist, format_ist_timestamp

# Import the existing infrastructure
from libs.audit_queue.unified_queue_service import create_and_log_audit, create_and_log_error
from libs.audit_queue.audit_models import Actor, Trace

# Configure module logger
_logger = logging.getLogger(__name__)


class AuditLogLevel(str, Enum):
    """
    Audit log severity levels following industry standards.
    
    Attributes:
        LOW: Routine operations, user activities
        MEDIUM: System operations, business logic
        HIGH: Errors, failures, warnings
        CRITICAL: Security events, system failures
    """
    LOW = "Low"
    MEDIUM = "Medium" 
    HIGH = "High"
    CRITICAL = "Critical"


@dataclass(frozen=True)
class PIIPatterns:
    """
    PII detection patterns for data sanitization.
    
    These patterns help identify and mask sensitive information
    before logging to ensure compliance with privacy regulations.
    """
    EMAIL_PATTERN = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
    PHONE_PATTERN = re.compile(r'\b(?:\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b')
    SSN_PATTERN = re.compile(r'\b\d{3}-?\d{2}-?\d{4}\b')
    CREDIT_CARD_PATTERN = re.compile(r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b')
    IP_ADDRESS_PATTERN = re.compile(r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b')


class PIISanitizer:
    """
    Utility class for sanitizing PII data in log messages and data.
    
    This class implements industry-standard PII protection patterns
    to ensure sensitive data is not logged in plain text.
    """
    
    @staticmethod
    def sanitize_string(text: str, mask_char: str = "*") -> str:
        """
        Sanitize a string by masking PII patterns.
        
        Args:
            text: Input string to sanitize
            mask_char: Character to use for masking
            
        Returns:
            Sanitized string with PII masked
        """
        if not isinstance(text, str):
            return text
            
        # Mask email addresses
        text = PIIPatterns.EMAIL_PATTERN.sub(
            lambda m: f"{m.group().split('@')[0][:2]}{mask_char * 3}@{mask_char * 5}.com", 
            text
        )
        
        # Mask phone numbers
        text = PIIPatterns.PHONE_PATTERN.sub(f"{mask_char * 3}-{mask_char * 3}-{mask_char * 4}", text)
        
        # Mask SSN
        text = PIIPatterns.SSN_PATTERN.sub(f"{mask_char * 3}-{mask_char * 2}-{mask_char * 4}", text)
        
        # Mask credit cards
        text = PIIPatterns.CREDIT_CARD_PATTERN.sub(f"{mask_char * 4}-{mask_char * 4}-{mask_char * 4}-{mask_char * 4}", text)
        
        return text
    
    @staticmethod
    def sanitize_data(data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Sanitize dictionary data by masking PII in values.
        
        Args:
            data: Dictionary to sanitize
            
        Returns:
            Sanitized dictionary with PII masked
        """
        if not isinstance(data, dict):
            return data
            
        sanitized = {}
        pii_fields = {
            'email', 'email_address', 'user_email', 'contact_email',
            'phone', 'phone_number', 'mobile', 'telephone',
            'ssn', 'social_security_number', 'tax_id',
            'credit_card', 'card_number', 'cc_number',
            'password', 'passwd', 'secret', 'token', 'api_key'
        }
        
        for key, value in data.items():
            key_lower = key.lower()
            
            # Mask known PII fields
            if any(pii_field in key_lower for pii_field in pii_fields):
                sanitized[key] = "***MASKED***"
            elif isinstance(value, str):
                sanitized[key] = PIISanitizer.sanitize_string(value)
            elif isinstance(value, dict):
                sanitized[key] = PIISanitizer.sanitize_data(value)
            elif isinstance(value, list):
                sanitized[key] = [
                    PIISanitizer.sanitize_string(item) if isinstance(item, str)
                    else PIISanitizer.sanitize_data(item) if isinstance(item, dict)
                    else item
                    for item in value
                ]
            else:
                sanitized[key] = value
                
        return sanitized


class AuditLogger:
    """
    Enterprise-grade audit logger with PII protection and clean architecture.
    
    This class provides a simplified interface for audit logging while maintaining
    security, compliance, and industry best practices. All logged data is automatically
    sanitized to protect PII and sensitive information.
    
    Features:
        - Automatic PII sanitization
        - Structured logging with consistent schema
        - Correlation ID support for tracing
        - Industry-standard log levels
        - Clean architecture separation of concerns
    
    Usage:
        from libs.audit_queue.simple_logger import audit_logger
        
        # User actions (API calls, UI interactions)
        audit_logger.log_user_action(service, user_id, action, message, **data)
        
        # System operations (internal processes)
        audit_logger.log_system_operation(service, operation, message, **data)
        
        # Scheduled jobs (cron, background tasks)
        audit_logger.log_scheduled_job(service, job_id, status, message, **data)
        
        # Error events (exceptions, failures)
        audit_logger.log_error_event(service, error_name, error_message, **context)
        
        # Security events (auth, access control)
        audit_logger.log_security_event(service, event_type, message, **data)
    """
    
    def __init__(self, enable_pii_protection: bool = True):
        """
        Initialize the audit logger.
        
        Args:
            enable_pii_protection: Whether to enable automatic PII sanitization
        """
        self._pii_protection_enabled = enable_pii_protection
        self._sanitizer = PIISanitizer()
    
    def _sanitize_if_enabled(self, message: str, data: Dict[str, Any]) -> tuple[str, Dict[str, Any]]:
        """
        Sanitize message and data if PII protection is enabled.
        
        Args:
            message: Log message to sanitize
            data: Data dictionary to sanitize
            
        Returns:
            Tuple of (sanitized_message, sanitized_data)
        """
        if not self._pii_protection_enabled:
            return message, data
            
        sanitized_message = self._sanitizer.sanitize_string(message)
        sanitized_data = self._sanitizer.sanitize_data(data)
        
        return sanitized_message, sanitized_data
    
    def _create_base_metadata(self, **additional_data) -> Dict[str, Any]:
        """
        Create base metadata for all log entries.
        
        Args:
            **additional_data: Additional metadata to include
            
        Returns:
            Dictionary containing base metadata
        """
        base_metadata = {
            "timestamp": format_ist_timestamp(),
            "logger_version": "2.0.0",
            "pii_protected": self._pii_protection_enabled,
            "timezone": "IST",
            **additional_data
        }
        
        return base_metadata
    
    def log_user_action(
        self,
        service: str,
        user_id: str,
        action: str,
        message: str,
        session_id: Optional[str] = None,
        success: bool = True,
        level: AuditLogLevel = AuditLogLevel.MEDIUM,
        **additional_data
    ) -> str:
        """
        Log user-initiated actions such as API calls and UI interactions.
        
        This method captures user activities with automatic PII protection
        and structured data formatting for compliance and auditing.
        
        Args:
            service: Service name (e.g., "ingestion", "auth")
            user_id: User identifier (will be sanitized if PII protection enabled)
            action: Action performed (e.g., "provider_create", "file_upload")
            message: Human-readable description of the action
            session_id: User session identifier for correlation (optional)
            success: Whether the action completed successfully
            level: Log severity level
            **additional_data: Additional structured data (will be sanitized)
            
        Returns:
            str: Unique log entry identifier for correlation
            
        Example:
            audit_logger.log_user_action(
                service="ingestion",
                user_id="user123",
                action="provider_create", 
                message="User created new provider",
                session_id="session456",
                provider_name="Test Provider",
                provider_type="API"
            )
        """
        try:
            # Prepare data for sanitization
            log_data = self._create_base_metadata(
                action_type=action,
                user_id=user_id,
                session_id=session_id,
                **additional_data
            )
            
            # Sanitize message and data
            sanitized_message, sanitized_data = self._sanitize_if_enabled(message, log_data)
            
            # Create actor object (user_id will be sanitized in data)
            actor = Actor(id=user_id, type="user")
            
            # Create trace object for session correlation
            trace = None
            if session_id:
                trace = Trace(sessionId=session_id, userId=user_id)
            
            return create_and_log_audit(
                service=service,
                log_type="api",
                message=sanitized_message,
                priority=level.value,
                status="success" if success else "failed",
                actor=actor,
                trace=trace,
                data=sanitized_data
            )
            
        except Exception as e:
            _logger.error(f"Failed to log user action: {e}", exc_info=True)
            return ""
    
    def log_system_operation(
        self,
        service: str,
        operation: str,
        message: str,
        correlation_id: Optional[str] = None,
        success: bool = True,
        level: AuditLogLevel = AuditLogLevel.MEDIUM,
        **additional_data
    ) -> str:
        """
        Log internal system operations and processes.
        
        This method captures system-level activities such as data processing,
        validation, and internal business logic execution.
        
        Args:
            service: Service name where operation occurred
            operation: Operation type (e.g., "data_processing", "validation")
            message: Human-readable description of the operation
            correlation_id: Unique identifier for operation correlation (optional)
            success: Whether the operation completed successfully
            level: Log severity level
            **additional_data: Additional structured data (will be sanitized)
            
        Returns:
            str: Unique log entry identifier for correlation
            
        Example:
            audit_logger.log_system_operation(
                service="ingestion",
                operation="file_processing",
                message="Processing uploaded CSV file",
                correlation_id="job123",
                file_name="data.csv",
                records_processed=150,
                processing_duration_ms=2500
            )
        """
        try:
            # Prepare data for sanitization
            log_data = self._create_base_metadata(
                operation_type=operation,
                correlation_id=correlation_id,
                **additional_data
            )
            
            # Sanitize message and data
            sanitized_message, sanitized_data = self._sanitize_if_enabled(message, log_data)
            
            # Create trace object for correlation
            trace = None
            meta_kwargs = {}
            if correlation_id:
                trace = Trace(jobId=correlation_id, requestId=correlation_id)
                meta_kwargs["correlationId"] = correlation_id
            
            return create_and_log_audit(
                service=service,
                log_type="app",
                message=sanitized_message,
                priority=level.value,
                status="success" if success else "failed",
                trace=trace,
                meta_kwargs=meta_kwargs,
                data=sanitized_data
            )
            
        except Exception as e:
            _logger.error(f"Failed to log system operation: {e}", exc_info=True)
            return ""
    
    def log_scheduled_job(
        self,
        service: str,
        job_id: str,
        status: str,
        message: str,
        job_name: Optional[str] = None,
        duration_ms: Optional[int] = None,
        level: AuditLogLevel = AuditLogLevel.MEDIUM,
        **additional_data
    ) -> str:
        """
        Log scheduled job events such as cron jobs and background tasks.
        
        This method captures the lifecycle of scheduled jobs including
        start, completion, and failure events with performance metrics.
        
        Args:
            service: Service name where job executed
            job_id: Unique job execution identifier
            status: Job status (started, completed, failed, etc.)
            message: Human-readable description of job event
            job_name: Descriptive job name (optional)
            duration_ms: Job execution duration in milliseconds (optional)
            level: Log severity level
            **additional_data: Additional structured data (will be sanitized)
            
        Returns:
            str: Unique log entry identifier for correlation
            
        Example:
            audit_logger.log_scheduled_job(
                service="ingestion",
                job_id="upload_processor_20241221_160000",
                status="completed",
                message="Upload processing completed successfully",
                job_name="Upload Raw Data Processor",
                duration_ms=45000,
                processed_files=5,
                failed_files=0
            )
        """
        try:
            # Prepare data for sanitization
            # Remove job_type from additional_data to avoid conflict
            additional_data_clean = {k: v for k, v in additional_data.items() if k != 'job_type'}
            log_data = self._create_base_metadata(
                job_type="scheduled",
                job_id=job_id,
                job_name=job_name,
                job_status=status,
                execution_duration_ms=duration_ms,
                **additional_data_clean
            )
            
            # Sanitize message and data
            sanitized_message, sanitized_data = self._sanitize_if_enabled(message, log_data)
            
            # Create trace object for job correlation
            trace = Trace(jobId=job_id, requestId=job_id)
            
            return create_and_log_audit(
                service=service,
                log_type="job",
                message=sanitized_message,
                priority=level.value,
                status=status,
                trace=trace,
                durationMs=duration_ms,
                meta_kwargs={"correlationId": job_id},
                data=sanitized_data
            )
            
        except Exception as e:
            _logger.error(f"Failed to log scheduled job: {e}", exc_info=True)
            return ""
    
    def log_error_event(
        self,
        service: str,
        error_name: str,
        error_message: str,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        level: AuditLogLevel = AuditLogLevel.MEDIUM,
        **error_context
    ) -> str:
        """
        Log error events and exceptions with context preservation.
        
        This method captures application errors, exceptions, and failures
        with appropriate context for debugging and monitoring.
        
        Args:
            service: Service name where error occurred
            error_name: Error type or exception class name
            error_message: Detailed error description
            user_id: User identifier if error relates to user action (optional)
            session_id: Session identifier for user correlation (optional)
            correlation_id: Unique identifier for operation correlation (optional)
            level: Error severity level
            **error_context: Additional error context (will be sanitized)
            
        Returns:
            str: Unique log entry identifier for correlation
            
        Example:
            audit_logger.log_error_event(
                service="ingestion",
                error_name="ValidationError",
                error_message="Invalid CSV format detected in uploaded file",
                user_id="user123",
                session_id="session456",
                correlation_id="upload_job_789",
                file_name="data.csv",
                validation_rule="required_columns"
            )
        """
        try:
            # Prepare data for sanitization
            # Remove error_type from error_context to avoid conflict
            safe_error_context = {k: v for k, v in error_context.items() if k != 'error_type'}
            
            log_data = self._create_base_metadata(
                error_category="application_error",
                error_type=error_name,
                user_id=user_id,
                session_id=session_id,
                correlation_id=correlation_id,
                **safe_error_context
            )
            
            # Sanitize message and data (especially important for error messages)
            sanitized_message, sanitized_data = self._sanitize_if_enabled(error_message, log_data)
            
            # Create trace object for correlation
            trace_data = {}
            if correlation_id:
                trace_data["jobId"] = correlation_id
                trace_data["requestId"] = correlation_id
            if session_id:
                trace_data["sessionId"] = session_id
            if user_id:
                trace_data["userId"] = user_id
            
            trace = Trace(**trace_data) if trace_data else None
            
            return create_and_log_error(
                service=service,
                error_name=error_name,
                error_message=sanitized_message,
                priority=level.value,
                trace=trace,
                data=sanitized_data
            )
            
        except Exception as e:
            _logger.error(f"Failed to log error event: {e}", exc_info=True)
            return ""
    
    def log_security_event(
        self,
        service: str,
        event_type: str,
        message: str,
        user_id: Optional[str] = None,
        client_ip: Optional[str] = None,
        success: bool = True,
        level: AuditLogLevel = AuditLogLevel.MEDIUM,
        **additional_data
    ) -> str:
        """
        Log security-related events with enhanced protection and monitoring.
        
        This method captures critical security events such as authentication,
        authorization, and access control activities. IP addresses are
        automatically masked for privacy compliance.
        
        Args:
            service: Service name where security event occurred
            event_type: Security event type (login, logout, access_denied, etc.)
            message: Human-readable description of security event
            user_id: User identifier (optional, will be sanitized)
            client_ip: Client IP address (optional, will be masked)
            success: Whether the security event was successful
            level: Security event severity level
            **additional_data: Additional security context (will be sanitized)
            
        Returns:
            str: Unique log entry identifier for correlation
            
        Example:
            audit_logger.log_security_event(
                service="auth",
                event_type="login_attempt",
                message="User authentication successful",
                user_id="user123",
                client_ip="192.168.1.1",
                authentication_method="password",
                session_duration_minutes=60
            )
        """
        try:
            # Prepare data for sanitization (IP will be masked)
            log_data = self._create_base_metadata(
                event_category="security",
                event_type=event_type,
                user_id=user_id,
                client_ip=client_ip,
                **additional_data
            )
            
            # Sanitize message and data
            sanitized_message, sanitized_data = self._sanitize_if_enabled(message, log_data)
            
            # Create actor object (IP will be masked in sanitized_data)
            actor = None
            if user_id:
                # Use original IP for actor, sanitized version is in data
                actor = Actor(id=user_id, type="user", ip_address=client_ip)
            
            return create_and_log_audit(
                service=service,
                log_type="security",
                message=sanitized_message,
                priority=level.value,
                status="success" if success else "failed",
                actor=actor,
                data=sanitized_data
            )
            
        except Exception as e:
            _logger.error(f"Failed to log security event: {e}", exc_info=True)
            return ""


# Global instance with PII protection enabled by default
audit_logger = AuditLogger(enable_pii_protection=True)

# Alternative instance without PII protection for internal use
internal_audit_logger = AuditLogger(enable_pii_protection=False)


# Convenience functions for simplified usage
def log_user_action(
    service: str, 
    user_id: str, 
    action: str, 
    message: str, 
    **kwargs
) -> str:
    """
    Convenience function for logging user actions.
    
    Args:
        service: Service name
        user_id: User identifier
        action: Action performed
        message: Human-readable message
        **kwargs: Additional data
        
    Returns:
        str: Log entry identifier
    """
    return audit_logger.log_user_action(service, user_id, action, message, **kwargs)


def log_system_operation(
    service: str, 
    operation: str, 
    message: str, 
    **kwargs
) -> str:
    """
    Convenience function for logging system operations.
    
    Args:
        service: Service name
        operation: Operation type
        message: Human-readable message
        **kwargs: Additional data
        
    Returns:
        str: Log entry identifier
    """
    return audit_logger.log_system_operation(service, operation, message, **kwargs)


def log_scheduled_job(
    service: str, 
    job_id: str, 
    status: str, 
    message: str, 
    **kwargs
) -> str:
    """
    Convenience function for logging scheduled jobs.
    
    Args:
        service: Service name
        job_id: Job identifier
        status: Job status
        message: Human-readable message
        **kwargs: Additional data
        
    Returns:
        str: Log entry identifier
    """
    return audit_logger.log_scheduled_job(service, job_id, status, message, **kwargs)


def log_error_event(
    service: str, 
    error_name: str, 
    error_message: str, 
    **kwargs
) -> str:
    """
    Convenience function for logging error events.
    
    Args:
        service: Service name
        error_name: Error type
        error_message: Error description
        **kwargs: Additional context
        
    Returns:
        str: Log entry identifier
    """
    return audit_logger.log_error_event(service, error_name, error_message, **kwargs)


def log_security_event(
    service: str, 
    event_type: str, 
    message: str, 
    **kwargs
) -> str:
    """
    Convenience function for logging security events.
    
    Args:
        service: Service name
        event_type: Security event type
        message: Human-readable message
        **kwargs: Additional context
        
    Returns:
        str: Log entry identifier
    """
    return audit_logger.log_security_event(service, event_type, message, **kwargs)


# All legacy methods have been removed
# Use the new audit_logger methods:
# - audit_logger.log_user_action()
# - audit_logger.log_system_event() 
# - audit_logger.log_security_event()
# - audit_logger.log_error_event()