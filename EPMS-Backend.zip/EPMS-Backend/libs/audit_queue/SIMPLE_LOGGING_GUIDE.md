# 📝 Enterprise Audit Logging Guide

## 🎯 Secure, Clean, and Industry-Standard Logging

A unified audit logging interface with **automatic PII protection** and **clean architecture** principles:

```python
from libs.audit_queue.simple_logger import audit_logger

# 1. User Actions (API calls, UI interactions)
audit_logger.log_user_action(service, user_id, action, message, **data)

# 2. System Operations (internal processes)
audit_logger.log_system_operation(service, operation, message, **data)

# 3. Scheduled Jobs (cron, background tasks)
audit_logger.log_scheduled_job(service, job_id, status, message, **data)

# 4. Error Events (exceptions, failures)
audit_logger.log_error_event(service, error_name, error_message, **context)

# 5. Security Events (auth, access control)
audit_logger.log_security_event(service, event_type, message, **data)
```

## 🔒 Built-in PII Protection

All logged data is **automatically sanitized** to protect sensitive information:
- Email addresses → `us***@*****.com`
- Phone numbers → `***-***-****`
- Credit cards → `****-****-****-****`
- SSN → `***-**-****`
- Known PII fields → `***MASKED***`

## 📚 Usage Examples

### 1. 👤 User Actions (API Endpoints)

```python
# Provider management
audit_logger.log_user_action(
    service="ingestion",
    user_id="user123",
    action="provider_create",
    message="User created new provider",
    session_id="session456",
    provider_name="Test Provider",
    provider_code="TEST_PROV"
)

# File upload with PII protection
audit_logger.log_user_action(
    service="ingestion", 
    user_id="user123",
    action="file_upload",
    message="User uploaded CSV file",
    session_id="session456",
    file_name="customer_data.csv",  # Will be sanitized if contains PII
    file_size=2048,
    user_email="john.doe@company.com"  # Automatically masked
)

# Status check
audit_logger.log_user_action(
    service="ingestion",
    user_id="user123", 
    action="status_check",
    message="User checked system status",
    session_id="session456"
)
```

### 2. ⚙️ System Operations (Internal Processes)

```python
# Data processing with correlation
audit_logger.log_system_operation(
    service="ingestion",
    operation="file_processing",
    message="Processing uploaded CSV file",
    correlation_id="job123",
    file_name="data.csv",
    records_processed=150,
    processing_duration_ms=2500
)

# Validation with PII-safe logging
audit_logger.log_system_operation(
    service="ingestion",
    operation="data_validation", 
    message="Validating provider configuration",
    correlation_id="job123",
    provider_code="TEST_PROV",
    validation_rules_applied=["email_format", "phone_format"]
)
```

### 3. 🔄 Scheduled Jobs (Cron & Background Tasks)

```python
# Job start
audit_logger.log_scheduled_job(
    service="ingestion",
    job_id="upload_processor_20241221_160000",
    status="started",
    message="Upload processing job started",
    job_name="Upload Raw Data Processor"
)

# Job completion with metrics
audit_logger.log_scheduled_job(
    service="ingestion", 
    job_id="upload_processor_20241221_160000",
    status="completed",
    message="Upload processing completed successfully",
    job_name="Upload Raw Data Processor",
    duration_ms=45000,
    processed_files=5,
    failed_files=0,
    total_records=15000
)
```

### 4. ❌ Error Events (Exceptions & Failures)

```python
# User-related error with PII protection
audit_logger.log_error_event(
    service="ingestion",
    error_name="ValidationError",
    error_message="Invalid CSV format detected in user file",
    user_id="user123",
    session_id="session456",
    correlation_id="upload_job_789",
    file_name="customer_data.csv",
    validation_rule="email_format"
)

# System error with context
audit_logger.log_error_event(
    service="ingestion",
    error_name="DatabaseConnectionError", 
    error_message="Failed to establish database connection",
    correlation_id="job123",
    operation="data_storage",
    retry_count=3,
    connection_timeout_ms=5000
)
```

### 5. 🔒 Security Events (Auth & Access Control)

```python
# Successful login with IP masking
audit_logger.log_security_event(
    service="auth",
    event_type="login_success",
    message="User authentication successful",
    user_id="user123",
    client_ip="192.168.1.1",  # Will be masked in logs
    authentication_method="password",
    session_duration_minutes=60
)

# Access denied with security context
audit_logger.log_security_event(
    service="ingestion",
    event_type="access_denied",
    message="User access denied to sensitive resource",
    user_id="user123",
    client_ip="192.168.1.1",
    success=False,
    requested_resource="Provider Management",
    access_level_required="admin",
    user_access_level="user"
)
```

## 🎛️ Log Levels & Best Practices

Use appropriate log levels following industry standards:

```python
from libs.audit_queue.simple_logger import AuditLogLevel

# LOW: Routine user activities, status checks
audit_logger.log_user_action(..., level=AuditLogLevel.LOW)

# MEDIUM: System operations, scheduled jobs  
audit_logger.log_system_operation(..., level=AuditLogLevel.MEDIUM)

# HIGH: Errors, failures, warnings
audit_logger.log_error_event(..., level=AuditLogLevel.HIGH)

# CRITICAL: Security events, system failures
audit_logger.log_security_event(..., level=AuditLogLevel.CRITICAL)
```

## 🏗️ Clean Architecture Benefits

- **Separation of Concerns**: Logging logic separated from business logic
- **Dependency Inversion**: Interface-based design for testability
- **Single Responsibility**: Each method handles one type of audit event
- **PII Protection**: Built-in data sanitization layer

## 🚀 Convenience Functions

For simplified usage, use the convenience functions with automatic PII protection:

```python
from libs.audit_queue.simple_logger import (
    log_user_action, log_system_operation, log_scheduled_job, 
    log_error_event, log_security_event
)

# Quick logging with PII protection
log_user_action("ingestion", "user123", "provider_create", "User created provider")
log_system_operation("ingestion", "file_processing", "Processing file", correlation_id="job123")
log_scheduled_job("ingestion", "job123", "completed", "Job finished successfully")
log_error_event("ingestion", "ValidationError", "Invalid data format detected")
log_security_event("auth", "login_success", "User authenticated", user_id="user123")
```

## 🔧 Advanced Configuration

```python
from libs.audit_queue.simple_logger import AuditLogger

# Custom logger without PII protection (internal use only)
internal_logger = AuditLogger(enable_pii_protection=False)

# Custom logger with PII protection (default)
secure_logger = AuditLogger(enable_pii_protection=True)
```

## 📊 What Gets Logged Where

The system automatically routes logs to appropriate destinations:

| Log Type | Database | Files | Retention |
|----------|----------|-------|-----------|
| **User Actions** | ❌ No | ✅ Yes | 3 months |
| **System Operations** | ✅ Yes | ❌ No | 6 months |
| **Cron Jobs** | ✅ Yes | ✅ Yes | 6 months |
| **Errors** | ✅ Yes | ✅ Yes | 1 year |
| **Security Events** | ✅ Yes | ❌ No | Permanent |

## 🔍 Database Queries

Find logs easily with consistent structure:

```javascript
// Find all user actions
db.audit_logs.find({"record_type": "api", "data.action_type": "provider_create"})

// Find all cron jobs
db.audit_logs.find({"record_type": "job", "data.job_type": "cron"})

// Find all errors
db.audit_logs.find({"error": {"$exists": true}})

// Find logs by correlation ID
db.audit_logs.find({"meta.correlationId": "job123"})

// Find logs by user
db.audit_logs.find({"actor.id": "user123"})
```

## ✅ Migration from Legacy System

Upgrade to secure, PII-protected logging:

```python
# LEGACY - No PII protection
log_user_activity(
    service="ingestion",
    session_id=session_id,
    user_id=user_id, 
    activity="provider_list_view",
    message="User john.doe@company.com viewed provider list",
    status="success",
    data={"user_email": "john.doe@company.com"}
)

# NEW - Secure with PII protection
audit_logger.log_user_action(
    service="ingestion",
    user_id=user_id,
    action="provider_list_view", 
    message="User viewed provider list",  # PII automatically removed
    session_id=session_id,
    user_email="john.doe@company.com"  # Automatically masked as jo***@*****.com
)
```

## 🔍 PII Protection Examples

```python
# Input with PII
audit_logger.log_error_event(
    service="ingestion",
    error_name="ValidationError",
    error_message="Invalid email john.doe@company.com in file customer_data.csv",
    user_phone="555-123-4567",
    customer_ssn="123-45-6789"
)

# Logged output (sanitized)
# message: "Invalid email jo***@*****.com in file customer_data.csv"
# user_phone: "***-***-****"
# customer_ssn: "***MASKED***"
```

## 🎯 Summary

**Enterprise-grade audit logging with 5 secure methods:**
1. `audit_logger.log_user_action()` - User interactions with PII protection
2. `audit_logger.log_system_operation()` - Internal processes with correlation
3. `audit_logger.log_scheduled_job()` - Background tasks with metrics
4. `audit_logger.log_error_event()` - Errors & exceptions with context
5. `audit_logger.log_security_event()` - Security events with IP masking

**Features:**
- ✅ **Automatic PII Protection** - Emails, phones, SSNs masked
- ✅ **Clean Architecture** - Separation of concerns, testable
- ✅ **Industry Standards** - Proper naming, structured logging
- ✅ **Correlation Support** - Track related events across services
- ✅ **Security Compliant** - GDPR/CCPA ready with data sanitization

**Secure, compliant, and developer-friendly!** 🔒🚀