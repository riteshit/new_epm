"""
EPMS Core Libraries
Shared utilities and models for EPMS services
"""

# Declare this as a namespace package
__path__ = __import__('pkgutil').extend_path(__path__, __name__)

__version__ = "0.1.0"
__author__ = "EPMS Team"
__email__ = "dev@epms.com"