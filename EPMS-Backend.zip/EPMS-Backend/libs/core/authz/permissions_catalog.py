# libs/core/authz/permissions_catalog.py
"""
Permissions catalog management for RBAC system
"""

from typing import Set

# Standard permissions catalog
DEFAULT_PERMISSIONS_CATALOG = [
    # Admin permissions
    "admin:*",
    
    # User management
    "users:read",
    "users:write", 
    "users:create",
    "users:delete",
    
    # Role management
    "roles:read",
    "roles:write",
    "roles:create", 
    "roles:delete",
    
    # Menu management
    "menu:read",
    "menu:write",
    "menu:create",
    "menu:delete",
    
    # Dashboard
    "dashboard:read",
    "dashboard:write",
    
    # Authentication & MFA
    "auth:login",
    "auth:logout", 
    "mfa:setup",
    "mfa:disable",
    
    # System
    "system:health",
    "system:status",
]

async def ensure_permissions_catalog(db) -> bool:
    """
    Ensure permissions catalog exists in database
    """
    try:
        existing = await db.permissions_catalog.find_one({})
        if not existing:
            catalog_doc = {
                "permissions": DEFAULT_PERMISSIONS_CATALOG,
                "version": 1,
                "description": "Default RBAC permissions catalog"
            }
            await db.permissions_catalog.insert_one(catalog_doc)
            return True
        return True
    except Exception as e:  # noqa: BLE001
        print(f"Error ensuring permissions catalog: {e}")
        return False

def get_expanded_permissions() -> Set[str]:
    """
    Get all permissions when wildcard '*' is present
    """
    return set(DEFAULT_PERMISSIONS_CATALOG)
