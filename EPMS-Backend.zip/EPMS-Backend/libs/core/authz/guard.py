# libs/core/authz/guard.py
from __future__ import annotations
from typing import Any, Optional, Set
from fastapi import Depends, HTTPException, Request

# your shared deps module (the one you pasted)
from libs.core.dependencies import get_db, jwt_validator

from libs.core.authz.config import required_permissions_for
from libs.core.authz.principal import UserPrincipal, compute_effective_permissions
from libs.core.authz.context import request_context, RequestContext

# --- helpers ---------------------------------------------------------

async def _load_user_doc(db, user_id: str) -> Optional[dict]:
    return await db.users.find_one({"_id": user_id}) if user_id else None

def _bearer(request: Request) -> str:
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    return auth.split(" ", 1)[1]

# --- principal builder -----------------------------------------------

async def get_current_user(
    request: Request,
    ctx: RequestContext = Depends(request_context),
    db: Any = Depends(get_db),
) -> UserPrincipal:
    """
    Build principal using YOUR jwt_validator + Mongo roles.
    """
    token = _bearer(request)

    payload, err = jwt_validator.validate_token_with_details(token)
    if err or payload is None:
        raise HTTPException(status_code=401, detail=err or "Invalid or expired token")

    tenant_id = ctx.tenant_id  # Always "default" in single-tenant system

    user_doc = await _load_user_doc(db, payload.user_id)
    if not user_doc:
        raise HTTPException(status_code=401, detail="User not found")

    # Optional: enforce freshness via authz_version if needed
    user_authz_ver = int(user_doc.get("authz_version", 0))

    # Get effective permissions from database (roles + direct permissions)
    # This will handle the Auth Service flat structure correctly
    db_perms: Set[str] = await compute_effective_permissions(user_doc, tenant_id, db)
    
    # Token permissions from JWT (already validated)
    token_perms: Set[str] = set(payload.permissions or [])
    
    # Union of DB permissions and token permissions
    effective: Set[str] = db_perms | token_perms

    # Super-admin detection: check multiple sources
    is_super_admin = (
        bool(user_doc.get("is_super_admin", False)) or  # DB flag
        ("admin" in (payload.roles or [])) or           # Admin role in token
        ("*" in effective)                              # Wildcard permission
    )

    return UserPrincipal(
        user_id = payload.user_id,
        tenant_id = tenant_id,
        is_super_admin = is_super_admin,
        authz_version = user_authz_ver,
        effective_permissions = effective,
    )

# --- SINGLE global guard ---------------------------------------------

async def global_authz_guard(
    request: Request,
    user: UserPrincipal = Depends(get_current_user),
    db: Any = Depends(get_db),
):
    """
    Attach this once per router:
        app.include_router(router, dependencies=[Depends(global_authz_guard)])
    No per-endpoint annotations needed.
    """
    if user.is_super_admin:
        return

    route = request.scope.get("route")
    if not route:
        return

    path_templ = getattr(route, "path_format", request.url.path)
    method = request.method.upper()

    required = await required_permissions_for(db, method, path_templ)
    if not required:  # public
        return

    have = user.effective_permissions

    # /admin/* shortcut
    if "admin:*" in required and (("admin:*" in have) or ("*" in have)):
        return

    missing = [p for p in required if p not in have]
    if missing:
        raise HTTPException(status_code=403, detail=f"Missing permissions: {', '.join(missing)}")
