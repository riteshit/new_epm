# EPMS Core Libraries

Shared utilities and models for EPMS services.

## Installation

```bash
pip install epms-libs
```

## Development Installation

```bash
pip install -e .
```

## Usage

```python
from epms_libs.core import cron_manager
from epms_libs.models import provider_models
from epms_libs.services import provider_service
```

## Version History

- **0.1.0** - Initial release with core functionality

## Contributing

1. Make changes to the library
2. Update version in `__init__.py`
3. Run `python setup.py sdist bdist_wheel`
4. Publish with `twine upload dist/*`

## License

MIT License
