"""
Demand calculation helper functions for conditional field calculation.
"""

import logging
from datetime import datetime
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)


def get_fifteen_time_block_id(idx: int) -> str:
    """
    Get the 15-minute time block string for a given index.
    
    Args:
        idx: Index of the time block (0–96)
        
    Returns:
        Time string in "HH:MM" format
    """
    # Generate all 15-minute intervals
    time_blocks = [f"{h:02}:{m:02}" for h in range(24) for m in (0, 15, 30, 45)]
    time_blocks.append("24:00")  # Add final block

    return time_blocks[idx]


def get_deviation_charge(acp: float, frequency: float) -> float:
    """
    Calculate deviation charge based on frequency and ACP.
    
    Args:
        acp: Area clearing price
        frequency: System frequency
        
    Returns:
        Deviation charge amount
    """
    frequency_array = [
        51.50, 51.49, 51.48, 51.47, 51.46, 51.45, 51.44, 51.43, 51.42, 51.41, 51.40, 51.39,
        51.38, 51.37, 51.36, 51.35, 51.34, 51.33, 51.32, 51.31, 51.30, 51.29, 51.28, 51.27,
        51.26, 51.25, 51.24, 51.23, 51.22, 51.21, 51.20, 51.19, 51.18, 51.17, 51.16, 51.15,
    ]

    deviation_charges_array = [
        0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00,
    ]

    deviation_sum_array = [
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    ]

    deviation_divisible_array = [
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    ]

    # Core logic
    if frequency > 50.04:
        deviation_charge = 0.00
    elif frequency < 49.85:
        deviation_charge = 800
    else:
        try:
            idx = frequency_array.index(round(frequency, 2))  # match upto 2 decimals
            deviation_charge = (
                deviation_charges_array[idx] +
                (deviation_sum_array[idx] * acp) / deviation_divisible_array[idx]
            )
        except ValueError:
            deviation_charge = 0.00  # frequency not found

    return deviation_charge


def calculate_dsm_metrics(
    acp: float, 
    data_item: Dict[str, Any], 
    cursor_areapricertm: Optional[List[Dict]] = None,
    cursor_areapricedam: Optional[List[Dict]] = None,
    index: int = 0
) -> Dict[str, Any]:
    """
    Calculate DSM (Demand Side Management) metrics for a single data item.
    
    Args:
        acp: Area clearing price
        data_item: Single data item containing frequency, schedule, actual drawal, etc.
        cursor_areapricertm: RTM price data cursor (optional)
        cursor_areapricedam: DAM price data cursor (optional)
        index: Index of the current item in the data array
        
    Returns:
        Dict containing calculated DSM metrics
    """
    try:
        # Extract basic data
        time_blocks_id = data_item.get("time_block", 0)
        frequency = float(data_item.get("frequency", data_item.get("Raw_Frequency", 0)))
        schedule = float(data_item.get("schedule", data_item.get("Schedule", 0)))
        actual = float(data_item.get("actual", data_item.get("Drawal", 0)))
        drawal = float(data_item.get("drawal", data_item.get("Drawal", 0)))
        
        # Get time block information
        if time_blocks_id == 96:
            next_time_blocks = get_fifteen_time_block_id(0)
        else:
            next_time_blocks = get_fifteen_time_block_id(time_blocks_id + 1)
        
        start_time = get_fifteen_time_block_id(time_blocks_id)
        
        # Get RTM and DAM prices
        w1_rtm = 0.0
        w1_dam = 0.0
        
        if cursor_areapricertm and len(cursor_areapricertm) > index:
            w1_rtm = float(cursor_areapricertm[index].get("W1", 0) or 0)
        
        if cursor_areapricedam and len(cursor_areapricedam) > index:
            w1_dam = float(cursor_areapricedam[index].get("W1", 0) or 0)
        
        # Debug logging
        logger.debug(f"DSM Calculation Debug - Index: {index}, Frequency: {frequency}, Schedule: {schedule}, Actual: {actual}")
        logger.debug(f"DSM Calculation Debug - W1_RTM: {w1_rtm}, W1_DAM: {w1_dam}, ACP: {acp}")
        
        # Calculate DSM rate
        dsm_rate = max(w1_rtm, w1_dam) / 10
        
        # Calculate deviation charge
        deviation_charge_array = get_deviation_charge(acp, round(frequency, 2))
        
        # Calculate deviation
        odd_udd = actual - schedule
        
        if odd_udd > 0:
            difference_in_deviation_under_drawl = 0
            difference_in_deviation_over_drawl = abs(odd_udd)
        else:
            difference_in_deviation_under_drawl = abs(odd_udd)
            difference_in_deviation_over_drawl = 0
        
        # ----- UNDER DRAWL CALCULATIONS -----
        if 0 <= difference_in_deviation_under_drawl <= 200:
            lessthentwohundred = (0.9 * dsm_rate * difference_in_deviation_under_drawl) / 40000
        else:
            lessthentwohundred = (0.9 * dsm_rate * 200) / 40000

        if 200 <= difference_in_deviation_under_drawl <= 300:
            lessthenthreehundred = (0.5 * dsm_rate * (difference_in_deviation_under_drawl - 200)) / 40000
        elif difference_in_deviation_under_drawl > 300:
            lessthenthreehundred = (0.5 * dsm_rate * 100) / 40000
        else:
            lessthenthreehundred = 0

        # ----- OVER DRAWL CALCULATIONS -----
        if 0 <= difference_in_deviation_over_drawl <= 200:
            lessthanhundred = (1 * dsm_rate * difference_in_deviation_over_drawl) / 40000
        else:
            lessthanhundred = (1 * dsm_rate * 200) / 40000

        if 200 <= difference_in_deviation_over_drawl <= 300:
            lessthanonehundredtwenty = (1.2 * dsm_rate * (difference_in_deviation_over_drawl - 200)) / 40000
        elif difference_in_deviation_over_drawl > 300:
            lessthanonehundredtwenty = (1.2 * dsm_rate * 100) / 40000
        else:
            lessthanonehundredtwenty = 0

        if difference_in_deviation_over_drawl > 300:
            lessthanhundredfifty = (1.5 * dsm_rate * (difference_in_deviation_over_drawl - 300)) / 40000
        else:
            lessthanhundredfifty = 0

        # ----- FREQUENCY CONDITIONS -----
        logger.debug(f"DSM Frequency Check - Frequency: {frequency}, Range: 49.95-50.03, In Range: {49.95 <= frequency < 50.03}")
        
        if 49.95 <= frequency < 50.03:
            final_less_thanonehundred = lessthentwohundred
            final_less_thanonehundredtwent = lessthenthreehundred
            final_less_lessthanhundredfifty = lessthanhundredfifty
            final_less_hundred = lessthanhundred
            final_less_hundredtwenty = lessthanonehundredtwenty
        else:
            final_less_thanonehundred = 0
            final_less_thanonehundredtwent = 0
            final_less_lessthanhundredfifty = 0
            final_less_hundred = 0
            final_less_hundredtwenty = 0

        # Additional frequency-based calculations
        fourtyninpontninezeroandnightyfive = (1.2 * dsm_rate * difference_in_deviation_under_drawl) / 40000 if 49.90 < frequency < 49.95 else 0
        fourtyninpontninezero = (1.5 * dsm_rate * difference_in_deviation_under_drawl) / 40000 if frequency <= 49.90 else 0
        fiftypontzerothree = (0.5 * dsm_rate * difference_in_deviation_under_drawl) / 40000 if 50.03 <= frequency < 50.05 else 0
        fiftypontninezerothree = (0 * dsm_rate * difference_in_deviation_under_drawl) / 40000 if frequency >= 50.03 else 0

        fourtyninpontninezeroandnightyfive_1 = (1.2 * dsm_rate * difference_in_deviation_over_drawl) / 40000 if 49.90 < frequency < 49.95 else 0
        fourtyninpontninezero_2 = (2 * dsm_rate * difference_in_deviation_over_drawl) / 40000 if frequency <= 49.90 else 0
        fiftypontzerothree_3 = (0.75 * dsm_rate * difference_in_deviation_over_drawl) / 40000 if 50.03 <= frequency < 50.05 else 0
        fiftypontninezerothree_4 = (0 * dsm_rate * difference_in_deviation_over_drawl) / 40000 if frequency >= 50.03 else 0

        # ----- TOTAL DSM CALCULATIONS -----
        total_dsm_ud = -1 * (
            fiftypontninezerothree
            + fiftypontzerothree
            + fourtyninpontninezero
            + final_less_thanonehundred
            + final_less_thanonehundredtwent
            + fourtyninpontninezeroandnightyfive
        )

        total_dsm_od = (
            fiftypontninezerothree_4
            + fiftypontzerothree_3
            + fourtyninpontninezero_2
            + final_less_hundred
            + final_less_hundredtwenty
            + fourtyninpontninezeroandnightyfive_1
            + final_less_lessthanhundredfifty
        )

        net_dsm = total_dsm_ud + total_dsm_od

        # Debug logging for final values
        logger.debug(f"DSM Final Values - DSM Rate: {dsm_rate}, Net DSM: {net_dsm}, Total UD: {total_dsm_ud}, Total OD: {total_dsm_od}")

        # Return comprehensive DSM metrics
        return {
            "inserted_date": data_item.get("inserted_date"),
            "start_time": start_time,
            "time_block": time_blocks_id,
            "net_dsm_amount": round(net_dsm, 2),
            "dsm_rate": round(dsm_rate, 2),
            "total_dsm_ud": round(total_dsm_ud, 2),
            "total_dsm_od": round(total_dsm_od, 2),
            "deviation_charge": round(deviation_charge_array, 2),
            "frequency": round(frequency, 2),
            "actual_drawal": round(actual, 2),
            "schedule": round(schedule, 2),
            "deviation": round(odd_udd, 2),
            "under_drawal": round(difference_in_deviation_under_drawl, 2),
            "over_drawal": round(difference_in_deviation_over_drawl, 2)
        }
        
    except Exception as e:
        logger.error(f"Error calculating DSM metrics: {str(e)}")
        return {
            "inserted_date": data_item.get("inserted_date"),
            "start_time": data_item.get("start_time", ""),
            "time_block": data_item.get("time_block", 0),
            "net_dsm_amount": 0.0,
            "dsm_rate": 0.0,
            "error": str(e)
        }


def calculate_demand_metrics(actual: float, forecast: float, rostering: float) -> Dict[str, float]:
    """
    Calculate demand metrics including MPE, MAPE, comp_act_demand, and comp_udm.
    
    Args:
        actual: Actual demand value
        forecast: Forecast demand value  
        rostering: Rostering value
        
    Returns:
        Dict containing calculated metrics
    """
    try:
        # Calculate MPE: ((actual + rostering - forecast) / (actual + rostering)) * 100
        denominator = actual + rostering
        if denominator != 0:
            mpe = ((actual + rostering - forecast) / denominator) * 100
        else:
            mpe = 0.0
            
        # Calculate MAPE: absolute value of MPE
        mape = abs(mpe)
        
        # Calculate comp_act_demand: if actual is available then actual, otherwise forecast - rostering
        if actual and actual != 0:
            comp_act_demand = actual
        else:
            comp_act_demand = forecast - rostering
        
        # Calculate comp_udm: if actual is available then actual + rostering, otherwise forecast
        if actual and actual != 0:
            comp_udm = actual + rostering
        else:
            comp_udm = forecast
        
        return {
            "mpe": round(mpe, 2),
            "mape": round(mape, 2), 
            "comp_act_demand": round(comp_act_demand, 2),
            "comp_udm": round(comp_udm, 2)
        }
        
    except Exception as e:
        logger.error(f"Error calculating demand metrics: {str(e)}")
        # Apply same logic for fallback values
        fallback_comp_act_demand = actual if (actual and actual != 0) else (forecast - rostering)
        fallback_comp_udm = (actual + rostering) if (actual and actual != 0) else forecast
        
        return {
            "mpe": 0.0,
            "mape": 0.0,
            "comp_act_demand": fallback_comp_act_demand,
            "comp_udm": fallback_comp_udm
        }


def is_field_empty_or_zero(value: Any) -> bool:
    """
    Check if a field value is empty, zero, or null.
    
    Args:
        value: Field value to check
        
    Returns:
        bool: True if field is empty, zero, or null
    """
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip() == ""
    if isinstance(value, (int, float)):
        return value == 0
    return False


def process_demand_calculations_conditional(data_array: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Process demand data array and add calculated metrics only for fields that are empty, zero, or null.
    
    Args:
        data_array: List of demand data dictionaries
        
    Returns:
        List of demand data with calculated metrics added only where needed
    """
    processed_data = []
    
    for item in data_array:
        try:
            # Create a copy of the item to avoid modifying the original
            processed_item = item.copy()
            
            # Extract values for calculation
            actual = float(item.get("actual", 0))
            forecast = float(item.get("forecast", 0))
            rostering = float(item.get("rostering", 0))
            
            # Check which fields need calculation
            fields_to_calculate = []
            
            # Check if mape needs calculation
            if is_field_empty_or_zero(item.get("mape")):
                fields_to_calculate.append("mape")
            
            # Check if mpe needs calculation
            if is_field_empty_or_zero(item.get("mpe")):
                fields_to_calculate.append("mpe")
            
            # Check if comp_act_demand needs calculation
            if is_field_empty_or_zero(item.get("comp_act_demand")):
                fields_to_calculate.append("comp_act_demand")
            
            # Check if comp_udm needs calculation
            if is_field_empty_or_zero(item.get("comp_udm")):
                fields_to_calculate.append("comp_udm")
            
            # Only calculate if at least one field needs calculation
            if fields_to_calculate:
                logger.debug(f"Calculating fields for demand record: {fields_to_calculate}")
                metrics = calculate_demand_metrics(actual, forecast, rostering)
                
                # Add only the calculated fields that were missing
                for field in fields_to_calculate:
                    if field in metrics:
                        processed_item[field] = metrics[field]
                        logger.debug(f"Calculated {field}: {metrics[field]}")
            else:
                logger.debug("All calculated fields already present in raw data, skipping calculation")
            
            processed_data.append(processed_item)
            
        except Exception as e:
            logger.error(f"Error processing demand item: {str(e)}")
            # Add item with original data if calculation fails
            processed_data.append(item)
    
    return processed_data


def process_dsm_calculations_conditional(
    data_array: List[Dict[str, Any]], 
    acp: Optional[float] = None,
    cursor_areapricertm: Optional[List[Dict]] = None,
    cursor_areapricedam: Optional[List[Dict]] = None
) -> List[Dict[str, Any]]:
    """
    Process DSM calculations with optional exchange data parameters.
    
    Args:
        data_array: List of demand data dictionaries
        acp: Area clearing price (optional)
        cursor_areapricertm: RTM data cursor (optional)
        cursor_areapricedam: DAM data cursor (optional)
        
    Returns:
        List of demand data with calculated DSM metrics added only where needed
    """
    processed_data = []
    
    # Default ACP if not provided
    if acp is None:
        acp = 0.0
        logger.warning("ACP not provided, using default value of 0.0")
    
    logger.debug(f"Processing DSM calculations with acp={acp}, rtm_data={cursor_areapricertm is not None}, dam_data={cursor_areapricedam is not None}")
    
    for index, item in enumerate(data_array):
        try:
            # Create a copy of the item to avoid modifying the original
            processed_item = item.copy()
            
            # Check which DSM fields need calculation
            dsm_fields_to_calculate = []
            
            # Check if DSM fields need calculation
            if is_field_empty_or_zero(item.get("net_dsm_amount")):
                dsm_fields_to_calculate.append("net_dsm_amount")
            
            if is_field_empty_or_zero(item.get("dsm_rate")):
                dsm_fields_to_calculate.append("dsm_rate")
            
            if is_field_empty_or_zero(item.get("total_dsm_ud")):
                dsm_fields_to_calculate.append("total_dsm_ud")
            
            if is_field_empty_or_zero(item.get("total_dsm_od")):
                dsm_fields_to_calculate.append("total_dsm_od")
            
            if is_field_empty_or_zero(item.get("deviation_charge")):
                dsm_fields_to_calculate.append("deviation_charge")
            
            # Only calculate DSM fields if at least one needs calculation
            if dsm_fields_to_calculate:
                logger.debug(f"Calculating DSM fields for record {index}: {dsm_fields_to_calculate}")
                dsm_metrics = calculate_dsm_metrics(
                    acp=acp,
                    data_item=item,
                    cursor_areapricertm=cursor_areapricertm,
                    cursor_areapricedam=cursor_areapricedam,
                    index=index
                )
                
                # Add only the calculated DSM fields that were missing
                for field in dsm_fields_to_calculate:
                    if field in dsm_metrics:
                        processed_item[field] = dsm_metrics[field]
                        logger.debug(f"Calculated DSM {field}: {dsm_metrics[field]}")
                
                # Also add additional DSM fields if they were calculated
                additional_dsm_fields = [
                    "frequency", "actual_drawal", "schedule", "deviation", 
                    "under_drawal", "over_drawal", "start_time"
                ]
                for field in additional_dsm_fields:
                    if field in dsm_metrics and field not in processed_item:
                        processed_item[field] = dsm_metrics[field]
            else:
                logger.debug(f"All DSM fields already present in record {index}, skipping DSM calculation")
            
            # Also process regular demand calculations
            processed_item = process_single_demand_calculation(processed_item)
            
            processed_data.append(processed_item)
            
        except Exception as e:
            logger.error(f"Error processing DSM item {index}: {str(e)}")
            # Add item with original data if calculation fails
            processed_data.append(item)
    
    return processed_data


def process_single_demand_calculation(item: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process demand calculations for a single item.
    
    Args:
        item: Single demand data dictionary
        
    Returns:
        Dictionary with calculated demand metrics added only where needed
    """
    try:
        # Extract values for calculation
        actual = float(item.get("actual", 0))
        forecast = float(item.get("forecast", 0))
        rostering = float(item.get("rostering", 0))
        
        # Check which fields need calculation
        fields_to_calculate = []
        
        # Check if mape needs calculation
        if is_field_empty_or_zero(item.get("mape")):
            fields_to_calculate.append("mape")
        
        # Check if mpe needs calculation
        if is_field_empty_or_zero(item.get("mpe")):
            fields_to_calculate.append("mpe")
        
        # Check if comp_act_demand needs calculation
        if is_field_empty_or_zero(item.get("comp_act_demand")):
            fields_to_calculate.append("comp_act_demand")
        
        # Check if comp_udm needs calculation
        if is_field_empty_or_zero(item.get("comp_udm")):
            fields_to_calculate.append("comp_udm")
        
        # Only calculate if at least one field needs calculation
        if fields_to_calculate:
            logger.debug(f"Calculating demand fields: {fields_to_calculate}")
            metrics = calculate_demand_metrics(actual, forecast, rostering)
            
            # Add only the calculated fields that were missing
            for field in fields_to_calculate:
                if field in metrics:
                    item[field] = metrics[field]
                    logger.debug(f"Calculated {field}: {metrics[field]}")
        else:
            logger.debug("All demand calculated fields already present, skipping calculation")
        
        return item
        
    except Exception as e:
        logger.error(f"Error processing demand calculations: {str(e)}")
        return item


def get_calculation_summary(data_array: List[Dict[str, Any]]) -> Dict[str, int]:
    """
    Get summary of how many records need calculation for each field.
    
    Args:
        data_array: List of demand data dictionaries
        
    Returns:
        Dict with count of records needing calculation for each field
    """
    summary = {
        "total_records": len(data_array),
        "mape_calculated": 0,
        "mpe_calculated": 0,
        "comp_act_demand_calculated": 0,
        "comp_udm_calculated": 0,
        "no_calculation_needed": 0
    }
    
    for item in data_array:
        needs_calculation = False
        
        if is_field_empty_or_zero(item.get("mape")):
            summary["mape_calculated"] += 1
            needs_calculation = True
        
        if is_field_empty_or_zero(item.get("mpe")):
            summary["mpe_calculated"] += 1
            needs_calculation = True
        
        if is_field_empty_or_zero(item.get("comp_act_demand")):
            summary["comp_act_demand_calculated"] += 1
            needs_calculation = True
        
        if is_field_empty_or_zero(item.get("comp_udm")):
            summary["comp_udm_calculated"] += 1
            needs_calculation = True
        
        if not needs_calculation:
            summary["no_calculation_needed"] += 1
    
    return summary


def get_dsm_calculation_summary(data_array: List[Dict[str, Any]]) -> Dict[str, int]:
    """
    Get summary of how many records need DSM calculation for each field.
    
    Args:
        data_array: List of demand data dictionaries
        
    Returns:
        Dict with count of records needing DSM calculation for each field
    """
    summary = {
        "total_records": len(data_array),
        "net_dsm_amount_calculated": 0,
        "dsm_rate_calculated": 0,
        "total_dsm_ud_calculated": 0,
        "total_dsm_od_calculated": 0,
        "deviation_charge_calculated": 0,
        "no_dsm_calculation_needed": 0
    }
    
    for item in data_array:
        needs_dsm_calculation = False
        
        if is_field_empty_or_zero(item.get("net_dsm_amount")):
            summary["net_dsm_amount_calculated"] += 1
            needs_dsm_calculation = True
        
        if is_field_empty_or_zero(item.get("dsm_rate")):
            summary["dsm_rate_calculated"] += 1
            needs_dsm_calculation = True
        
        if is_field_empty_or_zero(item.get("total_dsm_ud")):
            summary["total_dsm_ud_calculated"] += 1
            needs_dsm_calculation = True
        
        if is_field_empty_or_zero(item.get("total_dsm_od")):
            summary["total_dsm_od_calculated"] += 1
            needs_dsm_calculation = True
        
        if is_field_empty_or_zero(item.get("deviation_charge")):
            summary["deviation_charge_calculated"] += 1
            needs_dsm_calculation = True
        
        if not needs_dsm_calculation:
            summary["no_dsm_calculation_needed"] += 1
    
    return summary


def get_combined_calculation_summary(data_array: List[Dict[str, Any]]) -> Dict[str, int]:
    """
    Get combined summary of both demand and DSM calculations.
    
    Args:
        data_array: List of demand data dictionaries
        
    Returns:
        Dict with count of records needing calculation for each field type
    """
    demand_summary = get_calculation_summary(data_array)
    dsm_summary = get_dsm_calculation_summary(data_array)
    
    # Combine summaries
    combined = {
        "total_records": demand_summary["total_records"],
        "demand_calculations": {
            "mape_calculated": demand_summary["mape_calculated"],
            "mpe_calculated": demand_summary["mpe_calculated"],
            "comp_act_demand_calculated": demand_summary["comp_act_demand_calculated"],
            "comp_udm_calculated": demand_summary["comp_udm_calculated"],
            "no_demand_calculation_needed": demand_summary["no_calculation_needed"]
        },
        "dsm_calculations": {
            "net_dsm_amount_calculated": dsm_summary["net_dsm_amount_calculated"],
            "dsm_rate_calculated": dsm_summary["dsm_rate_calculated"],
            "total_dsm_ud_calculated": dsm_summary["total_dsm_ud_calculated"],
            "total_dsm_od_calculated": dsm_summary["total_dsm_od_calculated"],
            "deviation_charge_calculated": dsm_summary["deviation_charge_calculated"],
            "no_dsm_calculation_needed": dsm_summary["no_dsm_calculation_needed"]
        }
    }
    
    return combined


def example_dsm_usage():
    """
    Example function demonstrating how to use the DSM calculation functions.
    This is for documentation and testing purposes.
    """
    # Sample data array
    sample_data = [
        {
            "time_block": 1,
            "inserted_date": "2024-01-01",
            "Raw_Frequency": 49.95,
            "Schedule": 1000.0,
            "Drawal": 1050.0,
            "actual": 1000.0,
            "forecast": 1100.0,
            "rostering": 50.0
        },
        {
            "time_block": 2,
            "inserted_date": "2024-01-01", 
            "Raw_Frequency": 50.02,
            "Schedule": 1200.0,
            "Drawal": 1150.0,
            "actual": 1200.0,
            "forecast": 1250.0,
            "rostering": 30.0
        }
    ]
    
    # Sample RTM and DAM price data
    rtm_data = [
        {"W1": 5000.0},
        {"W1": 5200.0}
    ]
    
    dam_data = [
        {"W1": 4800.0},
        {"W1": 5100.0}
    ]
    
    # ACP value
    acp = 100.0
    
    # Process DSM calculations
    result = process_dsm_calculations_conditional(
        data_array=sample_data,
        acp=acp,
        cursor_areapricertm=rtm_data,
        cursor_areapricedam=dam_data
    )
    
    # Get calculation summary
    summary = get_combined_calculation_summary(sample_data)
    
    return {
        "processed_data": result,
        "calculation_summary": summary
    }
