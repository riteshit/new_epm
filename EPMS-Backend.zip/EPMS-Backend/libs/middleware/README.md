# EPMS Middleware Suite

This package provides comprehensive middleware for EPMS services including authentication, correlation ID tracking, and request/response logging.

## Features

- **JWT Authentication**: Validates Bearer tokens and extracts user context
- **Correlation ID Tracking**: Automatically injects correlation IDs for request tracing
- **Request/Response Logging**: Comprehensive logging with correlation ID support
- **Real-time Console Output**: Live request monitoring with colored output
- **Auth Client Integration**: Communicates with auth service for token validation
- **Configurable**: Environment-based configuration
- **Reusable**: Can be applied to any FastAPI application

## Quick Start

### 1. Complete Setup with Logging (Recommended)

```python
from fastapi import FastAPI
from libs.middleware import (
    CorrelationMiddleware, 
    LoggingMiddleware, 
    configure_logging
)

# Configure logging first
configure_logging(
    level="INFO",
    format_type="text",  # or "json"
    include_correlation=True
)

app = FastAPI()

# Add middleware (order matters - last added = first executed)
app.add_middleware(LoggingMiddleware, 
    log_requests=True,
    log_responses=True,
    log_body=False  # Set True for debugging
)
app.add_middleware(CorrelationMiddleware)
```

### 2. Basic Usage (Legacy)

```python
from fastapi import FastAPI
from libs.middleware import CorrelationMiddleware, AuthMiddleware
from libs.auth_client import get_auth_client

app = FastAPI()

# Add middleware (order matters - last added = first executed)
app.add_middleware(AuthMiddleware, auth_client=get_auth_client())
app.add_middleware(CorrelationMiddleware)
```

### 2. Using V2 Middleware (Recommended for new services)

```python
from fastapi import FastAPI
from libs.middleware import CorrelationMiddleware
from services.processing.app.v2.middleware.auth import V2AuthMiddleware

app = FastAPI()

# V2 middleware includes auth client integration
app.add_middleware(V2AuthMiddleware)
app.add_middleware(CorrelationMiddleware)
```

### 3. Using Dependencies in Endpoints

```python
from fastapi import APIRouter, Depends
from libs.middleware import get_current_user, get_correlation_id

router = APIRouter()

@router.get("/protected-endpoint")
async def protected_endpoint(
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    correlation_id = get_correlation_id()
    
    return {
        "message": "Success",
        "user_id": user_id,
        "correlation_id": correlation_id
    }
```

### 4. Using V2 Dependencies (Enhanced)

```python
from fastapi import APIRouter, Depends
from services.processing.app.v2.dependencies import get_user_context

router = APIRouter()

@router.get("/v2-endpoint")
async def v2_endpoint(
    user_context: dict = Depends(get_user_context)
):
    return {
        "message": "Success",
        "user": user_context["user"],
        "correlation_id": user_context["correlation_id"],
        "user_id": user_context["user_id"],
        "roles": user_context["roles"]
    }
```

## Configuration

Set these environment variables:

```bash
# JWT Settings
JWT_SECRET_KEY=your-secret-key-change-in-production
JWT_ALGORITHM=HS256

# Auth Service
AUTH_SERVICE_HOST=localhost
AUTH_SERVICE_PORT=8001
AUTH_SERVICE_TIMEOUT=30.0

# Middleware Settings
REQUIRE_AUTH=true
CORRELATION_HEADER_NAME=X-Correlation-ID
AUTH_EXCLUDED_PATHS=/health,/docs,/redoc,/openapi.json
```

## Request Flow

1. **Request arrives** → Correlation ID middleware injects/extracts correlation ID
2. **Auth middleware** → Validates JWT token and extracts user context
3. **Endpoint** → Accesses user context via dependencies
4. **Response** → Includes correlation ID in headers

## Headers

### Request Headers
```
Authorization: Bearer <jwt-token>
X-Correlation-ID: <optional-correlation-id>
```

### Response Headers
```
X-Correlation-ID: <correlation-id>
```

## Error Responses

### 401 Unauthorized
```json
{
    "detail": "Authorization header required"
}
```

### 401 Invalid Token
```json
{
    "detail": "Invalid or expired token"
}
```

## Logging

### Real-time Request Logging with Colors

All requests are logged with correlation IDs, user context, and color coding:

**Colored Format (Default in Development):**
```
2024-10-02 10:30:15,123 - processing_service - INFO - [abc123-def456] - → GET /api/v2/market/overview [user123] (192.168.1.1)
2024-10-02 10:30:15,456 - processing_service - INFO - [abc123-def456] - ✓ GET /api/v2/market/overview → 200 (0.333s) [user123]
```

**Text Format:**
```
2024-10-02 10:30:15,123 - processing_service - INFO - [abc123-def456] - → GET /api/v2/market/overview
2024-10-02 10:30:15,456 - processing_service - INFO - [abc123-def456] - ✓ GET /api/v2/market/overview → 200 (0.333s)
```

**JSON Format:**
```json
{"timestamp": "2024-10-02 10:30:15,123", "level": "INFO", "logger": "processing_service", "correlation_id": "abc123-def456", "message": "→ GET /api/v2/market/overview"}
{"timestamp": "2024-10-02 10:30:15,456", "level": "INFO", "logger": "processing_service", "correlation_id": "abc123-def456", "message": "✓ GET /api/v2/market/overview → 200 (0.333s)"}
```

### Log Symbols & Colors

**Symbols:**
- `→` Incoming request (cyan)
- `✓` Successful response (green)
- `⚠` Client error (yellow)
- `✗` Server error (red)
- `💥` Exception occurred (red)

**Color Coding:**
- 🟢 **Green**: GET methods, 2xx responses, success symbols
- 🔵 **Blue**: POST methods, INFO log levels
- 🟡 **Yellow**: PUT methods, 4xx responses, WARNING log levels
- 🔴 **Red**: DELETE methods, 5xx responses, ERROR log levels, exceptions
- 🟣 **Purple**: Correlation IDs, usernames
- 🟠 **Cyan**: Logger names, incoming request arrows
- ⚫ **Gray**: Processing times, client IPs (dimmed)

### Configuration

```python
# Configure logging with colors
configure_logging(
    level="INFO",           # DEBUG, INFO, WARNING, ERROR
    format_type="colored",  # "text", "json", or "colored"
    include_correlation=True,
    use_colors=True         # Auto-detects terminal support
)

# Configure logging middleware
app.add_middleware(LoggingMiddleware,
    log_requests=True,      # Log incoming requests
    log_responses=True,     # Log responses
    log_body=False,         # Log request/response bodies (debug only)
    exclude_paths=["/health", "/docs"],  # Skip logging for these paths
    max_body_size=1000      # Max body size to log
)
```

**Format Types:**
- `"colored"`: Colored output with symbols (best for development)
- `"text"`: Plain text format (good for production logs)
- `"json"`: Structured JSON format (best for log aggregation)

**Color Support:**
- Automatically detects terminal color support
- Works with Windows Terminal, VS Code, and most modern terminals
- Falls back to plain text if colors not supported
```