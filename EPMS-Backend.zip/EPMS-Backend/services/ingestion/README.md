# EPMS Ingestion Service

## Overview

The EPMS Ingestion Service is a microservice responsible for handling data ingestion, validation, and processing for the Energy Portfolio Management System (EPMS). It provides secure data ingestion capabilities with JWT authentication, supports multiple data formats, and includes comprehensive validation and monitoring features.

## Features

- **Multi-Format Data Ingestion**: Support for CSV, JSON, XML, Excel files
- **Real-time Data Processing**: Handle streaming data from various sources
- **Data Validation**: Comprehensive validation rules and quality checks
- **JWT Authentication**: Secure access control with role-based permissions
- **File Upload Support**: Handle large file uploads with progress tracking
- **Data Quality Monitoring**: Track ingestion metrics and quality scores
- **Async Processing**: Celery-based background task processing
- **API Integration**: RESTful API with comprehensive documentation
- **Audit Logging**: Complete audit trail for all ingestion activities

## Project Structure

```
ingestion/
├── app/
│   ├── api/
│   │   └── v1/
│   │       └── routes/
│   │           └── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   └── logger.py
│   └── main.py
├── requirements.txt
└── README.md
```

## Technology Stack

- **Framework**: FastAPI 0.109.2
- **ASGI Server**: Uvicorn 0.27.1
- **Database**: MongoDB (PyMongo 4.6.1)
- **File Processing**: Pandas 2.2.0, openpyxl 3.1.2, xlrd 2.0.1
- **File Upload**: python-multipart 0.0.9, aiofiles 23.2.1
- **File Type Detection**: python-magic 0.4.27
- **HTTP Client**: httpx 0.26.0, requests 2.31.0
- **Background Tasks**: Celery 5.3.4
- **Validation**: Pydantic 2.6.1
- **Configuration**: Pydantic Settings 2.1.0
- **Caching**: Redis 5.0.1

## Prerequisites

- Python 3.8+
- MongoDB
- Redis
- Celery (for background processing)
- Virtual environment (recommended)

## Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd EPMS-Backend/services/ingestion
```

### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Environment Configuration
Create a `.env` file in the ingestion service directory:

```env
# Service Configuration
SERVICE_NAME=ingestion-service
SERVICE_PORT=8002
SERVICE_HOST=0.0.0.0
DEBUG=true
LOG_LEVEL=INFO

# Database Configuration
MONGODB_URI=mongodb://localhost:27017
INGESTION_DB_NAME=ingestion_db
AUDIT_DB_NAME=audit_db

# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0

# JWT Configuration
JWT_SECRET_KEY=your-super-secret-jwt-key-change-in-production
JWT_ALGORITHM=HS256

# File Upload Configuration
MAX_FILE_SIZE=100MB
ALLOWED_FILE_TYPES=["csv","json","xml","xlsx","xls"]
UPLOAD_DIR=./uploads

# Celery Configuration
CELERY_BROKER_URL=redis://localhost:6379/1
CELERY_RESULT_BACKEND=redis://localhost:6379/2

# CORS Configuration
CORS_ORIGINS=["http://localhost:3000","http://localhost:8080"]
```

### 5. Start the Service
```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8002 --reload
```

### 6. Start Celery Worker (Optional)
```bash
celery -A app.celery_app worker --loglevel=info
```

## API Documentation

### Base URL
```
http://localhost:8002
```



### Interactive Documentation
- Swagger UI: `http://localhost:8002/docs`
- ReDoc: `http://localhost:8002/redoc`

## Data Ingestion Features

### Supported File Formats

| Format | Extension | Description |
|--------|-----------|-------------|
| CSV | .csv | Comma-separated values |
| JSON | .json | JavaScript Object Notation |
| XML | .xml | Extensible Markup Language |
| Excel | .xlsx, .xls | Microsoft Excel files |

### Data Validation Rules

The service supports various validation rules:

- **Range Check**: Validate numeric values within specified ranges
- **Format Check**: Validate data format and structure
- **Required Fields**: Ensure required fields are present
- **Data Type Validation**: Validate data types
- **Business Rules**: Custom business logic validation

### Authentication & Authorization

All endpoints require JWT authentication with the following roles:

- **admin**: Full access to all ingestion operations
- **operator**: Can ingest and validate data
- **user**: Can view ingestion status
- **viewer**: Read-only access to status information

## Configuration

### Service Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `SERVICE_PORT` | 8002 | Service port |
| `SERVICE_HOST` | 0.0.0.0 | Service host |
| `DEBUG` | true | Debug mode |
| `LOG_LEVEL` | INFO | Logging level |

### File Upload Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `MAX_FILE_SIZE` | 100MB | Maximum file size |
| `ALLOWED_FILE_TYPES` | ["csv","json","xml","xlsx","xls"] | Allowed file types |
| `UPLOAD_DIR` | ./uploads | Upload directory |

### Database Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `MONGODB_URI` | mongodb://localhost:27017 | MongoDB connection string |
| `INGESTION_DB_NAME` | ingestion_db | Ingestion database name |
| `AUDIT_DB_NAME` | audit_db | Audit database name |

### Celery Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `CELERY_BROKER_URL` | redis://localhost:6379/1 | Celery broker URL |
| `CELERY_RESULT_BACKEND` | redis://localhost:6379/2 | Celery result backend |

## Usage Examples

### Ingest Data via API
```bash
curl -X POST "http://localhost:8002/api/v1/ingest/data" \
  -H "Authorization: Bearer <your_jwt_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "timestamp": "2024-01-01T00:00:00Z",
      "value": 100.5,
      "unit": "MW",
      "location": "Plant-A"
    },
    "source": "manual",
    "priority": "normal"
  }'
```

### Upload File
```bash
curl -X POST "http://localhost:8002/api/v1/files/upload" \
  -H "Authorization: Bearer <your_jwt_token>" \
  -F "file=@data.csv" \
  -F "source=file_upload" \
  -F "priority=normal"
```

### Validate Data
```bash
curl -X POST "http://localhost:8002/api/v1/ingest/validate" \
  -H "Authorization: Bearer <your_jwt_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "timestamp": "2024-01-01T00:00:00Z",
      "value": 100.5,
      "unit": "MW"
    },
    "validation_rules": ["range_check", "format_check"]
  }'
```

## Development

### Running Tests
```bash
# Run all tests
python -m pytest tests/ingestion/

# Run with coverage
python -m pytest tests/ingestion/ --cov=app --cov-report=html
```

### Code Quality
```bash
# Linting
flake8 app/

# Type checking
mypy app/
```

### Database Setup
```bash
# Initialize database collections
python scripts/init_db.py
```

## Monitoring & Logging

### Health Checks
The service provides health check endpoints for monitoring:
- `GET /health` - Returns service status and version

### Logging
Logs are structured in JSON format and include:
- File upload events
- Data processing metrics
- Validation results
- Error tracking
- Performance metrics

### Metrics
Key metrics to monitor:
- File upload success/failure rates
- Data processing times
- Validation success rates
- API response times
- Queue processing metrics

## Performance Optimization

### File Processing
- Async file uploads
- Streaming file processing
- Background task processing
- Memory-efficient data handling

### Database Optimization
- Connection pooling
- Indexed queries
- Efficient data storage
- Audit trail optimization

### Caching Strategy
- Redis caching for frequently accessed data
- File metadata caching
- Validation rule caching

## Security Considerations

### File Upload Security
- File type validation
- File size limits
- Malware scanning (recommended)
- Secure file storage

### Data Validation
- Input sanitization
- SQL injection prevention
- XSS protection
- Data encryption for sensitive information

### Access Control
- JWT token validation
- Role-based permissions
- API rate limiting
- Audit logging

## Troubleshooting

### Common Issues

1. **File Upload Failures**
   - Check file size limits
   - Verify file type is allowed
   - Ensure upload directory exists
   - Check disk space

2. **Processing Errors**
   - Verify file format
   - Check data validation rules
   - Review error logs
   - Validate JWT tokens

3. **Celery Worker Issues**
   - Ensure Redis is running
   - Check Celery worker status
   - Verify broker configuration
   - Monitor queue processing

### Logs
Check application logs for detailed error information:
```bash
tail -f logs/ingestion-service.log
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## License

This project is part of the EPMS (Energy Portfolio Management System) and is proprietary software.

## Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the main EPMS documentation 