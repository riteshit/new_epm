"""
Controller package for ingestion service
"""

from .file_upload_controller import FileUploadController

__all__ = [
    "FileUploadController"
]
