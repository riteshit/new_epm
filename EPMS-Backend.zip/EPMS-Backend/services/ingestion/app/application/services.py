"""
Application Services for Ingestion Use Cases
Orchestrates business logic without infrastructure dependencies
"""

import uuid
import time
from datetime import datetime
from typing import Dict, Any, List, Optional

from ..domain.entities import (
    UploadEntity, ProviderEntity, FileUploadRequest, UploadResult
)
from ..interfaces.repositories import (
    IUploadTrackingRepository, IProviderRepository, IFileStorageRepository
)
from libs.enum.raw_data_status import RawDataStatus


class FileUploadApplicationService:
    """Application service for file upload use cases"""
    
    def __init__(
        self,
        upload_repository: IUploadTrackingRepository,
        provider_repository: IProviderRepository,
        file_storage: IFileStorageRepository
    ):
        self._upload_repository = upload_repository
        self._provider_repository = provider_repository
        self._file_storage = file_storage
    
    async def upload_file(self, upload_request: FileUploadRequest) -> UploadResult:
        """
        Execute file upload use case
        
        Args:
            upload_request: Domain object containing upload data
            
        Returns:
            UploadResult: Result of the upload operation
            
        Raises:
            ValueError: If validation fails
            RuntimeError: If upload processing fails
        """
        start_time = time.time()
        
        # 1. Validate upload request
        validation_errors = upload_request.validate()
        if validation_errors:
            raise ValueError(f"Upload validation failed: {', '.join(validation_errors)}")
        
        # 2. Validate provider exists and supports uploads
        provider = await self._provider_repository.get_provider_by_code_and_type(
            upload_request.provider_type,
            upload_request.data_type
        )
        
        if not provider:
            raise ValueError(
                f"Provider '{upload_request.provider_type}' not found for data type '{upload_request.data_type}'"
            )
        
        provider_entity = ProviderEntity(**provider)
        if not provider_entity.can_process_uploads():
            raise ValueError(
                f"Provider '{upload_request.provider_type}' does not support file uploads or is disabled"
            )
        
        # 3. Generate upload ID and create upload entity
        upload_id = str(uuid.uuid4())
        upload_entity = UploadEntity(
            upload_id=upload_id,
            file_name=upload_request.file_name,
            file_size=upload_request.file_size,
            data_type=upload_request.data_type,
            provider_type=upload_request.provider_type,
            status=RawDataStatus.PENDING,
            status_message="File uploaded successfully, processing queued",
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        # 4. Save file to storage
        try:
            file_path = await self._file_storage.save_file(
                upload_request.file_content,
                upload_request.file_name,
                upload_id
            )
        except Exception as e:
            raise RuntimeError(f"Failed to save file: {str(e)}") from e
        
        # 5. Create upload tracking record
        try:
            tracking_id = await self._upload_repository.create_upload_record(
                upload_id=upload_id,
                file_name=upload_request.file_name,
                file_size=upload_request.file_size,
                data_type=upload_request.data_type,
                provider_type=upload_request.provider_type,
                status=RawDataStatus.PENDING
            )
        except Exception as e:
            # Cleanup file if database operation fails
            await self._file_storage.delete_file(file_path)
            raise RuntimeError(f"Failed to create upload record: {str(e)}") from e
        
        # 6. Calculate processing time and return result
        processing_time = (time.time() - start_time) * 1000
        
        return UploadResult(
            upload_id=upload_id,
            tracking_id=tracking_id,
            file_name=upload_request.file_name,
            file_size=upload_request.file_size,
            status="pending",
            status_message="File uploaded successfully, processing queued",
            processing_time_ms=processing_time,
            upload_timestamp=upload_entity.created_at or datetime.utcnow(), 
            success=True
        )
    
    async def get_upload_status(self, upload_id: str) -> Dict[str, Any]:
        """
        Get upload status use case
        
        Args:
            upload_id: Upload identifier
            
        Returns:
            Dict containing upload status information
            
        Raises:
            ValueError: If upload not found
        """
        upload_data = await self._upload_repository.get_upload_by_id(upload_id)
        
        if not upload_data:
            raise ValueError(f"Upload with ID '{upload_id}' not found")
        
        # Convert datetime objects to ISO format strings for JSON serialization
        datetime_fields = ['created_at', 'updated_at', 'completed_at', 'failed_at']
        for field in datetime_fields:
            if field in upload_data and upload_data[field] is not None:
                if isinstance(upload_data[field], datetime):
                    upload_data[field] = upload_data[field].isoformat() + 'Z'
        
        return upload_data
    
    async def get_uploads_paginated(
        self,
        skip: int = 0,
        limit: int = 20,
        status_filter: Optional[str] = None,
        sort_by: str = "created_at",
        sort_order: int = -1
    ) -> Dict[str, Any]:
        """
        Get paginated uploads use case
        
        Args:
            skip: Number of records to skip
            limit: Maximum number of records to return
            status_filter: Optional status filter (pending, processing, completed, failed)
            sort_by: Field to sort by (default: created_at)
            sort_order: Sort order (1 for ascending, -1 for descending)
            
        Returns:
            Dict containing paginated uploads and metadata
        """
        result = await self._upload_repository.get_uploads_paginated(
            skip=skip,
            limit=limit,
            status_filter=status_filter,
            sort_by=sort_by,
            sort_order=sort_order
        )
        
        # Convert datetime objects to ISO format strings for JSON serialization
        for upload in result["uploads"]:
            datetime_fields = ['created_at', 'updated_at', 'completed_at', 'failed_at']
            for field in datetime_fields:
                if field in upload and upload[field] is not None:
                    if isinstance(upload[field], datetime):
                        upload[field] = upload[field].isoformat() + 'Z'
        
        return result

    async def get_csv_format(self, data_type: str, provider_code: str) -> Dict[str, Any]:
        """
        Get CSV format for specific data type and provider code use case
        
        Args:
            data_type: Type of data ('demand', 'supply', etc.)
            provider_code: Provider code
            
        Returns:
            Dict containing CSV format information
            
        Raises:
            ValueError: If provider not found or validation fails
        """
        # 1. Validate data type
        from libs.models.provider_models import DataType
        try:
            DataType(data_type.lower())
        except ValueError:
            valid_types = [dt.value for dt in DataType]
            raise ValueError(f"Invalid data type '{data_type}'. Valid types: {valid_types}")
        
        # 2. Get provider by code and data type
        provider_data = await self._provider_repository.get_provider_by_code_and_type(
            provider_code.upper(),
            data_type.lower()
        )
        
        if not provider_data:
            raise ValueError(f"No provider found with code '{provider_code}' for data type '{data_type}'")
        
        # 3. Check if provider is enabled
        if not provider_data.get('enabled', False):
            raise ValueError(f"Provider '{provider_code}' is disabled for data type '{data_type}'")
        
        # 4. Check if provider has schema defined
        if not provider_data.get('fields') or len(provider_data['fields']) == 0:
            raise ValueError(f"Provider '{provider_code}' does not have a defined schema for data type '{data_type}'")
        
        # 5. Build CSV format information
        fields = provider_data['fields']
        required_fields = []
        optional_fields = []
        field_specifications = []
        
        for field in fields:
            field_name = field.get('field_name', '')
            field_type = field.get('field_type', 'string')
            is_required = field.get('is_required', False)
            description = field.get('description', '')
            validation_rules = field.get('validation', [])
            
            if is_required:
                required_fields.append(field_name)
            else:
                optional_fields.append(field_name)
            
            # Convert validation rules to a more readable format
            formatted_rules = []
            for rule in validation_rules:
                formatted_rules.append({
                    "rule": rule.get('rule', ''),
                    "value": rule.get('value', ''),
                    "message": rule.get('message', '')
                })
            
            field_specifications.append({
                "field_name": field_name,
                "field_type": field_type,
                "is_required": is_required,
                "description": description,
                "example": self._get_field_example(field_name, field_type),
                "validation_rules": formatted_rules
            })
        
        # 6. Generate CSV template with headers only (no sample data)
        csv_template = self._generate_csv_template_headers_only(fields)
        
        # 7. Build response
        result = {
            "provider_info": {
                "provider_code": provider_data.get('code', ''),
                "provider_name": provider_data.get('name', ''),
                "data_type": provider_data.get('data_type', ''),
                "ingestion_type": provider_data.get('ingestion_type', ''),
                "enabled": provider_data.get('enabled', False),
                "description": provider_data.get('description', '')
            },
            "csv_format": {
                "headers": [field.get('field_name', '') for field in fields],
                "required_fields": required_fields,
                "optional_fields": optional_fields,
                "field_specifications": field_specifications
            },
            "csv_template": csv_template,
            "file_requirements": {
                "max_size_mb": 100,
                "encoding": "utf-8",
                "delimiter": ",",
                "has_header": True,
                "line_ending": "\\n"
            }
        }
        
        return result
    
    def _get_field_example(self, field_name: str, field_type: str) -> str:
        """Generate example value for a field based on its type"""
        examples = {
            "string": "example_value",
            "integer": "123",
            "float": "123.45",
            "datetime": "2024-01-15",
            "boolean": "true",
            "date": "2024-01-15",
            "time": "14:30:00"
        }
        
        # Special cases for common field names
        if "date" in field_name.lower():
            return "2024-01-15"
        elif "time" in field_name.lower():
            return "00:00-01:00" if "block" in field_name.lower() else "14:30:00"
        elif "demand" in field_name.lower() or "supply" in field_name.lower():
            return "1250.5"
        elif "price" in field_name.lower():
            return "45.67"
        elif "id" in field_name.lower():
            return "12345"
        
        return examples.get(field_type.lower(), "example_value")
    
    def _generate_sample_data(self, fields: list) -> list:
        """Generate sample data for CSV template"""
        sample_records = []
        
        # Generate 2 sample records
        for i in range(2):
            record = {}
            for field in fields:
                field_name = field.get('field_name', '')
                field_type = field.get('field_type', 'string')
                example_value = self._get_field_example(field_name, field_type)
                
                # Modify second record slightly
                if i == 1:
                    if field_type in ['integer', 'float']:
                        # Only try to convert to float if it's a numeric string
                        try:
                            numeric_value = float(example_value)
                            example_value = str(numeric_value + 100)
                        except (ValueError, TypeError):
                            # If conversion fails, just use the original value
                            pass
                    elif field_type == 'datetime':
                        example_value = "2024-01-16"
                    elif field_type == 'date':
                        example_value = "2024-01-16"
                    elif "time" in field_name.lower() and "block" in field_name.lower():
                        example_value = "01:00-02:00"
                
                record[field_name] = example_value
            
            sample_records.append(record)
        
        return sample_records
    
    def _generate_csv_template(self, fields: list, sample_data: list) -> str:
        """Generate CSV template with headers and sample data"""
        if not fields:
            return ""
        
        # Get field names
        headers = [field.get('field_name', '') for field in fields]
        
        # Create CSV content
        csv_lines = [','.join(headers)]
        
        for record in sample_data:
            csv_line = ','.join([str(record.get(header, '')) for header in headers])
            csv_lines.append(csv_line)
        
        return '\n'.join(csv_lines)
    
    def _generate_csv_template_headers_only(self, fields: list) -> str:
        """Generate CSV template with headers only (no sample data)"""
        if not fields:
            return ""
        
        # Get field names
        headers = [field.get('field_name', '') for field in fields]
        
        # Return only headers
        return ','.join(headers)


class ProviderManagementApplicationService:
    """Application service for provider management use cases"""
    
    def __init__(self, provider_repository: IProviderRepository):
        self._provider_repository = provider_repository
    
    async def create_provider(self, provider_data: Dict[str, Any]) -> str:
        """
        Create provider use case
        
        Args:
            provider_data: Provider information
            
        Returns:
            str: Created provider ID
            
        Raises:
            ValueError: If validation fails
        """
        # Create domain entity for validation
        provider_entity = ProviderEntity(
            provider_id=None,
            name=provider_data.get("name", ""),
            code=provider_data.get("code", ""),
            data_type=provider_data.get("data_type", ""),
            ingestion_type=provider_data.get("ingestion_type", ""),
            enabled=provider_data.get("enabled", True),
            description=provider_data.get("description", ""),
            schema=provider_data.get("schema"),
            created_at=datetime.utcnow()
        )
        
        # Validate entity
        validation_errors = provider_entity.validate()
        if validation_errors:
            raise ValueError(f"Provider validation failed: {', '.join(validation_errors)}")
        
        # Check if provider with same code and data type already exists
        existing_provider = await self._provider_repository.get_provider_by_code_and_type(
            provider_entity.code,
            provider_entity.data_type
        )
        
        if existing_provider:
            raise ValueError(
                f"Provider with code '{provider_entity.code}' and data type '{provider_entity.data_type}' already exists"
            )
        
        # Create provider
        return await self._provider_repository.create_provider(provider_entity.to_dict())
    
    async def update_provider(self, provider_id: str, update_data: Dict[str, Any]) -> bool:
        """
        Update provider use case
        
        Args:
            provider_id: Provider identifier
            update_data: Data to update
            
        Returns:
            bool: True if updated successfully
            
        Raises:
            ValueError: If provider not found or validation fails
        """
        # Add updated timestamp
        update_data["updated_at"] = datetime.utcnow()
        
        # Update provider
        success = await self._provider_repository.update_provider(provider_id, update_data)
        
        if not success:
            raise ValueError(f"Provider with ID '{provider_id}' not found")
        
        return success
    
    async def delete_provider(self, provider_id: str) -> bool:
        """
        Delete provider use case
        
        Args:
            provider_id: Provider identifier
            
        Returns:
            bool: True if deleted successfully
            
        Raises:
            ValueError: If provider not found
        """
        success = await self._provider_repository.delete_provider(provider_id)
        
        if not success:
            raise ValueError(f"Provider with ID '{provider_id}' not found")
        
        return success
    
    async def get_providers_list(
        self,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Get providers list use case
        
        Args:
            skip: Number of records to skip
            limit: Maximum number of records to return
            filters: Optional filters to apply
            
        Returns:
            Dict containing providers list and metadata
        """
        return await self._provider_repository.get_providers_list(skip, limit, filters)