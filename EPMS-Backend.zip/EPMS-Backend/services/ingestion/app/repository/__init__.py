"""
Repository package for ingestion service
"""

# All repositories have been moved to the unified system
# Use libs.services.raw_data_service.RawDataService instead

__all__ = []