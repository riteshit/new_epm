"""
Ingestion Service Core
""" 