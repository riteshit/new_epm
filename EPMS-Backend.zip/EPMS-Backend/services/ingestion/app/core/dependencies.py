"""
Dependency Injection Container
Manages dependencies and implements dependency inversion
"""

from functools import lru_cache
from typing import Dict, Any

from ..interfaces.repositories import (
    IUploadTrackingRepository, IProviderRepository, IFileStorageRepository
)
from ..repository.upload_tracking_repository_impl import UploadTrackingRepositoryImpl
from ..services.provider_service import ProviderManagementService
from ..services.file_storage_service import FileStorageService
from ..application.services import (
    FileUploadApplicationService, ProviderManagementApplicationService
)
from .config import settings


class DependencyContainer:
    """Container for managing dependencies"""
    
    def __init__(self):
        self._repositories: Dict[str, Any] = {}
        self._services: Dict[str, Any] = {}
    
    @lru_cache(maxsize=1)
    def get_upload_repository(self) -> IUploadTrackingRepository:
        """Get upload tracking repository instance"""
        if "upload_repository" not in self._repositories:
            self._repositories["upload_repository"] = UploadTrackingRepositoryImpl(
                mongodb_uri=settings.MONGODB_URI,
                database_name=settings.MONGODB_DATABASE
            )
        return self._repositories["upload_repository"]
    
    @lru_cache(maxsize=1)
    def get_provider_repository(self) -> IProviderRepository:
        """Get provider repository instance"""
        if "provider_repository" not in self._repositories:
            # For now, wrap the existing service as repository
            # TODO: Create proper ProviderRepositoryImpl
            self._repositories["provider_repository"] = ProviderRepositoryAdapter(
                ProviderManagementService()
            )
        return self._repositories["provider_repository"]
    
    @lru_cache(maxsize=1)
    def get_file_storage_repository(self) -> IFileStorageRepository:
        """Get file storage repository instance"""
        if "file_storage_repository" not in self._repositories:
            # Wrap existing service as repository
            self._repositories["file_storage_repository"] = FileStorageRepositoryAdapter(
                FileStorageService()
            )
        return self._repositories["file_storage_repository"]
    
    @lru_cache(maxsize=1)
    def get_file_upload_service(self) -> FileUploadApplicationService:
        """Get file upload application service"""
        if "file_upload_service" not in self._services:
            self._services["file_upload_service"] = FileUploadApplicationService(
                upload_repository=self.get_upload_repository(),
                provider_repository=self.get_provider_repository(),
                file_storage=self.get_file_storage_repository()
            )
        return self._services["file_upload_service"]
    
    @lru_cache(maxsize=1)
    def get_provider_management_service(self) -> ProviderManagementApplicationService:
        """Get provider management application service"""
        if "provider_management_service" not in self._services:
            self._services["provider_management_service"] = ProviderManagementApplicationService(
                provider_repository=self.get_provider_repository()
            )
        return self._services["provider_management_service"]


# Adapter classes to wrap existing services as repositories
class ProviderRepositoryAdapter(IProviderRepository):
    """Adapter to make existing provider service work as repository"""
    
    def __init__(self, provider_service: ProviderManagementService):
        self._service = provider_service
    
    async def get_provider_by_code_and_type(
        self,
        provider_code: str,
        data_type: str
    ) -> Dict[str, Any]:
        """Get provider by code and data type"""
        # Delegate to existing service method
        return await self._service.get_provider_by_code_and_type(provider_code, data_type)
    
    async def create_provider(self, provider_data: Dict[str, Any]) -> str:
        """Create a new provider"""
        return await self._service.create_provider(provider_data)
    
    async def update_provider(self, provider_id: str, update_data: Dict[str, Any]) -> bool:
        """Update provider"""
        return await self._service.update_provider(provider_id, update_data)
    
    async def delete_provider(self, provider_id: str) -> bool:
        """Delete provider"""
        return await self._service.delete_provider(provider_id)
    
    async def get_providers_list(
        self,
        skip: int = 0,
        limit: int = 100,
        filters: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Get paginated providers list"""
        return await self._service.get_providers_list(skip, limit, filters)


class FileStorageRepositoryAdapter(IFileStorageRepository):
    """Adapter to make existing file storage service work as repository"""
    
    def __init__(self, file_storage_service: FileStorageService):
        self._service = file_storage_service
    
    async def save_file(self, file_content: bytes, file_name: str, upload_id: str) -> str:
        """Save file and return file path"""
        return await self._service.save_file(file_content, file_name, upload_id)
    
    async def get_file_path(self, upload_id: str) -> str:
        """Get file path by upload ID"""
        return await self._service.get_file_path(upload_id)
    
    async def delete_file(self, file_path: str) -> bool:
        """Delete file"""
        return await self._service.delete_file(file_path)
    
    async def file_exists(self, file_path: str) -> bool:
        """Check if file exists"""
        return await self._service.file_exists(file_path)


# Global container instance
container = DependencyContainer()


# FastAPI dependency functions
def get_file_upload_service() -> FileUploadApplicationService:
    """FastAPI dependency for file upload service"""
    return container.get_file_upload_service()


def get_provider_management_service() -> ProviderManagementApplicationService:
    """FastAPI dependency for provider management service"""
    return container.get_provider_management_service()


def get_upload_repository() -> IUploadTrackingRepository:
    """FastAPI dependency for upload repository"""
    return container.get_upload_repository()