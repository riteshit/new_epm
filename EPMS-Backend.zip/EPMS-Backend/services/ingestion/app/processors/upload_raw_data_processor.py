"""
Upload Raw Data Processor
Handles asynchronous file processing tasks with job detail recording
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path
import csv
import io

from libs.audit_queue.simple_logger import audit_logger
from libs.models.provider_models import ProviderEntity
from libs.enum.raw_data_status import RawDataStatus

from services.ingestion.app.core.config import settings
from services.ingestion.app.repository.upload_tracking_repository import UploadTrackingRepository
from services.ingestion.app.services.file_storage_service import file_storage_service
from services.ingestion.app.processors.base_raw_data_processor import BaseRawDataProcessor
from services.ingestion.app.processors.plants_processor import PlantsProcessor
import logging


logger = logging.getLogger("upload_raw_data_processor")


class UploadRawDataProcessor(BaseRawDataProcessor):
    """
    Service for managing upload raw data processing tasks with job detail recording
    """

    def __init__(self):
        """Initialize upload raw data processor"""
        super().__init__()
        
        self.upload_tracking_repository = UploadTrackingRepository(
            mongodb_uri=settings.MONGODB_URI,
            database_name=settings.MONGODB_DATABASE
        )
        
        # Initialize plants processor for plants data type
        self.plants_processor = PlantsProcessor()

    async def process_uploaded_file(self, upload_id: str, data_type: str, provider_type: str) -> Dict[str, Any]:
        """
        Process uploaded file in background (wrapper for backward compatibility)
        """
        return await self.process_data(upload_id, data_type, provider_type)

    async def process_data(self, upload_id: str, data_type: str, provider_type: str) -> Dict[str, Any]:
        """
        Process uploaded file in background

        Args:
            upload_id: Upload identifier
            data_type: Type of data (demand or supply)
            provider_type: Provider type (e.g., test_data, scada_data)

        Returns:
            Dict[str, Any]: Processing result
        """
        try:
            logger.info("=== UPLOAD PROCESS START === upload_id: %s, type: %s, provider: %s",
                       upload_id, data_type, provider_type)

            # Get upload creation time from tracking record
            upload_record = await self.upload_tracking_repository.get_upload_by_id(upload_id)
            if not upload_record:
                raise ValueError(f"Upload record not found for upload_id: {upload_id}")

            upload_created_at = upload_record.get("created_at", datetime.now())
            logger.info("Using upload creation time: %s for upload_id: %s", upload_created_at, upload_id)

            # Update status to PROCESSING
            await self._update_upload_status(upload_id, RawDataStatus.PROCESSING, "Starting file processing")

            # Get file path
            file_path = file_storage_service.get_file_path(upload_id)
            if not file_path:
                raise FileNotFoundError(f"File not found for upload_id: {upload_id}")

            # Process the file
            processing_result = await self._process_file_content(
                file_path, upload_id, data_type, provider_type, upload_created_at
            )

            if processing_result["success"]:
                # Update status to COMPLETED
                await self._update_upload_status(
                    upload_id,
                    RawDataStatus.COMPLETED,
                    f"Processing completed successfully. Records: {processing_result['total_records']}"
                )

                # Clean up file
                file_storage_service.delete_file(upload_id)

                logger.info("Upload processing completed successfully for upload_id: %s", upload_id)

            else:
                # Update status to FAILED
                await self._update_upload_status(
                    upload_id,
                    RawDataStatus.FAILED,
                    f"Processing failed: {processing_result.get('error', 'Unknown error')}"
                )

                logger.error("Upload processing failed for upload_id: %s", upload_id)

            logger.info("=== UPLOAD PROCESS COMPLETE === upload_id: %s, success: %s",
                       upload_id, processing_result.get("success", False))
            return processing_result

        except (ValueError, FileNotFoundError, OSError, RuntimeError) as e:
            logger.error("=== UPLOAD PROCESS ERROR === upload_id: %s, error: %s", upload_id, e, exc_info=True)

            # Update status to FAILED
            await self._update_upload_status(
                upload_id,
                RawDataStatus.FAILED,
                f"Processing error: {str(e)}"
            )

            return {
                "success": False,
                "error": str(e),
                "upload_id": upload_id
            }

    async def _process_file_content(self, file_path: str, upload_id: str, data_type: str, provider_type: str, upload_created_at: datetime) -> Dict[str, Any]:
        """
        Process file content and store in appropriate collection

        Args:
            file_path: Path to stored file
            upload_id: Upload identifier
            data_type: Type of data
            provider_type: Provider type
            upload_created_at: Upload creation time to use for raw data insertion

        Returns:
            Dict[str, Any]: Processing result
        """
        try:
            # Read file content with encoding detection
            try:
                # Try UTF-8 first (most common)
                with open(file_path, 'r', encoding='utf-8') as file:
                    csv_content = file.read()
            except UnicodeDecodeError:
                # Fallback to UTF-8 with BOM if regular UTF-8 fails
                try:
                    with open(file_path, 'r', encoding='utf-8-sig') as file:
                        csv_content = file.read()
                except UnicodeDecodeError:
                    # Last resort: try with error handling
                    with open(file_path, 'r', encoding='utf-8', errors='replace') as file:
                        csv_content = file.read()
                        logger.warning("File read with encoding errors replaced - some characters may be corrupted")

            # Get complete provider details for validation and storage
            provider = await self._get_provider_details(provider_type, data_type)
            if not provider:
                raise ValueError(f"Provider not found for {provider_type}/{data_type}")

            # Check if this is plants data type - process directly to plants collection
            if data_type.lower() == "plants":
                logger.info("Processing plants data type - routing to plants processor")
                return await self._process_plants_data(csv_content, provider, file_path, upload_id)
            
            # Parse CSV content with schema validation for other data types
            csv_data = self._parse_csv_content(csv_content, provider)
            if not csv_data:
                raise ValueError("Failed to parse CSV content or file is empty")

            # Store raw data using unified service with complete provider details
            additional_metadata = {
                "file_name": Path(file_path).name,
                "upload_id": upload_id,
                "upload_created_at": upload_created_at
            }
            result = self.raw_data_service.store_raw_data(
                raw_data=csv_data,
                provider=provider,
                additional_metadata=additional_metadata
            )

            # Status decision based on validation results
            if result.get("success", False):
                # Validation passed - proceed with processing workflow
                processing_result = {
                    "success": True,
                    "upload_id": upload_id,
                    "raw_data_id": result.get("document_id"),
                    "processing_status_id": result.get("processing_status_id"),
                    "total_records": result.get("total_records", 0)
                }

                return processing_result
            else:
                # Validation failed - return failure without further processing
                validation_error = result.get("error", "Unknown validation error")
                logger.error("Data validation failed for upload_id %s: %s", upload_id, validation_error)

                return {
                    "success": False,
                    "error": f"Data validation failed: {validation_error}",
                    "upload_id": upload_id,
                    "raw_data_id": result.get("document_id"),
                    "processing_status_id": result.get("processing_status_id"),
                    "total_records": result.get("total_records", 0)
                }

        except (ValueError, OSError, RuntimeError, UnicodeDecodeError) as e:
            logger.error("Error processing file content for upload_id %s: %s", upload_id, e, exc_info=True)
            return {
                "success": False,
                "error": str(e),
                "upload_id": upload_id
            }

    async def _update_upload_status(self, upload_id: str, status: RawDataStatus, message: str) -> None:
        """
        Update upload status in database

        Args:
            upload_id: Upload identifier
            status: New status
            message: Status message
        """
        try:
            update_data = {
                "status": status.value,
                "status_message": message,
                "updated_at": datetime.now()
            }

            if status == RawDataStatus.COMPLETED:
                update_data["completed_at"] = datetime.now()
            elif status == RawDataStatus.FAILED:
                update_data["failed_at"] = datetime.now()

            await self.upload_tracking_repository.update_upload_status(
                upload_id, 
                status, 
                message, 
                completed_at=update_data.get("completed_at"), 
                failed_at=update_data.get("failed_at")
            )
            logger.debug("Updated upload status for %s: %s", upload_id, status.value)

        except (ValueError, TypeError, OSError) as e:
            logger.error("Error updating upload status for %s: %s", upload_id, e, exc_info=True)


    def _record_job_completion(self, job_type: str, job_name: str, schedule: str,
                              execution_start: datetime, execution_end: datetime, execution_id: str,
                              status: str, success: bool, result: Optional[Dict[str, Any]] = None,
                              error_message: Optional[str] = None) -> None:
        """
        Record job completion in audit database

        Args:
            job_type: Type of job
            job_name: Name of job
            schedule: Cron schedule
            execution_start: Start time
            execution_end: End time
            execution_id: Execution ID
            status: Final status
            success: Whether job was successful
            result: Job result data
            error_message: Error message if failed
        """
        if not self.job_data_repository or not self.job_detail_repository:
            logger.debug("Job repositories not available for audit logging")
            return

        try:
            # Get the job_id (ObjectId) from job_data collection using job_type
            job_data = self.job_data_repository.get_job(job_type)
            if not job_data:
                logger.error("Job data not found for job_type: %s", job_type)
                return

            # Use base class method for job completion recording
            self.record_job_completion(
                job_type=job_type,
                job_name=job_name,
                schedule=schedule,
                execution_start=execution_start,
                execution_end=execution_end,
                execution_id=execution_id,
                status=status,
                success=success,
                job_id=str(job_data.get('_id')),
                result=result,
                error_message=error_message
            )

        except (ValueError, TypeError, OSError, RuntimeError) as e:
            logger.error("Failed to record job completion for %s: %s", job_type, str(e))

    async def execute_cron_job(self) -> Dict[str, Any]:
        """
        Execute upload raw data processing as a cron job with job detail recording
        This method is called by the cron manager to process pending uploads

        Returns:
            Dict[str, Any]: Processing result with statistics
        """
        job_type = "upload_raw_data_processor"
        job_name = "Upload Raw Data Processor"
        schedule = "*/2 * * * *"  # Every 2 minutes
        start_time = datetime.now()

        # Record job start
        execution_id = self.record_job_start(job_type, job_name, schedule, start_time)

        # Log job start
        if execution_id:
            audit_logger.log_system_operation(
                operation="cron_job_started",
                service="ingestion",
                message=f"Cron job started: {job_name}",
                job_detail_id=execution_id,
                job_name=job_name,
                job_type=job_type,
                schedule=schedule,
                execution_mode="scheduled"
            )

        logger.info("Starting upload raw data processing cron job at %s", start_time.strftime('%Y-%m-%d %H:%M:%S'))

        try:
            # Get pending uploads that need processing
            pending_uploads = self.upload_tracking_repository.get_uploads_by_status_and_date(
                status=[RawDataStatus.PENDING, RawDataStatus.FAILED],
                limit=getattr(settings, 'BACKGROUND_PROCESSING_BATCH_SIZE', 10)
            )

            if not pending_uploads:
                logger.info("No pending uploads found for background processing")
                end_time = datetime.now()
                result = {
                    'status': 'success',
                    'processed_files': 0,
                    'execution_time': (end_time - start_time).total_seconds()
                }

                # Log job completion
                if execution_id:
                    audit_logger.log_system_operation(
                        operation="cron_job_completed",
                        service="ingestion",
                        message=f"Cron job completed: {job_name} - No pending uploads",
                        job_detail_id=execution_id,
                        job_name=job_name,
                        job_type=job_type,
                        execution_mode="scheduled",
                        duration_ms=int((end_time - start_time).total_seconds() * 1000),
                        processed_files=0,
                        success=True
                    )

                    # Record job completion in job detail system
                    self._record_job_completion(
                        job_type, job_name, schedule, start_time, end_time, execution_id,
                        "success", True, result
                    )

                return result

            processed_files = 0
            failed_files = 0

            logger.info("Found %d pending uploads to process", len(pending_uploads))

            for upload in pending_uploads:
                try:
                    upload_id = upload.get('upload_id')
                    if not upload_id:
                        logger.error("Upload record missing upload_id: %s", upload)
                        failed_files += 1
                        continue

                    file_path = upload.get('file_path')
                    data_type = upload.get('data_type', 'unknown')
                    provider_type = upload.get('provider_type', 'unknown')

                    logger.info("Processing upload: %s (file: %s, type: %s)", upload_id, file_path, data_type)

                    # Log upload processing start
                    if execution_id:
                        audit_logger.log_system_operation(
                            operation="upload_processing_started",
                            service="ingestion",
                            message=f"Starting upload processing for file: {upload_id}",
                            job_detail_id=execution_id,
                            upload_id=upload_id,
                            file_path=file_path,
                            data_type=data_type,
                            provider_type=provider_type
                        )

                    # Process the file using existing method
                    result = await self.process_uploaded_file(
                        upload_id=upload_id,
                        data_type=data_type,
                        provider_type=provider_type
                    )

                    if result.get('success', False):
                        processed_files += 1
                        logger.info("Successfully processed upload: %s", upload_id)
                        
                        # Log successful upload processing
                        if execution_id:
                            audit_logger.log_system_operation(
                                operation="upload_processing_completed",
                                service="ingestion",
                                message=f"Successfully processed upload: {upload_id}",
                                job_detail_id=execution_id,
                                upload_id=upload_id,
                                data_type=data_type,
                                provider_type=provider_type,
                                processed_records=result.get('processed_records', 0),
                                success=True
                            )
                    else:
                        failed_files += 1
                        error_message = result.get('error', 'Unknown processing error')
                        logger.error("Failed to process upload %s: %s", upload_id, error_message)
                        
                        # Log failed upload processing
                        if execution_id:
                            audit_logger.log_system_operation(
                                operation="upload_processing_failed",
                                service="ingestion",
                                message=f"Upload processing failed: {error_message}",
                                job_detail_id=execution_id,
                                upload_id=upload_id,
                                data_type=data_type,
                                provider_type=provider_type,
                                success=False
                            )

                except (ValueError, OSError, RuntimeError) as file_error:
                    failed_files += 1
                    upload_id = upload.get('upload_id', 'unknown')
                    logger.error("Exception processing upload %s: %s", upload_id, str(file_error))

                    # Log upload processing exception
                    if execution_id:
                        audit_logger.log_system_operation(
                            operation="upload_processing_error",
                            service="ingestion",
                            message=f"Upload processing error: {str(file_error)}",
                            job_detail_id=execution_id,
                            upload_id=upload_id,
                            exception_type=type(file_error).__name__,
                            success=False
                        )

                    # Update status to failed
                    await self._update_upload_status(
                        upload_id,
                        RawDataStatus.FAILED,
                        f"Cron processing error: {str(file_error)}"
                    )

            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()

            # Determine overall status
            overall_success = processed_files > 0 and failed_files == 0
            status = "success" if overall_success else ("partial_success" if processed_files > 0 else "error")

            result = {
                'status': status,
                'processed_files': processed_files,
                'failed_files': failed_files,
                'total_files': len(pending_uploads),
                'execution_time': execution_time,
                'execution_id': execution_id
            }

            # Log job completion with queue-based audit
            if execution_id:
                error_message = None if overall_success else f"Processed {processed_files}, failed {failed_files}"
                
                audit_logger.log_system_operation(
                    operation="cron_job_completed",
                    service="ingestion",
                    message=f"Cron job completed: {job_name} - {processed_files} processed, {failed_files} failed",
                    job_detail_id=execution_id,
                    job_name=job_name,
                    job_type=job_type,
                    execution_mode="scheduled",
                    duration_ms=int(execution_time * 1000),
                    processed_files=processed_files,
                    failed_files=failed_files,
                    total_files=len(pending_uploads),
                    success=overall_success
                )

                # Record job completion in job detail system
                self._record_job_completion(
                    job_type, job_name, schedule, start_time, end_time, execution_id,
                    status, overall_success, result=result, error_message=error_message
                )

            logger.info("Upload raw data processing cron job completed in %.2fs", execution_time)
            logger.info("   - Processed: %d files", processed_files)
            logger.info("   - Failed: %d files", failed_files)
            logger.info("   - Total: %d files", len(pending_uploads))
            logger.info("   - Execution ID: %s", execution_id)

            return result

        except (ValueError, OSError, RuntimeError) as e:
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            logger.error("Error in upload raw data processing cron job after %.2fs: %s", execution_time, str(e))

            result = {'status': 'error', 'error': str(e), 'execution_time': execution_time}

            # Log job error
            if execution_id:
                audit_logger.log_system_operation(
                    operation="cron_job_failed",
                    service="ingestion",
                    message=f"Cron job failed: {job_name} - {str(e)}",
                    job_detail_id=execution_id,
                    job_name=job_name,
                    job_type=job_type,
                    execution_mode="scheduled",
                    duration_ms=int(execution_time * 1000),
                    exception_type=type(e).__name__,
                    success=False
                )

                # Record job completion with error in job detail system
                self._record_job_completion(
                    job_type, job_name, schedule, start_time, end_time, execution_id,
                    "error", False, result=result, error_message=str(e)
                )

            return result

    async def _get_provider_details(self, provider_type: str, data_type: str) -> Optional[ProviderEntity]:
        """
        Get complete provider details for validation and storage

        Args:
            provider_type: Provider type code
            data_type: Data type (demand, supply, etc.)

        Returns:
            Optional[ProviderEntity]: Complete provider object or None if not found
        """
        try:
            provider_service = self.provider_service

            # Get provider details directly
            provider = provider_service.get_provider_by_code_and_data_type(
                provider_type, data_type.lower()
            )

            if not provider:
                logger.error("Provider not found: %s for data type %s", provider_type, data_type)
                return None

            if not provider.enabled:
                logger.error("Provider is disabled: %s for data type %s", provider_type, data_type)
                return None

            return provider

        except (ValueError, TypeError, OSError, RuntimeError) as e:
            logger.error("Error getting provider details for %s/%s: %s", provider_type, data_type, e)
            return None

    def _parse_csv_content(self, csv_content: str, provider: Optional[ProviderEntity] = None) -> List[Dict[str, Any]]:
        """
        Parse CSV content into list of dictionaries using appropriate parser

        Args:
            csv_content: Raw CSV content string
            provider: Provider entity containing schema definition (optional)

        Returns:
            List[Dict[str, Any]]: Parsed CSV data as list of dictionaries
        """
        try:
            # Import parser factory with error handling
            try:
                from libs.parsers import create_parser
            except ImportError as import_error:
                logger.error("Failed to import parser factory: %s", import_error)
                raise ValueError(f"Parser system not available: {str(import_error)}") from import_error
            
            # Create appropriate parser based on provider configuration
            try:
                parser = create_parser(provider)
                logger.info("Using parser: %s for provider: %s", 
                           parser.__class__.__name__, 
                           provider.code if provider else 'unknown')
            except Exception as parser_error:
                logger.error("Failed to create parser for provider %s: %s", 
                           provider.code if provider else 'unknown', parser_error)
                raise ValueError(f"Parser creation failed: {str(parser_error)}") from parser_error
            
            # Parse content using selected parser
            try:
                raw_data = parser.parse(csv_content, provider)
            except Exception as parse_error:
                logger.error("Failed to parse CSV content with %s: %s", 
                           parser.__class__.__name__, parse_error)
                raise ValueError(f"CSV parsing failed: {str(parse_error)}") from parse_error
            
            logger.info("Parsed CSV content: %d raw records using %s", 
                       len(raw_data), parser.__class__.__name__)

            # Apply schema validation and mapping if provider is provided
            if provider:
                # Check if parser already applied field mapping (e.g., TradingParser)
                parser_type = provider.metadata.get('parser_type', '')
                if parser_type == 'trading':
                    # TradingParser already handles field mapping and validation, skip additional processing
                    logger.info("TradingParser already applied field mapping and validation, skipping additional processing")
                    return raw_data
                else:
                    # Map data to schema format for other parsers
                    mapped_data = self.map_data_to_schema(raw_data, provider)
                
                # Validate data against schema
                validation_result = self.validate_data_schema(mapped_data, provider)
                
                if validation_result["success"]:
                    logger.info("CSV validation successful: %d records validated", validation_result["validated_records"])
                    return validation_result["validated_data"]
                else:
                    # Log validation errors and raise exception
                    error_msg = f"Validation failed: {', '.join(validation_result['errors'][:5])}"
                    if len(validation_result['errors']) > 5:
                        error_msg += f" (and {len(validation_result['errors']) - 5} more errors)"
                    raise ValueError(error_msg)
            else:
                # No schema validation, return raw data
                return raw_data

        except (ValueError, UnicodeDecodeError, OSError) as e:
            logger.error("Error parsing CSV content: %s", e, exc_info=True)
            raise ValueError(f"CSV parsing failed: {str(e)}") from e

    async def _process_plants_data(self, csv_content: str, provider: ProviderEntity, file_path: str, upload_id: str) -> Dict[str, Any]:
        """
        Process plants data directly into plants collection
        
        Args:
            csv_content: CSV file content as string
            provider: Provider entity containing schema and mapping configuration
            file_path: Path to the source file
            upload_id: Upload identifier
            
        Returns:
            Dict[str, Any]: Processing result
        """
        try:
            logger.info("Processing plants data for provider: %s", provider.code)
            
            # Parse CSV content using the same parser as other data types
            csv_data = self._parse_csv_content(csv_content, provider)
            if not csv_data:
                raise ValueError("Failed to parse CSV content or file is empty")
            
            logger.info("Parsed %d plant records from CSV", len(csv_data))
            
            # Process plants data using plants processor
            result = await self.plants_processor.process_plants_data(csv_data, provider)
            
            if result["success"]:
                logger.info("Successfully processed plants data: %d records processed", result["processed_records"])
                return {
                    "success": True,
                    "message": result["message"],
                    "total_records": result["processed_records"],
                    "inserted": result.get("inserted", 0),
                    "updated": result.get("updated", 0),
                    "provider_code": result.get("provider_code", provider.code),
                    "file_name": Path(file_path).name,
                    "upload_id": upload_id
                }
            else:
                logger.error("Failed to process plants data: %s", result.get("message", "Unknown error"))
                return {
                    "success": False,
                    "error": result.get("message", "Unknown error"),
                    "upload_id": upload_id,
                    "total_records": 0
                }
                
        except Exception as e:
            logger.error("Error processing plants data: %s", str(e), exc_info=True)
            return {
                "success": False,
                "error": f"Plants data processing failed: {str(e)}",
                "upload_id": upload_id,
                "total_records": 0
            }


# Global instance
upload_raw_data_processor = UploadRawDataProcessor()
