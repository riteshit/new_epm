"""
Models package for ingestion service
"""

# All legacy entities removed - using unified raw data system with provider-based schema validation
# No specific entities needed - using generic RawDataEntity from libs with provider schemas

__all__ = []