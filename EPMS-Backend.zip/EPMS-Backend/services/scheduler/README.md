# EPMS Scheduler Service

## Overview

The EPMS Scheduler Service is a microservice responsible for managing cron jobs, retries, and periodic tasks in the Energy Portfolio Management System (EPMS). It provides job scheduling capabilities, task orchestration, and automated workflow management for the entire EPMS ecosystem.

## Features

- **Cron Job Management**: Schedule and manage recurring tasks
- **Task Orchestration**: Coordinate complex workflows across services
- **Retry Mechanisms**: Automatic retry with exponential backoff
- **Job Monitoring**: Real-time job status and progress tracking
- **Resource Management**: CPU and memory usage monitoring
- **APScheduler Integration**: Advanced Python scheduling library
- **Celery Integration**: Background task processing
- **RESTful API**: Comprehensive API for job management
- **Health Monitoring**: System health and performance monitoring
- **Audit Logging**: Complete audit trail for all scheduled jobs

## Project Structure

```
scheduler/
├── app/
│   ├── api/
│   │   └── v1/
│   │       └── routes/
│   │           └── __init__.py
│   ├── controllers/
│   │   └── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   └── logger.py
│   ├── main.py
│   ├── models/
│   │   └── __init__.py
│   ├── schemas/
│   │   └── __init__.py
│   └── services/
│       └── __init__.py
├── requirements.txt
└── README.md
```

## Technology Stack

- **Framework**: FastAPI 0.109.2
- **ASGI Server**: Uvicorn 0.27.1
- **Database**: MongoDB (PyMongo 4.6.1)
- **Scheduling**: APScheduler 3.10.4, croniter 2.0.1
- **Background Tasks**: Celery 5.3.4
- **System Monitoring**: psutil 5.9.8
- **HTTP Client**: httpx 0.26.0
- **Validation**: Pydantic 2.6.1
- **Configuration**: Pydantic Settings 2.1.0
- **Caching**: Redis 5.0.1

## Prerequisites

- Python 3.8+
- MongoDB
- Redis
- Celery (for background processing)
- Virtual environment (recommended)

## Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd EPMS-Backend/services/scheduler
```

### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Environment Configuration
Create a `.env` file in the scheduler service directory:

```env
# Service Configuration
SERVICE_NAME=scheduler-service
SERVICE_PORT=8004
SERVICE_HOST=0.0.0.0
DEBUG=true
LOG_LEVEL=INFO

# Database Configuration
MONGODB_URI=mongodb://localhost:27017
SCHEDULER_DB_NAME=scheduler_db
AUDIT_DB_NAME=audit_db

# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0

# JWT Configuration
JWT_SECRET_KEY=your-super-secret-jwt-key-change-in-production
JWT_ALGORITHM=HS256

# Scheduler Configuration
MAX_CONCURRENT_JOBS=10
JOB_TIMEOUT=300
RETRY_ATTEMPTS=3
RETRY_DELAY=60

# Celery Configuration
CELERY_BROKER_URL=redis://localhost:6379/1
CELERY_RESULT_BACKEND=redis://localhost:6379/2

# Monitoring Configuration
ENABLE_SYSTEM_MONITORING=true
MONITORING_INTERVAL=30
RESOURCE_THRESHOLD=80

# CORS Configuration
CORS_ORIGINS=["http://localhost:3000","http://localhost:8080"]
```

### 5. Start the Service
```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8004 --reload
```

### 6. Start Celery Worker (Optional)
```bash
celery -A app.celery_app worker --loglevel=info
```

## API Documentation

### Base URL
```
http://localhost:8004
```



### Interactive Documentation
- Swagger UI: `http://localhost:8004/docs`
- ReDoc: `http://localhost:8004/redoc`

## Job Scheduling Features

### Job Types

| Type | Description | Use Case |
|------|-------------|----------|
| **Cron Jobs** | Time-based scheduling | Regular data processing |
| **Interval Jobs** | Fixed interval execution | Periodic health checks |
| **One-time Jobs** | Single execution | Ad-hoc tasks |
| **Recurring Jobs** | Custom recurrence patterns | Complex scheduling |

### Cron Expressions

The service supports standard cron expressions:

```
┌───────────── minute (0 - 59)
│ ┌───────────── hour (0 - 23)
│ │ ┌───────────── day of the month (1 - 31)
│ │ │ ┌───────────── month (1 - 12)
│ │ │ │ ┌───────────── day of the week (0 - 6) (Sunday to Saturday)
│ │ │ │ │
* * * * *
```

### Job States

- **PENDING**: Job is scheduled but not yet executed
- **RUNNING**: Job is currently executing
- **COMPLETED**: Job completed successfully
- **FAILED**: Job failed during execution
- **PAUSED**: Job is paused and not executing
- **CANCELLED**: Job was cancelled

## Configuration

### Service Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `SERVICE_PORT` | 8004 | Service port |
| `SERVICE_HOST` | 0.0.0.0 | Service host |
| `DEBUG` | true | Debug mode |
| `LOG_LEVEL` | INFO | Logging level |

### Scheduler Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `MAX_CONCURRENT_JOBS` | 10 | Maximum concurrent jobs |
| `JOB_TIMEOUT` | 300 | Job timeout in seconds |
| `RETRY_ATTEMPTS` | 3 | Number of retry attempts |
| `RETRY_DELAY` | 60 | Delay between retries in seconds |

### Monitoring Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `ENABLE_SYSTEM_MONITORING` | true | Enable system monitoring |
| `MONITORING_INTERVAL` | 30 | Monitoring interval in seconds |
| `RESOURCE_THRESHOLD` | 80 | Resource usage threshold (%) |

### Database Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `MONGODB_URI` | mongodb://localhost:27017 | MongoDB connection string |
| `SCHEDULER_DB_NAME` | scheduler_db | Scheduler database name |
| `AUDIT_DB_NAME` | audit_db | Audit database name |

## Usage Examples

### Create a Cron Job
```bash
curl -X POST "http://localhost:8004/api/v1/cron" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "daily_data_processing",
    "cron_expression": "0 2 * * *",
    "task": "process_daily_data",
    "parameters": {
      "source": "ingestion_service",
      "target": "processing_service"
    },
    "enabled": true
  }'
```

### Create an Interval Job
```bash
curl -X POST "http://localhost:8004/api/v1/jobs" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "health_check",
    "job_type": "interval",
    "interval_seconds": 300,
    "task": "check_service_health",
    "parameters": {
      "services": ["auth", "ingestion", "processing"]
    },
    "enabled": true
  }'
```

### Execute Job Immediately
```bash
curl -X POST "http://localhost:8004/api/v1/jobs/{job_id}/execute" \
  -H "Content-Type: application/json"
```

### Get Job Status
```bash
curl -X GET "http://localhost:8004/api/v1/jobs/{job_id}/status"
```

### Get System Monitoring
```bash
curl -X GET "http://localhost:8004/api/v1/monitor/system"
```

## Development

### Running Tests
```bash
# Run all tests
python -m pytest tests/scheduler/

# Run with coverage
python -m pytest tests/scheduler/ --cov=app --cov-report=html
```

### Code Quality
```bash
# Linting
flake8 app/

# Type checking
mypy app/
```

### Database Setup
```bash
# Initialize database collections
python scripts/init_db.py
```

## Monitoring & Logging

### Health Checks
The service provides health check endpoints for monitoring:
- `GET /health` - Returns service status and version

### Logging
Logs are structured in JSON format and include:
- Job execution events
- Scheduling decisions
- System resource usage
- Error tracking
- Performance metrics

### Metrics
Key metrics to monitor:
- Job success/failure rates
- Job execution times
- System resource usage
- Queue processing metrics
- API response times

## Performance Optimization

### Job Scheduling
- Efficient job queue management
- Priority-based job execution
- Resource-aware scheduling
- Load balancing across workers

### System Monitoring
- Real-time resource monitoring
- Proactive alerting
- Performance optimization
- Capacity planning

### Database Optimization
- Connection pooling
- Indexed queries for job history
- Efficient data storage
- Audit trail optimization

## Security Considerations

### Job Security
- Job execution isolation
- Resource limits per job
- Secure job parameters
- Access control for job management

### System Security
- Secure job storage
- Encrypted job parameters
- Audit logging
- Access control for scheduling

### API Security
- JWT token validation
- Rate limiting
- Input validation
- Error handling without information leakage

## Troubleshooting

### Common Issues

1. **Job Execution Failures**
   - Check job parameters
   - Verify task function exists
   - Review error logs
   - Check resource limits

2. **Scheduling Issues**
   - Verify cron expressions
   - Check timezone settings
   - Review job conflicts
   - Validate job configuration

3. **System Resource Issues**
   - Monitor CPU/memory usage
   - Check disk space
   - Review concurrent job limits
   - Optimize job execution

4. **Database Connection Issues**
   - Verify MongoDB connection
   - Check connection pool settings
   - Review database performance
   - Monitor query execution

### Logs
Check application logs for detailed error information:
```bash
tail -f logs/scheduler-service.log
```

## Job Templates

### Data Processing Job
```json
{
  "name": "data_processing_job",
  "cron_expression": "0 */6 * * *",
  "task": "process_energy_data",
  "parameters": {
    "source_service": "ingestion",
    "target_service": "processing",
    "data_type": "energy_consumption",
    "batch_size": 1000
  },
  "retry_attempts": 3,
  "timeout": 1800
}
```

### Health Check Job
```json
{
  "name": "service_health_check",
  "interval_seconds": 300,
  "task": "check_service_health",
  "parameters": {
    "services": ["auth", "ingestion", "processing"],
    "timeout": 30,
    "alert_on_failure": true
  },
  "retry_attempts": 2,
  "timeout": 60
}
```

### Backup Job
```json
{
  "name": "database_backup",
  "cron_expression": "0 1 * * 0",
  "task": "backup_database",
  "parameters": {
    "database": "epms_main",
    "backup_path": "/backups",
    "retention_days": 30
  },
  "retry_attempts": 1,
  "timeout": 3600
}
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## License

This project is part of the EPMS (Energy Portfolio Management System) and is proprietary software.

## Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the main EPMS documentation 