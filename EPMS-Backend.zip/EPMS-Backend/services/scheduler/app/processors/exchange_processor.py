"""
Exchange data processor for handling exchange data processing logic.
"""

import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from enum import Enum

from .base_processor import BaseProcessor
from libs.models.exchange_serve_entity import ExchangeServeEntity, ExchangeHistoricalEntity
from libs.enum.updated_flag import UpdatedFlag
from ..repository.exchange_repository import ExchangeRepository
from libs.core.job_entities import JobDetail


logger = logging.getLogger(__name__)

# Constants for better maintainability
MIN_TIMEBLOCK = 1
MAX_TIMEBLOCK = 96
FLOAT_COMPARISON_TOLERANCE = 0.001
PRICE_COMPARISON_TOLERANCE = 0.01


class ExchangeProcessor(BaseProcessor):
    """
    Exchange data processor that handles exchange data processing and storage.
    Uses provider mapping configuration for dynamic field mapping.
    """
    
    def __init__(self):
        super().__init__()
        self.repository = ExchangeRepository()
        
        # Preload timeblock mappings for better performance using base processor's caching
        self.preload_timeblock_mappings()
        
        # Initialize job repositories for execution tracking
        from libs.core.job_factory import create_job_data_repository, create_job_detail_repository
        from ..core.config import settings
        
        self.job_data_repository = create_job_data_repository(
            settings.AUDIT_DB_URI,
            settings.AUDIT_DB_NAME,
            settings.JOB_DATA_COLLECTION
        )
        self.job_detail_repository = create_job_detail_repository(
            settings.AUDIT_DB_URI,
            settings.AUDIT_DB_NAME,
            settings.JOB_DETAIL_COLLECTION
        )

    async def execute_cron_job(self) -> Dict[str, Any]:
        """
        Execute exchange data processing as a cron job with execution_id as correlation ID
        """
        job_type = "exchange_data_processing"
        job_name = "Exchange Data Processing"
        schedule = "*/15 * * * *"  # Default schedule
        start_time = datetime.now()
        
        # Generate and record job start to get execution_id (correlation ID)
        execution_id = self._record_job_execution(job_type, job_name, schedule, start_time, is_start=True)
        if not execution_id:
            logger.error("Failed to record job start for %s", job_type)
            return {
                "status": "error",
                "message": "Failed to record job start",
                "execution_time": 0.0,
                "data_type": "exchange"
            }
        
        # Set execution_id as correlation ID using base processor method
        self.set_correlation_id(execution_id)
        
        logger.info("=== EXECUTING EXCHANGE DATA PROCESSING JOB ===")
        
        try:
            # Create metadata for exchange data processing with correlation ID
            metadata = {
                "data_type": "exchange",
                "scraped_at": start_time,
                "source": "exchange_processor_cron",
                "triggered_by": "cron_job",
                "execution_id": execution_id,
                "correlation_id": execution_id
            }
            
            # Process the metadata trigger with correlation ID context
            success = await self.process_metadata_trigger(metadata)
            
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            # Record job completion with correlation ID
            result = {
                "status": "success" if success else "error",
                "message": "Exchange data processed successfully" if success else "Exchange data processing failed",
                "execution_time": execution_time,
                "data_type": "exchange",
                "correlation_id": execution_id,
            }
            
            self._record_job_execution(
                job_type=job_type,
                job_name=job_name,
                schedule=schedule,
                execution_start=start_time,
                execution_end=end_time,
                execution_id=execution_id,
                status=result["status"],
                success=success,
                result=result,
                is_start=False
            )
            
            if success:
                logger.info("Exchange data processing completed successfully in %.2fs", execution_time)
            else:
                logger.error("Exchange data processing failed after %.2fs", execution_time)
                
            return result
                
        except Exception as e:
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            error_result = {
                "status": "error",
                "message": f"Exchange data processing error: {str(e)}",
                "execution_time": execution_time,
                "data_type": "exchange",
                "correlation_id": execution_id
            }
            
            self._record_job_execution(
                job_type=job_type,
                job_name=job_name,
                schedule=schedule,
                execution_start=start_time,
                execution_end=end_time,
                execution_id=execution_id,
                status="error",
                success=False,
                result=error_result,
                error_message=str(e),
                is_start=False
            )
            
            logger.error("Error executing exchange data processing job: %s", str(e), exc_info=True)
            return error_result
        finally:
            # Clear correlation ID after job completion
            self.clear_correlation_id()
    
    def process_raw_data_to_serve(
        self, 
        raw_data: List[Dict[str, Any]], 
        metadata: Dict[str, Any],
        provider_config: Dict[str, Any]
    ) -> bool:
        """
        Process raw data and convert to exchange serve entities for storage.
        Uses provider mapping configuration for dynamic field mapping.
        Uses atomic upsert operations to prevent data discrepancy.
        
        Args:
            raw_data: List of raw data items to process
            metadata: Processing metadata
            provider_config: Provider configuration with schema and mapping
            
        Returns:
            bool: True if processing was successful
        """
        try:
            if not self._validate_raw_data(raw_data):
                return False

            logger.info("Processing %d exchange records with provider mapping configuration", len(raw_data))
            
            # Get market type from provider config
            market_type = self._extract_market_type(provider_config)
            
            # Process raw data into exchange entities using provider mapping with date-based routing
            exchange_entities, historical_entities = self._build_exchange_entities_with_mapping_and_routing(raw_data, metadata, provider_config, market_type)
            
            # Persist entities with atomic upsert and historical routing
            return self._persist_exchange_entities_with_routing(exchange_entities, historical_entities, provider_config)

        except Exception as e:
            logger.error("Error processing raw data to serve: %s", str(e), exc_info=True)
            return False
    
    def _validate_raw_data(self, raw_data: List[Dict[str, Any]]) -> bool:
        """Validate raw data input"""
        if not raw_data:
            logger.warning("No raw data provided for processing")
            return False

        if not isinstance(raw_data, list):
            logger.error("Raw data must be a list, got: %s", type(raw_data))
            return False
            
        return True
            
    def _extract_market_type(self, provider_config: Dict[str, Any]) -> str:
        """Extract market type from provider configuration"""
        config = provider_config.get("metadata", {}).get("config", {})
        market_type = config.get("market_type", "unknown").upper()
                
        if market_type == "UNKNOWN":
            # Fallback to data_type for backward compatibility
            market_type = config.get("data_type", "unknown").upper()
            logger.debug("Using fallback data_type from metadata.config: %s", market_type)
        else:
            logger.debug("Using market_type from metadata.config: %s", market_type)

        return market_type
    
    def _build_exchange_entities_with_mapping(self, raw_data: List[Dict[str, Any]], metadata: Dict[str, Any], 
                                             provider_config: Dict[str, Any], market_type: str) -> List[ExchangeServeEntity]:
        """Build exchange entities using provider mapping configuration"""
        exchange_entities = []
        
        # Get mapping configuration from provider
        mapping_config = self._get_provider_mapping_config(provider_config)
        
        for item in raw_data:
            if not isinstance(item, dict):
                logger.warning("Skipping non-dict item in raw data")
                continue

            # Skip summary data with more robust detection
            if self._is_summary_record(item):
                continue

            try:
                # Validate required fields before processing
                validation_errors = ExchangeServeEntity.validate_required_fields(item, provider_config)
                if validation_errors:
                    logger.warning("Validation errors for exchange record: %s", validation_errors)
                    continue
                
                # Process time block with enhanced validation
                time_block = self._process_timeblock(item.get("Time Block", ""))
                if time_block is None:
                    continue

                scheduled_date = item.get("Date")
                if not isinstance(scheduled_date, datetime):
                    logger.warning("Invalid or missing Date field")
                    continue

                # Determine updated flag based on existing record and data changes
                updated_flag = self._determine_updated_flag_with_mapping(scheduled_date, time_block, market_type, item, mapping_config)
                
                # Only create entity if we need to upsert (skip if no changes needed)
                if updated_flag is not None:
                    exchange_entity = self._build_exchange_record_with_mapping(
                        raw_data=item,
                        time_block=time_block,
                        metadata=metadata,
                        provider_config=provider_config,
                        mapping_config=mapping_config,
                        updated_flag=updated_flag
                    )
                    exchange_entities.append(exchange_entity)

            except Exception as entity_error:
                logger.error("Error processing exchange record for item %s: %s", 
                           item.get("Date", "unknown"), str(entity_error), exc_info=True)
                continue

        return exchange_entities
    
    def _build_exchange_entities_with_mapping_and_routing(self, raw_data: List[Dict[str, Any]], metadata: Dict[str, Any], 
                                                         provider_config: Dict[str, Any], market_type: str) -> tuple[List[ExchangeServeEntity], List[ExchangeHistoricalEntity]]:
        """Build exchange entities using provider mapping configuration with date-based routing"""
        exchange_entities = []
        historical_entities = []
        
        # Get mapping configuration from provider
        mapping_config = self._get_provider_mapping_config(provider_config)
        
        for item in raw_data:
            if not isinstance(item, dict):
                logger.warning("Skipping non-dict item in raw data")
                continue

            # Skip summary data with more robust detection
            if self._is_summary_record(item):
                continue

            try:
                # Validate required fields before processing
                validation_errors = ExchangeServeEntity.validate_required_fields(item, provider_config)
                if validation_errors:
                    logger.warning("Validation errors for exchange record: %s", validation_errors)
                    continue
                
                # Process time block with enhanced validation
                time_block = self._process_timeblock(item.get("Time Block", ""))
                if time_block is None:
                    continue

                scheduled_date = item.get("Date")
                if not isinstance(scheduled_date, datetime):
                    logger.warning("Invalid or missing Date field")
                    continue

                # Calculate date difference for routing
                today_date = datetime.now().date()
                record_date = scheduled_date.date()
                day_diff = (today_date - record_date).days
                
                # Route based on date rules
                if day_diff >= 3:
                    # Historical only - process for historical collection
                    logger.debug(f"Routing exchange record to historical only: {record_date}")
                    historical_entity = self._build_exchange_historical_entity_with_mapping(
                        raw_data=item,
                        time_block=time_block,
                        metadata=metadata,
                        provider_config=provider_config,
                        mapping_config=mapping_config
                    )
                    if historical_entity:
                        historical_entities.append(historical_entity)
                elif day_diff == 1:
                    # Yesterday - both serve and historical
                    logger.debug(f"Routing exchange record to both serve and historical: {record_date}")
                    # Process for serve
                    updated_flag = self._determine_updated_flag_with_mapping(scheduled_date, time_block, market_type, item, mapping_config)
                    if updated_flag is not None:
                        exchange_entity = self._build_exchange_record_with_mapping(
                            raw_data=item,
                            time_block=time_block,
                            metadata=metadata,
                            provider_config=provider_config,
                            mapping_config=mapping_config,
                            updated_flag=updated_flag
                        )
                        exchange_entities.append(exchange_entity)
                    
                    # Also add to historical
                    historical_entity = self._build_exchange_historical_entity_with_mapping(
                        raw_data=item,
                        time_block=time_block,
                        metadata=metadata,
                        provider_config=provider_config,
                        mapping_config=mapping_config
                    )
                    if historical_entity:
                        historical_entities.append(historical_entity)
                else:
                    # Today or tomorrow - serve only
                    logger.debug(f"Routing exchange record to serve only: {record_date}")
                    updated_flag = self._determine_updated_flag_with_mapping(scheduled_date, time_block, market_type, item, mapping_config)
                    if updated_flag is not None:
                        exchange_entity = self._build_exchange_record_with_mapping(
                            raw_data=item,
                            time_block=time_block,
                            metadata=metadata,
                            provider_config=provider_config,
                            mapping_config=mapping_config,
                            updated_flag=updated_flag
                        )
                        exchange_entities.append(exchange_entity)

            except Exception as entity_error:
                logger.error("Error processing exchange record for item %s: %s", 
                           item.get("Date", "unknown"), str(entity_error), exc_info=True)
                continue

        return exchange_entities, historical_entities
    
    def _get_provider_mapping_config(self, provider_config: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        """
        Extract and organize mapping configuration from provider config
        
        Args:
            provider_config: Provider configuration containing mapping
            
        Returns:
            Dictionary with serve_field as key and mapping details as value
        """
        mapping_config = {}
        
        # Get mapping from provider configuration
        mapping = provider_config.get("mapping", [])
        
        if mapping:
            for field_map in mapping:
                serve_field = field_map.get("serve_field")
                provider_field = field_map.get("provider_field")
                transformation = field_map.get("transformation")
                
                if serve_field and provider_field:
                    mapping_config[serve_field] = {
                        "provider_field": provider_field,
                        "transformation": transformation,
                        "field_type": self._determine_field_type(serve_field)
                    }
        
        logger.debug("Extracted %d field mappings from provider configuration", len(mapping_config))
        return mapping_config
    
    def _determine_field_type(self, serve_field: str) -> str:
        """Determine the data type for a serve field based on field name patterns"""
        if serve_field in ["buy_bid", "sell_bid", "mcv", "mcp", "acp", "acv", "final_scheduled_volume"]:
            return "float"
        elif serve_field in ["time_block"]:
            return "int"
        elif serve_field in ["market_type", "px_name", "data_type", "source"]:
            return "string"
        else:
            return "string"  # Default to string
    
    def _is_summary_record(self, item: Dict[str, Any]) -> bool:
        """Check if record is a summary record with robust detection"""
        # Check multiple indicators for summary records
        summary_indicators = ["Summary", "Total", "Aggregate", "Grand Total"]
        
        for key, value in item.items():
            if isinstance(value, str):
                for indicator in summary_indicators:
                    if indicator.lower() in value.lower():
                        return True

        return False
    
    def _process_timeblock(self, time_block_str: str) -> Optional[int]:
        """Process timeblock with comprehensive validation and error handling"""
        if not time_block_str or not isinstance(time_block_str, str):
            logger.error("Invalid timeblock input: %s", time_block_str)
            return None
        
        # Clean the input
        time_block_str = time_block_str.strip()
        
        if not time_block_str:
            logger.warning("Empty timeblock string")
            return None
        
        # Try primary lookup first
        time_block = self._get_timeblock_number(time_block_str)
        
        # If primary fails, try alternative parsing
        if time_block == 0:
            time_block = self._parse_timeblock_alternative(time_block_str)
        
        # Final validation
        if not self._is_valid_timeblock(time_block):
            logger.error("Invalid timeblock '%s' -> %d (must be %d-%d)", 
                        time_block_str, time_block, MIN_TIMEBLOCK, MAX_TIMEBLOCK)
            return None
        
        return time_block
    
    def _parse_timeblock_alternative(self, time_block_str: str) -> int:
        """Alternative parsing for time ranges like '00:00-00:15'"""
        if "-" not in time_block_str:
            return 0
        
        try:
            time_parts = time_block_str.split("-", 1)
            if len(time_parts) != 2:
                return 0
            
            start_time, end_time = time_parts[0].strip(), time_parts[1].strip()
            timeblock_data = self.get_timeblock_by_time_range(start_time, end_time)
            return timeblock_data.get("timeblock", 0) if timeblock_data else 0
        except Exception as e:
            logger.error("Error parsing timeblock range '%s': %s", time_block_str, str(e))
            return 0
    
    def _is_valid_timeblock(self, time_block: int) -> bool:
        """Validate timeblock is within valid range"""
        return isinstance(time_block, int) and MIN_TIMEBLOCK <= time_block <= MAX_TIMEBLOCK
    
    def _determine_updated_flag_with_mapping(self, scheduled_date: datetime, time_block: int, market_type: str, 
                                           new_item: Dict[str, Any], mapping_config: Dict[str, Dict[str, Any]]) -> Optional[UpdatedFlag]:
        """
        Determine the appropriate updated flag based on existing record and data changes using provider mapping
        
        Args:
            scheduled_date: Scheduled datetime
            time_block: Time block number
            market_type: Market type
            new_item: New data item
            mapping_config: Provider mapping configuration
            
        Returns:
            UpdatedFlag or None if no upsert needed
        """
        existing_record = self.repository.find_by_schedule_timeblock_market(scheduled_date, time_block, market_type)
        
        if existing_record:
            # Check if data has changed using provider mapping
            if self._has_exchange_data_changed_with_mapping(existing_record, new_item, mapping_config):
                logger.debug("Data changed for market_type: %s - will replace with REPLACED flag", market_type)
                return UpdatedFlag.REPLACED
            else:
                # Data not changed - check if flag needs to change from UPDATED to OLD
                if existing_record.get("updated_flag") == UpdatedFlag.UPDATED:
                    logger.debug("Data unchanged, changing flag to OLD for market_type: %s", market_type)
                    return UpdatedFlag.OLD
                else:
                    # If already OLD or other status, skip upsert
                    logger.debug("Data unchanged and flag already appropriate for market_type: %s - skipping", market_type)
                    return None
        else:
            # New record
            logger.debug("New record for market_type: %s - will insert with UPDATED flag", market_type)
            return UpdatedFlag.UPDATED

    def _has_exchange_data_changed_with_mapping(self, existing_record: Dict[str, Any], new_record: Dict[str, Any], 
                                               mapping_config: Dict[str, Dict[str, Any]]) -> bool:
        """
        Check if exchange data has changed using provider mapping configuration
        
        Args:
            existing_record: Existing exchange record from database
            new_record: New exchange record from raw data
            mapping_config: Provider mapping configuration
            
        Returns:
            bool: True if data has changed
        """
        # Compare fields based on provider mapping configuration
        for serve_field, mapping_info in mapping_config.items():
            provider_field = mapping_info["provider_field"]
            field_type = mapping_info["field_type"]
            
            # Get existing value from database record
            existing_value = existing_record.get(serve_field)
            
            # Get new value from raw data using provider field
            new_raw_value = new_record.get(provider_field)
            
            # Convert new value based on field type
            new_value = self._convert_value_by_type(new_raw_value, field_type)
            
            # Compare values with appropriate tolerance
            if not self._compare_values_with_tolerance(existing_value, new_value, field_type):
                logger.debug("Field '%s' changed: %s -> %s (provider_field: %s)", 
                           serve_field, existing_value, new_value, provider_field)
                return True
        
        return False
    
    def _convert_value_by_type(self, value: Any, field_type: str) -> Any:
        """Convert value to appropriate type based on field type"""
        if field_type == "float":
            return ExchangeServeEntity._safe_float(value)
        elif field_type == "int":
            try:
                return int(ExchangeServeEntity._safe_float(value))
            except (ValueError, TypeError):
                return 0
        else:
            return value
    
    def _compare_values_with_tolerance(self, existing_value: Any, new_value: Any, field_type: str) -> bool:
        """Compare values with appropriate tolerance based on field type"""
        try:
            if field_type == "float":
                existing_float = float(existing_value or 0)
                new_float = float(new_value or 0)
                # Use different tolerances for price vs volume fields
                if "price" in str(existing_value).lower() or "mcp" in str(existing_value).lower() or "acp" in str(existing_value).lower():
                    tolerance = PRICE_COMPARISON_TOLERANCE
                else:
                    tolerance = FLOAT_COMPARISON_TOLERANCE
                return abs(existing_float - new_float) <= tolerance
            elif field_type == "int":
                existing_int = int(float(existing_value or 0))
                new_int = int(float(new_value or 0))
                return existing_int == new_int
            elif field_type == "string":
                return str(existing_value or "").strip() == str(new_value or "").strip()
            else:
                return existing_value == new_value
        except (ValueError, TypeError) as e:
            logger.warning("Error comparing values: %s", str(e))
            return False
    
    def _persist_exchange_entities(self, exchange_entities: List[ExchangeServeEntity], 
                                  provider_config: Dict[str, Any]) -> bool:
        """Persist exchange entities with atomic upsert operations"""
        if not exchange_entities:
            logger.info("No exchange entities to process (all records unchanged or invalid)")
            return True
        
        try:
            # Prepare entity records with validation
            entity_records = self._prepare_entity_records(exchange_entities, provider_config)
            if not entity_records:
                logger.warning("No valid entity records to upsert")
                return False
            
            # Perform atomic upsert with transaction safety
            upsert_result = self.repository.bulk_upsert_exchange_records(entity_records)
            
            if upsert_result.get("success"):
                self._log_upsert_results(upsert_result)
                return True
            else:
                logger.error("Bulk upsert failed: %s", upsert_result.get("error", "Unknown error"))
                return False
                
        except Exception as e:
            logger.error("Error persisting exchange entities: %s", str(e), exc_info=True)
            return False
    
    def _prepare_entity_records(self, entities: List[ExchangeServeEntity], 
                               provider_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Prepare entity records with validation"""
        valid_records = []
        
        for entity in entities:
            try:
                if hasattr(entity, 'model_dump_for_db'):
                    record = entity.model_dump_for_db(provider_config)
                else:
                    record = entity.model_dump(by_alias=True)
                
                # Validate record before adding
                if self._validate_upsert_record(record):
                    valid_records.append(record)
                else:
                    logger.warning("Skipping invalid entity record")
                    
            except Exception as e:
                logger.error("Error preparing entity record: %s", str(e))
                continue
        
        return valid_records
    
    def _validate_upsert_record(self, record: Dict[str, Any]) -> bool:
        """Validate record has required fields for upsert"""
        required_fields = ["scheduled_at", "time_block", "market_type"]
        return all(field in record and record[field] is not None for field in required_fields)
    
    def _log_upsert_results(self, result: Dict[str, Any]) -> None:
        """Log upsert operation results"""
        total_operations = result.get("inserted_count", 0) + result.get("replaced_count", 0)
        logger.info("Atomically processed %d exchange serve entities (%d inserted, %d replaced)", 
                   total_operations, result.get("inserted_count", 0), result.get("replaced_count", 0))
    
    def _build_exchange_record_with_mapping(self, raw_data: Dict[str, Any], time_block: int, 
                                           metadata: Dict[str, Any], provider_config: Dict[str, Any],
                                           mapping_config: Dict[str, Dict[str, Any]], updated_flag: UpdatedFlag) -> ExchangeServeEntity:
        """
        Build exchange record entity using provider mapping configuration
        
        Args:
            raw_data: Raw exchange data item
            time_block: Processed time block number (already converted to integer 1-96)
            metadata: Processing metadata (now includes raw_data_id)
            provider_config: Provider configuration
            mapping_config: Provider mapping configuration
            updated_flag: Updated flag to set
            
        Returns:
            ExchangeServeEntity: Built exchange entity
        """
        # Ensure time_block is an integer (should already be processed by caller)
        if not self._is_valid_timeblock(time_block):
            logger.error("Invalid time_block value: %s (type: %s)", time_block, type(time_block))
            raise ValueError(f"time_block must be an integer between {MIN_TIMEBLOCK}-{MAX_TIMEBLOCK}, got: {time_block}")
        
        # Create mapped raw data using provider mapping
        mapped_raw_data = self._apply_provider_mapping(raw_data, mapping_config)
        
        # Add processed time_block to mapped data for entity creation
        mapped_raw_data["time_block"] = time_block
        
        # Create entity using the from_raw_data class method
        entity = ExchangeServeEntity.from_raw_data(
            raw_data=mapped_raw_data,
            metadata=metadata,
            provider_config=provider_config
        )
        
        # Override the updated_flag with the determined value
        entity.updated_flag = updated_flag
        
        # Store raw_data_id instead of execution_id in the entity
        entity.raw_data_id = metadata.get("raw_data_id")
        
        return entity
    
    def _apply_provider_mapping(self, raw_data: Dict[str, Any], mapping_config: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Apply provider mapping to raw data
        
        Args:
            raw_data: Original raw data
            mapping_config: Provider mapping configuration
            
        Returns:
            Mapped raw data with serve field names
        """
        mapped_data = {}
        
        # Apply mappings from provider configuration
        for serve_field, mapping_info in mapping_config.items():
            provider_field = mapping_info["provider_field"]
            transformation = mapping_info["transformation"]
            field_type = mapping_info["field_type"]
            
            # Get value from raw data using provider field name
            if provider_field in raw_data:
                value = raw_data[provider_field]
                
                # Apply transformation if specified
                if transformation:
                    value = ExchangeServeEntity._apply_transformation(value, transformation)
                
                # Convert to appropriate type
                if field_type == "float":
                    value = ExchangeServeEntity._safe_float(value)
                elif field_type == "int":
                    try:
                        value = int(ExchangeServeEntity._safe_float(value))
                    except (ValueError, TypeError):
                        value = 0
                
                # Use serve field name in mapped data
                mapped_data[serve_field] = value
        
        # Add any unmapped fields that might be needed (like metadata)
        for key, value in raw_data.items():
            if key not in [mapping_info["provider_field"] for mapping_info in mapping_config.values()]:
                mapped_data[key] = value
        
        logger.debug("Applied provider mapping: %d fields mapped", len(mapping_config))
        return mapped_data
    
    def _build_exchange_historical_entity_with_mapping(self, raw_data: Dict[str, Any], time_block: int, 
                                                      metadata: Dict[str, Any], provider_config: Dict[str, Any],
                                                      mapping_config: Dict[str, Dict[str, Any]]) -> Optional[ExchangeHistoricalEntity]:
        """
        Build exchange historical entity using provider mapping configuration
        
        Args:
            raw_data: Raw exchange data item
            time_block: Processed time block number
            metadata: Processing metadata
            provider_config: Provider configuration
            mapping_config: Provider mapping configuration
            
        Returns:
            ExchangeHistoricalEntity: Built historical entity or None if invalid
        """
        try:
            # Ensure time_block is an integer
            if not self._is_valid_timeblock(time_block):
                logger.error("Invalid time_block value: %s (type: %s)", time_block, type(time_block))
                return None
            
            # Create mapped raw data using provider mapping
            mapped_raw_data = self._apply_provider_mapping(raw_data, mapping_config)
            
            # Add processed time_block to mapped data for entity creation
            mapped_raw_data["time_block"] = time_block
            
            # Create historical entity from mapped data
            historical_entity = ExchangeHistoricalEntity(**mapped_raw_data)
            
            # Set metadata fields
            historical_entity.execution_id = metadata.get("execution_id")
            historical_entity.raw_data_id = metadata.get("raw_data_id")
            historical_entity.updated_flag = UpdatedFlag.UPDATED
            
            return historical_entity
            
        except Exception as e:
            logger.error("Error building exchange historical entity: %s", str(e))
            return None
    
    def _persist_exchange_entities_with_routing(self, exchange_entities: List[ExchangeServeEntity], 
                                               historical_entities: List[ExchangeHistoricalEntity], 
                                               provider_config: Dict[str, Any]) -> bool:
        """Persist exchange entities with atomic upsert operations and historical routing"""
        serve_success = True
        historical_success = True
        
        # Process serve entities
        if exchange_entities:
            try:
                # Prepare entity records with validation
                entity_records = self._prepare_entity_records(exchange_entities, provider_config)
                if entity_records:
                    # Perform atomic upsert with transaction safety
                    upsert_result = self.repository.bulk_upsert_exchange_records(entity_records)
                    
                    if upsert_result.get("success"):
                        self._log_upsert_results(upsert_result)
                        serve_success = True
                    else:
                        logger.error("Bulk upsert failed: %s", upsert_result.get("error", "Unknown error"))
                        serve_success = False
                else:
                    logger.warning("No valid entity records to upsert")
                    serve_success = False
            except Exception as e:
                logger.error("Error persisting exchange entities: %s", str(e), exc_info=True)
                serve_success = False
        else:
            logger.info("No exchange serve entities to process (all records unchanged or invalid)")
        
        # Process historical entities
        if historical_entities:
            try:
                # Convert historical entities to records
                historical_records = []
                for entity in historical_entities:
                    try:
                        record = entity.model_dump(by_alias=True)
                        historical_records.append(record)
                    except Exception as e:
                        logger.error("Error converting historical entity to record: %s", str(e))
                        continue
                
                if historical_records:
                    # Insert into historical collection
                    self.repository.historical_collection.insert_many(historical_records)
                    logger.info("Processed and stored %d exchange historical entities", len(historical_records))
                else:
                    logger.warning("No valid historical records to insert")
                    historical_success = False
            except Exception as e:
                logger.error("Error inserting historical exchange entities: %s", str(e))
                historical_success = False
        else:
            logger.info("No exchange historical entities to process")
        
        return serve_success and historical_success

    async def execute_archival_job(self) -> Dict[str, Any]:
        """
        Execute exchange data archival as a separate cron job with its own correlation ID
        Moves data older than 4 days to historical collection
        """
        job_type = "exchange_data_archival"
        job_name = "Exchange Data Archival"
        schedule = "0 0 * * *"  # Daily at 12 AM
        start_time = datetime.now()
        
        # Generate and record job start to get execution_id (correlation ID)
        execution_id = self._record_job_execution(job_type, job_name, schedule, start_time, is_start=True)
        if not execution_id:
            logger.error("Failed to record job start for %s", job_type)
            return {
                "status": "error",
                "message": "Failed to record job start",
                "execution_time": 0.0,
                "data_type": "exchange"
            }
        
        # Set execution_id as correlation ID using base processor method
        self.set_correlation_id(execution_id)
        
        logger.info("=== EXECUTING EXCHANGE DATA ARCHIVAL JOB ===")
        
        try:
            # Archive old exchange data to keep a 4-day active window (day<=D-3 archived)
            archive_result = self.repository.archive_old_exchange_data()
            
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            if archive_result.get("error"):
                error_result = {
                    "status": "error",
                    "message": f"Exchange data archival error: {archive_result['error']}",
                    "execution_time": execution_time,
                    "data_type": "exchange",
                    "correlation_id": execution_id
                }
                
                self._record_job_execution(
                    job_type=job_type,
                    job_name=job_name,
                    schedule=schedule,
                    execution_start=start_time,
                    execution_end=end_time,
                    execution_id=execution_id,
                    status="error",
                    success=False,
                    result=error_result,
                    error_message=archive_result["error"],
                    is_start=False
                )
                
                logger.error("Exchange data archival failed: %s", archive_result["error"])
                return error_result
            else:
                archived_count = archive_result.get("archived_count", 0)
                success_result = {
                    "status": "success",
                    "message": f"Archived {archived_count} exchange records",
                    "execution_time": execution_time,
                    "archived_count": archived_count,
                    "cutoff_date": archive_result.get("cutoff_date"),
                    "data_type": "exchange",
                    "correlation_id": execution_id
                }
                
                self._record_job_execution(
                    job_type=job_type,
                    job_name=job_name,
                    schedule=schedule,
                    execution_start=start_time,
                    execution_end=end_time,
                    execution_id=execution_id,
                    status="success",
                    success=True,
                    result=success_result,
                    is_start=False
                )
                
                logger.info("Exchange data archival completed: %d records archived in %.2fs", 
                           archived_count, execution_time)
                return success_result
                
        except Exception as e:
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            error_result = {
                "status": "error",
                "message": f"Exchange data archival error: {str(e)}",
                "execution_time": execution_time,
                "data_type": "exchange",
                "correlation_id": execution_id
            }
            
            self._record_job_execution(
                job_type=job_type,
                job_name=job_name,
                schedule=schedule,
                execution_start=start_time,
                execution_end=end_time,
                execution_id=execution_id,
                status="error",
                success=False,
                result=error_result,
                error_message=str(e),
                is_start=False
            )
            
            logger.error("Error executing exchange data archival job: %s", str(e), exc_info=True)
            return error_result
        finally:
            # Clear correlation ID after job completion
            self.clear_correlation_id()

    def _record_job_execution(self, job_type: str, job_name: str, schedule: str, 
                             execution_start: datetime, execution_end: Optional[datetime] = None,
                             execution_id: Optional[str] = None, status: Optional[str] = None, 
                             success: Optional[bool] = None, result: Optional[Dict[str, Any]] = None,
                             error_message: Optional[str] = None, is_start: bool = True) -> Optional[str]:
        """
        Unified method for recording job start and completion in audit database
        Returns execution_id for start operations, None for completion operations
        """
        try:
            # Get the job_id (ObjectId) from job_data collection using job_type
            job_data = self.job_data_repository.get_job(job_type)
            if not job_data:
                logger.error("Job data not found for job_type: %s", job_type)
                return None
            
            job_id = job_data.get("_id")
            
            if is_start:
                # Generate unique execution ID for start
                if not execution_id:
                    execution_id = f"{job_type}_{execution_start.strftime('%Y%m%d_%H%M%S')}"

                job_detail = JobDetail(
                    job_id=str(job_id),
                    execution_id=execution_id,
                    job_name=job_name,
                    execution_start=execution_start,
                    execution_end=None,
                    status="running",
                    success=False,
                    result_data=None,
                    error_message=None,
                    service="scheduler",
                    duration_seconds=None,
                    error_details=None,
                    metadata=None
                )

                self.job_detail_repository.log_execution(job_detail)
                logger.info("Recorded job start for %s (job_type: %s, execution_id: %s) in audit database",
                           job_id, job_type, execution_id)
                return execution_id
            else:
                # Record job completion
                if not execution_id:
                    logger.error("Execution ID required for job completion recording")
                    return None

                # Calculate duration_seconds if both start and end are present
                duration_seconds = None
                if execution_start and execution_end:
                    duration_seconds = (execution_end - execution_start).total_seconds()

                job_detail = JobDetail(
                    job_id=str(job_id),
                    execution_id=execution_id,
                    job_name=job_name,
                    execution_start=execution_start,
                    execution_end=execution_end,
                    status=status or "completed",
                    success=success or False,
                    result_data=result,
                    error_message=error_message,
                    service="scheduler",
                    duration_seconds=duration_seconds,
                    error_details=None,
                    metadata=None
                )

                self.job_detail_repository.log_execution(job_detail)
                logger.info("Recorded job completion for %s (job_type: %s, execution_id: %s, status: %s) in audit database", 
                           job_id, job_type, execution_id, status)
                return None
                
        except Exception as e:
            logger.error("Error recording job execution for %s: %s", job_type, str(e), exc_info=True)
            return None