"""
Demand data processor for handling demand data processing logic.
"""

import logging
from datetime import datetime
from typing import Dict, List, Any, Optional

from .base_processor import BaseProcessor
from libs.models.demand_serve_entity import DemandServeEntity, DemandServeHistoricalEntity
from libs.enum.updated_flag import UpdatedFlag
from libs.core.job_entities import JobDetail
from ..repository.demand_serve_repository import demand_serve_repository
from ..repository.exchange_repository import ExchangeRepository

logger = logging.getLogger(__name__)


class DemandProcessor(BaseProcessor):
    """
    Demand data processor that handles demand data processing and storage.
    """
    
    def __init__(self):
        super().__init__()
        
        # Use the existing demand serve repository
        self.demand_repository = demand_serve_repository
        
        # Initialize exchange repository for fetching area prices
        self.exchange_repository = ExchangeRepository()
        
        # Initialize job repositories for execution tracking
        from libs.core.job_factory import create_job_data_repository, create_job_detail_repository
        from ..core.config import settings
        
        self.job_data_repository = create_job_data_repository(
            settings.AUDIT_DB_URI,
            settings.AUDIT_DB_NAME,
            settings.JOB_DATA_COLLECTION
        )
        self.job_detail_repository = create_job_detail_repository(
            settings.AUDIT_DB_URI,
            settings.AUDIT_DB_NAME,
            settings.JOB_DETAIL_COLLECTION
        )
    
    async def _fetch_exchange_data_for_dsm(self, scheduled_at: datetime, time_blocks: List[int]) -> Dict[str, Any]:
        """
        Fetch exchange data (RTM and DAM) for DSM calculation based on scheduled_at and time_blocks.
        
        Args:
            scheduled_at: The scheduled date for which to fetch exchange data
            time_blocks: List of time blocks to fetch data for
            
        Returns:
            Dict containing RTM and DAM area price data and ACP values
        """
        try:
            logger.info(f"Fetching exchange data for DSM calculation - scheduled_at: {scheduled_at}, time_blocks: {time_blocks}")
            
            # Fetch RTM data
            rtm_data = []
            dam_data = []
            acp_values = []
            
            for time_block in time_blocks:
                # Fetch RTM data
                rtm_query = {
                    "scheduled_at": scheduled_at,
                    "time_block": time_block,
                    "market_type": "RTM",  # IDF for RTM
                }
                rtm_records = self.exchange_repository.find_many(rtm_query)
                
                # Fetch DAM data
                dam_query = {
                    "scheduled_at": scheduled_at,
                    "time_block": time_block,
                    "market_type": "DAM",  # DAF for DAM
                }
                dam_records = self.exchange_repository.find_many(dam_query)
                
                # Process RTM data
                rtm_record = rtm_records[0] if rtm_records else {}
                rtm_w1 = rtm_record.get("acp", 0.0) or rtm_record.get("mcp", 0.0)
                rtm_data.append({
                    "W1": rtm_w1,  # Use ACP, fallback to MCP
                    "time_block": time_block
                })
                
                # Process DAM data
                dam_record = dam_records[0] if dam_records else {}
                dam_w1 = dam_record.get("acp", 0.0) or dam_record.get("mcp", 0.0)
                dam_data.append({
                    "W1": dam_w1,  # Use ACP, fallback to MCP
                    "time_block": time_block
                })
                
                # Debug logging for exchange data
                logger.debug(f"Exchange Data Debug - Time Block: {time_block}")
                logger.debug(f"RTM Records Found: {len(rtm_records)}, ACP: {rtm_record.get('acp')}, MCP: {rtm_record.get('mcp')}, W1: {rtm_w1}")
                logger.debug(f"DAM Records Found: {len(dam_records)}, ACP: {dam_record.get('acp')}, MCP: {dam_record.get('mcp')}, W1: {dam_w1}")
                
                # Get ACP for this time block (prefer RTM ACP, fallback to DAM ACP, then MCP)
                acp_value = 0.0
                if rtm_record.get("acp", 0) > 0:
                    acp_value = rtm_record.get("acp", 0)
                elif dam_record.get("acp", 0) > 0:
                    acp_value = dam_record.get("acp", 0)
                elif rtm_record.get("mcp", 0) > 0:
                    acp_value = rtm_record.get("mcp", 0)
                elif dam_record.get("mcp", 0) > 0:
                    acp_value = dam_record.get("mcp", 0)
                else:
                    acp_value = 100.0  # Default ACP if no data found
                
                acp_values.append(acp_value)
            
            logger.info(f"Fetched exchange data - RTM records: {len(rtm_data)}, DAM records: {len(dam_data)}")
            logger.info(f"ACP values: {acp_values}")
            
            return {
                "rtm_data": rtm_data,
                "dam_data": dam_data,
                "acp_values": acp_values
            }
            
        except Exception as e:
            logger.error(f"Error fetching exchange data for DSM calculation: {str(e)}")
            # Return empty data with default ACP
            return {
                "rtm_data": [],
                "dam_data": [],
                "acp_values": [100.0] * len(time_blocks)  # Default ACP
            }
    
    async def execute_cron_job(self) -> Dict[str, Any]:
        """
        Execute demand data processing as a cron job with correlation ID
        """
        job_type = "demand_data_processing"
        job_name = "Demand Data Processing"
        schedule = "*/15 * * * *"  # Default schedule
        start_time = datetime.now()
        
        # Generate and record job start to get execution_id (correlation ID)
        execution_id = self._record_job_start(job_type, job_name, schedule, start_time)
        if not execution_id:
            logger.error("Failed to record job start for %s", job_type)
            return {
                "status": "error",
                "message": "Failed to record job start",
                "execution_time": 0.0,
                "data_type": "demand"
            }
        
        # Set execution_id as correlation ID using base processor method
        self.set_correlation_id(execution_id)
        
        logger.info("=== EXECUTING DEMAND DATA PROCESSING JOB ===")
        
        try:
            # Create metadata for demand data processing with correlation ID
            metadata = {
                "data_type": "demand",
                "scraped_at": start_time,
                "source": "demand_processor_cron",
                "triggered_by": "cron_job",
                "execution_id": execution_id,
                "correlation_id": execution_id
            }
            
            # Process the metadata trigger
            success = await self.process_metadata_trigger(metadata)
            
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            # Record job completion
            result = {
                "status": "success" if success else "error",
                "message": "Demand data processed successfully" if success else "Demand data processing failed",
                "execution_time": execution_time,
                "data_type": "demand",
                "correlation_id": execution_id
            }
            
            self._record_job_completion(
                job_type=job_type,
                job_name=job_name,
                schedule=schedule,
                execution_start=start_time,
                execution_end=end_time,
                execution_id=execution_id,
                status=result["status"],
                success=success,
                result=result
            )
            
            if success:
                logger.info("Demand data processing completed successfully in %.2fs", execution_time)
            else:
                logger.error("Demand data processing failed after %.2fs", execution_time)
                
            return result
                
        except Exception as e:
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            error_result = {
                "status": "error",
                "message": f"Demand data processing error: {str(e)}",
                "execution_time": execution_time,
                "data_type": "demand",
                "correlation_id": execution_id
            }
            
            self._record_job_completion(
                job_type=job_type,
                job_name=job_name,
                schedule=schedule,
                execution_start=start_time,
                execution_end=end_time,
                execution_id=execution_id,
                status="error",
                success=False,
                result=error_result,
                error_message=str(e)
            )
            
            logger.error("Error executing demand data processing job: %s", str(e))
            return error_result
        finally:
            # Clear correlation ID after job completion
            self.clear_correlation_id()
    
    async def execute_archival_job(self) -> Dict[str, Any]:
        """
        Execute demand data archival as a separate cron job with its own correlation ID
        Moves data older than or equal to today-2 into historical (keeps yesterday,today,tomorrow in serve)
        """
        job_type = "demand_serve_archival"
        job_name = "Demand Data Archival"
        schedule = "0 2 * * *"  # Daily at 2 AM
        start_time = datetime.now()
        
        # Generate and record job start to get execution_id (correlation ID)
        execution_id = self._record_job_start(job_type, job_name, schedule, start_time)
        if not execution_id:
            logger.error("Failed to record job start for %s", job_type)
            return {
                "status": "error",
                "message": "Failed to record job start",
                "execution_time": 0.0,
                "data_type": "demand"
            }
        
        # Set execution_id as correlation ID using base processor method
        self.set_correlation_id(execution_id)
        
        logger.info("=== EXECUTING DEMAND DATA ARCHIVAL JOB ===")
        
        try:
            # Archive old demand data based on new 3-day active window (yesterday,today,tomorrow)
            archive_result = self.demand_repository.archive_old_demand_data(days_to_keep=2)
            
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            if archive_result.get("error"):
                error_result = {
                    "status": "error",
                    "message": f"Demand data archival error: {archive_result['error']}",
                    "execution_time": execution_time,
                    "data_type": "demand",
                    "correlation_id": execution_id
                }
                
                self._record_job_completion(
                    job_type=job_type,
                    job_name=job_name,
                    schedule=schedule,
                    execution_start=start_time,
                    execution_end=end_time,
                    execution_id=execution_id,
                    status="error",
                    success=False,
                    result=error_result,
                    error_message=archive_result["error"]
                )
                
                logger.error("Demand data archival failed: %s", archive_result["error"])
                return error_result
            else:
                archived_count = archive_result.get("archived_count", 0)
                success_result = {
                    "status": "success",
                    "message": f"Archived {archived_count} demand records",
                    "execution_time": execution_time,
                    "archived_count": archived_count,
                    "cutoff_date": archive_result.get("cutoff_date"),
                    "data_type": "demand",
                    "correlation_id": execution_id
                }
                
                self._record_job_completion(
                    job_type=job_type,
                    job_name=job_name,
                    schedule=schedule,
                    execution_start=start_time,
                    execution_end=end_time,
                    execution_id=execution_id,
                    status="success",
                    success=True,
                    result=success_result
                )
                
                logger.info("Demand data archival completed: %d records archived in %.2fs", 
                           archived_count, execution_time)
                return success_result
                
        except Exception as e:
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            error_result = {
                "status": "error",
                "message": f"Demand data archival error: {str(e)}",
                "execution_time": execution_time,
                "data_type": "demand",
                "correlation_id": execution_id
            }
            
            self._record_job_completion(
                job_type=job_type,
                job_name=job_name,
                schedule=schedule,
                execution_start=start_time,
                execution_end=end_time,
                execution_id=execution_id,
                status="error",
                success=False,
                result=error_result,
                error_message=str(e)
            )
            
            logger.error("Error executing demand data archival job: %s", str(e))
            return error_result
        finally:
            # Clear correlation ID after job completion
            self.clear_correlation_id()
    
    async def process_raw_data_to_serve(
        self, 
        raw_data: List[Dict[str, Any]], 
        metadata: Dict[str, Any],
        provider_config: Dict[str, Any]
    ) -> bool:
        """
        Process raw data and convert to demand serve entities for storage.
        Handles duplicates for time-series collections by keeping only the most recent data.
        
        Args:
            raw_data: List of raw data items to process
            metadata: Processing metadata
            provider_config: Provider configuration with schema and mapping
            
        Returns:
            bool: True if processing was successful
        """
        try:
            if not raw_data:
                logger.warning("No raw data provided for processing")
                return False

            logger.info(f"Processing {len(raw_data)} demand records for time-series collection")
            
            # Process demand calculations conditionally
            from libs.helpers.demand_calculations import process_demand_calculations_conditional, get_calculation_summary
            processed_data = process_demand_calculations_conditional(raw_data)
            
            # Log calculation summary
            calc_summary = get_calculation_summary(raw_data)
            logger.info(f"Demand calculation summary: {calc_summary}")
            
            # Fetch exchange data for DSM calculation
            scheduled_at = metadata.get("scheduled_at")
            if not scheduled_at:
                # Try to get scheduled_at from the first record
                scheduled_at = raw_data[0].get("scheduled_at") if raw_data else None
            
            if scheduled_at:
                # Extract time blocks from raw data, filtering out None values and ensuring they are integers
                time_blocks = []
                for record in raw_data:
                    time_block = record.get("time_block")
                    if time_block is not None and isinstance(time_block, int):
                        time_blocks.append(time_block)
                time_blocks = list(set(time_blocks))  # Remove duplicates
                
                if time_blocks:
                    logger.info(f"Fetching exchange data for DSM calculation - scheduled_at: {scheduled_at}, time_blocks: {time_blocks}")
                    exchange_data = await self._fetch_exchange_data_for_dsm(scheduled_at, time_blocks)
                    
                    # Process DSM calculations with exchange data
                    from libs.helpers.demand_calculations import process_dsm_calculations_conditional
                    processed_data = process_dsm_calculations_conditional(
                        processed_data, 
                        acp=exchange_data.get("acp_values", [100.0])[0] if exchange_data.get("acp_values") else 100.0,
                        cursor_areapricertm=exchange_data.get("rtm_data"),
                        cursor_areapricedam=exchange_data.get("dam_data")
                    )
                else:
                    logger.warning("No time blocks found in raw data, using default DSM calculation")
                    from libs.helpers.demand_calculations import process_dsm_calculations_conditional
                    processed_data = process_dsm_calculations_conditional(processed_data)
            else:
                logger.warning("No scheduled_at found, using default DSM calculation")
                from libs.helpers.demand_calculations import process_dsm_calculations_conditional
                processed_data = process_dsm_calculations_conditional(processed_data)
            
            demand_entities = []
            historical_entities = []

            # Create entities for all records
            for raw_record in processed_data:
                if not isinstance(raw_record, dict):
                    logger.warning("Skipping non-dict item in raw data")
                    continue

                try:
                    # Extract scheduled_at, time_block, and type for unique key
                    scheduled_at = raw_record.get("scheduled_at")
                    time_block = raw_record.get("time_block")
                    type_val = raw_record.get("type", "IDF")
                    
                    if not scheduled_at:
                        # Try alternative field names
                        scheduled_at = raw_record.get("timestamp") or raw_record.get("date_time")
                    
                    if not scheduled_at:
                        logger.warning("Skipping record without scheduled_at")
                        continue
                    
                    # Ensure scheduled_at is datetime
                    if isinstance(scheduled_at, str):
                        scheduled_at = datetime.fromisoformat(scheduled_at.replace('Z', '+00:00'))
                    elif not isinstance(scheduled_at, datetime):
                        logger.warning("Invalid scheduled_at format")
                        continue
                    
                    # Check if record already exists to determine updated flag
                    existing_record = self.demand_repository.find_by_unique_key(
                        scheduled_at=scheduled_at,
                        time_block=time_block,
                        type=type_val
                    )
                    
                    # Set appropriate updated flag based on whether record exists and if data changed
                    if existing_record:
                        if self._has_demand_data_changed(existing_record, raw_record):
                            # Data changed - create entity with preserved inserted_at
                            demand_entity = self._create_demand_entity_with_preserved_timestamps(
                                raw_record, metadata, provider_config, existing_record
                            )
                            if demand_entity:
                                demand_entity.updated_flag = UpdatedFlag.UPDATED
                                logger.debug(f"Data changed - evaluating routing for scheduled_at: {scheduled_at}, time_block: {time_block}, type: {type_val}")
                                # Route based on date rules
                                record_date = scheduled_at.date()
                                today_date = datetime.now().date()
                                day_diff = (today_date - record_date).days
                                if day_diff >= 3:
                                    # Historical only
                                    historical_entities.append(DemandServeHistoricalEntity(**demand_entity.model_dump(by_alias=True)))
                                else:
                                    # Serve insert
                                    demand_entities.append(demand_entity)
                                    # If yesterday, also push to historical
                                    if day_diff == 1:
                                        historical_entities.append(DemandServeHistoricalEntity(**demand_entity.model_dump(by_alias=True)))
                        else:
                            # Data not changed - check if flag needs to change from UPDATED to OLD
                            if existing_record.get("updated_flag") == UpdatedFlag.UPDATED:
                                # Create entity with preserved timestamps to update flag
                                demand_entity = self._create_demand_entity_with_preserved_timestamps(
                                    raw_record, metadata, provider_config, existing_record
                                )
                                if demand_entity:
                                    demand_entity.updated_flag = UpdatedFlag.OLD
                                    logger.debug(f"Data unchanged - evaluating routing for scheduled_at: {scheduled_at}, time_block: {time_block}, type: {type_val}")
                                    record_date = scheduled_at.date()
                                    today_date = datetime.now().date()
                                    day_diff = (today_date - record_date).days
                                    if day_diff >= 3:
                                        historical_entities.append(DemandServeHistoricalEntity(**demand_entity.model_dump(by_alias=True)))
                                    else:
                                        demand_entities.append(demand_entity)
                                        if day_diff == 1:
                                            historical_entities.append(DemandServeHistoricalEntity(**demand_entity.model_dump(by_alias=True)))
                            else:
                                # Already OLD, skip this record
                                logger.debug(f"Data unchanged and already OLD - skipping scheduled_at: {scheduled_at}, time_block: {time_block}, type: {type_val}")
                                continue
                    else:
                        # New record - create entity with new timestamps
                        demand_entity = self._create_demand_entity(raw_record, metadata, provider_config)
                        if demand_entity:
                            demand_entity.updated_flag = UpdatedFlag.UPDATED
                            logger.debug(f"New record - evaluating routing for scheduled_at: {scheduled_at}, time_block: {time_block}, type: {type_val}")
                            record_date = scheduled_at.date()
                            today_date = datetime.now().date()
                            day_diff = (today_date - record_date).days
                            if day_diff >= 3:
                                historical_entities.append(DemandServeHistoricalEntity(**demand_entity.model_dump(by_alias=True)))
                            else:
                                demand_entities.append(demand_entity)
                                if day_diff == 1:
                                    historical_entities.append(DemandServeHistoricalEntity(**demand_entity.model_dump(by_alias=True)))

                except Exception as entity_error:
                    logger.error("Error processing demand record: %s", str(entity_error))
                    continue

            if demand_entities:
                # Use bulk insert with deduplication for time-series collections
                result = self.demand_repository.bulk_insert_demand_serve_with_deduplication(demand_entities)
                
                logger.info("Processed demand serve entities - Total: %d, Inserted: %d, Duplicates Removed: %d, Errors: %d", 
                           result["total_processed"], result["inserted_count"], result["duplicates_removed"], result["error_count"])
                
                if result["errors"]:
                    logger.warning("Encountered %d errors during processing: %s", len(result["errors"]), result["errors"])
                serve_ok = result["error_count"] == 0
            else:
                logger.info("No demand entities to process (all records unchanged or skipped)")
                serve_ok = True

            hist_ok = True
            if historical_entities:
                try:
                    self.demand_repository.bulk_insert_demand_historical(historical_entities)
                except Exception as e:
                    hist_ok = False
                    logger.error("Error inserting historical demand entities: %s", str(e))

            return serve_ok and hist_ok

        except Exception as e:
            logger.error("Error processing raw data to serve: %s", str(e))
            return False
    
    def _create_demand_entity(
        self, 
        raw_item: Dict[str, Any], 
        metadata: Dict[str, Any], 
        provider_config: Dict[str, Any]
    ) -> Optional[DemandServeEntity]:
        """
        Create a DemandServeEntity from raw data item.
        
        Args:
            raw_item: Raw data item
            metadata: Processing metadata
            provider_config: Provider configuration
            
        Returns:
            DemandServeEntity or None if creation fails
        """
        try:
            provider_metadata = provider_config.get("metadata", {})
            # Extract scheduled_at from raw data
            scheduled_at = raw_item.get("scheduled_at")
            if not scheduled_at:
                # Try alternative field names
                scheduled_at = raw_item.get("timestamp") or raw_item.get("date_time")
            
            if not scheduled_at:
                logger.warning("No scheduled_at field found in raw data")
                return None
            
            # Ensure scheduled_at is datetime
            if isinstance(scheduled_at, str):
                scheduled_at = datetime.fromisoformat(scheduled_at.replace('Z', '+00:00'))
            elif not isinstance(scheduled_at, datetime):
                logger.warning("Invalid scheduled_at format")
                return None
            
            # Extract values for calculations
            actual = self._safe_float(raw_item.get("actual", 0.0))
            forecast = self._safe_float(raw_item.get("forecast", 0.0))
            rostering = self._safe_float(raw_item.get("rostering", 0.0))
            
            # Calculate demand metrics using libs helper function
            from libs.helpers.demand_calculations import calculate_demand_metrics
            calculated_metrics = calculate_demand_metrics(actual, forecast, rostering)
            
            # Create demand entity with mapped fields and calculated metrics
            demand_entity = DemandServeEntity(
                scheduled_at=scheduled_at,
                time_block=self._safe_int(raw_item.get("time_block")),
                type=raw_item.get("type", "IDF"),
                forecast=float(forecast),
                actual=float(actual) if actual is not None else None,
                schedule=self._safe_float(raw_item.get("schedule")),
                drawal=self._safe_float(raw_item.get("drawal")),
                frequency=self._safe_float(raw_item.get("frequency")),
                rostering=float(rostering),
                mape=float(calculated_metrics.get("mape", 0.0)),
                mpe=float(calculated_metrics.get("mpe", 0.0)),
                source_actual=str(raw_item.get("source_actual", "")),
                source_forecast=str(raw_item.get("source_forecast", "")),
                source_rostering=str(raw_item.get("source_rostering", "")),
                zone=raw_item.get("zone"),
                source=provider_metadata.get("source"),
                comp_act_demand=float(calculated_metrics.get("comp_act_demand", 0.0)),
                net_dsm_amount=self._safe_float(raw_item.get("net_dsm_amount", 0.0)),
                dsm_rate=self._safe_float(raw_item.get("dsm_rate", 0.0)),
                udm=self._safe_float(raw_item.get("udm", 0.0)),
                comp_udm=float(calculated_metrics.get("comp_udm", 0.0)),
                updated_flag=UpdatedFlag.UPDATED
            )
            
            return demand_entity
            
        except Exception as e:
            logger.error("Error creating demand entity: %s", str(e))
            return None
    
    def _create_demand_entity_with_preserved_timestamps(
        self, 
        raw_item: Dict[str, Any], 
        metadata: Dict[str, Any], 
        provider_config: Dict[str, Any],
        existing_record: Dict[str, Any]
    ) -> Optional[DemandServeEntity]:
        """
        Create a DemandServeEntity from raw data item with preserved timestamps from existing record.
        This ensures that updated records maintain their original inserted_at timestamp for proper deduplication.
        
        Args:
            raw_item: Raw data item
            metadata: Processing metadata
            provider_config: Provider configuration
            existing_record: Existing record to preserve timestamps from
            
        Returns:
            DemandServeEntity or None if creation fails
        """
        try:
            provider_metadata = provider_config.get("metadata", {})
            # Extract scheduled_at from raw data
            scheduled_at = raw_item.get("scheduled_at")
            if not scheduled_at:
                # Try alternative field names
                scheduled_at = raw_item.get("timestamp") or raw_item.get("date_time")
            
            if not scheduled_at:
                logger.warning("No scheduled_at field found in raw data")
                return None
            
            # Ensure scheduled_at is datetime
            if isinstance(scheduled_at, str):
                scheduled_at = datetime.fromisoformat(scheduled_at.replace('Z', '+00:00'))
            elif not isinstance(scheduled_at, datetime):
                logger.warning("Invalid scheduled_at format")
                return None
            
            # Extract values for calculations
            actual = self._safe_float(raw_item.get("actual", 0.0))
            forecast = self._safe_float(raw_item.get("forecast", 0.0))
            rostering = self._safe_float(raw_item.get("rostering", 0.0))
            
            # Calculate demand metrics using libs helper function
            from libs.helpers.demand_calculations import calculate_demand_metrics
            calculated_metrics = calculate_demand_metrics(actual, forecast, rostering)
            
            # Preserve timestamps from existing record
            current_time = datetime.now()
            inserted_at = existing_record.get("inserted_at", current_time)
            created_at = existing_record.get("created_at", current_time)
            
            # Create demand entity with mapped fields, calculated metrics, and preserved timestamps
            demand_entity = DemandServeEntity(
                scheduled_at=scheduled_at,
                time_block=self._safe_int(raw_item.get("time_block")),
                type=raw_item.get("type", "IDF"),
                forecast=float(forecast),
                actual=float(actual) if actual is not None else None,
                schedule=self._safe_float(raw_item.get("schedule")),
                drawal=self._safe_float(raw_item.get("drawal")),
                frequency=self._safe_float(raw_item.get("frequency")),
                rostering=float(rostering),
                mape=float(calculated_metrics.get("mape", 0.0)),
                mpe=float(calculated_metrics.get("mpe", 0.0)),
                source_actual=str(raw_item.get("source_actual", "")),
                source_forecast=str(raw_item.get("source_forecast", "")),
                source_rostering=str(raw_item.get("source_rostering", "")),
                zone=raw_item.get("zone"),
                source=provider_metadata.get("source"),
                comp_act_demand=float(calculated_metrics.get("comp_act_demand", 0.0)),
                net_dsm_amount=self._safe_float(raw_item.get("net_dsm_amount", 0.0)),
                dsm_rate=self._safe_float(raw_item.get("dsm_rate", 0.0)),
                udm=self._safe_float(raw_item.get("udm", 0.0)),
                comp_udm=float(calculated_metrics.get("comp_udm", 0.0)),
                updated_flag=UpdatedFlag.UPDATED,
                # Preserve original timestamps
                inserted_at=inserted_at,
                created_at=created_at,
                # Update these timestamps
                updated_at=current_time,
                timestamp=current_time
            )
            
            return demand_entity
            
        except Exception as e:
            logger.error("Error creating demand entity with preserved timestamps: %s", str(e))
            return None
    
    def _has_demand_data_changed(self, existing_record: Dict[str, Any], new_record: Dict[str, Any]) -> bool:
        """
        Check if demand data has changed by comparing key fields that exist in raw data
        
        Args:
            existing_record: Existing demand record from database
            new_record: New demand record from raw data
            
        Returns:
            bool: True if data has changed
        """
        # List of fields to compare for changes - only fields that exist in raw data
        # Exclude calculated fields like mape, mpe, comp_act_demand, comp_udm as they don't exist in raw data
        compare_fields = [
            "forecast", "actual", "schedule", "drawal", "frequency", "rostering",
            "net_dsm_amount", "dsm_rate", "udm", "zone", 
            "source_actual", "source_forecast", "source_rostering"
        ]
        
        for field in compare_fields:
            existing_value = existing_record.get(field)
            new_value = new_record.get(field)
            
            # Skip comparison if new_value is None (field doesn't exist in raw data)
            if new_value is None:
                continue
                
            # Handle None values and type conversions
            if existing_value != new_value:
                # Handle float comparison with tolerance
                if isinstance(existing_value, (int, float)) and isinstance(new_value, (int, float)):
                    if abs(float(existing_value) - float(new_value)) > 0.001:  # Small tolerance for float comparison
                        logger.debug(f"Data changed in field '{field}': existing={existing_value}, new={new_value}")
                        return True
                else:
                    logger.debug(f"Data changed in field '{field}': existing={existing_value}, new={new_value}")
                    return True
        
        return False


    @staticmethod
    def _safe_float(value: Any) -> float:
        """Safely convert value to float"""
        if value is None:
            return 0.0
        try:
            return float(value)
        except (ValueError, TypeError):
            return 0.0
    
    @staticmethod
    def _safe_int(value: Any) -> Optional[int]:
        """Safely convert value to int"""
        if value is None:
            return None
        try:
            return int(value)
        except (ValueError, TypeError):
            return None
    
    def _record_job_start(self, job_type: str, job_name: str, schedule: str, 
                         execution_start: datetime) -> Optional[str]:
        """Record job start in audit database and return execution_id"""
        try:
            # Get the job_id (ObjectId) from job_data collection using job_type
            job_data = self.job_data_repository.get_job(job_type)
            if not job_data:
                logger.error("Job data not found for job_type: %s", job_type)
                return None
            
            job_id = job_data.get("_id")
            
            # Generate unique execution ID
            execution_id = f"{job_type}_{execution_start.strftime('%Y%m%d_%H%M%S')}"

            job_detail = JobDetail(
                job_id=str(job_id),  # Convert ObjectId to string for storage
                execution_id=execution_id,
                job_name=job_name,
                execution_start=execution_start,
                execution_end=None,
                duration_seconds=None,
                status="running",
                success=False,  # Set to False for running jobs
                result_data=None,
                error_message=None,
                error_details=None,
                service="scheduler",
                metadata=None
            )

            self.job_detail_repository.log_execution(job_detail)
            logger.info("Recorded job start for %s (job_type: %s, execution_id: %s) in audit database",
                        job_id, job_type, execution_id)
            return execution_id
                
        except Exception as e:
            logger.error("Error recording job start: %s", str(e))
            return None

    def _record_job_completion(self, job_type: str, job_name: str, schedule: str, 
                              execution_start: datetime, execution_end: datetime,
                              execution_id: str, status: str, success: bool, 
                              result: Optional[Dict[str, Any]] = None,
                              error_message: Optional[str] = None):
        """Record job completion in audit database"""
        try:
            # Get the job_id (ObjectId) from job_data collection using job_type
            job_data = self.job_data_repository.get_job(job_type)
            if not job_data:
                logger.error("Job data not found for job_type: %s", job_type)
                return
            
            job_id = job_data.get("_id")

            # Calculate duration_seconds
            duration_seconds = None
            if execution_start and execution_end:
                duration_seconds = (execution_end - execution_start).total_seconds()

            job_detail = JobDetail(
                job_id=str(job_id),  # Convert ObjectId to string for storage
                execution_id=execution_id,  # Use the same execution_id from start
                job_name=job_name,
                execution_start=execution_start,
                execution_end=execution_end,
                duration_seconds=duration_seconds,
                status=status,
                success=success,
                result_data=result,
                error_message=error_message,
                error_details=None,
                service="scheduler",
                metadata=None
            )
            
            self.job_detail_repository.log_execution(job_detail)
            logger.info("Recorded job completion for %s (job_type: %s, execution_id: %s, status: %s) in audit database", 
                        job_id, job_type, execution_id, status)
                
        except Exception as e:
            logger.error("Error recording job completion: %s", str(e))