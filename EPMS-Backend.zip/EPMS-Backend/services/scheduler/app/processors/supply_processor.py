"""
Supply data processor for handling supply data processing logic with a two-stage flow.
1. Raw data is validated and stored in a staging collection (dc_sg).
2. Staged data is then processed into the final time-series collection (supply_serve).
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

from .base_processor import BaseProcessor
from libs.models.supply_serve_entity import SupplyServeEntity, SupplyServeHistoricalEntity
from libs.models.dc_sg_entity import DCSgEntity
from libs.enum.updated_flag import UpdatedFlag
from libs.core.job_entities import JobDetail
from ..repository.supply_serve_repository import supply_serve_repository
from ..repository.plant_repository import plant_repository
from ..repository.dc_sg_repository import dc_sg_repository
from ..core.config import settings

logger = logging.getLogger(__name__)


class SupplyProcessor(BaseProcessor):
    """
    Supply data processor that handles supply data processing and storage with a two-stage flow:
    1. raw_data -> dc_sg (staging collection)
    2. dc_sg -> supply_serve (time-series collection with 4-day rolling window)
    """

    def __init__(self):
        super().__init__()

        self.supply_repository = supply_serve_repository
        self.plant_repository = plant_repository
        self.dc_sg_repository = dc_sg_repository

        from libs.core.job_factory import create_job_data_repository, create_job_detail_repository

        self.job_data_repository = create_job_data_repository(
            settings.AUDIT_DB_URI,
            settings.AUDIT_DB_NAME,
            settings.JOB_DATA_COLLECTION
        )
        self.job_detail_repository = create_job_detail_repository(
            settings.AUDIT_DB_URI,
            settings.AUDIT_DB_NAME,
            settings.JOB_DETAIL_COLLECTION
        )

    async def execute_cron_job(self) -> Dict[str, Any]:
        """
        Execute supply data processing as a cron job with correlation ID
        """
        job_type = "supply_data_processing"
        job_name = "Supply Data Processing"
        schedule = "*/15 * * * *"  # Default schedule
        start_time = datetime.now()

        execution_id = self._record_job_start(job_type, job_name, schedule, start_time)
        if not execution_id:
            logger.error("Failed to record job start for %s", job_type)
            return {
                "status": "error",
                "message": "Failed to record job start",
                "execution_time": 0.0,
                "data_type": "supply"
            }

        self.set_correlation_id(execution_id)

        logger.info("=== EXECUTING SUPPLY DATA PROCESSING JOB ===")

        try:
            metadata = {
                "data_type": "supply",
                "scraped_at": start_time,
                "source": "supply_processor_cron",
                "triggered_by": "cron_job",
                "execution_id": execution_id,
                "correlation_id": execution_id
            }

            success = await self.process_metadata_trigger(metadata)

            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()

            result = {
                "status": "success" if success else "error",
                "message": "Supply data processed successfully" if success else "Supply data processing failed",
                "execution_time": execution_time,
                "data_type": "supply",
                "correlation_id": execution_id
            }

            self._record_job_completion(
                job_type=job_type,
                job_name=job_name,
                schedule=schedule,
                execution_start=start_time,
                execution_end=end_time,
                execution_id=execution_id,
                status=result["status"],
                success=success,
                result=result
            )

            return result

        except Exception as e:
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            error_result = {
                "status": "error",
                "message": f"Supply data processing error: {str(e)}",
                "execution_time": execution_time,
                "data_type": "supply",
                "correlation_id": execution_id
            }

            self._record_job_completion(
                job_type=job_type,
                job_name=job_name,
                schedule=schedule,
                execution_start=start_time,
                execution_end=end_time,
                execution_id=execution_id,
                status="error",
                success=False,
                result=error_result,
                error_message=str(e)
            )

            logger.error("Error executing supply data processing job: %s", str(e))
            return error_result
        finally:
            self.clear_correlation_id()

    def process_raw_data_to_serve(
        self,
        raw_data: List[Dict[str, Any]],
        metadata: Dict[str, Any],
        provider_config: Dict[str, Any]
    ) -> bool:
        """
        Process raw data through a two-stage flow:
        1. Raw data is staged in the 'dc_sg' collection.
        2. Staged data is processed into the 'supply_serve' collection.
        """
        try:
            if not raw_data:
                logger.warning("No raw data provided for processing.")
                return True

            logger.info(f"Starting two-stage supply processing for {len(raw_data)} raw records.")

            stage1_success = self._process_raw_data_to_dc_sg(raw_data, metadata, provider_config)
            if not stage1_success:
                logger.error("Stage 1 (raw_data -> dc_sg) failed. Aborting processing.")
                return False
            
            logger.info("Stage 1 (raw_data -> dc_sg) completed successfully.")

            stage2_success = self._process_dc_sg_to_supply_serve(metadata, provider_config)
            if not stage2_success:
                logger.error("Stage 2 (dc_sg -> supply_serve) failed.")
                return False

            logger.info("Stage 2 (dc_sg -> supply_serve) completed successfully.")

            return True

        except Exception as e:
            logger.error(f"Error in the main supply processing pipeline: {str(e)}")
            return False

    def _process_raw_data_to_dc_sg(
        self,
        raw_data: List[Dict[str, Any]],
        metadata: Dict[str, Any],
        provider_config: Dict[str, Any]
    ) -> bool:
        """
        Validates raw data and upserts it into the 'dc_sg' staging collection.
        """
        logger.info(f"Stage 1: Processing {len(raw_data)} raw records into dc_sg collection.")
        processed_count = 0
        skipped_count = 0
        
        for raw_record in raw_data:
            if not isinstance(raw_record, dict):
                logger.warning("Skipping non-dict item in raw data.")
                skipped_count += 1
                continue

            try:
                dc_sg_entity = self._create_dc_sg_entity_from_raw(raw_record, metadata, provider_config)
                
                if not dc_sg_entity:
                    skipped_count += 1
                    continue
                
                result = self.dc_sg_repository.update_or_insert_record(dc_sg_entity)
                if result.upserted_id or result.modified_count > 0:
                    processed_count += 1
                else:
                    skipped_count += 1

            except Exception as e:
                logger.error(f"Error processing a raw record for dc_sg staging: {str(e)}")
                skipped_count += 1
                continue
        
        logger.info(f"Stage 1 finished. Processed: {processed_count}, Skipped/Unchanged: {skipped_count}")
        return True

    def _create_dc_sg_entity_from_raw(
        self,
        raw_item: Dict[str, Any],
        metadata: Dict[str, Any],
        provider_config: Dict[str, Any]
    ) -> Optional[DCSgEntity]:
        """
        Creates a DCSgEntity from a raw data item, performing necessary validations.
        """
        try:
            provider_metadata = provider_config.get("metadata", {})
            
            scheduled_at = raw_item.get("scheduled_at") or raw_item.get("timestamp") or raw_item.get("date_time")
            if not scheduled_at:
                logger.warning(f"Skipping record due to missing 'scheduled_at'. Fields: {list(raw_item.keys())}")
                return None
            
            if isinstance(scheduled_at, str):
                scheduled_at = datetime.fromisoformat(scheduled_at.replace('Z', '+00:00'))
            elif not isinstance(scheduled_at, datetime):
                logger.warning(f"Invalid 'scheduled_at' format: {type(scheduled_at)}")
                return None

            plant_id = raw_item.get("plant_id")
            if not plant_id:
                logger.warning("Skipping record due to missing 'plant_id'.")
                return None
            
            plant_entity = self.plant_repository.find_one({"plant_id": str(plant_id)})
            if not plant_entity:
                logger.warning(f"Plant ID '{plant_id}' not found in plant master. Skipping record.")
                return None

            dc_sg = raw_item.get("dc_sg")
            if not dc_sg:
                logger.warning("Skipping record due to missing 'dc_sg'.")
                return None

            return DCSgEntity(
                scheduled_at=scheduled_at,
                time_block=self._safe_int(raw_item.get("time_block")),
                dc_sg=str(dc_sg),
                plant_id=str(plant_id),
                volume=self._safe_float(raw_item.get("volume")),
                fc_price=self._safe_float(raw_item.get("fc_price")),
                px_price=self._safe_float(raw_item.get("px_price")),
                vc_price=self._safe_float(raw_item.get("vc_price")),
                price_group=raw_item.get("price_group"),
                tm=self._safe_float(raw_item.get("tm", 0.0)),
                multiplier=str(raw_item.get("multiplier", "")),
                ramping=str(raw_item.get("ramping", "")),
                source=provider_metadata.get("source"),
            )
        except Exception as e:
            logger.error(f"Error creating DCSgEntity from raw data: {str(e)}")
            return None

    def _process_dc_sg_to_supply_serve(
        self,
        metadata: Dict[str, Any],
        provider_config: Dict[str, Any]
    ) -> bool:
        """
        Processes data from the 'dc_sg' staging collection into the 'supply_serve' collection.
        """
        logger.info("Stage 2: Processing staged data from dc_sg to supply_serve.")
        
        staged_records = self.dc_sg_repository.get_all_records()
        if not staged_records:
            logger.info("No staged records in dc_sg to process into supply_serve.")
            return True
        
        logger.info(f"Found {len(staged_records)} records in dc_sg to process.")

        try:
            today = datetime.now().date()
            supply_window_dates = [
                today - timedelta(days=2),
                today - timedelta(days=1),
                today,
                today + timedelta(days=1)
            ]
            three_days_ago = today - timedelta(days=3)

            logger.info(f"4-day supply window dates: {supply_window_dates}")
            
            self._cleanup_old_data(three_days_ago)

            supply_entities = []
            historical_entities = []
            processed_count = 0
            skipped_count = 0

            for staged_record in staged_records:
                try:
                    scheduled_at = staged_record["scheduled_at"]
                    record_date = scheduled_at.date()
                    today_date = datetime.now().date()
                    day_diff = (today_date - record_date).days

                    if record_date not in supply_window_dates and day_diff < 3:
                        logger.debug(f"Skipping record outside supply window: {record_date}")
                        skipped_count += 1
                        continue
                    
                    time_block = staged_record.get("time_block")
                    dc_sg = staged_record.get("dc_sg")
                    plant_id = staged_record.get("plant_id")

                    existing_supply_record = self.supply_repository.find_by_unique_key(
                        scheduled_at=scheduled_at,
                        time_block=time_block,
                        dc_sg=str(dc_sg),
                        plant_id=str(plant_id)
                    )
                    
                    supply_entity = None
                    if existing_supply_record:
                        if self._has_supply_data_changed(existing_supply_record, staged_record):
                            supply_entity = self._create_supply_entity_with_preserved_timestamps(staged_record, metadata, provider_config, existing_supply_record)
                            if supply_entity:
                                supply_entity.updated_flag = UpdatedFlag.UPDATED
                        else:
                            if existing_supply_record.get("updated_flag") == UpdatedFlag.UPDATED:
                                supply_entity = self._create_supply_entity_with_preserved_timestamps(staged_record, metadata, provider_config, existing_supply_record)
                                if supply_entity:
                                    supply_entity.updated_flag = UpdatedFlag.OLD
                            else:
                                skipped_count += 1
                                continue
                    else:
                        supply_entity = self._create_supply_entity_from_staged(staged_record, metadata, provider_config)
                        if supply_entity:
                            supply_entity.updated_flag = UpdatedFlag.UPDATED
                    
                    if not supply_entity:
                        skipped_count += 1
                        continue

                    if day_diff >= 3:
                        historical_entities.append(SupplyServeHistoricalEntity(**supply_entity.model_dump(by_alias=True)))
                    else:
                        supply_entities.append(supply_entity)
                        if day_diff >= 1:
                            historical_entities.append(SupplyServeHistoricalEntity(**supply_entity.model_dump(by_alias=True)))
                    
                    processed_count += 1

                except Exception as entity_error:
                    logger.error(f"Error processing a staged record: {str(entity_error)}")
                    continue

            serve_success = self._bulk_process_supply_entities(supply_entities, len(staged_records), processed_count, skipped_count)
            historical_success = self._bulk_process_historical_entities(historical_entities)
            
            return serve_success and historical_success

        except Exception as e:
            logger.error(f"Error in Stage 2 processing from dc_sg to supply_serve: {str(e)}")
            return False

    def _bulk_process_supply_entities(self, entities: List[SupplyServeEntity], total_raw: int, processed: int, skipped: int) -> bool:
        if not entities:
            logger.info("No new or updated supply serve records to process.")
            return True
        
        result = self.supply_repository.bulk_insert_supply_serve_with_deduplication(entities)
        logger.info(
            "Processed supply entities - Total: %d, Processed: %d, Skipped: %d, Inserted: %d, Duplicates Removed: %d, Errors: %d",
            total_raw, processed, skipped, result.get("inserted_count", 0),
            result.get("duplicates_removed", 0), result.get("error_count", 0)
        )
        return result.get("error_count", 0) == 0

    def _bulk_process_historical_entities(self, entities: List[SupplyServeHistoricalEntity]) -> bool:
        if not entities:
            logger.info("No historical supply records to process.")
            return True
        
        try:
            self.supply_repository.bulk_insert_supply_historical(entities)
            logger.info(f"Successfully stored {len(entities)} supply historical entities.")
            return True
        except Exception as hist_error:
            logger.error(f"Error inserting historical supply entities: {str(hist_error)}")
            return False

    def _create_supply_entity_from_staged(
        self,
        staged_item: Dict[str, Any],
        metadata: Dict[str, Any],
        provider_config: Dict[str, Any]
    ) -> Optional[SupplyServeEntity]:
        try:
            provider_metadata = provider_config.get("metadata", {})
            return SupplyServeEntity(
                scheduled_at=staged_item["scheduled_at"],
                time_block=staged_item.get("time_block"),
                dc_sg=staged_item.get("dc_sg"),
                volume=staged_item.get("volume"),
                fc_price=staged_item.get("fc_price"),
                px_price=staged_item.get("px_price"),
                vc_price=staged_item.get("vc_price"),
                price_group=staged_item.get("price_group"),
                tm=staged_item.get("tm", 0.0),
                multiplier=staged_item.get("multiplier", ""),
                ramping=staged_item.get("ramping", ""),
                updated_flag=UpdatedFlag.UPDATED,
                plant_id=staged_item.get("plant_id"),
                source=provider_metadata.get("source"),
            )
        except Exception as e:
            logger.error(f"Error creating new SupplyServeEntity from staged data: {str(e)}")
            return None

    def _create_supply_entity_with_preserved_timestamps(
        self,
        staged_item: Dict[str, Any],
        metadata: Dict[str, Any],
        provider_config: Dict[str, Any],
        existing_record: Dict[str, Any]
    ) -> Optional[SupplyServeEntity]:
        try:
            provider_metadata = provider_config.get("metadata", {})
            return SupplyServeEntity(
                scheduled_at=staged_item["scheduled_at"],
                time_block=staged_item.get("time_block"),
                dc_sg=staged_item.get("dc_sg"),
                plant_id=staged_item.get("plant_id"),
                volume=staged_item.get("volume"),
                fc_price=staged_item.get("fc_price"),
                px_price=staged_item.get("px_price"),
                vc_price=staged_item.get("vc_price"),
                price_group=staged_item.get("price_group", ""),
                tm=staged_item.get("tm"),
                multiplier=staged_item.get("multiplier", ""),
                ramping=staged_item.get("ramping", ""),
                inserted_at=existing_record.get("inserted_at", datetime.now()),
                created_at=existing_record.get("created_at", datetime.now()),
                updated_at=datetime.now(),
                timestamp=datetime.now(),
                source=provider_metadata.get("source", "manual"),
            )
        except Exception as e:
            logger.error(f"Error creating updated SupplyServeEntity from staged data: {str(e)}")
            return None

    def _cleanup_old_data(self, supply_cutoff_date):
        """
        Clean up old data from supply_serve collection by moving to historical
        """
        try:
            self._move_old_supply_data_to_historical(supply_cutoff_date)
        except Exception as e:
            logger.error("Error cleaning up old data: %s", str(e))

    def _move_old_supply_data_to_historical(self, cutoff_date):
        """
        Move data older than cutoff_date from supply_serve to supply_serve_historical
        """
        try:
            cutoff_datetime = datetime.combine(cutoff_date, datetime.min.time())
            
            old_records = self.supply_repository.find_supply_serve_by_date_range(
                start_date=datetime.min,
                end_date=cutoff_datetime
            )
            
            if not old_records:
                return

            logger.info(f"Found {len(old_records)} old supply records to move to historical (before {cutoff_date})")
            
            historical_entities = [SupplyServeHistoricalEntity(**record, archived_at=datetime.now()) for record in old_records]
            
            if historical_entities:
                self.supply_repository.bulk_insert_supply_historical(historical_entities)
                self.supply_repository.delete_supply_serve_by_date(cutoff_datetime)
            
        except Exception as e:
            logger.error("Error moving old supply data to historical: %s", str(e))

    def _has_supply_data_changed(self, existing_record: Dict[str, Any], new_record: Dict[str, Any]) -> bool:
        """
        Check if supply data has changed by comparing key fields
        """
        compare_fields = [
            "volume", "fc_price", "px_price", "vc_price", "price_group", 
            "tm", "multiplier", "ramping"
        ]
        
        for field in compare_fields:
            existing_value = existing_record.get(field)
            new_value = new_record.get(field)
            
            if new_value is None:
                continue
            
            if isinstance(existing_value, (int, float)) and isinstance(new_value, (int, float)):
                if abs(float(existing_value) - float(new_value)) > 1e-9:
                    return True
            elif str(existing_value) != str(new_value):
                return True
        
        return False

    @staticmethod
    def _safe_float(value: Any) -> float:
        if value is None: return 0.0
        try: return float(value)
        except (ValueError, TypeError): return 0.0
    
    @staticmethod
    def _safe_int(value: Any) -> Optional[int]:
        if value is None: return None
        try: return int(value)
        except (ValueError, TypeError): return None
    
    def _record_job_start(self, job_type: str, job_name: str, schedule: str, 
                         execution_start: datetime) -> Optional[str]:
        """Record job start in audit database and return execution_id"""
        try:
            # Get the job_id (ObjectId) from job_data collection using job_type
            job_data = self.job_data_repository.get_job(job_type)
            if not job_data:
                logger.error("Job data not found for job_type: %s", job_type)
                return None
            
            job_id = job_data.get("_id")
            
            # Generate unique execution ID
            execution_id = f"{job_type}_{execution_start.strftime('%Y%m%d_%H%M%S')}"

            job_detail = JobDetail(
                job_id=str(job_id),  # Convert ObjectId to string for storage
                execution_id=execution_id,
                job_name=job_name,
                execution_start=execution_start,
                execution_end=None,
                duration_seconds=None,
                status="running",
                success=False,  # Set to False for running jobs
                result_data=None,
                error_message=None,
                error_details=None,
                service="scheduler",
                metadata=None
            )

            self.job_detail_repository.log_execution(job_detail)
            logger.info("Recorded job start for %s (job_type: %s, execution_id: %s) in audit database",
                        job_id, job_type, execution_id)
            return execution_id
                
        except Exception as e:
            logger.error("Error recording job start: %s", str(e))
            return None

    def _record_job_completion(self, job_type: str, job_name: str, schedule: str, 
                              execution_start: datetime, execution_end: datetime,
                              execution_id: str, status: str, success: bool, 
                              result: Optional[Dict[str, Any]] = None,
                              error_message: Optional[str] = None):
        """Record job completion in audit database"""
        try:
            # Get the job_id (ObjectId) from job_data collection using job_type
            job_data = self.job_data_repository.get_job(job_type)
            if not job_data:
                logger.error("Job data not found for job_type: %s", job_type)
                return
            
            job_id = job_data.get("_id")

            # Calculate duration_seconds
            duration_seconds = None
            if execution_start and execution_end:
                duration_seconds = (execution_end - execution_start).total_seconds()

            job_detail = JobDetail(
                job_id=str(job_id),  # Convert ObjectId to string for storage
                execution_id=execution_id,  # Use the same execution_id from start
                job_name=job_name,
                execution_start=execution_start,
                execution_end=execution_end,
                duration_seconds=duration_seconds,
                status=status,
                success=success,
                result_data=result,
                error_message=error_message,
                error_details=None,
                service="scheduler",
                metadata=None
            )
            
            self.job_detail_repository.log_execution(job_detail)
            logger.info("Recorded job completion for %s (job_type: %s, execution_id: %s, status: %s) in audit database", 
                        job_id, job_type, execution_id, status)
                
        except Exception as e:
            logger.error("Error recording job completion: %s", str(e))

    async def execute_archival_job(self) -> Dict[str, Any]:
        """
        Execute supply data archival as a separate cron job.
        """
        job_type = "supply_serve_archival"
        job_name = "Supply Data Archival"
        schedule = "0 2 * * *"
        start_time = datetime.now()
        
        execution_id = self._record_job_start(job_type, job_name, schedule, start_time)
        if not execution_id:
            return {"status": "error", "message": "Failed to record job start"}
        
        self.set_correlation_id(execution_id)
        
        logger.info("=== EXECUTING SUPPLY DATA ARCHIVAL JOB ===")
        
        try:
            archive_result = self.supply_repository.archive_old_supply_data()
            
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            if archive_result.get("error"):
                raise Exception(archive_result["error"])

            success_result = {
                "status": "success",
                "message": f"Archived {archive_result.get('archived_count', 0)} supply records",
                "execution_time": execution_time,
                **archive_result
            }
            
            self._record_job_completion(
                job_type, job_name, schedule, start_time, end_time,
                execution_id, "success", True, success_result
            )
            return success_result
                
        except Exception as e:
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            error_result = {
                "status": "error",
                "message": f"Supply data archival error: {str(e)}",
                "execution_time": execution_time,
            }
            
            self._record_job_completion(
                job_type, job_name, schedule, start_time, end_time,
                execution_id, "error", False, error_result, str(e)
            )
            return error_result
        finally:
            self.clear_correlation_id()
