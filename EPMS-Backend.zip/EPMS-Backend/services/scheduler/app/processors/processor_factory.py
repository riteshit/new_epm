"""
Processor factory for creating appropriate processor instances based on data type.
"""

import logging
from typing import Optional

from .base_processor import BaseProcessor
from .exchange_processor import ExchangeProcessor
from .bid_processor import BidProcessor
from .weather_processor import WeatherProcessor
from .demand_processor import DemandProcessor
from .supply_processor import SupplyProcessor

logger = logging.getLogger(__name__)


class ProcessorFactory:
    """
    Factory class for creating processor instances based on data type.
    """
    
    @staticmethod
    def create_processor(data_type: str) -> Optional[BaseProcessor]:
        """
        Create and return the appropriate processor instance based on data type.
        
        Args:
            data_type: The type of data to process (weather, bid, exchange, demand, supply)
            
        Returns:
            BaseProcessor instance or None if data_type is not supported
        """
        try:
            data_type_lower = data_type.lower().strip()
            
            if data_type_lower == "exchange":
                return ExchangeProcessor()
            elif data_type_lower == "bid":
                return BidProcessor()
            elif data_type_lower == "weather":
                return WeatherProcessor()
            elif data_type_lower == "demand":
                return DemandProcessor()
            elif data_type_lower == "supply":
                return SupplyProcessor()
            else:
                logger.error(f"Unsupported data type: {data_type}")
                return None
                
        except Exception as e:
            logger.error(f"Error creating processor for data type '{data_type}': {str(e)}")
            return None
    
    @staticmethod
    def get_supported_data_types() -> list:
        """
        Get list of supported data types.
        
        Returns:
            List of supported data type strings
        """
        return ["exchange", "bid", "weather", "demand", "supply"]
    
    @staticmethod
    def is_supported_data_type(data_type: str) -> bool:
        """
        Check if a data type is supported.
        
        Args:
            data_type: The data type to check
            
        Returns:
            bool: True if supported, False otherwise
        """
        return data_type.lower().strip() in ProcessorFactory.get_supported_data_types()