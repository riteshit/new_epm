"""
Bid Trade Serve Repository
Handles database operations for bid trade serve data with timeseries support
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from bson import ObjectId

from libs.database.base_serve_repository import BaseServeRepository
from libs.models.bid_trade_serve_entity import BidTradeServeEntity, BidTradeServeHistoricalEntity
from ..core.config import settings

logger = logging.getLogger(__name__)


class BidTradeServeRepository(BaseServeRepository):
    """Repository for bid trade serve data operations with timeseries support"""
    
    def __init__(self):
        """Initialize the bid trade serve repository"""
        super().__init__(
            mongodb_uri=settings.MONGODB_URI,
            database_name=settings.MONGODB_DATABASE,
            serve_collection=settings.MONGODB_BID_TRADE_SERVE_COLLECTION,
            historical_collection=settings.MONGODB_BID_TRADE_SERVE_HISTORICAL_COLLECTION
        )
        self._ensure_bid_timeseries_collections()
    
    def _ensure_bid_timeseries_collections(self):
        """Create bid timeseries collections if they don't exist"""
        try:
            # Create bid_trade_serve as time series collection
            if "bid_trade_serve" not in self.db.list_collection_names():
                self.db.create_collection(
                    "bid_trade_serve",
                    timeseries={
                        "timeField": "timestamp",
                        "metaField": "data_type",
                        "granularity": "hours",
                    },
                )
                logger.info("Created time series collection: bid_trade_serve")

            # Create bid_trade_serve_historical as time series collection
            if "bid_trade_serve_historical" not in self.db.list_collection_names():
                self.db.create_collection(
                    "bid_trade_serve_historical",
                    timeseries={
                        "timeField": "archived_timestamp",
                        "metaField": "data_type",
                        "granularity": "hours",
                    },
                )
                logger.info("Created time series collection: bid_trade_serve_historical")

        except Exception as e:
            logger.error("Could not create bid timeseries collections: %s", str(e))
            logger.info("Using regular collections with timestamp indexes")
    
    def bulk_insert(self, bid_data: List[Any]) -> int:
        """
        Bulk insert bid trade serve data
        
        Args:
            bid_data: List of bid trade data (entities or dictionaries)
            
        Returns:
            Number of inserted documents
            
        Raises:
            DataInsertionError: If data insertion fails
        """
        try:
            if not bid_data:
                logger.info("No bid trade data to insert")
                return 0
                
            # Use the base repository's bulk insert method
            return self.bulk_insert_serve(bid_data)
            
        except Exception as e:
            error_msg = f"Error bulk inserting bid trade serve data: {str(e)}"
            logger.error(error_msg, exc_info=True)
            from libs.database.base_serve_repository import DataInsertionError
            if isinstance(e, DataInsertionError):
                raise
            raise DataInsertionError(error_msg) from e
    
    def find_by_schedule_timeblock_type(self, scheduled_at: datetime, time_block: int, bid_type: str) -> Optional[Dict[str, Any]]:
        """
        Find bid trade record by scheduled_at, time_block, and type
        
        Args:
            scheduled_at: Scheduled datetime
            time_block: Time block number
            bid_type: Bid type (DAM, GDAM, RTM, TAM)
            
        Returns:
            Bid trade record or None
        """
        try:
            # Convert datetime to date for comparison (since we're comparing dates)
            scheduled_date = scheduled_at.date() if hasattr(scheduled_at, 'date') else scheduled_at
            
            # Query with date range to handle datetime comparison
            start_of_day = datetime.combine(scheduled_date, datetime.min.time())
            end_of_day = datetime.combine(scheduled_date, datetime.max.time())
            
            query = {
                "scheduled_at": {"$gte": start_of_day, "$lte": end_of_day},
                "time_block": time_block,
                "type": bid_type
            }
            
            return self.serve_collection.find_one(query)
        except Exception as e:
            logger.error(f"Error finding bid trade record: {str(e)}")
            return None
    
    def delete_by_id(self, record_id: str) -> bool:
        """
        Delete bid trade record by ID string
        
        Args:
            record_id: Record ID to delete
            
        Returns:
            True if deleted successfully
        """
        try:
            result = self.serve_collection.delete_one({"_id": ObjectId(record_id)})
            return result.deleted_count > 0
        except Exception as e:
            logger.error(f"Error deleting bid trade record {record_id}: {str(e)}")
            return False
    
    def archive_old_bid_data(self, days_to_keep: int = 2) -> Dict[str, Any]:
        """
        Archive bid data older than specified days based on scheduled_at date
        
        This implements the 4-day rolling window logic:
        - Keep: today, tomorrow, yesterday, day before yesterday in serve collections
        - Archive: everything else to historical collections
        
        Args:
            days_to_keep: Number of days to keep in active collection (default: 4)
            
        Returns:
            Dictionary with archive results
        """
        try:
            from datetime import timedelta
            
            today = datetime.now().date()
            cutoff_date = today - timedelta(days=days_to_keep)
            
            records_to_archive = []
            records_to_delete = []
            
            # Find records to archive based on scheduled_at date
            records_to_archive = []
            records_to_delete = []
            
            # Get all records and filter by scheduled_at date
            all_records = list(self.serve_collection.find({}))
            
            for record in all_records:
                scheduled_at = record.get("scheduled_at")
                if scheduled_at:
                    # Convert to date for comparison
                    if isinstance(scheduled_at, datetime):
                        scheduled_date = scheduled_at.date()
                    else:
                        # Handle string dates if any
                        scheduled_date = datetime.fromisoformat(str(scheduled_at)).date()
                    
                    # Archive if scheduled date is older than cutoff
                    if scheduled_date < today:
                        records_to_archive.append(record)
                    if scheduled_date < cutoff_date:
                        records_to_delete.append(record)
            
            if not records_to_archive:
                logger.info("No bid records found to archive")

            if not records_to_delete:
                logger.info("No bid records found to delete")

            # Prepare records for historical collection
            historical_records = []
            record_ids_to_delete = []
            record_ids_to_archieve = []
            
            for record in records_to_archive:
                record_ids_to_archieve.append(record["_id"])

            existing_records = list(self.historical_collection.find({"_id": {"$in": record_ids_to_archieve}}))

            for record in records_to_archive:
                if record["_id"] not in existing_records:
                # Create historical record
                    historical_record = dict(record)
                    historical_record["archived_at"] = datetime.now()
                    historical_record["archived_timestamp"] = datetime.now()
                    historical_records.append(historical_record)
            
            for record in records_to_delete:
                record_ids_to_delete.append(record["_id"])
            
            # Insert into historical collection
            if historical_records:
                self.historical_collection.insert_many(historical_records)
                logger.info(f"Archived {len(historical_records)} bid records to historical collection")
            
            # Delete from active collection
            delete_result = self.serve_collection.delete_many({
                "_id": {"$in": record_ids_to_delete}
            })
            
            logger.info(f"Archived {len(historical_records)} bid records older than {days_to_keep} days")
            
            return {
                "archived_count": len(historical_records),
                "deleted_count": delete_result.deleted_count,
                "cutoff_date": cutoff_date.isoformat()
            }
            
        except Exception as e:
            logger.error("Error archiving old bid data: %s", str(e))
            return {"archived_count": 0, "deleted_count": 0, "error": str(e)}