"""
Repository for peak_demand_serve time series collection.
"""

import logging
from datetime import datetime
from typing import Dict, Any
from pymongo import MongoClient

from libs.database.base_serve_repository import BaseServeRepository
from libs.models.peak_demand_serve_entity import PeakDemandServeEntity
from services.scheduler.app.core.config import settings

logger = logging.getLogger(__name__)


class PeakDemandRepository(BaseServeRepository):
    """Repository managing peak_demand_serve collection with timeseries config."""

    def __init__(self):
        super().__init__(
            mongodb_uri=settings.MONGODB_URI,
            database_name=settings.MONGODB_DATABASE,
            serve_collection="peak_demand_serve",
            historical_collection="peak_demand_serve_historical",
        )

        try:
            if "peak_demand_serve" not in self.db.list_collection_names():
                self.db.create_collection(
                    "peak_demand_serve",
                    timeseries={
                        "timeField": "timestamp",
                        "metaField": None,
                        "granularity": "minutes",
                    },
                    expireAfterSeconds=None,
                )
                logger.info("Created time series collection: peak_demand_serve")
            if "peak_demand_serve_historical" not in self.db.list_collection_names():
                self.db.create_collection(
                    "peak_demand_serve_historical",
                    timeseries={
                        "timeField": "timestamp",
                        "metaField": None,
                        "granularity": "minutes",
                    },
                    expireAfterSeconds=None,
                )
                logger.info("Created time series collection: peak_demand_serve_historical")
            # helpful indexes
            self.serve_collection.create_index("scheduled_at")
            self.serve_collection.create_index("created_at")
            self.serve_collection.create_index("timestamp")
        except Exception as e:
            logger.error("Error ensuring peak_demand_serve timeseries: %s", e)

    def insert_one(self, entity: PeakDemandServeEntity) -> Dict[str, Any]:
        """Insert a single peak demand entity."""
        data = entity.model_dump(by_alias=True)
        result = self.serve_collection.insert_one(data)
        return {"inserted_id": str(result.inserted_id)}


