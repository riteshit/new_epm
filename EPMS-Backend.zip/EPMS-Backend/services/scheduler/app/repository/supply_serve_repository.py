"""
Scheduler Supply Serve Repository
Handles database operations for supply serve and historical collections
"""

import logging
from datetime import datetime
from typing import Dict, Any, List, Optional

from libs.database.base_serve_repository import BaseServeRepository
from libs.models import SupplyServeEntity, SupplyServeHistoricalEntity
from ..core.config import settings

logger = logging.getLogger(__name__)


class SupplyServeRepository(BaseServeRepository):
    """Repository for supply serve and historical collections"""
    
    def __init__(self):
        """Initialize the repository with MongoDB connection"""
        super().__init__(
            mongodb_uri=settings.MONGODB_URI,
            database_name=settings.MONGODB_DATABASE,
            serve_collection=settings.MONGODB_SUPPLY_SERVE_COLLECTION,
            historical_collection=settings.MONGODB_SUPPLY_SERVE_HISTORICAL_COLLECTION
        )
        self._ensure_time_series_collections()
    

    def _ensure_time_series_collections(self):
        """Create time-series collections if they don't exist"""
        try:
            # Create supply_serve as time-series collection
            if settings.MONGODB_SUPPLY_SERVE_COLLECTION not in self.db.list_collection_names():
                self.db.create_collection(
                    settings.MONGODB_SUPPLY_SERVE_COLLECTION,
                    timeseries={
                        "timeField": "timestamp",
                        "metaField": "scheduled_at",
                        "granularity": "hours",
                    },
                )
                logger.info(
                    "Created time-series collection: %s",
                    settings.MONGODB_SUPPLY_SERVE_COLLECTION,
                )

            # Create supply_serve_historical as time-series collection
            if settings.MONGODB_SUPPLY_SERVE_HISTORICAL_COLLECTION not in self.db.list_collection_names():
                self.db.create_collection(
                    settings.MONGODB_SUPPLY_SERVE_HISTORICAL_COLLECTION,
                    timeseries={
                        "timeField": "archived_timestamp",
                        "metaField": "scheduled_at",
                        "granularity": "hours",
                    },
                )
                logger.info(
                    "Created time-series collection: %s",
                    settings.MONGODB_SUPPLY_SERVE_HISTORICAL_COLLECTION,
                )

            # Get the collections after creation
            self.serve_collection = self.db[settings.MONGODB_SUPPLY_SERVE_COLLECTION]
            self.historical_collection = self.db[settings.MONGODB_SUPPLY_SERVE_HISTORICAL_COLLECTION]
            
        except (ConnectionError, TimeoutError) as e:
            logger.info("Could not create time-series collections: %s", str(e))
            logger.info("Using regular collections with timestamp indexes")
        except Exception as e:
            logger.error("Error creating time-series collections: %s", str(e))
            logger.info("Using regular collections with timestamp indexes")
    
    def insert_supply_serve(self, supply_serve: SupplyServeEntity) -> str:
        """
        Insert a new supply serve record
        
        Args:
            supply_serve: Supply serve entity to insert
            
        Returns:
            str: ID of the inserted record
        """
        return self.insert_serve(supply_serve)
    
    def insert_supply_historical(self, supply_historical: SupplyServeHistoricalEntity) -> str:
        """
        Insert a new supply historical record
        
        Args:
            supply_historical: Supply historical entity to insert
            
        Returns:
            str: ID of the inserted record
        """
        return self.insert_historical(supply_historical)
    
    def delete_supply_serve_by_date(self, scheduled_at: datetime) -> Dict[str, Any]:
        """
        Delete supply serve records by scheduled_at date
        
        Args:
            scheduled_at: Schedule date to delete records for
            
        Returns:
            Dict[str, Any]: Dictionary containing the number of records deleted and the deleted records
        """
        return self.delete_serve_by_date(scheduled_at)
    
    def find_supply_serve_by_date(self, scheduled_at: datetime) -> List[Dict[str, Any]]:
        """
        Find supply serve records by scheduled_at date
        
        Args:
            scheduled_at: Schedule date to find records for
            
        Returns:
            List of records found
        """
        return self.find_serve_by_date(scheduled_at)
    
    def find_supply_serve_by_date_range(self, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        """
        Find supply serve records by date range
        
        Args:
            start_date: Start date
            end_date: End date
            
        Returns:
            List of records found
        """
        return self.find_serve_by_date_range(start_date, end_date)
    
    def count_supply_serve(self) -> int:
        """
        Count total supply serve records
        
        Returns:
            int: Total number of records
        """
        return self.count_serve()
    
    def count_supply_historical(self) -> int:
        """
        Count total supply historical records
        
        Returns:
            int: Total number of records
        """
        return self.count_historical()

    def bulk_insert_supply_serve(self, entities: List[SupplyServeEntity]) -> List[str]:
        """
        Bulk insert supply serve records
        
        Args:
            entities: List of supply serve entities to insert
            
        Returns:
            List of inserted record IDs
        """
        result = self.bulk_insert_serve(entities)
        if isinstance(result, int):
            # If the underlying method returns an int (e.g., count), convert to list of str
            return [str(result)]
        elif isinstance(result, list):
            # If the underlying method returns a list of ObjectIds or strings
            return [str(_id) for _id in result]
        else:
            # Fallback: wrap in a list as string
            return [str(result)]

    def bulk_insert_supply_historical(self, entities: List[SupplyServeHistoricalEntity]) -> List[str]:
        """
        Bulk insert supply historical records
        
        Args:
            entities: List of supply historical entities to insert
            
        Returns:
            List of inserted record IDs
        """
        return self.bulk_insert_historical(entities)

    def delete_insert_supply_serve(self, filter_criteria: Dict[str, Any], entities: List[SupplyServeEntity]) -> Dict[str, Any]:
        """
        Delete existing supply serve records by filter criteria and insert new ones
        This method implements a delete-insert pattern suitable for time-series data
        
        Args:
            filter_criteria: MongoDB query criteria for deletion (can include multiple filters)
                          Examples:
                          - {"scheduled_at": datetime(2025, 1, 15)}  # Single date
                          - {"scheduled_at": {"$gte": start_date, "$lt": end_date}}  # Date range
                          - {"time_block": 1, "plant_id": "PLANT001"}  # Multiple criteria
                          - {"plant_name": "Thermal Plant A", "scheduled_at": {"$gte": start_date}}  # Mixed criteria
            entities: List of new supply serve entities to insert
            
        Returns:
            Dict[str, Any]: Dictionary containing operation results
        """
        try:
            # First, find existing records matching criteria
            existing_records = list(self.serve_collection.find(filter_criteria))
            
            # Delete existing records matching criteria
            delete_result = self.serve_collection.delete_many(filter_criteria)
            deleted_count = delete_result.deleted_count
            
            logger.info(f"Deleted {deleted_count} existing supply serve records matching criteria: {filter_criteria}")
            
            # Insert new entities
            inserted_ids = []
            if entities:
                inserted_ids = self.bulk_insert_supply_serve(entities)
                logger.info(f"Inserted {len(inserted_ids)} new supply serve records")
            
            return {
                "deleted_count": deleted_count,
                "inserted_count": len(inserted_ids),
                "deleted_records": existing_records,
                "inserted_ids": inserted_ids,
                "filter_criteria": filter_criteria
            }
            
        except Exception as e:
            logger.error(f"Error in delete-insert operation with criteria {filter_criteria}: {str(e)}")
            raise

    def find_by_unique_key(self, scheduled_at: datetime, time_block: Optional[int], 
                          dc_sg: str, plant_id: str) -> Optional[Dict[str, Any]]:
        """
        Find supply record by unique key (scheduled_at, time_block, dc_sg, plant_id)
        
        Args:
            scheduled_at: Schedule date and time
            time_block: Time block identifier
            dc_sg: DC/SG type
            plant_id: Plant ID
            
        Returns:
            Existing record or None if not found
        """
        try:
            filter_criteria = {
                "scheduled_at": scheduled_at,
                "dc_sg": dc_sg,
                "plant_id": plant_id
            }
            
            # Add time_block if it's not None
            if time_block is not None:
                filter_criteria["time_block"] = time_block
            
            # Find the most recent record with this unique key
            record = self.serve_collection.find_one(filter_criteria, sort=[("inserted_at", -1)])
            
            if record:
                logger.debug(f"Found existing supply record for key: {filter_criteria}")
            else:
                logger.debug(f"No existing supply record found for key: {filter_criteria}")
            
            return record
            
        except Exception as e:
            logger.error("Error finding supply record by unique key: %s", str(e))
            return None

    def archive_old_supply_data(self, days_to_keep: int = 2) -> Dict[str, Any]:
        try:
            from datetime import timedelta
            
            today = datetime.now().date()
            cutoff_date = today - timedelta(days=days_to_keep)
            
            records_to_archive = []
            records_to_delete = []
            
            all_records = list(self.serve_collection.find({}))
            
            for record in all_records:
                scheduled_at = record.get("scheduled_at")
                if scheduled_at:
                    # Convert to date for comparison
                    if isinstance(scheduled_at, datetime):
                        scheduled_date = scheduled_at.date()
                    else:
                        # Handle string dates if any
                        scheduled_date = datetime.fromisoformat(str(scheduled_at)).date()
                    
                    # Archive if scheduled date is older than cutoff
                    if scheduled_date < today:
                        records_to_archive.append(record)
                    if scheduled_date < cutoff_date:
                        records_to_delete.append(record)
            
            if not records_to_archive:
                logger.info("No supply records found to archive")

            if not records_to_delete:
                logger.info("No supply records found to delete")
            
            # Prepare records for historical collection
            historical_records = []
            record_ids_to_delete = []
            
            record_ids_to_archieve = []

            for record in records_to_archive:
                record_ids_to_archieve.append(record["_id"])

            existing_records = list(self.historical_collection.find({"_id": {"$in": record_ids_to_archieve}}))

            for record in records_to_archive:
                if record["_id"] not in existing_records:
                # Create historical record
                    historical_record = dict(record)
                    historical_record["archived_at"] = datetime.now()
                    historical_record["archived_timestamp"] = datetime.now()
                    historical_records.append(historical_record)
            
            for record in records_to_delete:
                record_ids_to_delete.append(record["_id"])
            
            # Insert into historical collection
            if historical_records:
                self.historical_collection.insert_many(historical_records)
                logger.info(f"Archived {len(historical_records)} supply records to historical collection")
            
            # Delete from active collection
            delete_result = self.serve_collection.delete_many({
                "_id": {"$in": record_ids_to_delete}
            })
            
            logger.info(f"Archived {len(historical_records)} supply records older than {days_to_keep} days")
            
            return {
                "archived_count": len(historical_records),
                "deleted_count": delete_result.deleted_count,
                "cutoff_date": cutoff_date.isoformat()
            }
            
        except Exception as e:
            logger.error("Error archiving old supply data: %s", str(e))
            return {"archived_count": 0, "deleted_count": 0, "error": str(e)}
    
    def delete_all_by_unique_key(self, scheduled_at: datetime, time_block: Optional[int], 
                                dc_sg: str, plant_id: str) -> int:
        """
        Delete ALL records for a unique key (used when replacing records)
        
        Args:
            scheduled_at: Schedule date and time
            time_block: Time block identifier
            dc_sg: DC/SG type
            plant_id: Plant ID
            
        Returns:
            int: Number of records deleted
        """
        try:
            filter_criteria = {
                "scheduled_at": scheduled_at,
                "dc_sg": dc_sg,
                "plant_id": plant_id
            }
            
            # Add time_block if it's not None
            if time_block is not None:
                filter_criteria["time_block"] = time_block
            
            # Delete all records matching the criteria
            result = self.serve_collection.delete_many(filter_criteria)
            deleted_count = result.deleted_count
            
            if deleted_count > 0:
                logger.debug(f"Deleted {deleted_count} supply records for key: {filter_criteria}")
            
            return deleted_count
            
        except Exception as e:
            logger.error("Error deleting supply records for key %s: %s", filter_criteria, str(e))
            return 0
    
    def bulk_insert_supply_serve_with_deduplication(self, entities: List[SupplyServeEntity]) -> Dict[str, Any]:
        """
        Bulk insert supply serve entities with deduplication based on unique key.
        This method groups entities by unique key and ensures only one record per key.
        
        Args:
            entities: List of SupplyServeEntity objects to insert
            
        Returns:
            Dict containing insertion results
        """
        try:
            if not entities:
                return {
                    "inserted_count": 0,
                    "duplicates_removed": 0,
                    "error_count": 0,
                    "errors": []
                }
            
            # Group entities by unique key (scheduled_at, time_block, dc_sg, plant_id)
            unique_keys = {}
            for entity in entities:
                key = (entity.scheduled_at, entity.time_block, entity.dc_sg, entity.plant_id)
                if key not in unique_keys:
                    unique_keys[key] = []
                unique_keys[key].append(entity)
            
            inserted_count = 0
            duplicates_removed = 0
            error_count = 0
            errors = []
            
            logger.info(f"Processing {len(entities)} entities with {len(unique_keys)} unique keys")
            
            # Process each unique key
            for (scheduled_at, time_block, dc_sg, plant_id), entity_list in unique_keys.items():
                try:
                    # Sort entities by inserted_at (most recent first)
                    entity_list.sort(key=lambda x: x.inserted_at, reverse=True)
                    
                    # Keep only the most recent entity for this unique key
                    entity_to_insert = entity_list[0]
                    
                    # Remove any existing records for this key (we're replacing them)
                    removed_count = self.delete_all_by_unique_key(
                        scheduled_at=scheduled_at,
                        time_block=time_block,
                        dc_sg=dc_sg,
                        plant_id=plant_id
                    )
                    duplicates_removed += removed_count
                    
                    # Insert the new entity
                    entity_dict = entity_to_insert.model_dump(by_alias=True)
                    result = self.serve_collection.insert_one(entity_dict)
                    
                    if result.inserted_id:
                        inserted_count += 1
                        logger.debug(f"Inserted supply record for key: {scheduled_at}, {time_block}, {dc_sg}, {plant_id}")
                    
                except Exception as key_error:
                    error_count += 1
                    error_msg = f"Error processing key {scheduled_at}, {time_block}, {dc_sg}, {plant_id}: {str(key_error)}"
                    errors.append(error_msg)
                    logger.error(error_msg)
            
            total_processed = inserted_count + error_count
            
            logger.info("Bulk insert with deduplication completed: %d total, %d inserted, %d duplicates removed, %d errors", 
                       total_processed, inserted_count, duplicates_removed, error_count)
            
            return {
                "inserted_count": inserted_count,
                "duplicates_removed": duplicates_removed,
                "error_count": error_count,
                "errors": errors
            }
            
        except Exception as e:
            logger.error("Error in bulk insert with deduplication: %s", str(e))
            return {
                "inserted_count": 0,
                "duplicates_removed": 0,
                "error_count": 1,
                "errors": [str(e)]
            }

# Create repository instance
supply_serve_repository = SupplyServeRepository()
