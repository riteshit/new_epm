"""
Scheduler DC SG Repository
Handles database operations for the dc_sg collection
"""

import logging
from datetime import datetime
from typing import Dict, Any, List, Optional

from pymongo.results import UpdateResult

from libs.database.base_repository import BaseRepository
from libs.models.dc_sg_entity import DCSgEntity
from ..core.config import settings

logger = logging.getLogger(__name__)


class DcSgRepository(BaseRepository):
    """Repository for the dc_sg collection"""

    def __init__(self):
        """Initialize the repository with MongoDB connection"""
        super().__init__(
            mongodb_uri=settings.MONGODB_URI,
            database_name=settings.MONGODB_DATABASE,
            collection_name="dc_sg"  # Collection name
        )

    def find_by_unique_key(self, scheduled_at: datetime, time_block: Optional[int],
                           dc_sg: str, plant_id: str) -> Optional[Dict[str, Any]]:
        """
        Find a record by its unique key (scheduled_at, time_block, dc_sg, plant_id)

        Args:
            scheduled_at: Schedule date and time
            time_block: Time block identifier
            dc_sg: DC/SG type
            plant_id: Plant ID

        Returns:
            Existing record or None if not found
        """
        try:
            filter_criteria = {
                "scheduled_at": scheduled_at,
                "dc_sg": dc_sg,
                "plant_id": plant_id
            }

            if time_block is not None:
                filter_criteria["time_block"] = time_block

            record = self.collection.find_one(filter_criteria)

            if record:
                logger.debug(f"Found existing dc_sg record for key: {filter_criteria}")
            else:
                logger.debug(f"No existing dc_sg record found for key: {filter_criteria}")

            return record

        except Exception as e:
            logger.error("Error finding dc_sg record by unique key: %s", str(e))
            return None

    def update_or_insert_record(self, entity: DCSgEntity) -> UpdateResult:
        """
        Update a record if it exists, otherwise insert a new one based on the unique key.

        Args:
            entity: The DCSgEntity to update or insert.

        Returns:
            The result of the update operation.
        """
        filter_criteria = {
            "scheduled_at": entity.scheduled_at,
            "time_block": entity.time_block,
            "dc_sg": entity.dc_sg,
            "plant_id": entity.plant_id
        }
        
        update_data = {"$set": entity.model_dump(by_alias=True, exclude_unset=True)}

        return self.collection.update_one(filter_criteria, update_data, upsert=True)

    def get_all_records(self) -> List[Dict[str, Any]]:
        """
        Retrieve all records from the dc_sg collection.

        Returns:
            A list of all records.
        """
        try:
            return list(self.collection.find({}))
        except Exception as e:
            logger.error("Error retrieving all records from dc_sg: %s", str(e))
            return []
            
    def delete_all_records(self) -> int:
        """
        Deletes all records from the dc_sg collection.

        Returns:
            The number of deleted records.
        """
        try:
            result = self.collection.delete_many({})
            logger.info(f"Deleted {result.deleted_count} records from dc_sg collection.")
            return result.deleted_count
        except Exception as e:
            logger.error("Error deleting all records from dc_sg: %s", str(e))
            return 0


# Create repository instance
dc_sg_repository = DcSgRepository()
