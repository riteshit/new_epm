"""
Scheduler Demand Serve Repository
Handles database operations for demand serve and historical collections
"""

import logging
from datetime import datetime
from typing import Dict, Any, List, Optional
from pymongo.errors import DuplicateKeyError

from libs.database.base_serve_repository import BaseServeRepository
from libs.models import DemandServeEntity, DemandServeHistoricalEntity
from ..core.config import settings

logger = logging.getLogger(__name__)


class DemandServeRepository(BaseServeRepository):
    """Repository for demand serve and historical collections"""
    
    def __init__(self):
        """Initialize the repository with MongoDB connection"""
        super().__init__(
            mongodb_uri=settings.MONGODB_URI,
            database_name=settings.MONGODB_DATABASE,
            serve_collection=settings.MONGODB_DEMAND_SERVE_COLLECTION,
            historical_collection=settings.MONGODB_DEMAND_SERVE_HISTORICAL_COLLECTION
        )
        # Ensure time-series collections are created
        self._ensure_time_series_collections()
        # Note: Time-series collections don't support unique indexes
        # We handle duplicates at the application level
    
    def _ensure_time_series_collections(self):
        """Create time-series collections if they don't exist"""
        try:
            # Create demand_serve as time-series collection
            if settings.MONGODB_DEMAND_SERVE_COLLECTION not in self.db.list_collection_names():
                self.db.create_collection(
                    settings.MONGODB_DEMAND_SERVE_COLLECTION,
                    timeseries={
                        "timeField": "timestamp",
                        "metaField": "schedule_date",
                        "granularity": "hours",
                    },
                )
                logger.info(
                    "Created time-series collection: %s",
                    settings.MONGODB_DEMAND_SERVE_COLLECTION,
                )

            # Create demand_serve_historical as time-series collection
            if settings.MONGODB_DEMAND_SERVE_HISTORICAL_COLLECTION not in self.db.list_collection_names():
                self.db.create_collection(
                    settings.MONGODB_DEMAND_SERVE_HISTORICAL_COLLECTION,
                    timeseries={
                        "timeField": "archived_timestamp",
                        "metaField": "schedule_date",
                        "granularity": "hours",
                    },
                )
                logger.info(
                    "Created time-series collection: %s",
                    settings.MONGODB_DEMAND_SERVE_HISTORICAL_COLLECTION,
                )

            # Get the collections after creation
            self.serve_collection = self.db[settings.MONGODB_DEMAND_SERVE_COLLECTION]
            self.historical_collection = self.db[settings.MONGODB_DEMAND_SERVE_HISTORICAL_COLLECTION]
            
        except (ConnectionError, TimeoutError) as e:
            logger.info("Could not create time-series collections: %s", str(e))
            logger.info("Using regular collections with timestamp indexes")
        except Exception as e:
            logger.error("Error creating time-series collections: %s", str(e))
            logger.info("Using regular collections with timestamp indexes")
    
    def find_by_unique_key(self, scheduled_at: datetime, time_block: Optional[int], type: str) -> Optional[Dict[str, Any]]:
        """
        Find demand serve record by unique key (scheduled_at, time_block, type)
        For time-series collections, we find the most recent record with this key
        
        Args:
            scheduled_at: Schedule date and time
            time_block: Time block identifier
            type: Market type (IDF/DAF)
            
        Returns:
            Dict[str, Any] or None if not found
        """
        try:
            filter_criteria = {
                "scheduled_at": scheduled_at,
                "type": type
            }
            
            # Only add time_block if it's not None
            if time_block is not None:
                filter_criteria["time_block"] = time_block
            
            # For time-series, find the most recent record (by inserted_at desc)
            record = self.serve_collection.find_one(
                filter_criteria,
                sort=[("inserted_at", -1)]  # Most recent first
            )
            
            if record:
                logger.debug("Found existing demand record for key: %s", filter_criteria)
            return record
        except Exception as e:
            logger.error("Error finding demand record by unique key: %s", str(e))
            return None
    
    def delete_duplicates_by_unique_key(self, scheduled_at: datetime, time_block: Optional[int], type: str) -> int:
        """
        Delete duplicate records for a unique key, keeping only the most recent one
        This is necessary for time-series collections since we can't use unique indexes
        
        Args:
            scheduled_at: Schedule date and time
            time_block: Time block identifier
            type: Market type (IDF/DAF)
            
        Returns:
            int: Number of duplicate records deleted
        """
        try:
            filter_criteria = {
                "scheduled_at": scheduled_at,
                "type": type
            }
            
            # Only add time_block if it's not None
            if time_block is not None:
                filter_criteria["time_block"] = time_block
            
            # Find all records with this unique key
            all_records = list(self.serve_collection.find(filter_criteria).sort("inserted_at", -1))
            
            if len(all_records) <= 1:
                return 0  # No duplicates
            
            # Keep the most recent record (first in sorted list)
            keep_record_id = all_records[0]["_id"]
            
            # Delete all others
            delete_filter = {
                **filter_criteria,
                "_id": {"$ne": keep_record_id}
            }
            
            result = self.serve_collection.delete_many(delete_filter)
            deleted_count = result.deleted_count
            
            if deleted_count > 0:
                logger.info(f"Deleted {deleted_count} duplicate records for key: {filter_criteria}")
            
            return deleted_count
            
        except Exception as e:
            logger.error("Error deleting duplicate records for key %s: %s", filter_criteria, str(e))
            return 0
    
    def delete_all_by_unique_key(self, scheduled_at: datetime, time_block: Optional[int], type: str) -> int:
        """
        Delete ALL records for a unique key (used when replacing records)
        
        Args:
            scheduled_at: Schedule date and time
            time_block: Time block identifier
            type: Market type (IDF/DAF)
            
        Returns:
            int: Number of records deleted
        """
        try:
            filter_criteria = {
                "scheduled_at": scheduled_at,
                "type": type
            }
            
            # Only add time_block if it's not None
            if time_block is not None:
                filter_criteria["time_block"] = time_block
            
            # Delete all records with this unique key
            result = self.serve_collection.delete_many(filter_criteria)
            deleted_count = result.deleted_count
            
            if deleted_count > 0:
                logger.info(f"Deleted {deleted_count} records for key: {filter_criteria}")
            
            return deleted_count
            
        except Exception as e:
            logger.error("Error deleting records for key %s: %s", filter_criteria, str(e))
            return 0
    
    def bulk_insert_demand_serve_with_deduplication(self, entities: List[DemandServeEntity]) -> Dict[str, Any]:
        """
        Bulk insert demand serve records with deduplication for time-series collections
        
        Args:
            entities: List of demand serve entities to insert
            
        Returns:
            Dict[str, Any]: Result containing operation details
        """
        try:
            if not entities:
                logger.info("No entities to insert")
                return {
                    "total_processed": 0,
                    "inserted_count": 0,
                    "duplicates_removed": 0,
                    "error_count": 0,
                    "errors": []
                }
            
            inserted_count = 0
            duplicates_removed = 0
            error_count = 0
            errors = []
            
            # Group entities by unique key for deduplication
            unique_keys = {}
            for entity in entities:
                key = (entity.scheduled_at, entity.time_block, entity.type)
                if key not in unique_keys:
                    unique_keys[key] = []
                unique_keys[key].append(entity)
            
            logger.info(f"Processing {len(entities)} entities with {len(unique_keys)} unique keys")
            
            # Process each unique key
            for (scheduled_at, time_block, type_val), entity_list in unique_keys.items():
                try:
                    # Sort entities by inserted_at (most recent first)
                    entity_list.sort(key=lambda x: x.inserted_at, reverse=True)
                    
                    # Keep only the most recent entity for this unique key
                    entity_to_insert = entity_list[0]
                    
                    # Remove any existing records for this key (we're replacing them)
                    removed_count = self.delete_all_by_unique_key(
                        scheduled_at=scheduled_at,
                        time_block=time_block,
                        type=type_val
                    )
                    duplicates_removed += removed_count
                    
                    # Insert the new entity
                    entity_dict = entity_to_insert.model_dump(by_alias=True)
                    result = self.serve_collection.insert_one(entity_dict)
                    
                    if result.inserted_id:
                        inserted_count += 1
                        logger.debug(f"Inserted demand record for key: {scheduled_at}, {time_block}, {type_val}")
                    
                except Exception as key_error:
                    error_count += 1
                    error_msg = f"Error processing key {scheduled_at}, {time_block}, {type_val}: {str(key_error)}"
                    errors.append(error_msg)
                    logger.error(error_msg)
            
            total_processed = inserted_count + error_count
            
            logger.info("Bulk insert with deduplication completed: %d total, %d inserted, %d duplicates removed, %d errors", 
                       total_processed, inserted_count, duplicates_removed, error_count)
            
            return {
                "total_processed": total_processed,
                "inserted_count": inserted_count,
                "duplicates_removed": duplicates_removed,
                "error_count": error_count,
                "errors": errors
            }
            
        except Exception as e:
            logger.error("Error in bulk insert with deduplication: %s", str(e))
            raise

    def insert_demand_serve(self, demand_serve: DemandServeEntity) -> str:
        """
        Insert a new demand serve record
        
        Args:
            demand_serve: Demand serve entity to insert
            
        Returns:
            str: ID of the inserted record
        """
        return self.insert_serve(demand_serve)
    
    def insert_demand_historical(self, demand_historical: DemandServeHistoricalEntity) -> str:
        """
        Insert a new demand historical record
        
        Args:
            demand_historical: Demand historical entity to insert
            
        Returns:
            str: ID of the inserted record
        """
        return self.insert_historical(demand_historical)
    
    def delete_demand_serve_by_date(self, scheduled_at: datetime) -> Dict[str, Any]:
        """
        Delete demand serve records by scheduled_at date
        
        Args:
            scheduled_at: Schedule date to delete records for
            
        Returns:
            Dict[str, Any]: Dictionary containing the number of records deleted and the deleted records
        """
        return self.delete_serve_by_date(scheduled_at)
    
    def find_demand_serve_by_date(self, scheduled_at: datetime) -> List[Dict[str, Any]]:
        """
        Find demand serve records by scheduled_at date
        
        Args:
            scheduled_at: Schedule date to find records for
            
        Returns:
            List of records found
        """
        return self.find_serve_by_date(scheduled_at)
    
    def find_demand_serve_by_date_range(self, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        """
        Find demand serve records by date range
        
        Args:
            start_date: Start date
            end_date: End date
            
        Returns:
            List of records found
        """
        return self.find_serve_by_date_range(start_date, end_date)
    
    def count_demand_serve(self) -> int:
        """
        Count total demand serve records
        
        Returns:
            int: Total number of records
        """
        return self.count_serve()
    
    def count_demand_historical(self) -> int:
        """
        Count total demand historical records
        
        Returns:
            int: Total number of records
        """
        return self.count_historical()

    def bulk_insert_demand_serve(self, entities: List[DemandServeEntity]) -> int:
        """
        Bulk insert demand serve records
        
        Args:
            entities: List of demand serve entities to insert
            
        Returns:
            int: Number of inserted records
        """
        return self.bulk_insert_serve(entities)

    def bulk_insert_demand_historical(self, entities: List[DemandServeHistoricalEntity]) -> List[str]:
        """
        Bulk insert demand historical records
        
        Args:
            entities: List of demand historical entities to insert
            
        Returns:
            List of inserted record IDs
        """
        return self.bulk_insert_historical(entities)

    def delete_by_id(self, record_id: str) -> bool:
        """
        Delete demand serve record by ID
        
        Args:
            record_id: MongoDB ObjectId as string
            
        Returns:
            bool: True if deletion was successful
        """
        try:
            from bson import ObjectId
            result = self.serve_collection.delete_one({"_id": ObjectId(record_id)})
            success = result.deleted_count > 0
            if success:
                logger.debug("Deleted demand record with ID: %s", record_id)
            else:
                logger.warning("No demand record found with ID: %s", record_id)
            return success
        except Exception as e:
            logger.error("Error deleting demand record by ID %s: %s", record_id, str(e))
            return False

    def delete_insert_demand_serve(self, filter_criteria: Dict[str, Any], entities: List[DemandServeEntity]) -> Dict[str, Any]:
        """
        Delete existing demand serve records by filter criteria and insert new ones
        This method implements a delete-insert pattern suitable for time-series data
        
        Args:
            filter_criteria: MongoDB query criteria for deletion (can include multiple filters)
                          Examples:
                          - {"scheduled_at": datetime(2025, 1, 15)}  # Single date
                          - {"scheduled_at": {"$gte": start_date, "$lt": end_date}}  # Date range
                          - {"time_block": 1, "type": "IDF"}  # Multiple criteria
                          - {"zone": "North", "scheduled_at": {"$gte": start_date}}  # Mixed criteria
            entities: List of new demand serve entities to insert
            
        Returns:
            Dict[str, Any]: Dictionary containing operation results
        """
        try:
            # First, find existing records matching criteria
            existing_records = list(self.serve_collection.find(filter_criteria))
            
            # Delete existing records matching criteria
            delete_result = self.serve_collection.delete_many(filter_criteria)
            deleted_count = delete_result.deleted_count
            
            logger.info(f"Deleted {deleted_count} existing demand serve records matching criteria: {filter_criteria}")
            
            # Insert new entities using bulk upsert (which will handle unique constraints)
            processed_count = 0
            if entities:
                processed_count = self.bulk_insert_demand_serve(entities)
                logger.info(f"Processed {processed_count} demand serve records (upserted/updated)")
            
            return {
                "deleted_count": deleted_count,
                "processed_count": processed_count,
                "deleted_records": existing_records,
                "filter_criteria": filter_criteria
            }
            
        except Exception as e:
            logger.error(f"Error in delete-insert operation with criteria {filter_criteria}: {str(e)}")
            raise

    def archive_old_demand_data(self, days_to_keep: int = 2) -> Dict[str, Any]:
        try:
            from datetime import timedelta
            
            today = datetime.now().date()
            cutoff_date = today - timedelta(days=days_to_keep)
            
            records_to_archive = []
            records_to_delete = []
            
            all_records = list(self.serve_collection.find({}))
            
            for record in all_records:
                scheduled_at = record.get("scheduled_at")
                if scheduled_at:
                    if isinstance(scheduled_at, datetime):
                        scheduled_date = scheduled_at.date()
                    else:
                        scheduled_date = datetime.fromisoformat(str(scheduled_at)).date()
                    
                    if scheduled_date < today:
                        records_to_archive.append(record)
                    if scheduled_date < cutoff_date:
                        records_to_delete.append(record)
            
            if not records_to_archive:
                logger.info("No demand records found to archive")

            if not records_to_delete:
                logger.info("No demand records found to delete")

            # Prepare records for historical collection
            historical_records = []
            record_ids_to_delete = []
            record_ids_to_archieve = []

            for record in records_to_archive:
                record_ids_to_archieve.append(record["_id"])

            existing_records = list(self.historical_collection.find({"_id": {"$in": record_ids_to_archieve}}))

            for record in records_to_archive:
                if record["_id"] not in existing_records:
                # Create historical record
                    historical_record = dict(record)
                    historical_record["archived_at"] = datetime.now()
                    historical_record["archived_timestamp"] = datetime.now()
                    historical_records.append(historical_record)
            
            for record in records_to_delete:
                record_ids_to_delete.append(record["_id"])
            
            if historical_records:
                self.historical_collection.insert_many(historical_records)
                logger.info(f"Archived {len(historical_records)} demand records to historical collection")
            
            delete_result = self.serve_collection.delete_many({
                "_id": {"$in": record_ids_to_delete}
            })
            
            logger.info(f"Archived {len(historical_records)} demand records older than {days_to_keep} days")
            
            return {
                "archived_count": len(historical_records),
                "deleted_count": delete_result.deleted_count,
                "cutoff_date": cutoff_date.isoformat()
            }
            
        except Exception as e:
            logger.error("Error archiving old demand data: %s", str(e))
            return {"archived_count": 0, "deleted_count": 0, "error": str(e)}
# Create repository instance
demand_serve_repository = DemandServeRepository()
