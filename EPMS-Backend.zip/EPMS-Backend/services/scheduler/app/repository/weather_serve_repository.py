"""
Weather Serve Repository
Handles database operations for weather serve data with timeseries support
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from bson import ObjectId
from pymongo import UpdateOne

from libs.database.base_serve_repository import BaseServeRepository
from libs.models.weather_serve_entity import WeatherServeEntity, WeatherServeHistoricalEntity
from ..core.config import settings

logger = logging.getLogger(__name__)


class WeatherServeRepository(BaseServeRepository):
    """Repository for weather serve data operations with timeseries support"""
    
    def __init__(self):
        """Initialize the weather serve repository"""
        super().__init__(
            mongodb_uri=settings.MONGODB_URI,
            database_name=settings.MONGODB_DATABASE,
            serve_collection=settings.MONGODB_WEATHER_SERVE_COLLECTION,
            historical_collection=settings.MONGODB_WEATHER_SERVE_HISTORICAL_COLLECTION
        )
        self._ensure_weather_timeseries_collections()
    
    def _ensure_weather_timeseries_collections(self):
        """Create weather timeseries collections if they don't exist"""
        try:
            # Create weather_serve as time series collection
            if "weather_serve" not in self.db.list_collection_names():
                self.db.create_collection(
                    "weather_serve",
                    timeseries={
                        "timeField": "timestamp",
                        "metaField": "data_type",
                        "granularity": "hours",
                    },
                )
                logger.info("Created time series collection: weather_serve")

            # Create weather_serve_historical as time series collection
            if "weather_serve_historical" not in self.db.list_collection_names():
                self.db.create_collection(
                    "weather_serve_historical",
                    timeseries={
                        "timeField": "archived_timestamp",
                        "metaField": "data_type",
                        "granularity": "hours",
                    },
                )
                logger.info("Created time series collection: weather_serve_historical")

        except Exception as e:
            logger.error("Could not create weather timeseries collections: %s", str(e))
            logger.info("Using regular collections with timestamp indexes")
    
    def bulk_insert(self, weather_data: List[Any]) -> int:
        """
        Bulk insert weather serve data
        
        Args:
            weather_data: List of weather data (entities or dictionaries)
            
        Returns:
            Number of inserted documents
            
        Raises:
            DataInsertionError: If data insertion fails
        """
        try:
            if not weather_data:
                logger.info("No weather data to insert")
                return 0
                
            # Use the base repository's bulk insert method
            return self.bulk_insert_serve(weather_data)
            
        except Exception as e:
            error_msg = f"Error bulk inserting weather serve data: {str(e)}"
            logger.error(error_msg, exc_info=True)
            from libs.database.base_serve_repository import DataInsertionError
            if isinstance(e, DataInsertionError):
                raise
            raise DataInsertionError(error_msg) from e
    
    def find_by_valid_time_utc(self, valid_time_utc: int, type: str) -> Optional[Dict[str, Any]]:
        """
        Find weather record by valid_time_utc
        
        Args:
            valid_time_utc: UTC valid time to search for
            
        Returns:
            Weather record or None
        """
        try:
            return self.serve_collection.find_one({"valid_time_utc": valid_time_utc, "type": type})
        except Exception as e:
            logger.error(f"Error finding weather record by valid_time_utc {valid_time_utc}: {str(e)}")
            return None
    
    def delete_by_id(self, record_id: str) -> bool:
        """
        Delete weather record by ID
        
        Args:
            record_id: Record ID to delete
            
        Returns:
            True if deleted successfully
        """
        try:
            result = self.serve_collection.delete_one({"_id": ObjectId(record_id)})
            return result.deleted_count > 0
        except Exception as e:
            logger.error(f"Error deleting weather record {record_id}: {str(e)}")
            return False

    def delete_by_time_and_source(self, valid_time_local: str, source: str) -> int:
        """
        Delete weather records by valid_time_local and source.
        
        Args:
            valid_time_local: The local valid time string to match.
            source: The data source to match.
            
        Returns:
            The number of deleted documents.
        """
        try:
            query = {"valid_time_local": valid_time_local, "source": source}
            result = self.serve_collection.delete_many(query)
            logger.debug(f"Deleted {result.deleted_count} weather records for time '{valid_time_local}' and source '{source}'.")
            return result.deleted_count
        except Exception as e:
            logger.error(f"Error deleting weather records for time '{valid_time_local}' and source '{source}': {str(e)}")
            return 0

    def archive_old_weather_data(self) -> Dict[str, Any]:
        """
        Performs a resilient, two-step archival process:
        1. Finds all data from before today in 'serve', checks for duplicates in 
        'historical', and copies only the new records.
        2. Deletes data from 'serve' that is older than the day before yesterday.
        """
        try:
            today = datetime.now().date()
            copied_count = 0

            # --- Step 1: Copy Missing Data to Historical (Duplicate-Safe) ---
            
            # 1. Find all potential records from 'serve' that should be in historical.
            # This correctly finds everything older than today.
            records_to_potentially_copy = list(self.serve_collection.find(
                {"valid_time_local": {"$lt": today.isoformat()}}
            ))

            if records_to_potentially_copy:
                # 2. Efficiently find which of these already exist in the historical collection.
                # Get all the unique time keys from the records we found.
                times_to_check = {r['valid_time_local'] for r in records_to_potentially_copy}
                
                # Find all documents in historical that match these times in a SINGLE query.
                # We only need the 'valid_time_local' field to check for existence.
                existing_records_cursor = self.historical_collection.find(
                    {"valid_time_local": {"$in": list(times_to_check)}},
                    {"_id": 0, "valid_time_local": 1} 
                )
                # Create a set for instant lookup.
                existing_times = {r['valid_time_local'] for r in existing_records_cursor}
                
                # 3. Filter out records that already exist.
                historical_records_to_insert = []
                for record in records_to_potentially_copy:
                    if record['valid_time_local'] not in existing_times:
                        historical_record = dict(record)
                        historical_record["archived_at"] = datetime.now()
                        historical_record["archived_timestamp"] = datetime.now()
                        historical_records_to_insert.append(historical_record)

                # 4. Bulk insert ONLY the records that are new.
                if historical_records_to_insert:
                    self.historical_collection.insert_many(historical_records_to_insert)
                    copied_count = len(historical_records_to_insert)
                    logger.info(f"Successfully copied {copied_count} new records to historical.")
                else:
                    logger.info("No new records to copy; historical collection is up-to-date.")
            else:
                logger.info("No records from previous days found in the serve collection to copy.")

            # --- Step 2: Delete Old Data from Serve (This logic remains the same) ---
            day_before_yesterday = today - timedelta(2)
            cutoff_iso_string = day_before_yesterday.isoformat()
            
            delete_query = {"valid_time_local": {"$lt": cutoff_iso_string}}
            delete_result = self.serve_collection.delete_many(delete_query)
            deleted_count = delete_result.deleted_count
            
            if deleted_count > 0:
                logger.info(f"Successfully deleted {deleted_count} records older than {cutoff_iso_string}.")

            return {
                "copied_count": copied_count,
                "deleted_count": deleted_count
            }

        except Exception as e:
            error_msg = f"Error during two-step archival process: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return {"copied_count": 0, "deleted_count": 0, "error": error_msg}