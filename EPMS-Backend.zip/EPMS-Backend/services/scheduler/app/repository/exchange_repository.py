"""
Market Data Repository
Handles database operations for market data using entity-repository pattern
"""

import logging
from datetime import datetime, timedelta, date
from typing import Dict, Any, List, Optional
from bson import ObjectId

from libs.database.base_serve_repository import BaseServeRepository, DataInsertionError
from libs.enum.raw_data_status import RawDataStatus
from ..core.config import settings
logger = logging.getLogger(__name__)


class ExchangeRepository(BaseServeRepository):
    """Repository for market data operations using entity-repository pattern"""
    
    def __init__(self):
        """Initialize the repository with MongoDB connection"""
        super().__init__(
            mongodb_uri=settings.MONGODB_URI,
            database_name=settings.MONGODB_DATABASE,
            serve_collection=settings.MONGODB_EXCHANGE_SERVE_COLLECTION,  # Use the existing exchange table directly
            historical_collection=settings.MONGODB_EXCHANGE_SERVE_HISTORICAL_COLLECTION
        )
        
        # Additional collections for market data
        # These will be created as time series collections
        self._raw_collection = None
        self._ensure_market_data_time_series_collections()

    def _ensure_market_data_time_series_collections(self):
        """Create market data time series collections if they don't exist"""
        try:
            # Create market_serve as time series collection
            if (
                settings.MONGODB_EXCHANGE_SERVE_COLLECTION
                not in self.db.list_collection_names()
            ):
                self.db.create_collection(
                    settings.MONGODB_EXCHANGE_SERVE_COLLECTION,
                    timeseries={
                        "timeField": "created_at",  # Use camelCase for time series
                        "metaField": "scheduled_at",  # Use camelCase for time series
                        "granularity": "minutes",
                    },
                )
                logger.info(
                    "Created time series collection: %s",
                    settings.MONGODB_EXCHANGE_SERVE_COLLECTION,
                )

            # Create market_historical as time series collection
            if (
                settings.MONGODB_EXCHANGE_SERVE_HISTORICAL_COLLECTION
                not in self.db.list_collection_names()
            ):
                self.db.create_collection(
                    settings.MONGODB_EXCHANGE_SERVE_HISTORICAL_COLLECTION,
                    timeseries={
                        "timeField": "archived_at",
                        "metaField": "scheduled_at",
                        "granularity": "hours",
                    },
                )
                logger.info(
                    "Created time series collection: %s",
                    settings.MONGODB_EXCHANGE_SERVE_HISTORICAL_COLLECTION,
                )

            # Collection references are already set correctly in __init__, don't override them
            # self.serve_collection and self.historical_collection are already initialized

        except (ConnectionError, TimeoutError) as e:
            logger.info("Could not create market data time series collections: %s", str(e))
            logger.info("Using regular collections with timestamp indexes")

    
    @property
    def raw_collection(self):
        """Lazy initialization of raw collection"""
        if self._raw_collection is None:
            self._raw_collection = self.db[settings.MONGODB_IEX_EXCHANGE_RAW_COLLECTION]
        return self._raw_collection
    
    def _map_fields_for_db(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        Prepare record for database storage
        Since the processor already applies provider mapping to convert provider fields 
        to serve fields, we just need to ensure proper data types for MongoDB
        
        Args:
            record: Entity record with serve field names from provider mapping
            
        Returns:
            Record ready for database storage with serve field names preserved
        """
        mapped_record = {}
        
        for field_name, value in record.items():
            # Convert Python date objects to datetime objects for MongoDB compatibility
            if isinstance(value, date) and not isinstance(value, datetime):
                # Convert date to datetime at start of day (UTC)
                mapped_record[field_name] = datetime.combine(value, datetime.min.time())
                logger.debug(f"Converted date field '{field_name}' from {value} to {mapped_record[field_name]}")
            elif value is None:
                # Handle None values
                mapped_record[field_name] = None
            else:
                # For all other types, keep as-is
                mapped_record[field_name] = value
        
        return mapped_record
    
    def find_by_market_type(self, market_type: str) -> Optional[Dict[str, Any]]:
        """
        Find exchange record by market_type only
        
        Args:
            market_type: Market type (IDF/DAF)
            
        Returns:
            Exchange record or None
        """
        try:
            query = {
                "market": market_type  # Use 'market' field instead of 'market_type'
            }
            
            logger.info(f"Exchange query: {query} on collection: {self.serve_collection.name}")
            result = self.serve_collection.find_one(query)
            logger.info(f"Exchange query result: {result is not None}")
            if result:
                logger.info(f"Found exchange record with ACP: {result.get('acp')}")
            
            return result
        except Exception as e:
            logger.error(f"Error finding exchange record: {str(e)}")
            return None

    def _day_bounds_utc(self, schedule_date: datetime) -> tuple[str, str]:
        """
        Given 'YYYY-MM-DD', return (start, end) ISO date strings for MongoDB $dateFromString.
        """
        # Create ISO date strings for MongoDB date parsing
        start_date_str = schedule_date.strftime("%Y-%m-%dT00:00:00.000Z")
        
        # Calculate next day for end date
        end_dt = schedule_date + timedelta(days=1)
        end_date_str = end_dt.strftime("%Y-%m-%dT00:00:00.000Z")
        
        return start_date_str, end_date_str

    
    def find_by_schedule_timeblock_market(self, scheduled_at: datetime, time_block: int, market_type: str) -> Optional[Dict[str, Any]]:
        """
        Find exchange record by scheduled_at, time_block, and market_type
        This method is kept for backward compatibility with bid processor
        
        Args:
            scheduled_at: Scheduled datetime
            time_block: Time block number
            market_type: Market type (IDF/DAF)
            
        Returns:
            Exchange record or None
        """
        
        start_date, end_date = self._day_bounds_utc(scheduled_at)
        try:
            query = {
                "scheduled_at": {
                    "$gte": {"$dateFromString": {"dateString": start_date}},
                    "$lt": {"$dateFromString": {"dateString": end_date}}
                },
                "time_block": time_block,
                "market_type": market_type
            }
            
            logger.info(f"Exchange query: {query} on collection: {self.serve_collection.name}")
            result = self.serve_collection.find_one(query)
            logger.info(f"Exchange query result: {result is not None}")
            if result:
                logger.info(f"Found exchange record with ACP: {result.get('acp')}")
            
            return result
        except Exception as e:
            logger.error(f"Error finding exchange record: {str(e)}")
            return None
    
    def archive_old_exchange_data(self, days_to_keep: int = 2) -> Dict[str, Any]:
        try:
            from datetime import timedelta
            
            today = datetime.now().date()
            cutoff_date = today - timedelta(days=days_to_keep)
            
            records_to_archive = []
            records_to_delete = []
            
            all_records = list(self.serve_collection.find({}))
            
            for record in all_records:
                scheduled_at = record.get("scheduled_at")
                if scheduled_at:
                    if isinstance(scheduled_at, datetime):
                        scheduled_date = scheduled_at.date()
                    else:
                        scheduled_date = datetime.fromisoformat(str(scheduled_at)).date()
                    
                    if scheduled_date < today:
                        records_to_archive.append(record)
                    if scheduled_date < cutoff_date:
                        records_to_delete.append(record)
            
            if not records_to_archive:
                logger.info("No exchange records found to archive")

            if not records_to_delete:
                logger.info("No exchange records found to delete")

            
            # Prepare records for historical collection
            historical_records = []
            record_ids_to_delete = []
            record_ids_to_archieve = []

            for record in records_to_archive:
                record_ids_to_archieve.append(record["_id"])

            existing_records = list(self.historical_collection.find({"_id": {"$in": record_ids_to_archieve}}))
            
            for record in records_to_archive:
                if record["_id"] not in existing_records:
                # Create historical record
                    historical_record = dict(record)
                    historical_record["archived_at"] = datetime.now()
                    historical_record["archived_timestamp"] = datetime.now()
                    historical_records.append(historical_record)
            
            for record in records_to_delete:
                record_ids_to_delete.append(record["_id"])
            
            if historical_records:
                self.historical_collection.insert_many(historical_records)
                logger.info(f"Archived {len(historical_records)} exchange records to historical collection")
            
            delete_result = self.serve_collection.delete_many({
                "_id": {"$in": record_ids_to_delete}
            })
            
            return {
                "archived_count": len(historical_records),
                "deleted_count": delete_result.deleted_count,
                "cutoff_date": cutoff_date.isoformat()
            }
            
        except Exception as e:
            logger.error("Error archiving old exchange data: %s", str(e))
            return {"archived_count": 0, "deleted_count": 0, "error": str(e)}

    def get_pending_raw_data(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get pending and failed raw data records ordered by createdAt ascending"""
        try:
            query = {
                "status": {"$in": [RawDataStatus.PENDING, RawDataStatus.FAILED]}
            }
            
            records = list(
                self.raw_collection.find(query)
                .sort("createdAt", 1)  # Ascending order by createdAt
                .limit(limit)
            )
            
            logger.info(f"Found {len(records)} pending/failed raw data records")
            return records
            
        except Exception as e:
            logger.error("Error getting pending raw data: %s", str(e))
            return []

    def bulk_upsert_exchange_records(self, records: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Bulk upsert exchange records using base repository method.
        
        Args:
            records: List of complete record data to upsert
            
        Returns:
            Dictionary with bulk operation results from base repository
        """
        records_with_filters = []
        
        for record in records:
            # Extract filter fields
            scheduled_at = record.get("scheduled_at")
            time_block = record.get("time_block")
            market_type = record.get("market_type")
            
            if not all([scheduled_at, time_block is not None, market_type]):
                logger.warning("Skipping record missing required fields: scheduled_at, time_block, market_type")
                continue
            
            # Create filter query
            # Convert date to datetime if needed
            if isinstance(scheduled_at, date) and not isinstance(scheduled_at, datetime):
                scheduled_at = datetime.combine(scheduled_at, datetime.min.time())
            
            filter_query = {
                "scheduled_at": scheduled_at,
                "time_block": time_block,
                "market_type": market_type
            }
            
            # Map fields for database storage
            mapped_record = self._map_fields_for_db(record)
            
            records_with_filters.append({
                "filter_query": filter_query,
                "record_data": mapped_record
            })
        
        # Use base repository bulk upsert method
        return self.bulk_upsert_serve_records(records_with_filters)




# Global repository instance
exchange_repository = ExchangeRepository()