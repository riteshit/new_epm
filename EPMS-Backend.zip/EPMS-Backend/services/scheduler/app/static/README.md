# EPMS Admin Login System

This directory contains the admin login system for the EPMS (Energy Portfolio Management System) dashboard.

## Files

- **`index.html`** - Landing page that redirects to login or dashboard based on authentication status
- **`login.html`** - Admin login page with modern UI and MFA support
- **`job_dashboard.html`** - Main dashboard (now requires authentication)

## Features

### Login Page (`login.html`)
- **Modern UI**: Clean, responsive design with gradient backgrounds
- **Username/Email Login**: Supports both username and email authentication
- **Password Visibility Toggle**: Users can show/hide password
- **Remember Me**: Optional persistent login
- **MFA Support**: Two-factor authentication with TOTP codes
- **Error Handling**: Clear error messages and validation
- **Auto-redirect**: Redirects to dashboard on successful login

### Dashboard Authentication (`job_dashboard.html`)
- **Token Validation**: Checks JWT token validity on page load
- **Auto-refresh**: Automatically refreshes expired tokens
- **User Info Display**: Shows current user in header
- **Logout Functionality**: Secure logout with token cleanup
- **Session Management**: Handles token expiration gracefully

### Landing Page (`index.html`)
- **Smart Redirect**: Automatically redirects based on authentication status
- **Token Check**: Validates existing tokens before redirecting
- **Clean Design**: Professional landing page with system branding

## Authentication Flow

1. **Access**: User visits any page
2. **Check**: System checks for valid JWT token
3. **Redirect**: 
   - No token → Login page
   - Valid token → Dashboard
   - Expired token → Login page (with cleanup)

## Login Process

1. **Username/Password**: User enters credentials
2. **Validation**: System validates against auth service
3. **MFA Check**: If MFA enabled, prompts for TOTP code
4. **Token Storage**: Stores access and refresh tokens
5. **Dashboard Access**: Redirects to authenticated dashboard

## Security Features

- **JWT Tokens**: Secure token-based authentication
- **Token Refresh**: Automatic token renewal
- **MFA Support**: Two-factor authentication
- **Session Management**: Proper token cleanup on logout
- **HTTPS Ready**: Prepared for secure connections
- **Token Expiration**: Automatic logout on token expiry

## Configuration

The system connects to the auth service at:
```
http://localhost:8001/api/v1
```

## Usage

1. Start the auth service: `python run_services.py auth`
2. Start the scheduler service: `python run_services.py scheduler`
3. Navigate to: `http://localhost:8002/static/`
4. Login with admin credentials
5. Access the dashboard with full authentication

## Admin Credentials

Default admin credentials are seeded by the auth service. Check the auth service documentation for default credentials or create new admin users through the auth service API.

## Troubleshooting

- **Login Fails**: Check auth service is running on port 8001
- **Token Errors**: Clear browser storage and login again
- **MFA Issues**: Ensure TOTP app is properly configured
- **Redirect Loops**: Check token validity and auth service connectivity
