"""
Peak demand computation service.
Computes and backfills peak demand from demand_serve and demand_serve_historical into peak_demand_serve.
"""

import logging
from datetime import datetime, timedelta, date
from typing import Dict, Any, Optional
from pymongo.collection import Collection
from pymongo import DESCENDING

from services.scheduler.app.repository.demand_serve_repository import DemandServeRepository
from services.scheduler.app.repository.peak_demand_repository import PeakDemandRepository
from libs.models.peak_demand_serve_entity import PeakDemandServeEntity

logger = logging.getLogger(__name__)


class PeakDemandService:
    def __init__(self):
        self.demand_repo = DemandServeRepository()
        self.peak_repo = PeakDemandRepository()

    def compute_and_store_yesterday_peak(self) -> Dict[str, Any]:
        """
        Computes and stores peak demand, backfilling from the last known date.
        """
        today = datetime.utcnow().date()
        yesterday = today - timedelta(days=1)

        start_date = self._get_start_date()
        if not start_date:
            logger.info("No start date found for peak demand computation. Nothing to do.")
            return {"status": "skipped", "message": "No data to process."}

        logger.info(f"Starting peak demand computation from {start_date} to {yesterday}")

        processed_count = 0
        skipped_count = 0
        current_date = start_date
        while current_date <= yesterday:
            logger.info(f"Processing peak demand for {current_date.isoformat()}")
            
            # Use historical collection for past dates, live collection for yesterday
            collection_to_use = self.demand_repo.serve_collection if current_date == yesterday else self.demand_repo.historical_collection
            
            result = self._compute_and_store_for_date(current_date, collection_to_use)
            if result:
                processed_count += 1
            else:
                skipped_count += 1
            
            current_date += timedelta(days=1)

        logger.info(f"Peak demand computation finished. Processed: {processed_count}, Skipped/Exists: {skipped_count}")
        return {
            "status": "success",
            "processed_dates": processed_count,
            "skipped_dates": skipped_count,
            "start_date": start_date.isoformat(),
            "end_date": yesterday.isoformat()
        }

    def _get_start_date(self) -> Optional[date]:
        """Determines the start date for backfilling peak demand data."""
        # 1. Find the last entry in the peak_demand_serve collection
        last_peak_record = self.peak_repo.serve_collection.find_one(sort=[("scheduled_at", DESCENDING)])
        
        if last_peak_record and 'scheduled_at' in last_peak_record:
            last_date = last_peak_record['scheduled_at'].date()
            logger.info(f"Last peak demand record found for {last_date}. Starting from the next day.")
            return last_date + timedelta(days=1)

        # 2. If peak_demand_serve is empty, find the first entry in demand_serve_historical
        logger.info("No peak demand records found. Checking historical demand data for the first record.")
        first_historical_record = self.demand_repo.historical_collection.find_one(sort=[("scheduled_at", 1)])
        
        if first_historical_record and 'scheduled_at' in first_historical_record:
            first_date = first_historical_record['scheduled_at'].date()
            logger.info(f"First historical demand record found for {first_date}. Starting from this date.")
            return first_date
            
        # 3. If historical is also empty, check the live demand_serve collection
        logger.info("No historical demand records. Checking live demand data.")
        first_live_record = self.demand_repo.serve_collection.find_one(sort=[("scheduled_at", 1)])
        if first_live_record and 'scheduled_at' in first_live_record:
            first_date = first_live_record['scheduled_at'].date()
            logger.info(f"First live demand record found for {first_date}. Starting from this date.")
            return first_date

        return None

    def _compute_and_store_for_date(self, target_date: date, source_collection: Collection) -> Optional[Dict[str, Any]]:
        """Computes and stores peak demand for a single specified date."""
        start_dt = datetime.combine(target_date, datetime.min.time())
        end_dt = datetime.combine(target_date, datetime.max.time())

        # Idempotency check: Skip if a record for this day already exists
        if self.peak_repo.serve_collection.count_documents({"scheduled_at": {"$gte": start_dt, "$lte": end_dt}}) > 0:
            logger.info(f"Peak demand record already exists for {target_date.isoformat()}. Skipping.")
            return None

        # Find the record with the maximum comp_act_demand for the target date
        query = {"scheduled_at": {"$gte": start_dt, "$lte": end_dt}}
        sort_order = [("comp_act_demand", DESCENDING)]
        
        peak_doc = source_collection.find_one(query, sort=sort_order)

        if not peak_doc:
            logger.info(f"No demand records found in {source_collection.name} for {target_date.isoformat()}")
            # Create a placeholder to avoid re-processing this empty day
            placeholder_entity = PeakDemandServeEntity(
                scheduled_at=start_dt,
                time_block=0,
                peak_demand=0.0,
                average_demand=0.0,
            )
            return self.peak_repo.insert_one(placeholder_entity)

        # Extract peak data
        scheduled_at = peak_doc.get("scheduled_at")
        time_block = peak_doc.get("time_block")
        peak_value = peak_doc.get("comp_act_demand")

        if scheduled_at is None or time_block is None or peak_value is None:
            logger.warning(f"Peak candidate for {target_date.isoformat()} is missing required fields. Skipping.")
            return None

        # Calculate average demand for the same scheduled_at and type
        average_query = {
            "scheduled_at": {"$gte": start_dt, "$lte": end_dt}
        }
        
        # Use MongoDB aggregation to calculate average
        pipeline = [
            {"$match": average_query},
            {"$group": {
                "_id": None,
                "average_demand": {"$avg": "$comp_act_demand"},
                "count": {"$sum": 1}
            }}
        ]
        
        avg_result = list(source_collection.aggregate(pipeline))
        average_value = avg_result[0]["average_demand"] if avg_result else 0.0

        try:
            entity = PeakDemandServeEntity(
                scheduled_at=scheduled_at,
                time_block=int(time_block),
                peak_demand=float(peak_value),
                average_demand=float(average_value),
            )
            insert_result = self.peak_repo.insert_one(entity)
            logger.info(f"Stored peak demand for {target_date.isoformat()}: peak={peak_value} MW at block {time_block}, average={average_value:.2f} MW")
            return insert_result
        except (ValueError, TypeError) as e:
            logger.error(f"Error creating PeakDemandServeEntity for {target_date.isoformat()}: {e}")
            return None


peak_demand_service = PeakDemandService()
