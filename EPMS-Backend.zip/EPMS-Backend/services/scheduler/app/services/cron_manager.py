"""
Scheduler Service Cron Job Manager
Handles scheduling and execution of scheduler-specific cron jobs
Updated: Added missing methods to libs JobDetailRepository
"""

import logging
import asyncio
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from collections import defaultdict
from pymongo import MongoClient
import sys
import os

# Add project root to path for audit queue import
project_root = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..')
if project_root not in sys.path:
    sys.path.append(project_root)

from libs.audit_queue.simple_logger import audit_logger
from libs.core.cron_manager import BaseCronManager
from libs.core.job_entities import JobDetailQuery, JobDetail
from libs.core.job_factory import create_job_data_repository, create_job_detail_repository
from libs.core.job_repositories import JobDataRepository, JobDetailRepository
from services.scheduler.app.seeder.job_seeder import create_scheduler_job_seeder
from services.scheduler.app.core.config import settings
from services.scheduler.app.services.dummy_data_service import dummy_data_service, DummyDataService
# Temporarily commented out due to import issues
# from services.scheduler.app.exchange.services.iex.data_scrapper import data_scrapper
# from services.scheduler.app.exchange.services.iex.data_processor import data_processor
from services.scheduler.app.services.date_update_service import DateUpdate
from services.scheduler.app.processors.weather_processor import WeatherProcessor
from services.scheduler.app.processors.bid_processor import BidProcessor
from services.scheduler.app.processors.exchange_processor import ExchangeProcessor
from services.scheduler.app.processors.demand_processor import DemandProcessor
from services.scheduler.app.processors.supply_processor import SupplyProcessor
from services.scheduler.app.services.peak_demand_service import peak_demand_service
logger = logging.getLogger(__name__)


class CronManager(BaseCronManager):
    """Scheduler service cron manager with scheduler-specific jobs"""
    
    def __init__(self):
        """Initialize the scheduler cron manager"""
        # Type annotations for repository instances
        self.job_data_repository: Optional[JobDataRepository] = None
        self.job_detail_repository: Optional[JobDetailRepository] = None
        # Initialize scheduler-specific services
        # Linter refresh comment
        # self.data_scrapper = data_scrapper  # Temporarily commented out
        # self.data_processor = data_processor  # Temporarily commented out
        self.date_updater = DateUpdate()
        
        # Initialize processor instances
        self.weather_processor = WeatherProcessor()
        self.bid_processor = BidProcessor()
        self.exchange_processor = ExchangeProcessor()
        self.demand_processor = DemandProcessor()
        self.peak_demand_service = peak_demand_service  
        self.supply_processor = SupplyProcessor()  # Add supply processor
        
        # Create shared repository instances
        try:
            logger.info("Creating job repositories with URI: %s, DB: %s, Collection: %s", 
                       settings.AUDIT_DB_URI, settings.AUDIT_DB_NAME, settings.JOB_DATA_COLLECTION)
            self.job_data_repository = create_job_data_repository(
                settings.AUDIT_DB_URI,
                settings.AUDIT_DB_NAME,
                settings.JOB_DATA_COLLECTION
            )
            self.job_detail_repository = create_job_detail_repository(
                settings.AUDIT_DB_URI,
                settings.AUDIT_DB_NAME,
                settings.JOB_DETAIL_COLLECTION
            )
            logger.info("Job repositories created successfully - job_data: %s, job_detail: %s", 
                       self.job_data_repository is not None, self.job_detail_repository is not None)
        except Exception as e:
            logger.error("Failed to create job repositories: %s", e, exc_info=True)
            self.job_data_repository = None
            self.job_detail_repository = None
        
        # Create job seeder only if repository is available
        self.cron_job_seeder = None
        if self.job_data_repository:
            try:
                self.cron_job_seeder = create_scheduler_job_seeder(
                    self.job_data_repository
                )
                logger.info("Job seeder created successfully")
            except Exception as e:
                logger.error("Failed to create job seeder: %s", e)
                self.cron_job_seeder = None
        
        # Initialize base class
        super().__init__(
            service_name="scheduler",
            timezone=settings.CRON_TIMEZONE,
            job_data_repository=self.job_data_repository
        )
        
        logger.info("Initialized scheduler cron manager")
    
    def _register_service_jobs(self):
        """Register scheduler-specific jobs from database"""
        try:
            # Check if repository and seeder are available
            if not self.job_data_repository:
                logger.warning("Job data repository not available, skipping job registration")
                return
                
            if not self.cron_job_seeder:
                logger.warning("Job seeder not available, skipping job registration")
                return
                
            # First, ensure jobs are seeded
            logger.info("Seeding default jobs...")
            seeding_result = self.cron_job_seeder.seed_default_jobs()
            logger.info("Job seeding result: %s", seeding_result)
            
            # Get all enabled jobs from database
            jobs = self.job_data_repository.get_all_jobs(enabled_only=True)
            
            registered_count = 0
            for job_config in jobs:
                job_function = self._get_job_function(job_config['job_type'])
                if job_function:
                    success = self.register_job(
                        job_type=job_config['job_type'],
                        name=job_config['name'],
                        schedule=job_config['schedule'],
                        func=job_function,
                        enabled=job_config['enabled'],
                        timezone=job_config.get('timezone', 'Asia/Kolkata')
                    )
                    if success:
                        registered_count += 1
                else:
                    logger.warning("No execution function found for job: %s", job_config['job_type'])
                    
            logger.info("Registered %s scheduler jobs from database", registered_count)
            
        except (ValueError, TypeError, OSError, RuntimeError) as e:
            logger.error("Failed to register jobs from database: %s", str(e))
            # Fallback to hardcoded jobs for backward compatibility
            self._register_fallback_jobs()
    
    def _get_job_function(self, job_type: str):
        """Get the execution function for a job type"""
        job_functions = {
            # Core Data Management Jobs
            # "serve_data_reconciliation": self._execute_serve_data_reconciliation_job,
            # "demand_data_management": self._execute_demand_data_management_job,
            # "supply_data_management": self._execute_supply_data_management_job,
            "date_update": self.date_updater.date_update_job,

            # Data Processing Jobs
            "demand_data_processing": self.demand_processor.execute_cron_job,
            "raw_data_processing": self._execute_raw_data_processing_job,
            "supply_data_processing": self.supply_processor.execute_cron_job,
            
            # New Processor Jobs
            "weather_data_processing": self.weather_processor.execute_cron_job,
            "bid_data_processing": self.bid_processor.execute_cron_job,
            "exchange_data_processing": self.exchange_processor.execute_cron_job,
            # Data Scraping Jobs (disabled due to import issues)
            "exchange_serve_archival": self._execute_exchange_serve_archival_job,
            "demand_serve_archival": self._execute_demand_serve_archival_job,
            "supply_serve_archival": self._execute_supply_serve_archival_job,
            "weather_serve_archival": self._execute_weather_serve_archival_job,
            "bid_serve_archival": self._execute_bid_serve_archival_job,
            "peak_demand_compute": self.peak_demand_service.compute_and_store_yesterday_peak,
            # System Maintenance Jobs
            "system_cleanup": self._execute_system_cleanup_job,
            "retry_failed_jobs": self._execute_retry_failed_jobs,
            "data_migration": self._execute_data_migration_job,
            "job_logs_cleanup": self._execute_job_logs_cleanup_job,
            # Cross-service jobs (from other services)
            "upload_raw_data_processor": self._execute_upload_raw_data_processor_job,
            "scrape_raw_data_processor": self._execute_scrape_raw_data_processor_job
        }
        return job_functions.get(job_type)
    
    def _register_fallback_jobs(self):
        """Register fallback jobs for backward compatibility"""
        logger.info("Registering fallback scheduler jobs...")
        
        fallback_jobs = [
            {
                "job_type": "demand_data_management",
                "name": "Demand Data Management",
                "schedule": settings.DEMAND_DATA_CRON_SCHEDULE,
                "enabled": settings.DEMAND_DATA_CRON_ENABLED,
                "timezone": settings.DEMAND_DATA_CRON_TIMEZONE
            },
            {
                "job_type": "supply_data_management",
                "name": "Supply Data Management",
                "schedule": settings.DEMAND_DATA_CRON_SCHEDULE,
                "enabled": settings.DEMAND_DATA_CRON_ENABLED,
                "timezone": settings.DEMAND_DATA_CRON_TIMEZONE
            },
            {
                "job_type": "demand_data_processing",
                "name": "Demand Data Processing",
                "schedule": "* */15 * * *",  # Every 15 minutes
                "enabled": True,
                "timezone": settings.CRON_TIMEZONE
            },
            {
                "job_type": "supply_data_processing",
                "name": "Supply Data Processing",
                "schedule": "* */15 * * *",  # Every 15 minutes
                "enabled": True,
                "timezone": settings.CRON_TIMEZONE
            },
            {
                "job_type": "system_cleanup",
                "name": "System Cleanup",
                "schedule": settings.SYSTEM_CLEANUP_SCHEDULE,
                "enabled": settings.SYSTEM_CLEANUP_ENABLED,
                "timezone": settings.CRON_TIMEZONE
            },
            {
                "job_type": "retry_failed_jobs",
                "name": "Retry Failed Jobs",
                "schedule": settings.RETRY_FAILED_JOBS_SCHEDULE,
                "enabled": settings.RETRY_FAILED_JOBS_ENABLED,
                "timezone": settings.CRON_TIMEZONE
            }
        ]
        
        registered_count = 0
        for job_config in fallback_jobs:
            job_function = self._get_job_function(job_config['job_type'])
            if job_function:
                success = self.register_job(
                    job_type=job_config['job_type'],
                    name=job_config['name'],
                    schedule=job_config['schedule'],
                    func=job_function,
                    enabled=job_config['enabled'],
                    timezone=job_config.get('timezone', 'Asia/Kolkata')
                )
                if success:
                    registered_count += 1
            else:
                logger.warning("No execution function found for fallback job: %s", job_config['job_type'])
        
        logger.info("Registered %s fallback scheduler jobs", registered_count)
    
    # Enhanced methods from base class with audit database logging
    def start(self):
        """Start the cron scheduler with scheduler-specific startup logic"""
        if not self._is_running:
            try:
                logger.info("Starting scheduler cron manager...")
                
                # Call base class start method
                super().start()
                
                # Add scheduler-specific startup logic if needed
                if settings.RUN_ALL_JOBS_ON_STARTUP:
                    try:
                        # Try to get the current event loop
                        loop = asyncio.get_event_loop()
                        if loop.is_running():
                            # If loop is running, create a task
                            asyncio.create_task(self._run_all_jobs_on_startup())
                        else:
                            # If no loop is running, run in a new event loop
                            asyncio.run(self._run_all_jobs_on_startup())
                    except RuntimeError:
                        # No event loop exists, create one
                        asyncio.run(self._run_all_jobs_on_startup())
                
            except (ValueError, TypeError, OSError, RuntimeError) as e:
                logger.error("Failed to start scheduler cron manager: %s", str(e))
                raise
    
    async def _run_all_jobs_on_startup(self):
        """Run all enabled jobs immediately on startup according to priority with parallel execution for same priority"""
        try:
            
            logger.info("Running all enabled jobs on startup...")
            logger.info("   Startup delay: %s seconds", settings.STARTUP_JOB_DELAY_SECONDS)
            
            # Wait for the configured delay
            time.sleep(settings.STARTUP_JOB_DELAY_SECONDS)
            
            # Get all enabled jobs with their priorities from database
            enabled_jobs_with_priority = []
            
            for job_type, cron_job in self._registered_jobs.items():
                if cron_job.enabled:
                    # Get job data from database to get priority
                    job_data = self.job_data_repository.get_job(job_type)
                    priority = job_data.get('priority', 999) if job_data else 999  # Default to low priority
                    
                    enabled_jobs_with_priority.append({
                        'job_type': job_type,
                        'cron_job': cron_job,
                        'priority': priority
                    })
            
            # Sort jobs by priority (lower number = higher priority)
            enabled_jobs_with_priority.sort(key=lambda x: x['priority'])
            
            # Group jobs by priority
            jobs_by_priority = defaultdict(list)
            for job_info in enabled_jobs_with_priority:
                jobs_by_priority[job_info['priority']].append(job_info)
            
            logger.info("   Found %s enabled jobs to run on startup", len(enabled_jobs_with_priority))
            logger.info("   Jobs will run in priority order (parallel within same priority):")
            for priority in sorted(jobs_by_priority.keys()):
                jobs = jobs_by_priority[priority]
                logger.info("     Priority %s (%s jobs): %s", 
                          priority, len(jobs), 
                          ", ".join([job['cron_job'].name for job in jobs]))
            
            # Run jobs by priority groups (parallel within same priority, sequential across priorities)
            for priority in sorted(jobs_by_priority.keys()):
                jobs_in_priority = jobs_by_priority[priority]
                
                if len(jobs_in_priority) == 1:
                    # Single job - run sequentially
                    job_info = jobs_in_priority[0]
                    await self._execute_single_startup_job(job_info)
                else:
                    # Multiple jobs with same priority - run in parallel
                    logger.info("   Running %s jobs with priority %s in parallel", len(jobs_in_priority), priority)
                    await self._execute_parallel_startup_jobs(jobs_in_priority)
                
                # Add delay between priority groups (except for the last priority group)
                if priority != max(jobs_by_priority.keys()):
                    logger.info("   Waiting %s seconds before next priority group...", settings.STARTUP_JOB_INTERVAL_SECONDS)
                    time.sleep(settings.STARTUP_JOB_INTERVAL_SECONDS)
            
            logger.info("Completed startup job execution")
            
        except (ValueError, TypeError, OSError, RuntimeError) as e:
            logger.error("Failed to run jobs on startup: %s", str(e))
    
    async def _execute_single_startup_job(self, job_info: dict):
        """Execute a single startup job asynchronously"""
        
        job_type = job_info['job_type']
        cron_job = job_info['cron_job']
        priority = job_info['priority']
        
        try:
            logger.info("   Running startup job: %s (Type: %s, Priority: %s)", 
                      cron_job.name, job_type, priority)
            
            # Execute job function asynchronously
            if asyncio.iscoroutinefunction(cron_job.func):
                # Function is already async
                await cron_job.func()
            else:
                # Function is sync, run in thread pool
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, cron_job.func)
            
            logger.info("   Completed startup job: %s (Priority: %s)", cron_job.name, priority)
            
        except Exception as job_error:  # pylint: disable=broad-except
            logger.error("   Failed to run startup job %s (Priority: %s): %s", 
                       cron_job.name, priority, str(job_error))
    
    async def _execute_parallel_startup_jobs(self, jobs_in_priority: list):
        """Execute multiple startup jobs with the same priority in parallel"""
        
        async def execute_job(job_info: dict):
            """Execute a single job and return result with smart logging"""
            job_type = job_info['job_type']
            cron_job = job_info['cron_job']
            priority = job_info['priority']
            job_detail_id = None
            start_time = time.time()
            
            try:
                # Record job start and get job detail ID for correlation
                execution_start = datetime.now()
                job_detail_id = self._record_job_start(job_type, cron_job.name, "parallel", execution_start)
                
                logger.info("     Starting parallel job: %s (Type: %s, Priority: %s)", 
                          cron_job.name, job_type, priority)
                
                # Log job start
                audit_logger.log_system_operation(
                    service="scheduler",
                    operation="cron_job_started",
                    message=f"Cron job started: {cron_job.name}",
                    correlation_id=job_detail_id or f"job_{int(time.time())}",
                    job_name=cron_job.name,
                    job_type=job_type,
                    priority=priority,
                    execution_mode="parallel"
                )
                
                # Execute job function asynchronously
                if asyncio.iscoroutinefunction(cron_job.func):
                    # Function is already async
                    await cron_job.func()
                else:
                    # Function is sync, run in thread pool
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(None, cron_job.func)
                
                # Calculate duration
                duration_ms = int((time.time() - start_time) * 1000)

                # Log successful completion
                audit_logger.log_system_operation(
                    service="scheduler",
                    operation="cron_job_completed",
                    message=f"Cron job completed: {cron_job.name}",
                    job_detail_id=job_detail_id or f"job_{int(time.time())}",
                    job_name=cron_job.name,
                    job_type=job_type,
                    priority=priority,
                    execution_mode="parallel",
                    duration_ms=duration_ms,
                    duration_seconds=duration_ms / 1000,
                    success=True
                )

                logger.info("     Completed parallel job: %s (Priority: %s)", cron_job.name, priority)
                return {"status": "success", "job_name": cron_job.name, "priority": priority, "job_detail_id": job_detail_id}
            except Exception as job_error:  # pylint: disable=broad-except  # pylint: disable=broad-except
                duration_ms = int((time.time() - start_time) * 1000)
                
                # Log job failure
                audit_logger.log_system_operation(
                    service="scheduler",
                    operation="cron_job_failed",
                    message=f"Cron job failed: {cron_job.name} - {str(job_error)}",
                    job_detail_id=job_detail_id or f"job_{int(time.time())}",
                    job_name=cron_job.name,
                    job_type=job_type,
                    priority=priority,
                    execution_mode="parallel",
                    duration_ms=duration_ms,
                    duration_seconds=duration_ms / 1000,
                    success=False,
                    exception_type=type(job_error).__name__
                )
                
                logger.error("     Failed to run parallel job %s (Priority: %s): %s", 
                           cron_job.name, priority, str(job_error))
                return {"status": "error", "job_name": cron_job.name, "priority": priority, "error": str(job_error), "job_detail_id": job_detail_id}
        
        # Create tasks for all jobs in this priority group
        tasks = [execute_job(job_info) for job_info in jobs_in_priority]
        
        # Execute all tasks in parallel and wait for all to complete
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Log summary of parallel execution
        successful_jobs = [r for r in results if isinstance(r, dict) and r.get("status") == "success"]
        failed_jobs = [r for r in results if isinstance(r, dict) and r.get("status") == "error"]
        
        logger.info("     Parallel execution completed - Success: %s, Failed: %s", 
                  len(successful_jobs), len(failed_jobs))
    
    # Enhanced job status methods with audit database integration
    def get_all_jobs(self) -> Dict[str, Any]:
        """Get status of all jobs with scheduler-specific enhancements"""
        base_result = super().get_all_jobs()
        
        # Add scheduler-specific job statistics
        if base_result.get('jobs'):
            for job in base_result['jobs']:
                try:
                    job_stats = self.job_detail_repository.get_job_statistics(job['job_id'], days=1)
                    if job_stats:
                        job.update({
                            'total_executions': job_stats.get('total_executions', 0),
                            'success_rate': job_stats.get('success_rate', 0.0),
                            'average_duration': job_stats.get('average_duration_seconds', 0.0)
                        })
                except (ValueError, TypeError, OSError, RuntimeError) as e:
                    logger.error("Error getting job statistics for %s: %s", job['job_id'], str(e))
        
        return base_result
    
    def _record_job_start(self, job_type: str, job_name: str, schedule: str, 
                         execution_start: datetime) -> Optional[str]:
        """Record job start in audit database and return execution_id"""
        try:
            # Get the job_id (ObjectId) from job_data collection using job_type
            job_data = self.job_data_repository.get_job(job_type)
            if not job_data:
                logger.error("Job data not found for job_type: %s", job_type)
                return None
            
            job_id = job_data.get('_id')  # This is the ObjectId reference
            
            # Generate unique execution ID
            execution_id = f"{job_type}_{execution_start.strftime('%Y%m%d_%H%M%S')}"
            
            job_detail = JobDetail(
                job_id=str(job_id),  # Convert ObjectId to string for storage
                execution_id=execution_id,
                job_name=job_name,
                execution_start=execution_start,
                execution_end=execution_start,  # Same as start for processing entry
                duration_seconds=0.0,  # Will be updated on completion
                status="processing",
                success=False,  # Default to False for processing entry
                error_message=None,
                error_details=None,
                result_data={},
                service=self.service_name,
                metadata={
                    "timezone": settings.CRON_TIMEZONE,
                    "schedule": schedule,
                    "job_type": job_type,  # Store job_type for easy querying
                    "processing_started": True
                }
            )
            
            self.job_detail_repository.log_execution(job_detail)
            logger.info("Recorded job start for %s (job_type: %s, execution_id: %s) in audit database", 
                       job_id, job_type, execution_id)
            return execution_id
                
        except Exception as e:  # pylint: disable=broad-except
            logger.error("Failed to record job start for %s: %s", job_type, str(e))
            return None

    def _record_job_completion(self, job_type: str, job_name: str, schedule: str, 
                              execution_start: datetime, execution_end: datetime,
                              execution_id: str, status: str, success: bool, 
                              result: Optional[Dict[str, Any]] = None,
                              error_message: Optional[str] = None):
        """Record job completion in audit database"""
        try:
            duration_seconds = (execution_end - execution_start).total_seconds()
            
            # Get the job_id (ObjectId) from job_data collection using job_type
            job_data = self.job_data_repository.get_job(job_type)
            if not job_data:
                logger.error("Job data not found for job_type: %s", job_type)
                return
            
            job_id = job_data.get('_id')  # This is the ObjectId reference
            
            job_detail = JobDetail(
                job_id=str(job_id),  # Convert ObjectId to string for storage
                execution_id=execution_id,  # Use the same execution_id from start
                job_name=job_name,
                execution_start=execution_start,
                execution_end=execution_end,
                duration_seconds=duration_seconds,
                status=status,
                success=success,
                error_message=error_message,
                error_details=None,
                result_data=result if result is not None else {},
                service=self.service_name,
                metadata={
                    "timezone": settings.CRON_TIMEZONE,
                    "schedule": schedule,
                    "job_type": job_type,  # Store job_type for easy querying
                    "processing_completed": True,
                    "final_status": status
                }
            )
            
            self.job_detail_repository.log_execution(job_detail)
            logger.info("Recorded job completion for %s (job_type: %s, execution_id: %s, status: %s) in audit database", 
                       job_id, job_type, execution_id, status)
                
        except Exception as e:  # pylint: disable=broad-except
            logger.error("Failed to record job completion for %s: %s", job_type, str(e))
    
    def _record_job_completion_with_logs(self, job_type: str, job_name: str, execution_id: str, 
                                       status: str, duration_seconds: float, logs: list, 
                                       result_data: Optional[Dict[str, Any]] = None, error_message: Optional[str] = None):
        """Record job completion with captured execution logs"""
        try:
            # Try to get job data, but proceed even if not found
            job_id = job_type  # Default to job_type as job_id
            if hasattr(self, 'job_data_repository') and self.job_data_repository:
                job_data = self.job_data_repository.get_job(job_type)
                if job_data:
                    job_id = job_data.get("_id", job_type)
                else:
                    logger.warning("Job data not found for job_type: %s, using job_type as job_id", job_type)
            
            # Ensure result_data is properly formatted
            if result_data is not None:
                # Handle coroutines and other non-dict types
                if hasattr(result_data, '__await__'):  # It's a coroutine
                    result_data = {"status": "async_result", "type": "coroutine"}
                elif not isinstance(result_data, dict):
                    result_data = {"status": "success", "result": str(result_data)}
            else:
                result_data = {}
            
            # Create job detail record with logs
            job_detail = JobDetail(
                job_id=job_id,
                execution_id=execution_id,
                job_name=job_name,
                execution_start=datetime.now() - timedelta(seconds=duration_seconds),  # Approximate start time
                execution_end=datetime.now(),
                duration_seconds=duration_seconds,
                status=status,
                success=(status == "success"),
                error_message=error_message,
                error_details=None,
                result_data=result_data,
                service="scheduler",
                metadata={"logs": logs}  # Store the captured logs in metadata
            )
            
            self.job_detail_repository.log_execution(job_detail)
            logger.info("Recorded job completion with logs for %s (job_type: %s, execution_id: %s, status: %s, logs: %d)", 
                       job_name, job_type, execution_id, status, len(logs))
                
        except Exception as e:  # pylint: disable=broad-except
            logger.error("Failed to record job completion with logs for %s: %s", job_type, str(e))
    
    def _run_async_job(self, coroutine):
        """Safely run an async job in sync context"""
        try:
            # Create new event loop for async job execution
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                return loop.run_until_complete(coroutine)
            finally:
                loop.close()
        except Exception as e:
            logger.error(f"Error running async job: {e}")
            return {"status": "error", "error": str(e)}
    
    async def _execute_job_with_logging_async(self, cron_job):
        """Override to capture execution logs and store them in job detail records - ASYNC VERSION"""
        import time
        import asyncio
        from datetime import datetime
        from services.scheduler.app.utils.log_capture import LogCapture
        
        job_type = cron_job.job_id
        job_name = cron_job.name
        start_time = datetime.now()
        execution_start_timestamp = time.time()
        
        # Generate execution ID
        execution_id = f"{job_type}_{start_time.strftime('%Y%m%d_%H%M%S')}"
        
        # Create log capture instance
        log_capture = LogCapture()
        
        try:
            # Import audit logger (lazy import to avoid circular dependencies)
            import sys
            import os
            sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
            from libs.audit_queue.simple_logger import audit_logger
            
            # Record job start in job detail repository if available
            if hasattr(self, '_record_job_start'):
                execution_id = self._record_job_start(job_type, job_name, "scheduled", start_time)
            
            # Log job start
            audit_logger.log_scheduled_job(
                service=self.service_name,
                job_id=execution_id or job_type,
                status="started",
                message=f"Cron job started: {job_name}",
                job_name=job_name
            )
            
            logger.info("[ASYNC-EXEC] Starting scheduled job: %s (ID: %s)", job_name, job_type)
            log_capture.add_log("INFO", f"[ASYNC-EXEC] Starting scheduled job: {job_name} (ID: {job_type})")
            
            # Execute the actual job function with log capture
            # Capture both root logger and any named loggers
            with log_capture.capture_execution_logs():  # Capture root logger
                # Also set up handler for any existing loggers
                existing_loggers = [logging.getLogger(name) for name in logging.Logger.manager.loggerDict]
                for existing_logger in existing_loggers:
                    if existing_logger.level == logging.NOTSET:
                        existing_logger.setLevel(logging.INFO)
                
                # Handle both sync and async job functions
                if asyncio.iscoroutinefunction(cron_job.func):
                    # For async functions, await them directly
                    result = await cron_job.func()
                else:
                    # For sync functions, run in thread pool
                    loop = asyncio.get_event_loop()
                    result = await loop.run_in_executor(None, cron_job.func)
            
            # Calculate duration
            duration_ms = int((time.time() - execution_start_timestamp) * 1000)
            
            # Log successful completion
            audit_logger.log_scheduled_job(
                service=self.service_name,
                job_id=execution_id or job_type,
                status="completed",
                message=f"Cron job completed: {job_name}",
                job_name=job_name,
                duration_ms=duration_ms,
                result_data=result if isinstance(result, dict) else None
            )
            
            logger.info("[ASYNC-SUCCESS] Completed scheduled job: %s (Duration: %dms)", job_name, duration_ms)
            log_capture.add_log("INFO", f"[ASYNC-SUCCESS] Completed scheduled job: {job_name} (Duration: {duration_ms}ms)")
            
            # Update job completion record with captured logs
            if hasattr(self, 'job_detail_repository') and self.job_detail_repository:
                # Ensure result_data is a dict or None
                result_data = result if isinstance(result, dict) else None
                self._record_job_completion_with_logs(job_type, job_name, execution_id or job_type, "success", 
                                                    duration_ms / 1000, log_capture.get_logs(), result_data)
            
            return result
            
        except Exception as e:
            # Calculate duration even for failed jobs
            duration_ms = int((time.time() - execution_start_timestamp) * 1000)
            
            # Add error to captured logs
            log_capture.add_log("ERROR", f"[ASYNC-FAILED] Job execution failed: {str(e)}")
            
            # Log job failure
            try:
                audit_logger.log_scheduled_job(
                    service=self.service_name,
                    job_id=execution_id or job_type,
                    status="failed",
                    message=f"Cron job failed: {job_name} - {str(e)}",
                    job_name=job_name,
                    duration_ms=duration_ms,
                    exception_type=type(e).__name__,
                    error_message=str(e)
                )
            except Exception as audit_error:
                logger.error("Failed to log job failure: %s", audit_error)
                log_capture.add_log("ERROR", f"Failed to log job failure: {audit_error}")
            
            logger.error("[ASYNC-FAILED] Failed scheduled job: %s (Duration: %dms) - %s", job_name, duration_ms, str(e))
            
            # Update job completion record with captured logs (including error logs)
            if hasattr(self, 'job_detail_repository') and self.job_detail_repository:
                self._record_job_completion_with_logs(job_type, job_name, execution_id or job_type, "error", 
                                                    duration_ms / 1000, log_capture.get_logs(), None, str(e))
            
            raise
    
    # Job execution methods (delegates to target services following business rule)
    async def _execute_demand_data_job_delegate(self, payload: Optional[Dict[str, Any]] = None):
        """Delegate demand data management job to DummyDataService (follows business rule)"""
        logger.info("Delegating demand data management cron job to DummyDataService...")
        
        try:
            # Delegate to the target service which handles the complete lifecycle
            result = await dummy_data_service.execute_cron_job_demand_data_management(
                self.job_data_repository,
                self.job_detail_repository,
                payload
            )
            return result
                
        except Exception as e:  # pylint: disable=broad-except
            logger.error("Error delegating demand data management cron job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
     
    async def _execute_supply_data_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute the supply data management job with audit logging"""
        job_type = "supply_data_management"
        job_name = "Supply Data Management"
        schedule = settings.DEMAND_DATA_CRON_SCHEDULE
        start_time = datetime.now()
        
        # Record job start
        execution_id = self._record_job_start(job_type, job_name, schedule, start_time)
        
        # Log job start with audit logging
        if execution_id:
            audit_logger.log_system_operation(
                service="scheduler",
                operation="cron_job_started",
                message=f"Cron job started: {job_name}",
                job_detail_id=execution_id,
                job_name=job_name,
                job_type=job_type,
                execution_mode="scheduled"
            )
        
        try:
            logger.info("Starting %s cron job", job_type)
            
            # Delegate to dummy data service
            result = await dummy_data_service.execute_cron_job_supply_data_management(
                self.job_data_repository,
                self.job_detail_repository,
                payload
            )
            
            end_time = datetime.now()
            success = result.get('status') in ['success', 'partial_success']
            
            # Log job completion
            if execution_id:
                audit_logger.log_system_operation(
                    service="scheduler",
                    operation="cron_job_completed",
                    message=f"Cron job completed: {job_name}",
                    job_detail_id=execution_id,
                    job_name=job_name,
                    job_type=job_type,
                    execution_mode="scheduled",
                    duration_ms=int((end_time - start_time).total_seconds() * 1000),
                    success=success
                )
            
            # Record job completion
            self._record_job_completion(
                job_type, job_name, schedule, start_time, end_time, execution_id or job_type,
                "success" if success else "error", success, result
            )
            
            logger.info("Completed %s cron job: %s", job_type, result.get('status'))
            return result
            
        except Exception as e:
            end_time = datetime.now()
            logger.error("Error in %s cron job: %s", job_type, str(e))
            
            # Log job failure
            if execution_id:
                audit_logger.log_system_operation(
                    service="scheduler",
                    operation="cron_job_failed",
                    message=f"Cron job failed: {job_name} - {str(e)}",
                    job_detail_id=execution_id,
                    job_name=job_name,
                    job_type=job_type,
                    execution_mode="scheduled",
                    duration_ms=int((end_time - start_time).total_seconds() * 1000),
                    success=False,
                    exception_type=type(e).__name__
                )
            
            # Record job failure
            self._record_job_completion(
                job_type, job_name, schedule, start_time, end_time, execution_id or job_type,
                "error", False, error_message=str(e)
            )
            
            return {'status': 'error', 'error': str(e)}

    # Missing job execution methods
    def _execute_demand_data_management_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute demand data management job"""
        # Log job execution
        audit_logger.log_system_operation(
            service="scheduler",
            operation="cron_job_started",
            message=f"Cron job started: _execute_demand_data_management_job",
            job_type="_execute_demand_data_management_job",
            execution_mode="scheduled"
        )
        
        try:
            # Use sync wrapper for async delegate
            return self._run_async_job(self._execute_demand_data_job_delegate(payload))
        except Exception as e:
            logger.error("Error delegating demand data management job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_supply_data_management_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute supply data management job"""
        method_name = "_execute_supply_data_management_job"
        try:
            logger.info(f"Starting {method_name}")
            
            # Execute the async job
            result = asyncio.run(self._execute_supply_data_job(payload))
            
            # Log successful completion
            audit_logger.log_system_operation(
                service="scheduler",
                operation="cron_job_completed",
                message=f"Cron job completed: {method_name}",
                job_type=method_name,
                execution_mode="scheduled",
                success=True
            )
            
            return result
            
        except Exception as e:
            # Log job failure
            audit_logger.log_system_operation(
                service="scheduler",
                operation="cron_job_failed",
                message=f"Cron job failed: {method_name} - {str(e)}",
                job_type=method_name,
                execution_mode="scheduled",
                success=False,
                exception_type=type(e).__name__
            )
            logger.error("Error in %s: %s", method_name, str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_serve_data_reconciliation_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute serve data reconciliation job"""
        method_name = "_execute_serve_data_reconciliation_job"
        try:
            logger.info(f"Starting {method_name}")
            
            # Execute reconciliation logic
            from ..services.dummy_data_service import dummy_data_service
            result = dummy_data_service.reconcile_and_rerun_crons()
            
            # Log successful completion
            audit_logger.log_system_operation(
                service="scheduler",
                operation="cron_job_completed",
                message=f"Cron job completed: {method_name}",
                job_type=method_name,
                execution_mode="scheduled",
                success=True
            )
            
            return result
            
        except Exception as e:
            # Log job failure
            audit_logger.log_system_operation(
                service="scheduler",
                operation="cron_job_failed",
                message=f"Cron job failed: {method_name} - {str(e)}",
                job_type=method_name,
                execution_mode="scheduled",
                success=False,
                exception_type=type(e).__name__
            )
            logger.error("Error in %s: %s", method_name, str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_demand_data_processing_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute demand data processing job"""
        logger.info("Executing demand data processing job")
        try:
            # Import and use demand data processing service
            from ..services.demand_data_processing import DemandDataProcessor
            processor = DemandDataProcessor()
            return processor.process_demand_data(payload)
        except Exception as e:
            logger.error("Error in demand data processing job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_supply_data_processing_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute supply data processing job"""
        logger.info("Executing supply data processing job")
        try:
            # Import and use supply data processing service
            from ..services.supply_data_processing import SupplyDataProcessing
            processor = SupplyDataProcessing()
            return processor.process_supply_data(payload)
        except Exception as e:
            logger.error("Error in supply data processing job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_raw_data_processing_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute raw data processing job"""
        logger.info("Executing raw data processing job")
        try:
            # This would delegate to ingestion service processors
            result = {
                'status': 'success',
                'message': 'Raw data processing delegated to ingestion service',
                'processed_records': 0
            }
            return result
        except Exception as e:
            logger.error("Error in raw data processing job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_upload_raw_data_processor_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute upload raw data processor job (delegates to ingestion service)"""
        logger.info("Executing upload raw data processor job")
        try:
            # This delegates to the ingestion service
            result = {
                'status': 'success',
                'message': 'Upload processing delegated to ingestion service',
                'processed_files': 0
            }
            return result
        except Exception as e:
            logger.error("Error in upload raw data processor job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_scrape_raw_data_processor_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute scrape raw data processor job (delegates to ingestion service)"""
        logger.info("🔍 DEBUG: Starting scrape raw data processor job")
        try:
            logger.info("🔍 DEBUG: Inside try block of scrape job")
            # This delegates to the ingestion service
            result = {
                'status': 'success',
                'message': 'Scrape processing delegated to ingestion service',
                'processed_providers': 0
            }
            logger.info("🔍 DEBUG: Scrape job result: %s", result)
            return result
        except Exception as e:
            logger.error("🔍 DEBUG: Exception in scrape raw data processor job: %s", str(e))
            logger.error("🔍 DEBUG: Exception type: %s", type(e).__name__)
            import traceback
            logger.error("🔍 DEBUG: Full traceback: %s", traceback.format_exc())
            return {'status': 'error', 'error': str(e)}
    
    def _execute_iex_daf_data_scraping_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute IEX DAF data scraping job"""
        logger.info("Executing IEX DAF data scraping job")
        try:
            # Placeholder for IEX DAF scraping (currently disabled due to import issues)
            result = {
                'status': 'success',
                'message': 'IEX DAF scraping job placeholder - implementation pending',
                'scraped_records': 0
            }
            return result
        except Exception as e:
            logger.error("Error in IEX DAF scraping job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_iex_idf_data_scraping_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute IEX IDF data scraping job"""
        logger.info("Executing IEX IDF data scraping job")
        try:
            # Placeholder for IEX IDF scraping (currently disabled due to import issues)
            result = {
                'status': 'success',
                'message': 'IEX IDF scraping job placeholder - implementation pending',
                'scraped_records': 0
            }
            return result
        except Exception as e:
            logger.error("Error in IEX IDF scraping job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_exchange_serve_archival_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute exchange serve archival job"""
        logger.info("Executing exchange serve archival job")
        try:
            # Use the exchange processor's archival method
            import asyncio
            result = asyncio.run(self.exchange_processor.execute_archival_job())
            return result
        except Exception as e:
            logger.error("Error in exchange archival job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_demand_serve_archival_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute demand serve archival job"""
        logger.info("Executing demand serve archival job")
        try:
            # Use the demand processor's archival method
            import asyncio
            result = asyncio.run(self.demand_processor.execute_archival_job())
            return result
        except Exception as e:
            logger.error("Error in demand archival job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_supply_serve_archival_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute supply serve archival job"""
        logger.info("Executing supply serve archival job")
        try:
            # Use the supply processor's archival method
            import asyncio
            result = asyncio.run(self.supply_processor.execute_archival_job())
            return result
        except Exception as e:
            logger.error("Error in supply archival job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_weather_serve_archival_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute weather serve archival job"""
        logger.info("Executing weather serve archival job")
        try:
            # Use the weather processor's archival method
            import asyncio
            result = asyncio.run(self.weather_processor.execute_archival_job())
            return result
        except Exception as e:
            logger.error("Error in weather archival job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_bid_serve_archival_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute bid serve archival job"""
        logger.info("Executing bid serve archival job")
        try:
            # Use the bid processor's archival method
            import asyncio
            result = asyncio.run(self.bid_processor.execute_archival_job())
            return result
        except Exception as e:
            logger.error("Error in bid archival job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_system_cleanup_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute system cleanup job"""
        logger.info("Executing system cleanup job")
        try:
            # Placeholder for system cleanup logic
            result = {
                'status': 'success',
                'message': 'System cleanup job placeholder - implementation pending',
                'cleaned_files': 0
            }
            return result
        except Exception as e:
            logger.error("Error in system cleanup job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_retry_failed_jobs(self, payload: Optional[Dict[str, Any]] = None):
        """Execute retry failed jobs"""
        logger.info("Executing retry failed jobs")
        try:
            # Placeholder for retry logic
            result = {
                'status': 'success',
                'message': 'Retry failed jobs placeholder - implementation pending',
                'retried_jobs': 0
            }
            return result
        except Exception as e:
            logger.error("Error in retry failed jobs: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_data_migration_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute data migration job"""
        logger.info("Executing data migration job")
        try:
            # Placeholder for data migration logic
            result = {
                'status': 'success',
                'message': 'Data migration job placeholder - implementation pending',
                'migrated_records': 0
            }
            return result
        except Exception as e:
            logger.error("Error in data migration job: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def _execute_job_logs_cleanup_job(self, payload: Optional[Dict[str, Any]] = None):
        """Execute job logs cleanup"""
        logger.info("Executing job logs cleanup")
        try:
            # Placeholder for logs cleanup logic
            result = {
                'status': 'success',
                'message': 'Job logs cleanup placeholder - implementation pending',
                'cleaned_logs': 0
            }
            return result
        except Exception as e:
            logger.error("Error in job logs cleanup: %s", str(e))
            return {'status': 'error', 'error': str(e)}
    
    def get_job_execution_history(self, job_type: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get execution history for a specific job type"""
        try:
            # Get job execution history from the job detail repository
            if hasattr(self, 'job_detail_repository') and self.job_detail_repository:
                # The repository method expects job_id, which is the same as job_type in our case
                return self.job_detail_repository.get_job_execution_history(job_type, limit)
            else:
                logger.warning("Job detail repository not available for history retrieval")
                return []
        except Exception as e:
            logger.error("Failed to get job execution history for %s: %s", job_type, str(e))
            return []
    
    def get_all_job_executions(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get all job executions across all job types"""
        try:
            if hasattr(self, 'job_detail_repository') and self.job_detail_repository:
                return self.job_detail_repository.get_recent_job_executions(limit)
            else:
                logger.warning("Job detail repository not available for execution retrieval")
                return []
        except Exception as e:
            logger.error("Failed to get all job executions: %s", str(e))
            return []
    


# Global cron manager instance
cron_manager = CronManager()
