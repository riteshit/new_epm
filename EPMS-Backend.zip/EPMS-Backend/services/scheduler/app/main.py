"""
EPMS Scheduler Service
Handles cron jobs and scheduling
"""

# Auto-install libs package if not available
try:
    import libs.core.cron_manager
except ImportError:
    import sys
    import subprocess
    from pathlib import Path
    print("📦 Installing dependencies...")
    project_root = Path(__file__).parent.parent.parent.parent
    subprocess.check_call([
        sys.executable, "-m", "pip", "install", "-e", str(project_root)
    ])
    print("✅ Dependencies installed")

import sys
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import logging

from .core.config import settings
from .api.v1.routes import scheduler
from .routers import queue_health, job_monitoring
from .services.cron_manager import cron_manager
from .seeder.timeblock_seeder import TimeblockSeeder
from .shared.middleware.error_handler import ErrorHandlerMiddleware

# Configure logging with correlation ID support
from libs.middleware import configure_logging, LoggingMiddleware, CorrelationMiddleware, CacheMiddleware

# Configure logging based on settings
configure_logging(
    level=settings.LOG_LEVEL,
    format_type=getattr(settings, 'LOG_FORMAT', 'colored'),
    include_correlation=True
)

# Initialize logger (uses global config from configure_logging above)
logger = logging.getLogger("scheduler_service")


class HealthResponse(BaseModel):
    """Health check response model"""
    status: str
    service: str
    version: str
    timestamp: str


def run_timeblock_seeder():
    """Run the timeblock seeder and handle the results."""
    try:
        logger.info("Running timeblock seeder...")
        timeblock_seeder = TimeblockSeeder()
        seeder_result = timeblock_seeder.seed()
        
        if seeder_result['status'] == 'success':
            logger.info("Timeblock seeder completed successfully: %s", seeder_result['message'])
        elif seeder_result['status'] == 'skipped':
            logger.info("Timeblock seeder skipped: %s", seeder_result['message'])
        else:
            logger.warning("Timeblock seeder had issues: %s", seeder_result.get('message', 'Unknown error'))
            
    except Exception as e:
        logger.error("Failed to run timeblock seeder: %s", str(e))


def validate_database_configuration():
    """Validate database configuration"""
    try:
        # Check that job collections are properly configured
        job_collections = [
            settings.JOB_DATA_COLLECTION,
            settings.JOB_DETAIL_COLLECTION,
            settings.JOB_DETAIL_HISTORICAL_COLLECTION
        ]
        
        for collection in job_collections:
            if not collection:
                raise ValueError(f"Job collection name cannot be empty: {collection}")
        
        # Validate that required database settings are present
        if not settings.AUDIT_DB_URI:
            raise ValueError("AUDIT_DB_URI cannot be empty")
        
        if not settings.AUDIT_DB_NAME:
            raise ValueError("AUDIT_DB_NAME cannot be empty")
        
        print(f"✅ Database configuration validated - using database: {settings.AUDIT_DB_NAME}")
        
    except Exception as e:
        print(f"❌ Database configuration error: {e}")
        raise


async def start_cron_manager_async():
    """Start the cron manager asynchronously as a background task"""
    try:
        # Start the cron manager directly in the current event loop
        # since AsyncIOScheduler needs to be started in the same thread as the event loop
        cron_manager.start()
        logger.info("Cron scheduler started successfully in background")
    except Exception as e:
        logger.error(f"Failed to start cron scheduler in background: {str(e)}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup/shutdown events"""
    # Startup
    logger.info("Starting EPMS Scheduler Service...")
    logger.info(f"   Service: {settings.SERVICE_NAME}")
    logger.info(f"   Host: {settings.SERVICE_HOST}:{settings.SERVICE_PORT}")
    logger.info(f"   Debug: {settings.DEBUG}")
    logger.info(f"   Log Level: {settings.LOG_LEVEL}")
    
    # Validate configuration on startup
    validate_database_configuration()
    
    # Run timeblock seeder
    run_timeblock_seeder()
    
    # Step 2: Start the cron scheduler as a background task
    try:
        import asyncio
        # Start cron manager in background task
        asyncio.create_task(start_cron_manager_async())
        logger.info("Cron scheduler background task created successfully")
    except Exception as e:
        logger.error(f"Failed to create cron scheduler background task: {str(e)}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down EPMS Scheduler Service...")
    
    # Stop the cron scheduler
    try:
        cron_manager.stop()
        logger.info("Cron scheduler stopped successfully")
    except Exception as e:
        logger.error(f"Failed to stop cron scheduler: {str(e)}")


# Create FastAPI app
app = FastAPI(
    title=settings.SERVICE_NAME,
    version="1.0.0",
    lifespan=lifespan
)

# Add error handling middleware
app.add_middleware(ErrorHandlerMiddleware)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=settings.CORS_ALLOW_CREDENTIALS,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add middleware (order matters - last added = first executed)
logging_config = {
    "log_requests": True,
    "log_responses": True,
    "log_body": settings.DEBUG,  # Only log body in debug mode
    "exclude_paths": ["/health", "/docs", "/redoc", "/openapi.json", "/favicon.ico", "/static"]
}

# Add logging middleware first (executes last)
app.add_middleware(LoggingMiddleware, **logging_config)
# Add correlation middleware second (executes second to last)
app.add_middleware(CorrelationMiddleware)
# Add cache middleware third (executes third to last)
from libs.cache.config import get_ttl_config

app.add_middleware(
    CacheMiddleware,
    redis_host=settings.REDIS_HOST,
    redis_port=settings.REDIS_PORT,
    redis_db=settings.REDIS_DB,
    redis_password=settings.REDIS_PASSWORD or None,
    default_ttl=3600,
    ttl_config=get_ttl_config()
)

# Include routers
app.include_router(scheduler.router, prefix="/api/v1/scheduler", tags=["scheduler"])
app.include_router(queue_health.router, tags=["queue"])
app.include_router(job_monitoring.router, tags=["job-monitoring"])

# Mount static files
from pathlib import Path
static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


# Endpoints
@app.get("/config")
async def get_config():
    """Get frontend configuration"""
    return {
        "auth_service_url": settings.AUTH_SERVICE_URL + "/api/v1",
        "base_path": settings.BASE_PATH
    }


@app.get("/login", response_class=HTMLResponse)
async def login_page():
    """Serve login page"""
    static_dir = Path(__file__).parent / "static"
    login_file = static_dir / "login.html"
    
    if login_file.exists():
        return HTMLResponse(content=login_file.read_text(encoding='utf-8'))
    else:
        return HTMLResponse(content="<h1>Login page not found</h1>", status_code=404)


@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page():
    """Serve dashboard page"""
    static_dir = Path(__file__).parent / "static"
    dashboard_file = static_dir / "job_dashboard.html"
    
    if dashboard_file.exists():
        return HTMLResponse(content=dashboard_file.read_text(encoding='utf-8'))
    else:
        return HTMLResponse(content="<h1>Dashboard page not found</h1>", status_code=404)


@app.get("/", response_class=HTMLResponse)
async def index_page():
    """Serve index page"""
    static_dir = Path(__file__).parent / "static"
    index_file = static_dir / "index.html"
    
    if index_file.exists():
        return HTMLResponse(content=index_file.read_text(encoding='utf-8'))
    else:
        return HTMLResponse(content="<h1>Welcome to Scheduler Service</h1>")


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": settings.SERVICE_NAME,
        "scheduler_running": cron_manager.is_running(),
        "database": settings.AUDIT_DB_NAME
    }


@app.get("/cache/health")
async def cache_health_check():
    """Cache service health check endpoint"""
    from libs.middleware import check_cache_health
    return await check_cache_health()


@app.get("/cache/stats")
async def cache_stats():
    """Get cache service statistics"""
    from libs.middleware import get_cache_metrics
    return get_cache_metrics()


@app.post("/cache/clear/{pattern}")
async def clear_cache_pattern(pattern: str):
    """Clear cache keys matching a pattern"""
    from libs.middleware import clear_cache_pattern
    cleared_count = clear_cache_pattern(pattern)
    return {
        "message": f"Cleared {cleared_count} cache keys matching pattern '{pattern}'",
        "cleared_count": cleared_count
    }





if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.SERVICE_HOST,
        port=settings.SERVICE_PORT,
        reload=settings.DEBUG
    ) 