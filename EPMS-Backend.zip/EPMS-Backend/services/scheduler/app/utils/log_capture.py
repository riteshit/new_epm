"""
Log Capture Utility for Job Execution
Captures and stores execution logs for display in the dashboard
"""

import logging
import io
import sys
from datetime import datetime
from typing import List, Dict, Any
from contextlib import contextmanager


class LogCapture:
    """Utility class to capture logs during job execution"""
    
    def __init__(self):
        self.logs: List[Dict[str, Any]] = []
        self.log_handler = None
        self.original_stdout = None
        self.original_stderr = None
        self.stdout_capture = None
        self.stderr_capture = None
    
    def add_log(self, level: str, message: str, timestamp: datetime = None):
        """Add a log entry manually"""
        if timestamp is None:
            timestamp = datetime.utcnow()
        
        self.logs.append({
            "timestamp": timestamp.isoformat(),
            "level": level,
            "message": str(message)
        })
    
    def get_logs(self) -> List[Dict[str, Any]]:
        """Get all captured logs"""
        return self.logs.copy()
    
    def clear_logs(self):
        """Clear all captured logs"""
        self.logs.clear()
    
    @contextmanager
    def capture_execution_logs(self, logger_name: str = None):
        """
        Context manager to capture logs during job execution
        
        Args:
            logger_name: Name of the logger to capture (if None, captures root logger)
        """
        # Set up log handler to capture logs
        self.log_handler = LogCaptureHandler(self)
        
        # Get the logger to capture
        if logger_name:
            target_logger = logging.getLogger(logger_name)
        else:
            target_logger = logging.getLogger()
        
        # Store original level and add our handler
        original_level = target_logger.level
        target_logger.addHandler(self.log_handler)
        
        # Capture stdout and stderr
        self.original_stdout = sys.stdout
        self.original_stderr = sys.stderr
        self.stdout_capture = io.StringIO()
        self.stderr_capture = io.StringIO()
        
        sys.stdout = LoggingStringIO(self, 'INFO', self.original_stdout)
        sys.stderr = LoggingStringIO(self, 'ERROR', self.original_stderr)
        
        try:
            yield self
        finally:
            # Restore original streams
            sys.stdout = self.original_stdout
            sys.stderr = self.original_stderr
            
            # Remove our handler
            target_logger.removeHandler(self.log_handler)
            
            # Capture any remaining output from StringIO buffers
            if self.stdout_capture.getvalue():
                self.add_log('INFO', f"STDOUT: {self.stdout_capture.getvalue().strip()}")
            if self.stderr_capture.getvalue():
                self.add_log('ERROR', f"STDERR: {self.stderr_capture.getvalue().strip()}")


class LogCaptureHandler(logging.Handler):
    """Custom logging handler to capture log messages"""
    
    def __init__(self, log_capture: LogCapture):
        super().__init__()
        self.log_capture = log_capture
    
    def emit(self, record):
        """Emit a log record by adding it to the log capture"""
        try:
            level = record.levelname
            message = self.format(record)
            timestamp = datetime.fromtimestamp(record.created)
            self.log_capture.add_log(level, message, timestamp)
        except Exception:
            # Don't let logging errors break the job execution
            pass


class LoggingStringIO:
    """StringIO wrapper that also logs to our capture system"""
    
    def __init__(self, log_capture: LogCapture, level: str, original_stream):
        self.log_capture = log_capture
        self.level = level
        self.original_stream = original_stream
        self.buffer = io.StringIO()
    
    def write(self, text):
        """Write text to both the original stream and capture it"""
        # Write to original stream
        if self.original_stream:
            self.original_stream.write(text)
            self.original_stream.flush()
        
        # Capture for logs if it's not just whitespace
        if text.strip():
            self.log_capture.add_log(self.level, text.strip())
        
        return len(text)
    
    def flush(self):
        """Flush the original stream"""
        if self.original_stream:
            self.original_stream.flush()
    
    def __getattr__(self, name):
        """Delegate other attributes to the original stream"""
        return getattr(self.original_stream, name)