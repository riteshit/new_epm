"""
Scheduler Job Seeder
Seeds scheduler-specific cron job configurations
"""

import logging
from typing import List, Dict, Any
from libs.core.job_seeder import BaseJobSeeder
from libs.core.job_repositories import JobDataRepository
from services.scheduler.app.core.config import settings

logger = logging.getLogger(__name__)


class SchedulerJobSeeder(BaseJobSeeder):
    """Seeder for scheduler-specific cron jobs"""
    
    def __init__(self, job_data_repository: JobDataRepository):
        """Initialize scheduler job seeder"""
        super().__init__(job_data_repository, "scheduler")
        self.settings = settings
    
    def get_default_jobs(self) -> List[Dict[str, Any]]:
        """Get default scheduler jobs"""
        return [
            # Core Data Management Jobs
            {
                "job_type": "date_update",
                "name": "Date Update for Scheduled Entries",
                "type": "data_management",
                "schedule": getattr(self.settings, 'DATA_UPDATE_CRON', "0 0 * * *"),  # Daily at midnight
                "enabled": getattr(self.settings, 'DATA_UPDATE_CRON_ENABLED', False),
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Updates scheduled_date fields in serve collections",
                "priority": 3
            },
            # 
            # Data Processing Jobs
            {
                "job_type": "demand_data_processing",
                "name": "Demand Data Processing",
                "type": "data_processing",
                "schedule": getattr(self.settings, 'DEMAND_DATA_PROCESSING_CRON_SCHEDULE', '0 1 * * *'),
                "enabled": getattr(self.settings, 'DEMAND_DATA__PROCESSING_CRON_ENABLED', True),
                "timezone": getattr(self.settings, 'DEMAND_DATA__PROCESSING_CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Processes demand data from raw data to serve collections",
                "priority": 4
            },
            {
                "job_type": "supply_data_processing",
                "name": "Supply Data Processing",
                "type": "data_processing",
                "schedule": getattr(self.settings, 'SUPPLY_DATA__PROCESSING_CRON_SCHEDULE', '0 1 * * *'),
                "enabled": getattr(self.settings, 'SUPPLY_DATA__PROCESSING_CRON_ENABLED', True),
                "timezone": getattr(self.settings, 'SUPPLY_DATA__PROCESSING_CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Processes supply data from raw data to serve collections",
                "priority": 4
            },
            # New Processor Jobs
            {
                "job_type": "weather_data_processing",
                "name": "Weather Data Processing",
                "type": "data_processing",
                "schedule": getattr(self.settings, 'WEATHER_DATA_PROCESSING_CRON', '*/15 * * * *'),  # Every 15 minutes
                "enabled": getattr(self.settings, 'WEATHER_DATA_PROCESSING_ENABLED', True),
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Processes weather data from raw data to weather_serve collection",
                "priority": 5
            },
            {
                "job_type": "bid_data_processing",
                "name": "Bid Data Processing",
                "type": "data_processing",
                "schedule": getattr(self.settings, 'BID_DATA_PROCESSING_CRON', "*/15 * * * *"),  # Every 15 minutes
                "enabled": getattr(self.settings, 'BID_DATA_PROCESSING_ENABLED', True),
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Processes bid data from raw data to bid_trade_serve collection",
                "priority": 5
            },
            {
                "job_type": "exchange_data_processing",
                "name": "Exchange Data Processing",
                "type": "data_processing",
                "schedule": getattr(self.settings, 'EXCHANGE_DATA_PROCESSING_CRON', "*/15 * * * *"),
                "enabled": getattr(self.settings, 'EXCHANGE_DATA_PROCESSING_ENABLED', True),
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Processes exchange data from raw data to exchange_serve collection with complex logic",
                "priority": 5
            },
            {
                "job_type": "exchange_serve_archival",
                "name": "Exchange Serve Data Archival",
                "type": "maintenance",
                "schedule": "0 0 * * *",  # Daily at 12 AM
                "enabled": True,  # Enabled for 4-day rolling window archival
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Archives exchange serve data older than 4 days to historical collection (4-day rolling window: today, tomorrow, yesterday, day before yesterday)",
                "priority": 7
            },
            # 
            # System Maintenance Jobs
            {
                "job_type": "system_cleanup",
                "name": "System Cleanup",
                "type": "maintenance",
                "schedule": getattr(self.settings, 'SYSTEM_CLEANUP_SCHEDULE', '0 2 * * *'),
                "enabled": getattr(self.settings, 'SYSTEM_CLEANUP_ENABLED', False),
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'UTC'),
                "description": "Cleans up old system data and logs",
                "priority": 8
            },
            {
                "job_type": "retry_failed_jobs",
                "name": "Retry Failed Jobs",
                "type": "recovery",
                "schedule": getattr(self.settings, 'RETRY_FAILED_JOBS_SCHEDULE', '*/15 * * * *'),
                "enabled": getattr(self.settings, 'RETRY_FAILED_JOBS_ENABLED', False),
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'UTC'),
                "description": "Retries failed job executions",
                "priority": 9
            },
            {
                "job_type": "demand_serve_archival",
                "name": "Demand Serve Data Archival",
                "type": "maintenance",
                "schedule": "0 0 * * *",  # Daily at 12 AM
                "enabled": True,  # Enabled for 4-day rolling window archival
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Archives demand serve data older than 4 days to historical collection (4-day rolling window: today, tomorrow, yesterday, day before yesterday)",
                "priority": 7
            },
            {
                "job_type": "supply_serve_archival",
                "name": "Supply Serve Data Archival",
                "type": "maintenance",
                "schedule": "0 0 * * *",  # Daily at 12 AM
                "enabled": True,  # Enabled for 4-day rolling window archival
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Archives supply serve data older than 4 days to historical collection (4-day rolling window: today, tomorrow, yesterday, day before yesterday)",
                "priority": 7
            },
            {
                "job_type": "weather_serve_archival",
                "name": "Weather Serve Data Archival",
                "type": "maintenance",
                "schedule": "0 0 * * *",  # Daily at 12 AM
                "enabled": True,  # Enabled for 4-day rolling window archival
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Archives weather serve data older than 4 days to historical collection (4-day rolling window: today, tomorrow, yesterday, day before yesterday)",
                "priority": 7
            },
            {
                "job_type": "bid_serve_archival",
                "name": "Bid Serve Data Archival",
                "type": "maintenance",
                "schedule": "0 0 * * *",  # Daily at 12 AM
                "enabled": True,  # Enabled for 4-day rolling window archival
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Archives bid serve data older than 4 days to historical collection (4-day rolling window: today, tomorrow, yesterday, day before yesterday)",
                "priority": 7
            },
            # 
            # Data Archival Jobs
            {
                "job_type": "data_migration",
                "name": "Data Migration to Historical",
                "type": "maintenance",
                "schedule": getattr(self.settings, 'JOB_LOGS_MIGRATION_SCHEDULE', '0 3 * * *'),
                "enabled": False,
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'UTC'),
                "description": "Migrates old data to historical collection",
                "priority": 10
            },
            {
                "job_type": "job_logs_cleanup",
                "name": "Job Logs Cleanup",
                "type": "maintenance",
                "schedule": getattr(self.settings, 'JOB_LOGS_CLEANUP_SCHEDULE', '0 4 * * *'),
                "enabled": False,
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'UTC'),
                "description": "Cleans up old job execution logs",
                "priority": 11
            }
            ,
            {
                "job_type": "peak_demand_compute",
                "name": "Peak Demand Compute",
                "type": "data_processing",
                "schedule": "0 0 * * *",  # Daily at 12 AM
                "enabled": True,
                "timezone": getattr(self.settings, 'CRON_TIMEZONE', 'Asia/Kolkata'),
                "description": "Computes yesterday's peak comp_act_demand and stores in peak_demand_serve",
                "priority": 6
            }
        ]


# Global scheduler job seeder instance
def create_scheduler_job_seeder(job_data_repository: JobDataRepository) -> SchedulerJobSeeder:
    """Create scheduler job seeder instance"""
    return SchedulerJobSeeder(job_data_repository)
