"""
Scheduler Service API v1
""" 