"""
Scheduler Service Core
""" 