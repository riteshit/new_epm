# EPMS Processing Service

## Overview

The EPMS Processing Service is a microservice responsible for data validation, transformation, and quality checks in the Energy Portfolio Management System (EPMS). It provides advanced data processing capabilities including machine learning-based validation, data quality scoring, and automated data transformation workflows.

## Features

- **Data Validation**: Comprehensive validation with multiple rule engines
- **Data Transformation**: Automated data cleaning and transformation
- **Quality Scoring**: ML-based data quality assessment
- **Schema Validation**: JSON Schema and Cerberus validation
- **Data Profiling**: Automated data profiling and statistics
- **Machine Learning**: Scikit-learn based data quality models
- **Great Expectations**: Advanced data quality testing framework
- **Async Processing**: Background task processing with Celery
- **RESTful API**: Comprehensive API with full documentation
- **Monitoring**: Real-time processing metrics and monitoring

## Project Structure

```
processing/
├── app/
│   ├── api/
│   │   └── v1/
│   │       └── routes/
│   │           └── __init__.py
│   ├── controllers/
│   │   └── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   └── logger.py
│   ├── main.py
│   ├── models/
│   │   └── __init__.py
│   ├── schemas/
│   │   └── __init__.py
│   └── services/
│       └── __init__.py
├── requirements.txt
└── README.md
```

## Technology Stack

- **Framework**: FastAPI 0.109.2
- **ASGI Server**: Uvicorn 0.27.1
- **Database**: MongoDB (PyMongo 4.6.1)
- **Data Processing**: Pandas 2.2.0, NumPy 1.26.4
- **Machine Learning**: Scikit-learn 1.4.0
- **Data Quality**: Great Expectations 0.18.25
- **Validation**: JSON Schema 4.21.0, Cerberus 1.3.5
- **Background Tasks**: Celery 5.3.4
- **HTTP Client**: httpx 0.26.0
- **Validation**: Pydantic 2.6.1
- **Configuration**: Pydantic Settings 2.1.0
- **Caching**: Redis 5.0.1

## Prerequisites

- Python 3.8+
- MongoDB
- Redis
- Celery (for background processing)
- Virtual environment (recommended) 

## Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd EPMS-Backend/services/processing
```

### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Environment Configuration
Create a `.env` file in the processing service directory:

```env
# Service Configuration
SERVICE_NAME=processing-service
SERVICE_PORT=8003
SERVICE_HOST=0.0.0.0
DEBUG=true
LOG_LEVEL=INFO

# Database Configuration
MONGODB_URI=mongodb://localhost:27017
PROCESSING_DB_NAME=processing_db
AUDIT_DB_NAME=audit_db

# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0

# JWT Configuration
JWT_SECRET_KEY=your-super-secret-jwt-key-change-in-production
JWT_ALGORITHM=HS256

# Processing Configuration
MAX_BATCH_SIZE=10000
PROCESSING_TIMEOUT=300
QUALITY_THRESHOLD=0.8

# ML Model Configuration
MODEL_PATH=./models
MODEL_VERSION=v1.0.0
ENABLE_ML_PROCESSING=true

# Celery Configuration
CELERY_BROKER_URL=redis://localhost:6379/1
CELERY_RESULT_BACKEND=redis://localhost:6379/2

# CORS Configuration
CORS_ORIGINS=["http://localhost:3000","http://localhost:8080"]
```

### 5. Start the Service
```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8003 --reload
```

### 6. Start Celery Worker (Optional)
```bash
celery -A app.celery_app worker --loglevel=info
```

## API Documentation

### Base URL
```
http://localhost:8003
```



### Interactive Documentation
- Swagger UI: `http://localhost:8003/docs`
- ReDoc: `http://localhost:8003/redoc`

## Data Processing Features

### Validation Engines

The service supports multiple validation engines:

| Engine | Description | Use Case |
|--------|-------------|----------|
| **JSON Schema** | Schema-based validation | API data validation |
| **Cerberus** | Rule-based validation | Business rule validation |
| **Great Expectations** | Data quality testing | Production data validation |
| **Custom Rules** | Custom validation logic | Domain-specific validation |

### Data Transformation

Available transformation types:

- **Data Cleaning**: Remove duplicates, handle missing values
- **Type Conversion**: Convert data types
- **Normalization**: Standardize data formats
- **Aggregation**: Summarize data
- **Custom Transformations**: Domain-specific transformations

### Quality Assessment

Quality metrics include:

- **Completeness**: Percentage of non-null values
- **Accuracy**: Data accuracy assessment
- **Consistency**: Data format consistency
- **Timeliness**: Data freshness
- **Validity**: Data format validity

## Configuration

### Service Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `SERVICE_PORT` | 8003 | Service port |
| `SERVICE_HOST` | 0.0.0.0 | Service host |
| `DEBUG` | true | Debug mode |
| `LOG_LEVEL` | INFO | Logging level |

### Processing Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `MAX_BATCH_SIZE` | 10000 | Maximum batch size for processing |
| `PROCESSING_TIMEOUT` | 300 | Processing timeout in seconds |
| `QUALITY_THRESHOLD` | 0.8 | Minimum quality score threshold |

### ML Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `MODEL_PATH` | ./models | Path to ML models |
| `MODEL_VERSION` | v1.0.0 | Current model version |
| `ENABLE_ML_PROCESSING` | true | Enable ML-based processing |

### Database Configuration
| Variable | Default | Description |
|----------|---------|-------------|
| `MONGODB_URI` | mongodb://localhost:27017 | MongoDB connection string |
| `PROCESSING_DB_NAME` | processing_db | Processing database name |
| `AUDIT_DB_NAME` | audit_db | Audit database name |

## Usage Examples

### Validate Data
```bash
curl -X POST "http://localhost:8003/api/v1/process/validate" \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "timestamp": "2024-01-01T00:00:00Z",
      "value": 100.5,
      "unit": "MW",
      "location": "Plant-A"
    },
    "validation_rules": ["schema_check", "range_check"],
    "schema_id": "energy_data_schema"
  }'
```

### Transform Data
```bash
curl -X POST "http://localhost:8003/api/v1/process/transform" \
  -H "Content-Type: application/json" \
  -d '{
    "data": [
      {"timestamp": "2024-01-01T00:00:00Z", "value": 100.5},
      {"timestamp": "2024-01-01T01:00:00Z", "value": 105.2}
    ],
    "transformations": [
      {"type": "normalize_timestamp", "format": "ISO"},
      {"type": "convert_units", "from": "MW", "to": "kW"}
    ]
  }'
```

### Assess Quality
```bash
curl -X POST "http://localhost:8003/api/v1/quality/assess" \
  -H "Content-Type: application/json" \
  -d '{
    "data": [
      {"timestamp": "2024-01-01T00:00:00Z", "value": 100.5},
      {"timestamp": "2024-01-01T01:00:00Z", "value": 105.2}
    ],
    "metrics": ["completeness", "accuracy", "consistency"]
  }'
```

### ML Prediction
```bash
curl -X POST "http://localhost:8003/api/v1/ml/predict" \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "timestamp": "2024-01-01T00:00:00Z",
      "value": 100.5,
      "unit": "MW"
    },
    "model_id": "quality_predictor_v1"
  }'
```

## Development

### Running Tests
```bash
# Run all tests
python -m pytest tests/processing/

# Run with coverage
python -m pytest tests/processing/ --cov=app --cov-report=html
```

### Code Quality
```bash
# Linting
flake8 app/

# Type checking
mypy app/
```

### ML Model Development
```bash
# Train new model
python scripts/train_model.py --config configs/model_config.yaml

# Evaluate model
python scripts/evaluate_model.py --model_path ./models/quality_predictor_v1
```

## Monitoring & Logging

### Health Checks
The service provides health check endpoints for monitoring:
- `GET /health` - Returns service status and version

### Logging
Logs are structured in JSON format and include:
- Processing job events
- Validation results
- Quality assessment metrics
- ML model predictions
- Error tracking
- Performance metrics

### Metrics
Key metrics to monitor:
- Processing job success/failure rates
- Validation accuracy rates
- Quality score distributions
- ML model performance
- API response times
- Queue processing metrics

## Performance Optimization

### Data Processing
- Batch processing for large datasets
- Parallel processing with Celery
- Memory-efficient data handling
- Caching for repeated operations

### ML Model Optimization
- Model caching and versioning
- Batch prediction for efficiency
- Model performance monitoring
- Automated model retraining

### Database Optimization
- Connection pooling
- Indexed queries for processing results
- Efficient data storage
- Audit trail optimization

## Security Considerations

### Data Security
- Input validation and sanitization
- Secure data transmission
- Data encryption for sensitive information
- Access control for processing jobs

### ML Model Security
- Model validation and testing
- Secure model storage
- Input validation for predictions
- Model version control

### API Security
- JWT token validation
- Rate limiting
- Input sanitization
- Error handling without information leakage

## Troubleshooting

### Common Issues

1. **Processing Timeouts**
   - Increase processing timeout
   - Optimize batch sizes
   - Check system resources
   - Review processing logic

2. **ML Model Errors**
   - Verify model files exist
   - Check model version compatibility
   - Validate input data format
   - Review model training data

3. **Validation Failures**
   - Check validation rules
   - Verify data format
   - Review schema definitions
   - Validate business rules

4. **Memory Issues**
   - Reduce batch sizes
   - Implement data streaming
   - Monitor memory usage
   - Optimize data structures

### Logs
Check application logs for detailed error information:
```bash
tail -f logs/processing-service.log
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## License

This project is part of the EPMS (Energy Portfolio Management System) and is proprietary software.

## Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the main EPMS documentation 
