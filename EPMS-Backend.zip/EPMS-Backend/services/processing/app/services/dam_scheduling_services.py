import logging
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, Optional, List

from fastapi import HTTPException


from ..repository.serve_dam_scheduling import serveDamSchedulingRepository

logger = logging.getLogger(__name__)


class ServeDamSchedulingServices:
    """
    Service layer for DAM scheduling views.
    Produces the exact shape requested:

    {
      "schedule_date": [
        {
          "c_s": "central / state",
          "plant_name": "<plant_id or looked up name>",
          "vc": "_",
          "biddable_price": "-",
          "data": [
            {"time_block": 1, "volume": <float>},
            ... up to 96
          ]
        },
        ...
      ]
    }
    """

    IST = timezone(timedelta(hours=5, minutes=30))

    def __init__(self, collection_name: str = "serve_dam_scheduling"):
        self.repo = serveDamSchedulingRepository(collection_name=collection_name)

    # ---------- Helpers ----------
    @classmethod
    def _today_ist_str(cls) -> str:
        return datetime.now(cls.IST).date().isoformat()

    # ---------- Main methods ----------

    def schedule_by_date(
        self, schedule_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Build a single document with:
        {
        "schedule_date": [
            { c_s, plant_id, vc, biddable_price, data:[{time_block, volume}, ...1..96] },
            ...
        ]
        }
        for ALL plant_ids on the date.
        """
        date_str = schedule_date or self._today_ist_str()
        if schedule_date:
            try:
                datetime.strptime(schedule_date, "%Y-%m-%d")
            except ValueError:
                raise HTTPException(status_code=422, detail="schedule_date must be YYYY-MM-DD")

        R = lambda x: {"$round": [x, 2]}

        pipeline = [
            {"$match": {"schedule_date": date_str}},

            # Group per plant using a composite key to avoid merging when plant_id is missing
            {
                "$group": {
                    "_id": {
                        "pid": {"$ifNull": ["$plant_id", ""]},
                        "pname_norm": {
                            "$toUpper": {
                                "$trim": {"input": {"$ifNull": ["$plant_name", ""]}}
                            }
                        }
                    },
                    "plant_id": {"$first": "$plant_id"},
                    "plant_name_src": {"$first": "$plant_name"},
                    "c_s_src": {"$first": "$c_s"},
                    "blocks": {"$push": "$time_block"},
                    "volumes": {"$push": {"$ifNull": ["$schedule_volume", 0]}}
                }
            },

            # Prefer plant_id match; fallback to case/trim-insensitive plant_name match
            {
                "$lookup": {
                    "from": "plant_master",
                    "let": {
                        "pid": "$plant_id",
                        "pname": {"$ifNull": ["$plant_name_src", ""]},
                        "pname_norm": {
                            "$toUpper": {"$trim": {"input": {"$ifNull": ["$plant_name_src", ""]}}}
                        }
                    },
                    "pipeline": [
                        {
                            "$match": {
                                "$expr": {
                                    "$cond": [
                                        {
                                            "$and": [
                                                {"$ne": ["$$pid", None]},
                                                {"$ne": ["$$pid", ""]}
                                            ]
                                        },
                                        {"$eq": ["$plant_id", "$$pid"]},
                                        {
                                            "$and": [
                                                {"$ne": ["$$pname_norm", ""]},
                                                {
                                                    "$eq": [
                                                        {
                                                            "$toUpper": {
                                                                "$trim": {"input": "$plant_name"}
                                                            }
                                                        },
                                                        "$$pname_norm"
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            }
                        },
                        # Project prices robustly (handle vc_price/VC_price, px_price/PX_price; convert to numbers)
                        {
                            "$project": {
                                "_id": 0,
                                "plant_id": 1,
                                "c_s": 1,
                                "vc_price": {
                                    "$convert": {
                                        "input": {"$ifNull": ["$vc_price", "$VC_price"]},
                                        "to": "double",
                                        "onError": None,
                                        "onNull": None
                                    }
                                },
                                "px_price": {
                                    "$convert": {
                                        "input": {"$ifNull": ["$px_price", "$PX_price"]},
                                        "to": "double",
                                        "onError": None,
                                        "onNull": None
                                    }
                                }
                            }
                        }
                    ],
                    "as": "pm"
                }
            },

            {"$addFields": {"pm": {"$first": "$pm"}}},
            {"$addFields": {"range": {"$range": [1, 97]}}},

            {
                "$project": {
                    "_id": 0,

                    # Output plant_id; if missing but master matched via name, use pm.plant_id; else fallback to empty string
                    "plant_id": {
                        "$ifNull": [
                            "$plant_id",
                            {"$ifNull": ["$pm.plant_id", ""]}
                        ]
                    },

                    "c_s": {
                        "$ifNull": ["$pm.c_s", {"$ifNull": ["$c_s_src", "central / state"]}]
                    },
                    "vc": {"$ifNull": ["$pm.vc_price", None]},
                    "biddable_price": {"$ifNull": ["$pm.px_price", None]},
                    "data": {
                        "$map": {
                            "input": "$range",
                            "as": "tb",
                            "in": {
                                "time_block": "$$tb",
                                "volume": R({
                                    "$let": {
                                        "vars": {"idx": {"$indexOfArray": ["$blocks", "$$tb"]}},
                                        "in": {
                                            "$cond": [
                                                {"$ne": ["$$idx", -1]},
                                                {"$arrayElemAt": ["$volumes", "$$idx"]},
                                                0
                                            ]
                                        }
                                    }
                                })
                            }
                        }
                    }
                }
            },

            {"$sort": {"plant_id": 1}},

            {
                "$group": {
                    "_id": None,
                    "schedule_entries": {
                        "$push": {
                            "c_s": "$c_s",
                            "plant_id": "$plant_id",
                            "vc": "$vc",
                            "biddable_price": "$biddable_price",
                            "data": "$data"
                        }
                    }
                }
            },
            {"$project": {"_id": 0, "schedule_date": "$schedule_entries"}}
        ]

        try:
            docs = self.repo.aggregate(pipeline)
            if not docs:
                return {"schedule_date": []}
            return docs[0]
        except Exception:
            logger.exception("schedule_by_date failed | schedule_date=%s", date_str)
            raise HTTPException(status_code=500, detail="Failed to build DAM schedule view.")


# Global instance for controller import
serve_dam_scheduling_services = ServeDamSchedulingServices()