"""
Generic Base Repository for v2 API
Provides common database operations that work with any collection
"""

from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database
from bson import ObjectId
from ...core.config import settings
import logging
import json
import asyncio
from concurrent.futures import ThreadPoolExecutor
from datetime import date

logger = logging.getLogger(__name__)


def _serialize_value(value):
    """Convert common BSON/Mongo types to JSON-serializable values."""
    try:
        # primitives
        if value is None or isinstance(value, (int, float, bool, str)):
            return value
        if isinstance(value, ObjectId):
            return str(value)
        if isinstance(value, (date, datetime)):
            return value.isoformat()
        if isinstance(value, dict):
            return {k: _serialize_value(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [_serialize_value(v) for v in value]
        return str(value)
    except Exception:
        try:
            return str(value)
        except Exception:
            return None


class CursorWrapper:
    """Wrap a PyMongo cursor and yield serialized documents while preserving chainable methods."""
    def __init__(self, cursor):
        self._cursor = cursor

    def sort(self, *args, **kwargs):
        return CursorWrapper(self._cursor.sort(*args, **kwargs))

    def limit(self, *args, **kwargs):
        return CursorWrapper(self._cursor.limit(*args, **kwargs))

    def skip(self, *args, **kwargs):
        return CursorWrapper(self._cursor.skip(*args, **kwargs))

    def batch_size(self, *args, **kwargs):
        return CursorWrapper(self._cursor.batch_size(*args, **kwargs))

    def __iter__(self):
        for doc in self._cursor:
            yield _serialize_value(doc)

    def __next__(self):
        doc = next(self._cursor)
        return _serialize_value(doc)

    def next(self):
        return self.__next__()

    def to_list(self):
        return [ _serialize_value(d) for d in self._cursor ]



class GenericRepository:
    """
    Generic repository class for database operations.
    Handles common database functionality with MongoDB.
    """

    def __init__(self):
        self._client: Optional[MongoClient] = None
        self._db: Optional[Database] = None
        self.db_name = None
        
        logger.info("GenericRepository initialized (lazy connection)")
    
    @property
    def client(self) -> MongoClient:
        """Lazy initialization of MongoDB client"""
        if self._client is None:
            logger.info(f"Connecting to MongoDB: {settings.MONGODB_URI[:50]}...")
            self._client = MongoClient(settings.MONGODB_URI)
            logger.debug(f"MongoDB client created successfully")
        return self._client
    
    @property 
    def db(self) -> Database:
        """Lazy initialization of MongoDB database"""
        if self._db is None:
            self.db_name = settings.MONGODB_DATABASE
            self._db = self.client[self.db_name]
            logger.info(f"Connected to database: {self.db_name}")
            logger.debug(f"Logger effective level: {logger.getEffectiveLevel()}")
        return self._db
    
    def get_all(
        self, 
        collection_name: str,
        filter: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        sort: Optional[List[Tuple[str, int]]] = None,
        skip: int = 0, # Added skip parameter
        limit: Optional[int] = None,
        batch_size: int = 1000
    ) -> List[Dict[str, Any]]:
        """
        Get all documents from any collection with optional filtering, projection, and sorting
        
        Args:
            collection_name: Name of the collection to query
            filter: MongoDB filter query (default: {})
            projection: Fields to include/exclude (default: None - all fields)
            sort: List of (field, direction) tuples for sorting (default: None)
            skip: Number of documents to skip (default: 0)
            limit: Maximum number of documents to return (default: None - no limit)
            batch_size: Cursor batch size for memory efficiency (default: 1000)
            
        Returns:
            List of documents matching the criteria
        """
        try:
            collection = self.db[collection_name]
            query_filter = filter or {}
            
            # Create cursor with batch size optimization
            cursor = collection.find(query_filter, projection).batch_size(batch_size)
            
            if sort:
                cursor = cursor.sort(sort)
            
            if skip > 0:
                cursor = cursor.skip(skip)

            if limit:
                cursor = cursor.limit(limit)
            
            # Efficient cursor processing
            results = []
            doc_count = 0
            
            for document in cursor:
                results.append(document)
                doc_count += 1
                
                # Log progress for large queries
                if doc_count % batch_size == 0:
                    logger.info(f"Retrieved {doc_count} documents from '{collection_name}'...")
            
            logger.info(f"Retrieved {len(results)} documents from '{collection_name}' (limit: {limit or 'none'})")
            return results
            
        except Exception as e:
            logger.error(f"Error retrieving documents from '{collection_name}': {e}")
            return []

    # --- Compatibility shims ---
    def find(self, collection_name: str, filter: Optional[Dict[str, Any]] = None, projection: Optional[Dict[str, int]] = None):
        collection = self.db[collection_name]
        cursor = collection.find(filter or {}, projection)
        return CursorWrapper(cursor)

    def insert_one(self, collection_name: str, doc: Dict[str, Any]):
        collection = self.db[collection_name]
        return collection.insert_one(doc)

    def update_one(self, collection_name: str, filter: Dict[str, Any], update: Dict[str, Any], upsert: bool = False):
        collection = self.db[collection_name]
        return collection.update_one(filter, update, upsert=upsert)

    def delete_one(self, collection_name: str, filter: Dict[str, Any]):
        collection = self.db[collection_name]
        return collection.delete_one(filter)

    def replace_one(self, collection_name: str, filter: Dict[str, Any], replacement: Dict[str, Any], upsert: bool = False):
        collection = self.db[collection_name]
        return collection.replace_one(filter, replacement, upsert=upsert)
    
    def get_count(self, collection_name: str, filter: Optional[Dict[str, Any]] = None) -> int:
        """
        Get count of documents matching the filter in any collection
        
        Args:
            collection_name: Name of the collection to query
            filter: MongoDB filter query (default: {})
            
        Returns:
            Number of documents matching the filter
        """
        try:
            collection = self.db[collection_name]
            query_filter = filter or {}
            count = collection.count_documents(query_filter)
            logger.info(f"Document count for '{collection_name}': {count}")
            return count
            
        except Exception as e:
            logger.error(f"Error counting documents in '{collection_name}': {e}")
            return 0
    
    def get_paginated_response(
        self,
        collection_name: str,
        filter: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        sort: Optional[List[Tuple[str, int]]] = None,
        page: int = 1,
        page_size: int = 50
    ) -> Dict[str, Any]:
        """
        Get paginated response with metadata from any collection
        
        Args:
            collection_name: Name of the collection to query
            filter: MongoDB filter query (default: {})
            projection: Fields to include/exclude (default: None - all fields)
            sort: List of (field, direction) tuples for sorting (default: None)
            page: Page number (1-based, default: 1)
            page_size: Number of items per page (default: 50)
            
        Returns:
            Dictionary containing paginated results and metadata
        """
        try:
            collection = self.db[collection_name]
            query_filter = filter or {}
            
            # Calculate pagination parameters
            page = max(1, page)
            page_size = max(1, min(page_size, 1000))  # Cap at 1000 items per page
            skip = (page - 1) * page_size
            
            # Get total count
            total = collection.count_documents(query_filter)
            
            # Get documents for current page
            cursor = collection.find(query_filter, projection)
            
            if sort:
                cursor = cursor.sort(sort)
            
            cursor = cursor.skip(skip).limit(page_size)
            items = list(cursor)
            
            # Calculate pagination metadata
            total_pages = (total + page_size - 1) // page_size
            has_next = page < total_pages
            has_prev = page > 1
            
            result = {
                "items": items,
                "page": page,
                "page_size": page_size,
                "total": total,
                "total_pages": total_pages,
                "has_next": has_next,
                "has_prev": has_prev
            }
            
            logger.info(f"Paginated query on '{collection_name}': page {page}/{total_pages}, {len(items)} items returned")
            return result
            
        except Exception as e:
            logger.error(f"Error executing paginated query on '{collection_name}': {e}")
            return {
                "items": [],
                "page": page,
                "page_size": page_size,
                "total": 0,
                "total_pages": 0,
                "has_next": False,
                "has_prev": False
            }
    
    def aggregate(
        self, 
        collection_name: str,
        pipeline: List[Dict[str, Any]], 
        allow_disk_use: bool = True,
        max_time_ms: Optional[int] = None,
        batch_size: int = 1000,
        max_docs: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute aggregation pipeline on any collection with optimizations for large datasets
        
        Args:
            collection_name: Name of the collection to aggregate on
            pipeline: MongoDB aggregation pipeline
            allow_disk_use: Allow disk use for large operations (default: True)
            max_time_ms: Maximum execution time in milliseconds (default: None)
            batch_size: Cursor batch size for memory efficiency (default: 1000)
            max_docs: Maximum documents to return (default: None = unlimited)
            
        Returns:
            List of aggregation results
        """
        try:
            collection = self.db[collection_name]
            
            # Log aggregation execution
            logger.info(f"Executing aggregation on collection '{collection_name}' in database '{self.db_name}'")
            logger.info(f"Pipeline stages: {len(pipeline)}, allowDiskUse: {allow_disk_use}, maxTimeMS: {max_time_ms}")
            
            # Log pipeline details only in debug mode
            if logger.isEnabledFor(logging.DEBUG):
                try:
                    import json
                    logger.debug(f"Aggregation pipeline:\n{json.dumps(pipeline, default=str, indent=2)}")
                except Exception:
                    logger.debug(f"Aggregation pipeline (raw): {pipeline}")
            
            # Execute aggregation with optimized parameters
            cursor_options = {
                'allowDiskUse': allow_disk_use,
                'batchSize': batch_size
            }
            
            if max_time_ms is not None:
                cursor_options['maxTimeMS'] = max_time_ms
            
            cursor = collection.aggregate(pipeline, **cursor_options)
            
            # Efficient cursor processing with memory management
            try:
                results = []
                doc_count = 0
                
                # Process cursor in batches for memory efficiency
                for document in cursor:
                    results.append(document)
                    doc_count += 1
                    
                    # Check document limit to prevent memory issues
                    if max_docs and doc_count >= max_docs:
                        logger.warning(f"Aggregation on '{collection_name}' truncated at {max_docs} documents")
                        break
                    
                    # Yield control periodically for large datasets
                    if doc_count % batch_size == 0:
                        logger.info(f"Processed {doc_count} documents from '{collection_name}'...")
                
                # Log results summary
                logger.info(f"Aggregation on '{collection_name}' returned {len(results)} documents")
                
                # Log sample result only in debug mode
                if logger.isEnabledFor(logging.DEBUG) and results:
                    logger.debug(f"Sample result: {results[0]}")
                elif results:
                    logger.info(f"Sample result keys: {list(results[0].keys()) if isinstance(results[0], dict) else 'Non-dict result'}")
                
                return results
                
            except Exception as cursor_error:
                logger.error(f"Error processing aggregation cursor for '{collection_name}': {cursor_error}")
                return []
            
        except Exception as e:
            logger.error(f"Error executing aggregation on {collection_name}: {e}")
            logger.error(f"Pipeline that failed: {pipeline}")
            return []
    
    def aggregate_stream(
        self, 
        collection_name: str,
        pipeline: List[Dict[str, Any]], 
        allow_disk_use: bool = True,
        max_time_ms: Optional[int] = None,
        batch_size: int = 1000
    ):
        """
        Stream aggregation results for very large datasets (generator)
        
        Args:
            collection_name: Name of the collection to aggregate on
            pipeline: MongoDB aggregation pipeline
            allow_disk_use: Allow disk use for large operations (default: True)
            max_time_ms: Maximum execution time in milliseconds (default: None)
            batch_size: Cursor batch size for memory efficiency (default: 1000)
            
        Yields:
            Individual documents from aggregation results
        """
        try:
            collection = self.db[collection_name]
            
            logger.debug(f"Starting streaming aggregation on '{collection_name}'")
            
            # Execute aggregation with optimized parameters
            cursor_options = {
                'allowDiskUse': allow_disk_use,
                'batchSize': batch_size
            }
            
            if max_time_ms is not None:
                cursor_options['maxTimeMS'] = max_time_ms
            
            cursor = collection.aggregate(pipeline, **cursor_options)
            
            # Stream results one by one
            doc_count = 0
            try:
                for document in cursor:
                    yield document
                    doc_count += 1
                    
                    # Log progress periodically
                    if doc_count % batch_size == 0:
                        logger.debug(f"Streamed {doc_count} documents from '{collection_name}'...")
                
                logger.info(f"Streaming aggregation on '{collection_name}' completed: {doc_count} documents")
                
            except Exception as cursor_error:
                logger.error(f"Error streaming aggregation cursor for '{collection_name}': {cursor_error}")
                
        except Exception as e:
            logger.error(f"Error starting streaming aggregation on {collection_name}: {e}")
    
    def aggregate_batched(
        self, 
        collection_name: str,
        pipeline: List[Dict[str, Any]], 
        batch_size: int = 1000,
        allow_disk_use: bool = True,
        max_time_ms: Optional[int] = None
    ):
        """
        Process aggregation results in batches (generator)
        
        Args:
            collection_name: Name of the collection to aggregate on
            pipeline: MongoDB aggregation pipeline
            batch_size: Number of documents per batch (default: 1000)
            allow_disk_use: Allow disk use for large operations (default: True)
            max_time_ms: Maximum execution time in milliseconds (default: None)
            
        Yields:
            Batches of documents as lists
        """
        try:
            collection = self.db[collection_name]
            
            logger.debug(f"Starting batched aggregation on '{collection_name}' (batch_size: {batch_size})")
            
            # Execute aggregation with optimized parameters
            cursor_options = {
                'allowDiskUse': allow_disk_use,
                'batchSize': batch_size
            }
            
            if max_time_ms is not None:
                cursor_options['maxTimeMS'] = max_time_ms
            
            cursor = collection.aggregate(pipeline, **cursor_options)
            
            # Process in batches
            batch = []
            total_count = 0
            
            try:
                for document in cursor:
                    batch.append(document)
                    total_count += 1
                    
                    # Yield batch when full
                    if len(batch) >= batch_size:
                        yield batch
                        logger.debug(f"Yielded batch of {len(batch)} documents from '{collection_name}' (total: {total_count})")
                        batch = []
                
                # Yield remaining documents
                if batch:
                    yield batch
                    logger.debug(f"Yielded final batch of {len(batch)} documents from '{collection_name}'")
                
                logger.info(f"Batched aggregation on '{collection_name}' completed: {total_count} documents")
                
            except Exception as cursor_error:
                logger.error(f"Error processing batched aggregation cursor for '{collection_name}': {cursor_error}")
                
        except Exception as e:
            logger.error(f"Error starting batched aggregation on {collection_name}: {e}")
    
    def find_by_id(self, collection_name: str, id: str) -> Optional[Dict[str, Any]]:
        """
        Find document by ID in any collection
        
        Args:
            collection_name: Name of the collection to query
            id: Document ID (string)
            
        Returns:
            Document if found, None otherwise
        """
        try:
            collection = self.db[collection_name]
            if not ObjectId.is_valid(id):
                return None
            
            doc = collection.find_one({"_id": ObjectId(id)})
            return doc
            
        except Exception as e:
            logger.error(f"Error finding document by ID in {collection_name}: {e}")
            return None
    
    def find_one(
        self, 
        collection_name: str,
        filter: Dict[str, Any], 
        projection: Optional[Dict[str, int]] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Find one document by filter in any collection
        
        Args:
            collection_name: Name of the collection to query
            filter: MongoDB filter query
            projection: Fields to include/exclude (default: None - all fields)
            
        Returns:
            Document if found, None otherwise
        """
        try:
            collection = self.db[collection_name]
            doc = collection.find_one(filter, projection)
            return doc
            
        except Exception as e:
            logger.error(f"Error finding document in {collection_name}: {e}")
            return None

    def close(self):
        """Close database connection"""
        try:
            if self._client is not None:
                self._client.close()
                logger.info(f"Closed connection for database: {self.db_name}")
                self._client = None
                self._db = None
        except Exception as e:
            logger.error(f"Error closing connection: {e}")
    
    # --- Async Methods for Better Performance ---
    
    async def get_all_async(
        self, 
        collection_name: str,
        filter: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        sort: Optional[List[Tuple[str, int]]] = None,
        skip: int = 0, # Added skip parameter
        limit: Optional[int] = None,
        batch_size: int = 1000
    ) -> List[Dict[str, Any]]:
        """
        Async version of get_all for better performance in parallel operations
        
        Args:
            collection_name: Name of the collection to query
            filter: MongoDB filter query (default: {})
            projection: Fields to include/exclude (default: None - all fields)
            sort: List of (field, direction) tuples for sorting (default: None)
            skip: Number of documents to skip (default: 0)
            limit: Maximum number of documents to return (default: None - no limit)
            batch_size: Cursor batch size for memory efficiency (default: 1000)
            
        Returns:
            List of documents matching the criteria
        """
        try:
            loop = asyncio.get_event_loop()
            with ThreadPoolExecutor() as executor:
                return await loop.run_in_executor(
                    executor,
                    lambda: self.get_all(
                        collection_name=collection_name,
                        filter=filter,
                        projection=projection,
                        sort=sort,
                        skip=skip, # Passed skip to get_all
                        limit=limit,
                        batch_size=batch_size
                    )
                )
        except Exception as e:
            logger.error(f"Error in async get_all for collection '{collection_name}': {e}")
            return []
    
    async def aggregate_async(
        self, 
        collection_name: str,
        pipeline: List[Dict[str, Any]], 
        allow_disk_use: bool = True,
        max_time_ms: Optional[int] = None,
        batch_size: int = 1000,
        max_docs: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Async version of aggregate for better performance in parallel operations
        
        Args:
            collection_name: Name of the collection to aggregate on
            pipeline: MongoDB aggregation pipeline
            allow_disk_use: Allow disk use for large operations (default: True)
            max_time_ms: Maximum execution time in milliseconds (default: None)
            batch_size: Cursor batch size for memory efficiency (default: 1000)
            max_docs: Maximum documents to return (default: None = unlimited)
            
        Returns:
            List of aggregation results
        """
        try:
            loop = asyncio.get_event_loop()
            with ThreadPoolExecutor() as executor:
                return await loop.run_in_executor(
                    executor,
                    lambda: self.aggregate(
                        collection_name=collection_name,
                        pipeline=pipeline,
                        allow_disk_use=allow_disk_use,
                        max_time_ms=max_time_ms,
                        batch_size=batch_size,
                        max_docs=max_docs
                    )
                )
        except Exception as e:
            logger.error(f"Error in async aggregate for collection '{collection_name}': {e}")
            return []
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()
