
from typing import Any, Dict, List, Optional
from bson import ObjectId
import asyncio
from concurrent.futures import ThreadPoolExecutor

from ..repository.base_repository import GenericRepository
from ...core.config import settings
import logging

logger = logging.getLogger(__name__)

class MasterPlantsRepository(GenericRepository):
    def __init__(self):
        super().__init__()
        self.collection_name = settings.MONGODB_PLANT_MASTER_COLLECTION

    def _create_sync(self, plant_data: Dict[str, Any]) -> str:
        result = self.db[self.collection_name].insert_one(plant_data)
        return str(result.inserted_id)

    async def create_plant(self, plant_data: Dict[str, Any]) -> str:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor() as executor:
            return await loop.run_in_executor(executor, lambda: self._create_sync(plant_data))

    async def get_plant_by_id(self, plant_oid: str) -> Optional[Dict[str, Any]]:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor() as executor:
            return await loop.run_in_executor(executor, lambda: self.find_by_id(self.collection_name, plant_oid))

    async def list_plants(
        self,
        filters: Optional[Dict[str, Any]] = None,
        page: int = 1,
        page_size: int = 50,
        sort: Optional[List[tuple]] = None,
    ) -> Dict[str, Any]:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor() as executor:
            return await loop.run_in_executor(
                executor,
                lambda: self.get_paginated_response(
                    collection_name=self.collection_name,
                    filter=filters,
                    page=page,
                    page_size=page_size,
                    sort=sort
                )
            )

    def _update_sync(self, plant_oid: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if not ObjectId.is_valid(plant_oid):
            return None
        result = self.db[self.collection_name].update_one({"_id": ObjectId(plant_oid)}, {"$set": updates})
        if result.modified_count > 0:
            return self.find_by_id(self.collection_name, plant_oid)
        return self.find_by_id(self.collection_name, plant_oid) # Return doc even if no change

    async def update_plant(self, plant_oid: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor() as executor:
            return await loop.run_in_executor(executor, lambda: self._update_sync(plant_oid, updates))

    def _delete_sync(self, plant_oid: str) -> bool:
        if not ObjectId.is_valid(plant_oid):
            return False
        result = self.db[self.collection_name].delete_one({"_id": ObjectId(plant_oid)})
        return result.deleted_count > 0

    async def delete_plant(self, plant_oid: str) -> bool:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor() as executor:
            return await loop.run_in_executor(executor, lambda: self._delete_sync(plant_oid))

    def _bulk_upsert_sync(self, plants: List[Dict[str, Any]], filter_criteria: callable) -> Dict[str, int]:
        from pymongo import UpdateOne
        
        if not plants:
            return {"inserted": 0, "updated": 0, "total": 0}

        bulk_ops = [UpdateOne(filter_criteria(p), {"$set": p}, upsert=True) for p in plants]
        result = self.db[self.collection_name].bulk_write(bulk_ops)
        
        return {
            "inserted": result.upserted_count,
            "updated": result.modified_count,
            "total": result.upserted_count + result.modified_count
        }

    async def bulk_upsert_plants(self, plants: List[Dict[str, Any]], filter_criteria: callable) -> Dict[str, int]:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor() as executor:
            return await loop.run_in_executor(executor, lambda: self._bulk_upsert_sync(plants, filter_criteria))

master_plants_repository = MasterPlantsRepository()
