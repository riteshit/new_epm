from .base_repository import GenericRepository
from typing import List, Dict, Any, Optional
from datetime import datetime
from ...core.config import settings


class ForecastAnalysisRepository():
    """
    Repository for forecast analysis data, containing all pipeline logic.
    Inherits generic database operations from BaseRepository.
    """

    def __init__(self):
        super().__init__()
        self.repo = GenericRepository()
        # Use the v2 collection names
        self.demand_historical = "demand_serve_historical"
        self.demand_serve = "demand_serve"
        self.peak_demand_serve = "peak_demand_serve"

    # The __init__ is inherited from BaseRepository, so we don't need to redefine it
    # unless we add new dependencies.

    async def fetch_demand_blocks(self, dates: List[str], markets: List[str], zones: List[str], from_block: int,
                            to_block: int, union_with_live: bool) -> List[Dict[str, Any]]:
        normalize = {"$addFields": {"_sdate": {"$dateToString": {"date": "$scheduled_at", "format": "%Y-%m-%d"}},
                                    "_market": {"$toUpper": {"$ifNull": ["$type", "$market"]}},
                                    "_zone": {"$toUpper": {"$ifNull": ["$zone", ""]}}}}
        match = {"$match": {"$expr": {
            "$and": [{"$in": ["$_sdate", dates]}, {"$in": ["$_market", markets]}, {"$in": ["$_zone", zones]},
                     {"$gte": ["$time_block", from_block]}, {"$lte": ["$time_block", to_block]}]}}}
        pipeline = [normalize, match]
        if union_with_live:
            pipeline.append({"$unionWith": {"coll": self.demand_serve, "pipeline": [normalize, match]}})
        pipeline.extend([
            {"$group": {"_id": {"d": "$_sdate", "b": "$time_block"},
                        "cad": {"$sum": {"$ifNull": ["$comp_act_demand", 0]}},
                        "cudm": {"$sum": {"$ifNull": ["$comp_udm", 0]}}, "f": {"$sum": {"$ifNull": ["$forecast", 0]}},
                        "m": {"$avg": {"$ifNull": ["$mape", 0]}}}},
            {"$project": {"_id": 0, "schedule_date": "$_id.d", "time_block": "$_id.b",
                          "data": {"comp_act_demand": {"$round": ["$cad", 2]}, "comp_udm": {"$round": ["$cudm", 2]},
                                   "forecast": {"$round": ["$f", 2]},
                                   "MAPE": {"$concat": [{"$toString": {"$round": ["$m", 2]}}, "%"]}}}},
            {"$sort": {"schedule_date": 1, "time_block": 1}}
        ])
        return await self.repo.aggregate_async(self.demand_historical, pipeline)

    async def fetch_demand_curve(self, dates: List[str], markets: List[str], zones: List[str], from_block: int, to_block: int,
                           today_str: str, cur_blk: int, denominator: str, expected_total: Optional[float],
                           union_with_live: bool) -> List[Dict[str, Any]]:
        normalize = {"$addFields": {"_sdate": {"$dateToString": {"date": "$scheduled_at", "format": "%Y-%m-%d"}},
                                    "_market": {"$toUpper": {"$ifNull": ["$type", "$market"]}},
                                    "_zone": {"$toUpper": {"$ifNull": ["$zone", ""]}},
                                    "_cad": {"$toDouble": {"$ifNull": ["$comp_act_demand", 0]}}}}
        match_and = [{"$in": ["$_market", markets]}, {"$in": ["$_zone", zones]}, {"$in": ["$_sdate", dates]},
                     {"$gte": ["$time_block", from_block]}, {"$lte": ["$time_block", to_block]}, {
                         "$or": [{"$lt": ["$_sdate", today_str]},
                                 {"$and": [{"$eq": ["$_sdate", today_str]}, {"$lte": ["$time_block", cur_blk]}]}]}]
        match = {"$match": {"$expr": {"$and": match_and}}}
        pipeline = [normalize, match]
        if union_with_live:
            pipeline.append({"$unionWith": {"coll": self.demand_serve, "pipeline": [normalize, match]}})
        group = {"$group": {"_id": {"d": "$_sdate", "b": "$time_block"}, "cad": {"$sum": "$_cad"}}}
        sort = {"$sort": {"cad": 1, "_id.d": 1, "_id.b": 1}}
        window = {
            "$setWindowFields": {"sortBy": {"cad": 1}, "output": {"count": {"$documentNumber": {}}, "total": {"$count": {}}}}}
        if denominator == "expected":
            percent_expr = {"$cond": [{"$gt": [expected_total, 0]},
                                      {"$round": [{"$multiply": [{"$divide": ["$count", expected_total]}, 100]}, 2]},
                                      0]}
        else:
            percent_expr = {"$cond": [{"$gt": ["$total", 0]},
                                      {"$round": [{"$multiply": [{"$divide": ["$count", "$total"]}, 100]}, 2]}, 0]}
        project = {"$project": {"_id": 0, "count": "$count", "comp_act_demand": {"$round": ["$cad", 2]},
                                "percentage": percent_expr}}
        pipeline.extend([group, sort, window, project])
        return await self.repo.aggregate_async(self.demand_historical, pipeline)

    async def fetch_mape_curve(self, dates: List[str], markets: List[str], zones: List[str], from_block: int, to_block: int,
                         today_str: str, cur_blk: int, denominator: str, expected_total: Optional[float],
                         union_with_live: bool) -> List[Dict[str, Any]]:
        normalize = {"$addFields": {"_sdate": {"$dateToString": {"date": "$scheduled_at", "format": "%Y-%m-%d"}},
                                    "_market": {"$toUpper": {"$ifNull": ["$type", "$market"]}},
                                    "_zone": {"$toUpper": {"$ifNull": ["$zone", ""]}},
                                    "_mape": {"$toDouble": {"$ifNull": ["$mape", 0]}}}}
        match_and = [{"$in": ["$_market", markets]}, {"$in": ["$_zone", zones]}, {"$in": ["$_sdate", dates]},
                     {"$gte": ["$time_block", from_block]}, {"$lte": ["$time_block", to_block]}, {
                         "$or": [{"$lt": ["$_sdate", today_str]},
                                 {"$and": [{"$eq": ["$_sdate", today_str]}, {"$lte": ["$time_block", cur_blk]}]}]}]
        match = {"$match": {"$expr": {"$and": match_and}}}
        pipeline = [normalize, match]
        if union_with_live:
            pipeline.append({"$unionWith": {"coll": self.demand_serve, "pipeline": [normalize, match]}})
        group = {"$group": {"_id": {"d": "$_sdate", "b": "$time_block"}, "mape_avg": {"$avg": "$_mape"}}}
        sort = {"$sort": {"mape_avg": 1, "_id.d": 1, "_id.b": 1}}
        window = {"$setWindowFields": {"sortBy": {"mape_avg": 1},
                                       "output": {"count": {"$documentNumber": {}}, "total": {"$count": {}}}}}
        if denominator == "expected":
            percent_expr = {"$cond": [{"$gt": [expected_total, 0]},
                                      {"$round": [{"$multiply": [{"$divide": ["$count", expected_total]}, 100]}, 2]},
                                      0]}
        else:
            percent_expr = {"$cond": [{"$gt": ["$total", 0]},
                                      {"$round": [{"$multiply": [{"$divide": ["$count", "$total"]}, 100]}, 2]}, 0]}
        project = {"$project": {"_id": 0, "count": "$count",
                                "MAPE": {"$concat": [{"$toString": {"$round": ["$mape_avg", 2]}}, "%"]},
                                "percentage": percent_expr}}
        pipeline.extend([group, sort, window, project])
        return await self.repo.aggregate_async(self.demand_historical, pipeline)

    async def fetch_peak_demand_last_7_days(self, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        pipeline = [
            {"$match": {"scheduled_at": {"$gte": start_date, "$lte": end_date}}}, 
            {
                "$project": {
                    "_id": 0, 
                    "schedule_date": {"$dateToString": {"format": "%Y-%m-%d", "date": "$scheduled_at"}},
                    "peak_demand": {"$round": ["$peak_demand", 2]},
                    "average_demand": {"$round": ["$average_demand", 2]}
                }
            }, 
            {"$sort": {"schedule_date": 1}}
        ]
        return await self.repo.aggregate_async(self.peak_demand_serve, pipeline)

    async def fetch_selected_days_blocks(self, dates: List[str], markets: List[str], zones: List[str], from_block: int,
                                   to_block: int, union_with_live: bool) -> List[
        Dict[str, Any]]:
        normalize = {"$addFields": {"_sdate": {"$dateToString": {"date": "$scheduled_at", "format": "%Y-%m-%d"}},
                                    "_market": {"$toUpper": {"$ifNull": ["$type", "$market"]}},
                                    "_zone": {"$toUpper": {"$ifNull": ["$zone", ""]}}}}
        match = {"$match": {"$expr": {
            "$and": [{"$in": ["$_sdate", dates]}, {"$in": ["$_market", markets]}, {"$in": ["$_zone", zones]},
                     {"$gte": ["$time_block", from_block]}, {"$lte": ["$time_block", to_block]}]}}}
        pipeline = [normalize, match]
        if union_with_live:
            pipeline.append({"$unionWith": {"coll": self.demand_serve, "pipeline": [normalize, match]}})
        pipeline.extend([
            {"$group": {"_id": {"d": "$_sdate", "b": "$time_block"},
                        "cad": {"$sum": {"$ifNull": ["$comp_act_demand", 0]}},
                        "cudm": {"$sum": {"$ifNull": ["$comp_udm", 0]}}}},
            {"$project": {"_id": 0, "schedule_date": "$_id.d", "time_block": "$_id.b",
                          "data": {"comp_act_demand": {"$round": ["$cad", 2]}, "comp_udm": {"$round": ["$cudm", 2]}}}},
            {"$sort": {"schedule_date": 1, "time_block": 1}}
        ])
        return await self.repo.aggregate_async(self.demand_historical, pipeline)

    async def fetch_selected_days_stats(self, dates: List[str], markets: List[str], zones: List[str], from_block: int,
                                  to_block: int, union_with_live: bool) -> List[
        Dict[str, Any]]:
        normalize = {"$addFields": {"_sdate": {"$dateToString": {"date": "$scheduled_at", "format": "%Y-%m-%d"}},
                                    "_market": {"$toUpper": {"$ifNull": ["$type", "$market"]}},
                                    "_zone": {"$toUpper": {"$ifNull": ["$zone", ""]}},
                                    "_cad": {"$ifNull": ["$comp_act_demand", 0]},
                                    "_udm": {"$ifNull": ["$comp_udm", 0]}}}
        match = {"$match": {"$expr": {
            "$and": [{"$in": ["$_sdate", dates]}, {"$in": ["$_market", markets]}, {"$in": ["$_zone", zones]},
                     {"$gte": ["$time_block", from_block]}, {"$lte": ["$time_block", to_block]}]}}}
        pipeline = [normalize, match]
        if union_with_live:
            pipeline.append({"$unionWith": {"coll": self.demand_serve, "pipeline": [normalize, match]}})
        pipeline.extend([
            {"$group": {"_id": "$_sdate", "cad_min": {"$min": "$_cad"}, "cad_max": {"$max": "$_cad"},
                        "cad_avg": {"$avg": "$_cad"}, "cad_sum": {"$sum": "$_cad"}, "cad_count": {"$sum": 1},
                        "udm_min": {"$min": "$_udm"}, "udm_max": {"$max": "$_udm"}, "udm_avg": {"$avg": "$_udm"},
                        "udm_sum": {"$sum": "$_udm"}, "udm_count": {"$sum": 1}}},
            {"$project": {"_id": 0, "schedule_date": "$_id", "stats": {
                "comp_act_demand": {"min": {"$round": ["$cad_min", 2]}, "max": {"$round": ["$cad_max", 2]},
                                    "avg": {"$round": ["$cad_avg", 2]}, "sum": {"$round": ["$cad_sum", 2]},
                                    "count": "$cad_count"},
                "comp_udm": {"min": {"$round": ["$udm_min", 2]}, "max": {"$round": ["$udm_max", 2]},
                             "avg": {"$round": ["$udm_avg", 2]}, "sum": {"$round": ["$udm_sum", 2]},
                             "count": "$udm_count"}}}},
            {"$sort": {"schedule_date": 1}}
        ])
        return await self.repo.aggregate_async(self.demand_historical,pipeline)


forcast_analysis = ForecastAnalysisRepository()
