"""
Limit Workflow Repository (approval + audit)
"""

import logging
from typing import List, Dict, Any, Optional

from .base_repository import GenericRepository

logger = logging.getLogger(__name__)


class LimitWorkflowRepository:
    def __init__(self):
        self.repository = GenericRepository()

    # -------- Approval documents --------
    def create_approval(self, approval_collection: str, doc: Dict[str, Any]) -> Any:
        try:
            res = self.repository.insert_one(approval_collection, doc)
            return res.inserted_id
        except Exception as e:
            logger.exception(f"[LimitWorkflowRepository] create_approval failed: {str(e)}")
            raise

    def get_approval(self, approval_collection: str, approval_id: Any) -> Optional[Dict[str, Any]]:
        try:
            return self.repository.find_one(approval_collection, {"_id": approval_id})
        except Exception as e:
            logger.exception(f"[LimitWorkflowRepository] get_approval failed: {str(e)}")
            raise

    def update_approval(self, approval_collection: str, approval_id: Any, updates: Dict[str, Any]) -> None:
        try:
            self.repository.update_one(approval_collection, {"_id": approval_id}, {"$set": updates}, upsert=False)
        except Exception as e:
            logger.exception(f"[LimitWorkflowRepository] update_approval failed: {str(e)}")
            raise

    def list_approvals(self, approval_collection: str, status: Optional[str]) -> List[Dict[str, Any]]:
        try:
            filt = {"status": status} if status else {}
            return list(self.repository.find(approval_collection, filt).sort("requested_at", -1))
        except Exception as e:
            logger.exception(f"[LimitWorkflowRepository] list_approvals failed: {str(e)}")
            raise

    # -------- Audit logs --------
    def write_audit(self, audit_collection: str, log_doc: Dict[str, Any]) -> None:
        try:
            self.repository.insert_one(audit_collection, log_doc)
        except Exception as e:
            logger.exception(f"[LimitWorkflowRepository] write_audit failed: {str(e)}")
            raise


limit_workflow_repository = LimitWorkflowRepository()
