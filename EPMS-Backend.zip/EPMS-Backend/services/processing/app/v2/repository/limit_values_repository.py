"""
Limit Values Repository (main table operations)
"""

import logging
from typing import List, Dict, Any
from datetime import datetime

from .base_repository import GenericRepository

logger = logging.getLogger(__name__)


class LimitValuesRepository:
    def __init__(self):
        self.repository = GenericRepository()

    async def get_latest_date_data_pipeline(self, collection_name: str) -> List[Dict[str, Any]]:
        """
        Returns all rows for the max scheduled_at date (works for date or string).
        """
        try:
            pipeline = [
                {
                    "$addFields": {
                        "scheduled_at_dt": {
                            "$cond": [
                                {"$eq": [{"$type": "$scheduled_at"}, "date"]},
                                {"$dateTrunc": {"date": "$scheduled_at", "unit": "day"}},
                                {
                                    "$dateFromString": {
                                        "dateString": "$scheduled_at",
                                        "format": "%Y-%m-%d"
                                    }
                                }
                            ]
                        }
                    }
                },
                {"$group": {"_id": None, "max_date": {"$max": "$scheduled_at_dt"}}},
                {
                    "$lookup": {
                        "from": collection_name,
                        "let": {"maxd": "$max_date"},
                        "pipeline": [
                            {
                                "$addFields": {
                                    "scheduled_at_dt": {
                                        "$cond": [
                                            {"$eq": [{"$type": "$scheduled_at"}, "date"]},
                                            {"$dateTrunc": {"date": "$scheduled_at", "unit": "day"}},
                                            {
                                                "$dateFromString": {
                                                    "dateString": "$scheduled_at",
                                                    "format": "%Y-%m-%d"
                                                }
                                            }
                                        ]
                                    }
                                }
                            },
                            {"$match": {"$expr": {"$eq": ["$scheduled_at_dt", "$$maxd"]}}},
                            {"$project": {"scheduled_at_dt": 0}}
                        ],
                        "as": "records"
                    }
                },
                {"$unwind": "$records"},
                {"$replaceRoot": {"newRoot": "$records"}},
                {"$sort": {"block": 1, "id_type": 1}}
            ]
            result = self.repository.aggregate(collection_name, pipeline, max_time_ms=30000)
            return result
        except Exception as e:
            logger.exception(f"[LimitValuesRepository] Failed latest pipeline: {str(e)}")
            raise

    def upsert_one(
        self,
        collection_name: str,
        key: Dict[str, Any],
        values_doc: Dict[str, Any],
        created_by: str,
        updated_by: str,
        source_approval_id: Any,
    ) -> None:
        """
        Upsert a single limit_values document by business key.
        """
        try:
            now = datetime.utcnow()
            update = {
                "$set": {
                    **values_doc,
                    "source_approval_id": source_approval_id,
                    "updated_at": now,
                    "updated_by": updated_by,
                },
                "$setOnInsert": {
                    "created_at": now,
                    "created_by": created_by,
                    "version": 0
                },
                "$inc": {"version": 1}
            }
            self.repository.update_one(collection_name, key, update, upsert=True)
        except Exception as e:
            logger.exception(f"[LimitValuesRepository] Failed upsert_one: {str(e)}")
            raise

    def delete_one_soft(
        self,
        collection_name: str,
        key: Dict[str, Any],
        updated_by: str,
        source_approval_id: Any
    ) -> None:
        """
        Optional soft delete: mark inactive instead of physical delete.
        """
        try:
            now = datetime.utcnow()
            update = {
                "$set": {
                    "is_active": False,
                    "updated_at": now,
                    "updated_by": updated_by,
                    "source_approval_id": source_approval_id
                },
                "$inc": {"version": 1}
            }
            self.repository.update_one(collection_name, key, update, upsert=False)
        except Exception as e:
            logger.exception(f"[LimitValuesRepository] Failed delete_one_soft: {str(e)}")
            raise


limit_values_repository = LimitValuesRepository()
