import logging
from typing import Dict, Any, Optional, List
from fastapi import HTTPException, status, UploadFile

from ..services.limit_values_services import limit_service

logger = logging.getLogger(__name__)


class LimitController:
    def __init__(self):
        self.service = limit_service

    async def latest(self) -> Dict[str, Any]:
        try:
            return await self.service.latest()
        except Exception as e:
            logger.error(f"LimitController.latest error: {str(e)}")
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to fetch latest")

    async def stage_upload(self, file: UploadFile, user_ctx: Dict[str, Any]) -> Dict[str, Any]:
        try:
            content = await file.read()
            return await self.service.stage_file_upload(content, file.filename, user_ctx)
        except Exception as e:
            logger.error(f"LimitController.stage_upload error: {str(e)}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Failed to stage file: {str(e)}")

    async def stage_edit(self, approval_id: str, items: List[Dict[str, Any]], user_ctx: Dict[str, Any]) -> Dict[str, Any]:
        try:
            from bson import ObjectId
            return await self.service.stage_edit(ObjectId(approval_id), items, user_ctx)
        except Exception as e:
            logger.error(f"LimitController.stage_edit error: {str(e)}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Failed to edit stage: {str(e)}")

    async def list_pending(self, status_filter: Optional[str]) -> List[Dict[str, Any]]:
        try:
            return await self.service.list_pending(status_filter)
        except Exception as e:
            logger.error(f"LimitController.list_pending error: {str(e)}")
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to list approvals")

    async def approve(self, approval_id: str, approver_ctx: Dict[str, Any]) -> Dict[str, Any]:
        try:
            from bson import ObjectId
            return await self.service.approve(ObjectId(approval_id), approver_ctx)
        except Exception as e:
            logger.error(f"LimitController.approve error: {str(e)}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Failed to approve: {str(e)}")

    async def reject(self, approval_id: str, approver_ctx: Dict[str, Any], reason: Optional[str]) -> Dict[str, Any]:
        try:
            from bson import ObjectId
            return await self.service.reject(ObjectId(approval_id), approver_ctx, reason)
        except Exception as e:
            logger.error(f"LimitController.reject error: {str(e)}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Failed to reject: {str(e)}")


limit_controller = LimitController()
