
from typing import Any, Dict, List, Optional
import logging
from fastapi import UploadFile, HTTPException
import pandas as pd
from io import BytesIO
from bson import ObjectId
import numpy as np

from ..repository.master_plants_repository import master_plants_repository
from libs.models.plant_entity import PlantEntity
from libs.audit_queue.simple_logger import audit_logger

logger = logging.getLogger(__name__)

class PayloadMapper:
    def __init__(self):
        self.field_mapping = {
            'TM': 'tm',
            'FC_price': 'fc_price',
            'VC_price': 'vc_price',
            'PX_price': 'px_price',
        }
        self.reverse_mapping = {v: k for k, v in self.field_mapping.items()}

    def transform_input_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not payload:
            return payload
        transformed = {}
        for key, value in payload.items():
            if key in self.field_mapping:
                entity_key = self.field_mapping[key]
                transformed[entity_key] = value
            else:
                transformed[key] = value
        return transformed

    def transform_output_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not payload:
            return payload
        transformed = {}
        for key, value in payload.items():
            if key in self.reverse_mapping:
                legacy_key = self.reverse_mapping[key]
                transformed[legacy_key] = value
            else:
                transformed[key] = value
        return transformed

class MasterPlantsService:
    def __init__(self):
        self.repository = master_plants_repository
        self.payload_mapper = PayloadMapper()

    def _prepare_for_output(self, doc: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Converts _id to string and transforms payload to legacy format."""
        if not doc:
            return None
        
        if '_id' in doc and isinstance(doc['_id'], ObjectId):
            doc['_id'] = str(doc['_id'])
        
        return self.payload_mapper.transform_output_payload(doc)

    async def create_plant(self, payload: Dict[str, Any], actor: Dict[str, Any], request_info: Dict[str, Any]) -> str:
        try:
            transformed_payload = self.payload_mapper.transform_input_payload(payload)
            cleaned_payload = {k: v.strip() if isinstance(v, str) else v for k, v in transformed_payload.items()}
            
            new_id = await self.repository.create_plant(cleaned_payload)

            audit_logger.log_user_action(
                service="processing-v2",
                user_id=actor.get("user_id"),
                action="master_plant_create",
                message="Master plant created successfully",
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                resource_id=new_id,
                payload=cleaned_payload,
                success=True
            )
            logger.info(f"Master plant created | _id={new_id}")
            return new_id
        except Exception as e:
            audit_logger.log_error_event(
                service="processing-v2",
                error_name="MasterPlantCreateError",
                error_message=str(e),
                user_id=actor.get("user_id"),
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                payload=payload,
                error_type=type(e).__name__
            )
            raise

    async def get_plant(self, plant_oid: str, actor: Dict[str, Any], request_info: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            doc = await self.repository.get_plant_by_id(plant_oid)
            prepared_doc = self._prepare_for_output(doc)
            
            audit_logger.log_user_action(
                service="processing-v2",
                user_id=actor.get("user_id"),
                action="master_plant_get",
                message=f"Master plant get successful: {plant_oid}",
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                resource_id=plant_oid,
                found=bool(doc),
                success=True
            )
            return prepared_doc
        except Exception as e:
            audit_logger.log_error_event(
                service="processing-v2",
                error_name="MasterPlantGetError",
                error_message=str(e),
                user_id=actor.get("user_id"),
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                resource_id=plant_oid,
                error_type=type(e).__name__
            )
            raise

    async def list_plants(self, filters: Optional[Dict[str, Any]], page: int, page_size: int, actor: Dict[str, Any], request_info: Dict[str, Any]) -> Dict[str, Any]:
        try:
            result = await self.repository.list_plants(filters=filters, page=page, page_size=page_size, sort=[("plant_name", 1)])
            
            if 'items' in result and result['items']:
                result['items'] = [self._prepare_for_output(item) for item in result['items']]
            
            audit_logger.log_user_action(
                service="processing-v2",
                user_id=actor.get("user_id"),
                action="master_plant_list",
                message=f"Master plant list successful: {len(result.get('items', []))} items returned",
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                filters=filters,
                page=page,
                page_size=page_size,
                returned=len(result.get("items", [])),
                total=result.get("total"),
                success=True
            )
            return result
        except Exception as e:
            audit_logger.log_error_event(
                service="processing-v2",
                error_name="MasterPlantListError",
                error_message=str(e),
                user_id=actor.get("user_id"),
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                filters=filters,
                page=page,
                page_size=page_size,
                error_type=type(e).__name__
            )
            raise

    async def update_plant(self, plant_oid: str, updates: Dict[str, Any], actor: Dict[str, Any], request_info: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            transformed_updates = self.payload_mapper.transform_input_payload(updates)
            cleaned_updates = {k: v.strip() if isinstance(v, str) else v for k, v in transformed_updates.items() if v is not None and k != '_id'}

            if not cleaned_updates:
                doc = await self.repository.get_plant_by_id(plant_oid)
                return self._prepare_for_output(doc)

            updated_doc = await self.repository.update_plant(plant_oid, cleaned_updates)
            prepared_doc = self._prepare_for_output(updated_doc)

            audit_logger.log_user_action(
                service="processing-v2",
                user_id=actor.get("user_id"),
                action="master_plant_update",
                message=f"Master plant update successful: {plant_oid}",
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                resource_id=plant_oid,
                updates=cleaned_updates,
                found=bool(updated_doc),
                success=bool(updated_doc)
            )
            return prepared_doc
        except Exception as e:
            audit_logger.log_error_event(
                service="processing-v2",
                error_name="MasterPlantUpdateError",
                error_message=str(e),
                user_id=actor.get("user_id"),
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                resource_id=plant_oid,
                updates=updates,
                error_type=type(e).__name__
            )
            raise

    async def delete_plant(self, plant_oid: str, actor: Dict[str, Any], request_info: Dict[str, Any]) -> bool:
        try:
            ok = await self.repository.delete_plant(plant_oid)
            audit_logger.log_user_action(
                service="processing-v2",
                user_id=actor.get("user_id"),
                action="master_plant_delete",
                message=f"Master plant delete {'successful' if ok else 'failed'}: {plant_oid}",
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                resource_id=plant_oid,
                success=ok
            )
            return ok
        except Exception as e:
            audit_logger.log_error_event(
                service="processing-v2",
                error_name="MasterPlantDeleteError",
                error_message=str(e),
                user_id=actor.get("user_id"),
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                resource_id=plant_oid,
                error_type=type(e).__name__
            )
            raise

    def _create_plant_upsert_filter(self, plant: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "technology": plant.get("technology"),
            "c_s": plant.get("c_s"),
            "plant_name": plant.get("plant_name")
        }

    async def process_plant_file(self, file: UploadFile, actor: Dict[str, Any], request_info: Dict[str, Any]) -> Dict[str, Any]:
        try:
            if not file.filename or not file.filename.lower().endswith(('.csv', '.xlsx')):
                raise HTTPException(status_code=400, detail="Invalid file type. Only CSV and XLSX files are allowed.")

            file_content = await file.read()
            df = pd.read_csv(BytesIO(file_content)) if file.filename.lower().endswith('.csv') else pd.read_excel(BytesIO(file_content))
            df = df.replace({np.nan: None}) # Replace numpy NaN with None

            required_columns = ['plant_name', 'c_s', 'category', 'technology', 'price_group', 'vc_price', 'multiplier', 'volume', 'ppa', 'plant_id']
            if not all(col in df.columns for col in required_columns):
                raise HTTPException(status_code=400, detail=f"Missing required columns. Required: {', '.join(required_columns)}")

            plants_data = []
            for _, row in df.iterrows():
                try:
                    plant_dict = row.to_dict()
                    # Remove backend-managed fields from the uploaded data
                    plant_dict.pop('created_at', None)
                    plant_dict.pop('updated_at', None)

                    # Basic validation using pydantic model
                    PlantEntity(**plant_dict)
                    plants_data.append(plant_dict)
                except Exception as e:
                    logger.warning(f"Skipping invalid plant data: {row.to_dict()}, Error: {e}")
                    continue
            
            if not plants_data:
                raise HTTPException(status_code=400, detail="No valid plant data found in the file")

            result = await self.repository.bulk_upsert_plants(
                plants=plants_data,
                filter_criteria=self._create_plant_upsert_filter
            )

            audit_logger.log_user_action(
                service="processing-v2",
                user_id=actor.get("user_id"),
                action="master_plant_upload",
                message=f"Master plant file upload successful: {file.filename}",
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                payload={"filename": file.filename, "processed_count": len(plants_data)},
                success=True
            )
            return {
                "message": "File processed successfully",
                "filename": file.filename,
                "total_records": len(plants_data),
                **result
            }
        except Exception as e:
            audit_logger.log_error_event(
                service="processing-v2",
                error_name="MasterPlantUploadError",
                error_message=str(e),
                user_id=actor.get("user_id"),
                username=actor.get("username"),
                ip_address=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                resource="master_plants",
                payload={"filename": file.filename},
                error_type=type(e).__name__
            )
            raise

master_plants_service = MasterPlantsService()
