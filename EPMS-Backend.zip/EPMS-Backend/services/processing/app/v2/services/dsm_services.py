"""
Dashboard service layer using repository pattern.
Handles business logic for dashboard-related data operations.
"""

import logging
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta

from ..repository.dsm_repository import dsm_repository
from ...core.helpers import dsm_calculation
from ...core.config import settings

logger = logging.getLogger(__name__)


class DsmService:
    """
    Service layer for DSM-related operations.
    Handles business logic and data processing.
    """

    def __init__(self):
        self.dsm_repo = dsm_repository
        self.demand_serve = settings.MONGODB_DEMAND_SERVE_COLLECTION
        self.demand_serve_historical = (
            settings.MONGODB_DEMAND_SERVE_HISTORICAL_COLLECTION
        )

    async def get_dsm_data(
        self, scheduled_at: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """
        Get DSM data for a specific schedule date.

        Args:
            scheduled_at: Optional date filter in YYYY-MM-DD format

        Returns:
            Dict containing DSM data and metadata
        """
        try:
            if not scheduled_at:
                # Temporary: Hardcoded schedule date for fetching DSM records
                scheduled_at = datetime.now().replace(
                    hour=0, minute=0, second=0, microsecond=0
                )

            # Test collection access first
            logger.info(f"[DsmService] Testing collection access: {self.demand_serve}")
            test_docs = await self.dsm_repo.test_collection_access(self.demand_serve, limit=5)
            logger.info(
                f"[DsmService] Collection test - found {len(test_docs)} documents"
            )
            if test_docs:
                logger.info(f"[DsmService] Sample document: {test_docs[0]}")

            # Get DSM data using repository
            cursor = await self.dsm_repo.get_dsm_data_pipeline(
                self.demand_serve, scheduled_at
            )

            return {"data": cursor, "count": len(cursor) if cursor else 0}
        except Exception as e:
            logger.exception(f"[DsmService] Failed to fetch DSM data: {str(e)}")
            raise

    async def get_dsm_historical_data(
        self, from_date: Optional[datetime] = None, to_date: Optional[datetime] = None
    ) -> List[Dict[str, Any]]:
        """
        Get historical DSM data for a date range using MongoDB aggregation pipeline.

        Args:
            from_date: Start date
            to_date: End date

        Returns:
            List containing historical DSM data and metadata
        """
        try:
            # Default range if not provided
            if not from_date or not to_date:
                from_date = datetime.now().replace(
                    hour=0, minute=0, second=0, microsecond=0
                )
                to_date = datetime.now().replace(
                    hour=23, minute=59, second=59, microsecond=999999
                )
            else:
                from_date = datetime.now() - timedelta(days=8)
                from_date = from_date.replace(hour=0, minute=0, second=0, microsecond=0)
                to_date = datetime.now()

            # Get historical DSM data using repository
            cursor = await self.dsm_repo.get_dsm_historical_data_pipeline(
                self.demand_serve_historical, from_date, to_date
            )
            return cursor
        except Exception as e:
            logger.exception(
                f"[DsmService] Failed to fetch historical DSM data: {str(e)}"
            )
            raise

    async def get_dsm_historical_table_data(
        self,
        from_date: Optional[datetime] = None,
        to_date: Optional[datetime] = None,
        time_block: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get historical DSM table data for a date range and time block using MongoDB aggregation pipeline.

        Args:
            from_date: Start date in YYYY-MM-DD format
            to_date: End date in YYYY-MM-DD format
            time_block: Optional time block filter

        Returns:
            List containing historical DSM table data and metadata
        """
        try:
            logger.warning(f"No dashboard data found: {from_date, to_date, time_block}")
            
            # Validate required parameters
            if from_date is None or to_date is None:
                raise ValueError("from_date and to_date are required for historical table data")
            
            # Get historical DSM table data using repository
            cursor = await self.dsm_repo.get_dsm_historical_table_data_pipeline(
                self.demand_serve_historical, from_date, to_date, time_block
            )
            logger.warning(f"No dashboard data found: {cursor}")
            return cursor
        except Exception as e:
            logger.exception(
                f"[DsmService] Failed to fetch historical DSM table data: {str(e)}"
            )
            raise


# Create service instance
dsm_service = DsmService()
