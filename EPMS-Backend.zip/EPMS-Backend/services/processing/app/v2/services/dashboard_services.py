"""
Dashboard V2 Service
Enhanced dashboard service with business logic and repository integration
"""

import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from fastapi import HTTPException


# Update these import paths to match your project structure
from ..repository.dashboard_repository import dashboard_repository
from libs.helpers.timeblock_helper import ist_now, block_from_hhmm
from libs.utils.date_filters import validate_schedule_date

from ...core.config import settings

logger = logging.getLogger(__name__)


class DashboardService:
    """
    Service layer for Dashboard V2 operations.
    Handles business logic and data processing.
    """

    def __init__(self):
        self.dashboard_repository = dashboard_repository
        self.plant_master = settings.MONGODB_PLANT_MASTER_COLLECTION

    async def get_dashboard_home_data(self, schedule_date: Optional[str] = None) -> Dict[str, Any]:
        """
        Get dashboard home data, always centered on the current time block.
        If a schedule_date is provided, it will be centered on block 96 of that day.
        """
        try:
            now_ist = ist_now()
            today_str = now_ist.date().isoformat()

            # If a specific date is requested AND it's a past date, we show the end of that day.
            # Otherwise (today or no date), we use the current real-time date and block.
            if schedule_date and validate_schedule_date(schedule_date) and schedule_date != today_str:
                effective_date_str = schedule_date
                current_block = 96 # Show the full day for historical queries
                logger.info(f"Using user-provided historical date: {effective_date_str}, centering on Block 96")
            else:
                effective_date_str = today_str
                current_block = block_from_hhmm(now_ist.strftime("%H:%M"))
                logger.info(f"Using current time. Date: {effective_date_str}, Block: {current_block}")

            # Get dashboard data from repository
            dashboard_data = await self.dashboard_repository.get_dashboard_data(
                schedule_date_str=effective_date_str,
                current_block=current_block
            )

            # Process and enhance the data
            processed_data = self._process_dashboard_data(
                dashboard_data=dashboard_data,
                schedule_date=effective_date_str,
                current_block=current_block
            )

            logger.info(f"Successfully processed dashboard home data for {effective_date_str}")
            return processed_data

        except Exception as e:
            logger.error(f"Error processing dashboard home data - schedule_date: {schedule_date}, error: {str(e)}")
            raise

    def _process_dashboard_data(
        self,
        dashboard_data: Dict[str, Any],
        schedule_date: str,
        current_block: int
    ) -> Dict[str, Any]:
        """
        Process and enhance dashboard data with business logic.
        """
        processed_data = {
            "schedule_date": schedule_date,
            "current_block": current_block,
            "timestamp": datetime.utcnow().isoformat(),
            **dashboard_data
        }
        return processed_data

    async def get_dashboard_capacity_chart(self) -> Dict[str, Any]:
        """
        Returns hierarchical sunburst data with colors:
        Total Capacity -> c_s -> category -> plant_name (with ppa)
        Reads from `plant_master` where:
        - c_s (central/state/other) is used directly
        - capacity comes from `ppa` (converted to double)
        """
        try:
            pipeline = [
                # Convert ppa safely
                {
                    "$addFields": {
                        "ppa_num": {
                            "$convert": {
                                "input": "$ppa",
                                "to": "double",
                                "onError": 0.0,
                                "onNull": 0.0
                            }
                        }
                    }
                },

                # 1) plant level
                {
                    "$group": {
                        "_id": {
                            "c_s": "$c_s",
                            "category": "$category",
                            "plant_name": "$plant_name"
                        },
                        "ppa": {"$sum": "$ppa_num"}
                    }
                },

                # 2) category level
                {
                    "$group": {
                        "_id": {
                            "c_s": "$_id.c_s",
                            "category": "$_id.category"
                        },
                        "plants": {
                            "$push": {
                                "plant_name": "$_id.plant_name",
                                "ppa": "$ppa"
                            }
                        },
                        "category_capacity": {"$sum": "$ppa"}
                    }
                },

                # 3) c_s level
                {
                    "$group": {
                        "_id": "$_id.c_s",
                        "categories": {
                            "$push": {
                                "category": "$_id.category",
                                "capacity": "$category_capacity",
                                "children": "$plants"
                            }
                        },
                        "c_s_capacity": {"$sum": "$category_capacity"}
                    }
                },

                # 4) root
                {
                    "$group": {
                        "_id": None,
                        "total_capacity": {"$sum": "$c_s_capacity"},
                        "c_s_groups": {
                            "$push": {
                                "c_s": "$_id",
                                "capacity": "$c_s_capacity",
                                "children": "$categories"
                            }
                        }
                    }
                },

                # 5) shape final
                {
                    "$project": {
                        "_id": 0,
                        "name": {"$literal": "Total Capacity"},
                        "capacity": "$total_capacity",
                        "children": "$c_s_groups"
                    }
                }
            ]

            result = list(await self.dashboard_repository.repository.aggregate_async(self.plant_master, pipeline))
            if not result:
                raise HTTPException(status_code=404, detail="No capacity data found")

            root = result[0]

            # Color scheme by c_s
            cs_colors = {
                "central": "#34A853",
                "state": "#FF9900"
            }

            def lighten_color(base_hex: str, factor: float) -> str:
                base_hex = base_hex.lstrip('#')
                r, g, b = int(base_hex[:2], 16), int(base_hex[2:4], 16), int(base_hex[4:], 16)
                r = min(int(r + (255 - r) * factor), 255)
                g = min(int(g + (255 - g) * factor), 255)
                b = min(int(b + (255 - b) * factor), 255)
                return f"#{r:02X}{g:02X}{b:02X}"

            for cs_group in root['children']:
                cs_value = (cs_group.get('c_s') or "other").lower()
                cs_group['color'] = cs_colors.get(cs_value, "#CCCCCC")

                num_categories = len(cs_group.get('children', []))
                for c_idx, cat in enumerate(cs_group.get('children', [])):
                    factor = 0.2 + 0.6 * c_idx / max(1, num_categories - 1)
                    cat['color'] = lighten_color(cs_group['color'], factor)

                    num_plants = len(cat.get('children', []))
                    for p_idx, plant in enumerate(cat.get('children', [])):
                        factor_p = 0.3 + 0.4 * p_idx / max(1, num_plants - 1)
                        plant['color'] = lighten_color(cat['color'], factor_p)

            return root

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    async def get_demand_raw_v2_data(
        self,
        filters: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        Fetches raw demand data from the V2 collection based on provided filters.
        """
        try:
            query = {}
            # Date range filter
            if filters.get("date_from") or filters.get("date_to"):
                date_query = {}
                if filters.get("date_from"):
                    start_date = datetime.strptime(filters["date_from"], "%Y-%m-%d")
                    date_query["$gte"] = start_date
                if filters.get("date_to"):
                    end_date = datetime.strptime(filters["date_to"], "%Y-%m-%d") + timedelta(days=1, microseconds=-1)
                    date_query["$lte"] = end_date
                query["scheduled_at"] = date_query

            # Time block range filter
            if filters.get("from_block") or filters.get("to_block"):
                time_block_query = {}
                if filters.get("from_block"):
                    time_block_query["$gte"] = filters["from_block"]
                if filters.get("to_block"):
                    time_block_query["$lte"] = filters["to_block"]
                query["time_block"] = time_block_query

            # Type and Zone filters
            if filters.get("type"):
                query["type"] = filters["type"]
            if filters.get("zone"):
                query["zone"] = filters["zone"]

            # Min/Max filters for numerical fields
            numerical_fields = [
                "actual", "drawal", "mape", "mpe", "Raw_Frequency", "Schedule",
                "comp_act_demand", "comp_udm", "dsm_rate", "forecast",
                "forecasted_frequency", "net_dsm_amount", "rostering"
            ]
            for field in numerical_fields:
                min_val = filters.get(f"{field.lower()}_min")
                max_val = filters.get(f"{field.lower()}_max")
                if min_val is not None or max_val is not None:
                    field_query = {}
                    if min_val is not None:
                        field_query["$gte"] = min_val
                    if max_val is not None:
                        field_query["$lte"] = max_val
                    query[field] = field_query

            # Updated_at range filter
            if filters.get("updated_from") or filters.get("updated_to"):
                updated_at_query = {}
                if filters.get("updated_from"):
                    updated_at_query["$gte"] = filters["updated_from"]
                if filters.get("updated_to"):
                    updated_at_query["$lte"] = filters["updated_to"]
                query["updated_at"] = updated_at_query

            # Projection (include/exclude fields)
            projection = None
            if filters.get("include"):
                include_fields = {f.strip(): 1 for f in filters["include"].split(",") if f.strip()}
                if "_id" not in include_fields: # _id is included by default unless explicitly excluded
                    include_fields["_id"] = 0
                projection = include_fields
            elif filters.get("exclude"):
                exclude_fields = {f.strip(): 0 for f in filters["exclude"].split(",") if f.strip()}
                projection = exclude_fields

            # Sorting
            sort_params = None
            if filters.get("sort"):
                sort_params = []
                for s_param in filters["sort"].split(","):
                    field, direction = s_param.strip().split(":")
                    sort_params.append((field, 1 if direction.lower() == "asc" else -1))

            # Pagination
            skip = filters.get("skip", 0)
            limit = filters.get("limit")

            logger.info(f"Fetching demand raw V2 data with query: {query}, projection: {projection}, sort: {sort_params}, skip: {skip}, limit: {limit}")
            data = await self.dashboard_repository.get_demand_raw_v2(
                collection_name=self.dashboard_repository.demand_serve,
                query=query,
                projection=projection,
                sort=sort_params,
                skip=skip,
                limit=limit
            )
            return data
        except Exception as e:
            logger.error(f"Error in get_demand_raw_v2_data service: {str(e)}")
            raise


# Global instance
dashboard_service = DashboardService()
