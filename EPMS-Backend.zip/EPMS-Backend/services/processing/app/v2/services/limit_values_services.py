"""
Limit Values service layer using repository pattern.
Implements: file upload + edit (PENDING), approve/reject, latest read,
and writes to limit_audit_log.
"""

import csv
import io
import json
import logging
from typing import List, Optional, Dict, Any
from datetime import datetime

from ..repository.limit_values_repository import limit_values_repository
from ..repository.limit_workflow_repository import limit_workflow_repository
from ...core.config import settings

logger = logging.getLogger(__name__)

# ---------- helpers ----------
REQUIRED_COLUMNS = ["scheduled_at", "block", "id_type", "values"]
ALLOWED_ACTIONS = {"UPSERT", "DELETE"}

def _parse_date_yyyy_mm_dd(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%d")

def _normalize_item(row: Dict[str, Any]) -> Dict[str, Any]:
    try:
        scheduled_at = str(row["scheduled_at"])
        block = int(row["block"])
        id_type = str(row["id_type"])
        values = float(row["values"]) if row.get("action", "UPSERT") != "DELETE" else None

        item = {
            "action": str(row.get("action", "UPSERT")).upper(),
            "scheduled_at": scheduled_at,
            "block": block,
            "id_type": id_type,
            "market": row.get("market", "RTM"),
            "category": row.get("category", "Limits"),
            "area": row.get("area", ""),
            "values": values,
            "unit": row.get("unit", "MW"),
            "comment": row.get("comment"),
        }
        if item["action"] not in ALLOWED_ACTIONS:
            raise ValueError(f"Invalid action {item['action']}")
        if item["action"] == "UPSERT" and values is None:
            raise ValueError("values required for UPSERT")
        # validate date now (UI sends string; we convert during apply)
        _ = _parse_date_yyyy_mm_dd(scheduled_at)
        return item
    except Exception as e:
        raise ValueError(f"Invalid item: {row}. Error: {str(e)}")

def _business_key(item: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "scheduled_at": _parse_date_yyyy_mm_dd(item["scheduled_at"]),
        "block": item["block"],
        "id_type": item["id_type"],
        "market": item["market"],
        "category": item["category"],
        "area": item["area"],
    }

def _values_doc(item: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "scheduled_at": _parse_date_yyyy_mm_dd(item["scheduled_at"]),
        "block": item["block"],
        "id_type": item["id_type"],
        "market": item["market"],
        "category": item["category"],
        "area": item["area"],
        "values": item["values"],
        "unit": item["unit"],
        "is_active": True,
    }

class LimitService:
    def __init__(self):
        self.values_repo = limit_values_repository
        self.flow_repo = limit_workflow_repository
        self.values_collection = settings.MONGODB_LIMIT_VALUES_COLLECTION              # "limit_values"
        self.approval_collection = settings.MONGODB_LIMIT_APPROVAL_COLLECTION          # "limit_approval"
        self.audit_collection = settings.MONGODB_LIMIT_AUDIT_COLLECTION                # "limit_audit_log"

    # --------- Read (latest) ---------
    async def latest(self) -> Dict[str, Any]:
        try:
            rows = await self.values_repo.get_latest_date_data_pipeline(self.values_collection)

            # Convert BSON ObjectId and datetimes to JSON-serializable values
            try:
                from bson import ObjectId
            except Exception:
                ObjectId = None

            def _serialize(value):
                # Handle ObjectId
                if ObjectId is not None and isinstance(value, ObjectId):
                    return str(value)
                # Datetime -> ISO
                from datetime import datetime
                if isinstance(value, datetime):
                    return value.isoformat()
                # Dict -> recurse
                if isinstance(value, dict):
                    return {k: _serialize(v) for k, v in value.items()}
                # List/tuple -> recurse
                if isinstance(value, (list, tuple)):
                    return [_serialize(v) for v in value]
                return value

            serialized = [_serialize(r) for r in rows]
            return {"records": serialized, "count": len(serialized)}
        except Exception as e:
            logger.exception(f"[LimitService] latest failed: {str(e)}")
            raise

    # --------- Stage: create (file upload) ---------
    async def stage_file_upload(self, file_bytes: bytes, filename: str, user_ctx: Dict[str, Any]) -> Dict[str, Any]:
        try:
            name = filename.lower()
            raw_items: List[Dict[str, Any]] = []
            if name.endswith(".csv"):
                stream = io.StringIO(file_bytes.decode("utf-8"))
                reader = csv.DictReader(stream)
                raw_items = [dict(r) for r in reader]
            elif name.endswith(".json"):
                payload = json.loads(file_bytes.decode("utf-8"))
                raw_items = payload.get("records", payload) if isinstance(payload, dict) else payload
            else:
                raise ValueError("Unsupported file type. Use .csv or .json")

            # Normalize + validate
            items: List[Dict[str, Any]] = []
            errors = 0
            for r in raw_items:
                try:
                    items.append(_normalize_item(r))
                except Exception as ex:
                    errors += 1
                    items.append({"row_status": "ERROR", "row_errors": [str(ex)], **r})

            now = datetime.utcnow()
            approval_doc = {
                "status": "PENDING",
                "request_type": "FILE_UPLOAD",
                "title": filename,
                "description": f"Uploaded by {user_ctx.get('username','anonymous')}",
                "requested_by": user_ctx.get("user_id", "anonymous"),
                "requested_username": user_ctx.get("username", "anonymous"),
                "requested_at": now,
                "last_edited_at": now,
                "last_edited_by": user_ctx.get("user_id", "anonymous"),
                "items": items,
                "file": {
                    "filename": filename,
                    "mime_type": "text/csv" if name.endswith(".csv") else "application/json",
                    "size_bytes": len(file_bytes),
                    "storage_path": None,  # fill if you persist files
                    "checksum_sha256": None
                },
                "counts": {
                    "total_items": len(items),
                    "valid_items": len([i for i in items if i.get("row_status") != "ERROR"]),
                    "invalid_items": errors,
                    "applied_upserts": 0,
                    "applied_deletes": 0,
                },
                "correlation_id": user_ctx.get("correlation_id", "unknown"),
                "created_at": now,
                "created_by": user_ctx.get("user_id", "anonymous"),
            }

            approval_id = self.flow_repo.create_approval(self.approval_collection, approval_doc)

            # DB audit
            self.flow_repo.write_audit(self.audit_collection, {
                "ts": now,
                "actor_id": user_ctx.get("user_id", "anonymous"),
                "actor_username": user_ctx.get("username", "anonymous"),
                "action": "UPLOAD_STAGED",
                "entity_type": "limit_approval",
                "entity_id": approval_id,
                "operation": "INSERT",
                "request_id": approval_id,
                "correlation_id": user_ctx.get("correlation_id", "unknown"),
                "success": True
            })

            return {"approval_id": str(approval_id), "total": len(items), "invalid": errors}
        except Exception as e:
            logger.exception(f"[LimitService] stage_file_upload failed: {str(e)}")
            raise

    # --------- Stage: edit items while PENDING ---------
    async def stage_edit(self, approval_id: Any, items: List[Dict[str, Any]], user_ctx: Dict[str, Any]) -> Dict[str, Any]:
        try:
            approval = self.flow_repo.get_approval(self.approval_collection, approval_id)
            if not approval:
                raise ValueError("Approval request not found")
            if approval["status"] != "PENDING":
                raise ValueError("Only PENDING requests can be edited")
            if approval["requested_by"] != user_ctx.get("user_id"):
                raise PermissionError("Only the requester can edit this approval")

            normalized, errors = [], 0
            for r in items:
                try:
                    normalized.append(_normalize_item(r))
                except Exception as ex:
                    errors += 1
                    normalized.append({"row_status": "ERROR", "row_errors": [str(ex)], **r})

            now = datetime.utcnow()
            counts = {
                "total_items": len(normalized),
                "valid_items": len([i for i in normalized if i.get("row_status") != "ERROR"]),
                "invalid_items": errors,
                "applied_upserts": approval.get("counts", {}).get("applied_upserts", 0),
                "applied_deletes": approval.get("counts", {}).get("applied_deletes", 0),
            }
            self.flow_repo.update_approval(
                self.approval_collection,
                approval_id,
                {
                    "items": normalized,
                    "last_edited_at": now,
                    "last_edited_by": user_ctx.get("user_id", "anonymous"),
                    "counts": counts
                }
            )

            self.flow_repo.write_audit(self.audit_collection, {
                "ts": now,
                "actor_id": user_ctx.get("user_id", "anonymous"),
                "actor_username": user_ctx.get("username", "anonymous"),
                "action": "STAGE_EDIT",
                "entity_type": "limit_approval",
                "entity_id": approval_id,
                "operation": "UPDATE",
                "request_id": approval_id,
                "correlation_id": user_ctx.get("correlation_id", "unknown"),
                "success": True
            })

            return {"approval_id": str(approval_id), "total": counts["total_items"], "invalid": counts["invalid_items"]}
        except Exception as e:
            logger.exception(f"[LimitService] stage_edit failed: {str(e)}")
            raise

    # --------- Pending list ---------
    async def list_pending(self, status: Optional[str]) -> List[Dict[str, Any]]:
        try:
            return self.flow_repo.list_approvals(self.approval_collection, status or "PENDING")
        except Exception as e:
            logger.exception(f"[LimitService] list_pending failed: {str(e)}")
            raise

    # --------- Approve ---------
    async def approve(self, approval_id: Any, approver_ctx: Dict[str, Any]) -> Dict[str, Any]:
        try:
            approval = self.flow_repo.get_approval(self.approval_collection, approval_id)
            if not approval:
                raise ValueError("Approval request not found")
            if approval["status"] != "PENDING":
                return {"message": "Already processed", "status": approval["status"]}

            now = datetime.utcnow()
            apply_upserts = 0
            apply_deletes = 0

            # apply each valid item
            for item in approval.get("items", []):
                if item.get("row_status") == "ERROR":
                    continue
                action = item.get("action", "UPSERT")
                key = _business_key(item)
                if action == "UPSERT":
                    values_doc = _values_doc(item)
                    self.values_repo.upsert_one(
                        self.values_collection,
                        key,
                        values_doc,
                        created_by=approval.get("requested_by", "unknown"),
                        updated_by=approver_ctx.get("user_id", "approver"),
                        source_approval_id=approval["_id"],
                    )
                    apply_upserts += 1
                    # audit row
                    self.flow_repo.write_audit(self.audit_collection, {
                        "ts": now,
                        "actor_id": approver_ctx.get("user_id", "approver"),
                        "actor_username": approver_ctx.get("username", "approver"),
                        "action": "APPLY_UPSERT",
                        "entity_type": "limit_values",
                        "entity_id": None,
                        "operation": "UPDATE",
                        "request_id": approval["_id"],
                        "correlation_id": approver_ctx.get("correlation_id", "unknown"),
                        "key": {
                            **{k: (v.isoformat() if hasattr(v, 'isoformat') else v) for k, v in key.items()}
                        },
                        "success": True
                    })
                elif action == "DELETE":
                    self.values_repo.delete_one_soft(
                        self.values_collection, key,
                        updated_by=approver_ctx.get("user_id", "approver"),
                        source_approval_id=approval["_id"]
                    )
                    apply_deletes += 1
                    self.flow_repo.write_audit(self.audit_collection, {
                        "ts": now,
                        "actor_id": approver_ctx.get("user_id", "approver"),
                        "actor_username": approver_ctx.get("username", "approver"),
                        "action": "APPLY_DELETE",
                        "entity_type": "limit_values",
                        "entity_id": None,
                        "operation": "UPDATE",
                        "request_id": approval["_id"],
                        "correlation_id": approver_ctx.get("correlation_id", "unknown"),
                        "key": {
                            **{k: (v.isoformat() if hasattr(v, 'isoformat') else v) for k, v in key.items()}
                        },
                        "success": True
                    })

            # mark approval approved
            self.flow_repo.update_approval(
                self.approval_collection,
                approval["_id"],
                {
                    "status": "APPROVED",
                    "approved_by": approver_ctx.get("user_id", "approver"),
                    "approved_username": approver_ctx.get("username", "approver"),
                    "approved_at": now,
                    "counts.applied_upserts": apply_upserts,
                    "counts.applied_deletes": apply_deletes
                }
            )

            # approval audit
            self.flow_repo.write_audit(self.audit_collection, {
                "ts": now,
                "actor_id": approver_ctx.get("user_id", "approver"),
                "actor_username": approver_ctx.get("username", "approver"),
                "action": "APPROVE",
                "entity_type": "limit_approval",
                "entity_id": approval["_id"],
                "operation": "UPDATE",
                "request_id": approval["_id"],
                "correlation_id": approver_ctx.get("correlation_id", "unknown"),
                "success": True
            })

            return {"status": "APPROVED", "upserts": apply_upserts, "deletes": apply_deletes}
        except Exception as e:
            logger.exception(f"[LimitService] approve failed: {str(e)}")
            raise

    # --------- Reject ---------
    async def reject(self, approval_id: Any, approver_ctx: Dict[str, Any], reason: Optional[str]) -> Dict[str, Any]:
        try:
            approval = self.flow_repo.get_approval(self.approval_collection, approval_id)
            if not approval:
                raise ValueError("Approval request not found")
            if approval["status"] != "PENDING":
                return {"message": "Already processed", "status": approval["status"]}

            now = datetime.utcnow()
            self.flow_repo.update_approval(
                self.approval_collection,
                approval["_id"],
                {
                    "status": "REJECTED",
                    "rejected_by": approver_ctx.get("user_id", "approver"),
                    "rejected_username": approver_ctx.get("username", "approver"),
                    "rejected_at": now,
                    "decision_reason": reason or "Not specified"
                }
            )

            self.flow_repo.write_audit(self.audit_collection, {
                "ts": now,
                "actor_id": approver_ctx.get("user_id", "approver"),
                "actor_username": approver_ctx.get("username", "approver"),
                "action": "REJECT",
                "entity_type": "limit_approval",
                "entity_id": approval["_id"],
                "operation": "UPDATE",
                "request_id": approval["_id"],
                "correlation_id": approver_ctx.get("correlation_id", "unknown"),
                "success": True
            })

            return {"status": "REJECTED"}
        except Exception as e:
            logger.exception(f"[LimitService] reject failed: {str(e)}")
            raise


limit_service = LimitService()
