from fastapi import APIRouter, Request, HTTPException, status, Depends, UploadFile, File
from typing import Dict, Any, Optional, List
from pydantic import BaseModel, Field, validator
from datetime import datetime
import logging

from ...controller.limit_values_controller import limit_controller
from ...dependencies import get_user_context
from libs.audit_queue.simple_logger import audit_logger

router = APIRouter(
    prefix="/limit-values",
    tags=["Limit Values"]
)

logger = logging.getLogger(__name__)


class LatestResponse(BaseModel):
    data: Dict[str, Any]

class StageEditItem(BaseModel):
    scheduled_at: str
    block: int
    id_type: str
    market: Optional[str] = "RTM"
    category: Optional[str] = "Limits"
    area: Optional[str] = ""
    values: Optional[float] = None
    unit: Optional[str] = "MW"
    action: Optional[str] = "UPSERT"
    comment: Optional[str] = None

    @validator("scheduled_at")
    def _validate_date(cls, v):
        datetime.strptime(v, "%Y-%m-%d")
        return v

@router.get(
    "/latest",
    response_model=LatestResponse,
    status_code=status.HTTP_200_OK,
    summary="Get latest-date limit values"
)
async def get_latest(
    request: Request,
    user_context: Dict[str, Any] = Depends(get_user_context)
):
    user_id = user_context.get("user_id", "anonymous")
    username = user_context.get("username", "anonymous")
    correlation_id = user_context.get("correlation_id", "unknown")
    try:
        audit_logger.log_system_operation(
            service="processing-v2",
            operation="limit_values_latest_fetch",
            message="Fetch latest limit values",
            correlation_id=correlation_id,
            user_id=user_id
        )
        result = await limit_controller.latest()
        audit_logger.log_user_action(
            service="processing-v2",
            user_id=user_id,
            action="limit_values_latest_view",
            message="Fetched latest",
            username=username,
            correlation_id=correlation_id,
            record_count=result.get("count", 0),
            success=True
        )
        return LatestResponse(data=result)
    except Exception as e:
        audit_logger.log_error_event(
            service="processing-v2",
            error_name="LimitLatestError",
            error_message=str(e),
            user_id=user_id,
            correlation_id=correlation_id,
            error_type=type(e).__name__
        )
        raise HTTPException(status_code=500, detail="Failed to fetch latest")

@router.post(
    "/file-upload-stage",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Stage file upload (CSV/JSON) for approval"
)
async def stage_file_upload(
    request: Request,
    file: UploadFile = File(...),
    user_context: Dict[str, Any] = Depends(get_user_context)
):
    user_id = user_context.get("user_id", "anonymous")
    username = user_context.get("username", "anonymous")
    correlation_id = user_context.get("correlation_id", "unknown")
    try:
        audit_logger.log_user_action(
            service="processing-v2",
            user_id=user_id,
            action="limit_values_stage_file_upload",
            message=f"Staging file {file.filename}",
            username=username,
            correlation_id=correlation_id,
            success=True
        )
        result = await limit_controller.stage_upload(file, user_context)
        return {"data": result}
    except Exception as e:
        audit_logger.log_error_event(
            service="processing-v2",
            error_name="LimitStageUploadError",
            error_message=str(e),
            user_id=user_id,
            correlation_id=correlation_id,
            error_type=type(e).__name__
        )
        raise

@router.put(
    "/stage/{approval_id}",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Edit staged items while PENDING"
)
async def stage_edit(
    request: Request,
    approval_id: str,
    body: List[StageEditItem],
    user_context: Dict[str, Any] = Depends(get_user_context)
):
    user_id = user_context.get("user_id", "anonymous")
    username = user_context.get("username", "anonymous")
    correlation_id = user_context.get("correlation_id", "unknown")
    try:
        audit_logger.log_user_action(
            service="processing-v2",
            user_id=user_id,
            action="limit_values_stage_edit",
            message=f"Editing staged approval {approval_id}",
            username=username,
            correlation_id=correlation_id,
            record_count=len(body),
            success=True
        )
        result = await limit_controller.stage_edit(approval_id, [x.dict() for x in body], user_context)
        return {"data": result}
    except Exception as e:
        audit_logger.log_error_event(
            service="processing-v2",
            error_name="LimitStageEditError",
            error_message=str(e),
            user_id=user_id,
            correlation_id=correlation_id,
            error_type=type(e).__name__
        )
        raise

@router.get(
    "/pending",
    status_code=status.HTTP_200_OK,
    summary="List approval requests (default PENDING)"
)
async def list_pending(
    request: Request,
    status_filter: Optional[str] = "PENDING",
    user_context: Dict[str, Any] = Depends(get_user_context)
):
    user_id = user_context.get("user_id", "anonymous")
    correlation_id = user_context.get("correlation_id", "unknown")
    try:
        audit_logger.log_system_operation(
            service="processing-v2",
            operation="limit_values_list_approvals",
            message=f"List approvals status={status_filter}",
            correlation_id=correlation_id,
            user_id=user_id
        )
        result = await limit_controller.list_pending(status_filter)
        return {"data": result}
    except Exception as e:
        audit_logger.log_error_event(
            service="processing-v2",
            error_name="LimitListApprovalsError",
            error_message=str(e),
            user_id=user_id,
            correlation_id=correlation_id,
            error_type=type(e).__name__
        )
        raise HTTPException(status_code=500, detail="Failed to list approvals")

class DecisionBody(BaseModel):
    reason: Optional[str] = None

@router.post(
    "/approve/{approval_id}",
    status_code=status.HTTP_200_OK,
    summary="Approve a staged request and apply to limit_values"
)
async def approve(
    request: Request,
    approval_id: str,
    user_context: Dict[str, Any] = Depends(get_user_context)
):
    user_id = user_context.get("user_id", "anonymous")
    username = user_context.get("username", "anonymous")
    correlation_id = user_context.get("correlation_id", "unknown")
    try:
        audit_logger.log_user_action(
            service="processing-v2",
            user_id=user_id,
            action="limit_values_approve",
            message=f"Approving {approval_id}",
            username=username,
            correlation_id=correlation_id,
            success=True
        )
        result = await limit_controller.approve(approval_id, user_context)
        return {"data": result}
    except Exception as e:
        audit_logger.log_error_event(
            service="processing-v2",
            error_name="LimitApproveError",
            error_message=str(e),
            user_id=user_id,
            correlation_id=correlation_id,
            error_type=type(e).__name__
        )
        raise

@router.post(
    "/reject/{approval_id}",
    status_code=status.HTTP_200_OK,
    summary="Reject a staged request"
)
async def reject(
    request: Request,
    approval_id: str,
    body: DecisionBody,
    user_context: Dict[str, Any] = Depends(get_user_context)
):
    user_id = user_context.get("user_id", "anonymous")
    username = user_context.get("username", "anonymous")
    correlation_id = user_context.get("correlation_id", "unknown")
    try:
        audit_logger.log_user_action(
            service="processing-v2",
            user_id=user_id,
            action="limit_values_reject",
            message=f"Rejecting {approval_id}",
            username=username,
            correlation_id=correlation_id,
            success=True
        )
        result = await limit_controller.reject(approval_id, user_context, body.reason)
        return {"data": result}
    except Exception as e:
        audit_logger.log_error_event(
            service="processing-v2",
            error_name="LimitRejectError",
            error_message=str(e),
            user_id=user_id,
            correlation_id=correlation_id,
            error_type=type(e).__name__
        )
        raise

