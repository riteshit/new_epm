from typing import Any, Dict, List, Optional, Tuple
from pymongo import ReturnDocument
from bson import ObjectId
from libs.models.price_group_entity import PriceGroupEntity, COLL_PRICE_GROUP
from .base_repository import BaseRepository


class PriceGroupRepository(BaseRepository):
    """Data access for price_group collection built on your BaseRepository.
    Change the collection once in libs/models/price_group_entity.py
    """
    def __init__(self):
        super().__init__(COLL_PRICE_GROUP)
        self.ensure_indexes()


    def ensure_indexes(self):
        self.create_index([("price_group", 1)], unique=True)
        self.create_index([("price_from", 1), ("price_to", 1)], unique=False)


    # Strongly-typed helpers wrapping BaseRepository
    def create(self, data: Dict[str, Any]) -> str: # type: ignore[override]
        entity = PriceGroupEntity(**data)
        return super().create(entity.model_dump(by_alias=True, exclude_none=True))


    def get(self, _id: str) -> Optional[Dict[str, Any]]:
        doc = super().find_by_id(_id)
        return self._dump(doc)


    def get_by_group(self, price_group: str) -> Optional[Dict[str, Any]]:
        doc = super().find_one({"price_group": price_group})
        return self._dump(doc)


    def list(
        self,
        filters: Optional[Dict[str, Any]] = None,
        page: int = 1,
        page_size: int = 50,
        sort: Optional[List[Tuple[str, int]]] = None,
        ) -> Dict[str, Any]:
        filters = filters or {}
        sort = sort or [("price_group", 1)]
        skip = (page - 1) * page_size
        cursor = self.collection.find(filters).sort(sort).skip(skip).limit(page_size)
        items = [self._dump(d) for d in cursor]
        total = self.count(filters)
        return {"items": items, "total": total, "page": page, "page_size": page_size}


    def update(self, _id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if not ObjectId.is_valid(_id):
            return None
        if not updates:
            return self.get(_id)
        current = super().find_by_id(_id) or {}
        # Validate merged state
        PriceGroupEntity(**{**current, **updates})
        res = self.collection.find_one_and_update(
            {"_id": ObjectId(_id)},
            {"$set": updates},
            return_document=ReturnDocument.AFTER,
            )
        return self._dump(res)


    def delete(self, _id: str) -> bool:
       return super().delete(_id)


    def _dump(self, doc: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        if not doc:
            return None

        validated = PriceGroupEntity(**doc).model_dump(
            mode="python",      # keep datetimes as datetime; FastAPI will serialize
            by_alias=True,
            exclude_none=True,
        )

        # Ensure client-facing id key is present
        if "_id" in doc and doc["_id"] is not None:
            validated["price_group_id"] = str(doc["_id"])
            # stop exposing Mongo _id
            validated.pop("_id", None)

        return validated