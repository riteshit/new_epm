# repositories/serve_dam_scheduling_repository.py
from typing import List, Dict, Any, Optional
import logging

from .base_repository import BaseRepository

logger = logging.getLogger(__name__)


class PlantsMasterRepository(BaseRepository):
    """
    Thin repository for the 'serve_dam_scheduling' collection.
    Keeps the same interface style as your other repos (e.g., serveExchangeTableRepository).
    """

    def __init__(self, collection_name: str = "rtm_product_hardCoded_data"):
        super().__init__(collection_name=collection_name)
        logger.info(f"serveDamSchedulingRepository initialized with collection: {collection_name}")

    # ---- Generic passthrough used by the service layer ----
    async def get_Data(self):
        """
        Insert multiple documents into the collection asynchronously.
        Returns {"data": True} if successful.
        """
        try:    
            pipeline = [
                {
                   "$project": {
            "_id": 0,
                }
            },
            
            ]
            result= self.collection.aggregate(pipeline)

            logger.info("Bulk insert successful")
            return list(result)
        except Exception as e:
            logger.error("Failed to bulk insert iex exchange serve records: %s", str(e))
            return str(e) # type: ignore
