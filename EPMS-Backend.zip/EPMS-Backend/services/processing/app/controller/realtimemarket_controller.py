import logging
from typing import Dict, Any, Optional
from fastapi import HTTPException, status, Request
from ..services.realtimemarket_services import realtimemarket_service

logger = logging.getLogger(__name__)


class RealtimemarketController:
    """
    Controller for handling RealtimemarketController-related business logic and request processing.
    """

    def __init__(self):
        self.realtimemarket_service = realtimemarket_service

    def _extract_request_info(self, request: Request) -> Dict[str, Optional[str]]:
        """
        Extract useful information from the request for auditing/logging.

        Args:
            request (Request): The FastAPI request object.

        Returns:
            Dict[str, Optional[str]]: Extracted request metadata.
        """
        return {
            "ip_address": request.client.host if request.client else None,
            "user_agent": request.headers.get("user-agent"),
            "method": request.method,
            "path": request.url.path,
            "timestamp": request.headers.get("x-request-timestamp")
        }

    async def rtm_single_bid_graph(self, schedule_date, from_block, to_block) -> Dict[str, Any]:
        try:
            data = await self.realtimemarket_service.rtm_single_bid_graph(schedule_date, from_block, to_block)
            return {"data": data}
        except HTTPException:
            raise 
        except Exception:
            logger.exception("Error occurred in DsmoverviewController.dsm")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to process dsm data request."
            )
    
    async def dam_single_bid_graph(self, schedule_date, from_block=1, to_block=96) -> Dict[str, Any]:
        try:
            data = await self.realtimemarket_service.rtm_single_bid_graph(schedule_date, from_block, to_block)
            return {"data": data}
        except HTTPException:
            raise 
        except Exception:
            logger.exception("Error occurred in DsmoverviewController.dsm")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to process dsm data request."
            )
    
    async def rtm_single_bid_table(self, schedule_date, from_block, to_block) -> Dict[str, Any]:
        try:
            data = await self.realtimemarket_service.rtm_single_bid_table(schedule_date, from_block, to_block)
            return {"data": data}
        except HTTPException:
            raise 
        except Exception:
            logger.exception("Error occurred in DsmoverviewController.dsm")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to process dsm data request."
            )
        
    async def dam_single_bid_table(self, schedule_date, from_block=1, to_block=96) -> Dict[str, Any]:
        try:
            data = await self.realtimemarket_service.rtm_single_bid_table(schedule_date, from_block, to_block)
            return {"data": data}
        except HTTPException:
            raise 
        except Exception:
            logger.exception("Error occurred in DsmoverviewController.dsm")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to process dsm data request."
            )
    async def submit_for_approval_post_data(self, request: Dict[str, Any]) -> Dict[str, Any]:
        try:
            logger.info(f"Checking {request['data']}")
            data = await self.realtimemarket_service.submit_for_approval_post_data(request['data'])
            return {"data": data}
        except HTTPException:
            raise 
        except Exception:
            logger.exception("Error occurred in DsmoverviewController.dsm")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to process dsm data request."
            )
    
    async def rtm_scheduling_cal_table(self, schedule_date) -> Dict[str, Any]:
        try:
            # data = await self.realtimemarket_service.rtm_scheduling_table(schedule_date)
            data = await self.realtimemarket_service.calSchedulingTableData(schedule_date)
            return {"data": data}
        except HTTPException:
            raise 
        except Exception:
            logger.exception("Error occurred in DsmoverviewController.dsm")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to process dsm data request."
            )


# Global controller instance
realtimemarket_controller = RealtimemarketController()
