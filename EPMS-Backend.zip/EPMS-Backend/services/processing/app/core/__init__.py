"""
Processing Service Core
""" 