"""
EPMS Processing Service - Clean Structure
Maintains essential functionality with clean router organization
"""

# Auto-install libs package if not available
import sys
import os
from pathlib import Path

# Add project root to Python path for development
project_root = Path(__file__).parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# Check if libs package is available and install if needed
try:
    import libs.core.cron_manager
except ImportError as e:
    # Only auto-install if we're not in a container and haven't already tried recently
    is_development = not os.environ.get('DOCKER_CONTAINER', False)
    install_marker = project_root / '.libs_installed'
    
    if is_development and not install_marker.exists():
        print(f"📦 Installing dependencies due to import error: {e}")
        try:
            import subprocess
            subprocess.check_call([
                sys.executable, "-m", "pip", "install", "-e", str(project_root)
            ], timeout=60)
            print("✅ Dependencies installed successfully")
            
            # Create marker file to avoid repeated installations
            install_marker.touch()
            
            # Try importing again to verify
            import libs.core.cron_manager
        except subprocess.TimeoutExpired:
            print("⚠️ Installation timed out, continuing without auto-install")
        except Exception as install_error:
            print(f"⚠️ Failed to install dependencies: {install_error}")
            print("Continuing with manual path setup...")
    else:
        if install_marker.exists():
            print("⚠️ Dependencies were recently installed but import still failing")
            print("This might be a path issue - continuing with manual path setup...")
        else:
            print(f"⚠️ Import error: {e}")
            print("Continuing with manual path setup...")

from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.security import HTTPBearer
from pydantic import BaseModel
import logging
from starlette.responses import JSONResponse

from .core.config import settings
# Simple version constant
APP_VERSION = "2.0.0"
API_V2_VERSION = "2.0.0"
from .services.health_service import processing_health_service

# Configure logging with correlation ID support
from libs.middleware import configure_logging, LoggingMiddleware, CorrelationMiddleware

# Import V2 authentication middleware
from .v2.middleware.auth import V2AuthMiddleware

# Configure logging based on settings
configure_logging(
    level=settings.LOG_LEVEL,
    format_type=getattr(settings, 'LOG_FORMAT', 'colored'),
    include_correlation=True,
    use_colors=getattr(settings, 'LOG_USE_COLORS', True)
)



# Initialize logger (uses global config from configure_logging above)
logger = logging.getLogger("processing_service")


class HealthResponse(BaseModel):
    """Health check response model"""
    status: str
    service: str
    version: str
    environment: str
    base_path: str
    timestamp: str


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup/shutdown events"""
    # Startup
    logger.info("Starting EPMS Processing Service...")
    yield
    # Shutdown
    logger.info("Shutting down EPMS Processing Service...")


# Import routers using the clean structure
from .api.v1 import router as v1_router

# Import V2 routers
from .v2.api.router.dsm_overview import router as dsm_overview_router
from .v2.api.router.market_overview import router as market_overview_router
from .v2.api.router.graph_routes import router as graph_router
from .v2.api.router.demand_forecast_routes import router as demand_forecast_router
from .v2.api.router.dashboard_routes import router as dashboard_v2_router
from .v2.api.router.management_snapshot_routes import router as management_snapshot_v2_router
from .v2.api.router.price_group_routes import router as price_group_router
from .v2.api.router.supply_routes import router as supply_router
from .v2.api.router.master_plants_routes import router as master_plant_router
from .v2.api.router.forecastAnalysis_routes import router as forecast_analysis
from .v2.api.router.limit_values_routes import router as limit_values_routers


# Get environment from settings (which has proper defaults and validation)
environment = settings.ENVIRONMENT

# Main FastAPI application
app = FastAPI(
    title="EPMS Processing Service",
    description=f"""
    ## EPMS Processing Service
    
    Data processing service with V1 API endpoints.
    
    **Environment**: {environment}
    
    ### 📋 API Endpoints:
    - **V1 Endpoints** (`/api/v1/*`): Core processing functionality (No authentication required)
    - **V2 Endpoints** (`/api/v2/*`): Enhanced processing with JWT authentication (🔒 Bearer token required)
    
    ### 🔐 Authentication:
    V2 endpoints require JWT Bearer token authentication. Click the "Authorize" button and enter your token.
    
    ### 🏥 Health Check:
    - **Health**: `/health` - Service health status
    
    ### 🌍 Environment Configuration:
    - **Local Development**: No base path prefix
    - **Server/Docker**: `/processing` base path prefix
    """,
    version=APP_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
    root_path=settings.BASE_PATH
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=settings.CORS_ALLOW_CREDENTIALS,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include V1 router
app.include_router(v1_router)

# Create V2 router with proper prefix and security
from fastapi import APIRouter
security = HTTPBearer(auto_error=False)
v2_router = APIRouter(
    prefix="/api/v2"
)

# Include all V2 route modules in the V2 router
v2_router.include_router(dsm_overview_router)
v2_router.include_router(market_overview_router)
v2_router.include_router(graph_router)
v2_router.include_router(demand_forecast_router)
v2_router.include_router(dashboard_v2_router)
v2_router.include_router(management_snapshot_v2_router)
v2_router.include_router(price_group_router)
v2_router.include_router(supply_router)
v2_router.include_router(master_plant_router)
v2_router.include_router(forecast_analysis)
v2_router.include_router(limit_values_routers)


# Include V2 router in main app
app.include_router(v2_router)



# Add middleware (order matters - last added = first executed)
logging_config = {
    "log_requests": getattr(settings, 'LOG_REQUESTS', True),
    "log_responses": getattr(settings, 'LOG_RESPONSES', True),
    "log_body": getattr(settings, 'LOG_BODY', False),  # Only log body in debug mode
    "exclude_paths": ["/health", "/docs", "/redoc", "/openapi.json", "/favicon.ico"]
}

# Add debugging middleware for URL issues
@app.middleware("http")
async def debug_main_app_requests(request: Request, call_next):
    """Debug middleware to log all requests to main app"""
    if "processing" in str(request.url):
        logger.info(f"🔍 MAIN APP REQUEST - Method: {request.method}, URL: {request.url}, Path: {request.url.path}, Query: {request.url.query}")
    response = await call_next(request)
    return response

# Simple and robust authentication middleware
@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    """Handle authentication for V2 routes"""
    path = request.url.path
    
    # Debug logging
    logger.info(f"🔍 AUTH MIDDLEWARE - Path: {path}")
    
    # Define paths that need authentication (account for base path)
    v2_path = "/processing/api/v2"
    v2_health_path = "/api/v2/health"
    
    logger.info(f"🔍 AUTH MIDDLEWARE - Checking against V2 Path: {v2_path}")

    # Allow OPTIONS requests to pass through for CORS preflight.
    # The CORSMiddleware will handle the response.
    if request.method == "OPTIONS":
        logger.info(f"🔓 Bypassing auth for OPTIONS request: {path}")
        return await call_next(request)

    if v2_path in path and v2_health_path not in path:
        logger.info(f"🔐 AUTH REQUIRED for: {path}")
        
        # Get Authorization header
        auth_header = request.headers.get("authorization") or request.headers.get("Authorization")
        
        if not auth_header:
            logger.warning(f"❌ NO AUTH HEADER for: {path}")
            return JSONResponse(status_code=401, content={"detail": "Authorization header required"})
        
        if not auth_header.startswith("Bearer "):
            logger.warning(f"❌ INVALID AUTH FORMAT for: {path}")
            return JSONResponse(status_code=401, content={"detail": "Bearer token required"})
        
        # Extract token
        try:
            token = auth_header.split(" ")[1]
            logger.info(f"✅ TOKEN EXTRACTED for: {path}")

            # --- ADDED: Token Validation ---
            from jose import jwt, JWTError

            try:
                payload = jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])
                user_id: str = payload.get("sub") or payload.get("user_id")
                if user_id is None:
                    return JSONResponse(status_code=401, content={"detail": "Could not validate credentials: user_id missing from token"})
            except JWTError as e:
                logger.error(f"❌ JWT VALIDATION FAILED for: {path} - Error: {e}")
                return JSONResponse(status_code=401, content={"detail": f"Invalid or expired token: {e}"})
            
            # Create user context from validated token payload
            request.state.current_user = {
                "user_id": user_id,
                "username": payload.get("username", user_id),
                "token": token
            }
            logger.info(f"✅ USER CONTEXT SET for: {path}")
            
        except Exception as e:
            logger.error(f"❌ AUTH PROCESSING FAILED for: {path} - Error: {e}")
            # Re-raise if it's already an HTTPException, otherwise create a new one
            if isinstance(e, HTTPException):
                return JSONResponse(status_code=e.status_code, content={"detail": e.detail})
            return JSONResponse(status_code=401, content={"detail": f"Invalid token or authorization header: {e}"})
    
    else:
        logger.info(f"🔓 NO AUTH NEEDED for: {path}")
    
    # Continue with request
    response = await call_next(request)
    return response

# Add logging middleware first (executes last)
app.add_middleware(LoggingMiddleware, **logging_config)
# Add correlation middleware second (executes second to last)
app.add_middleware(CorrelationMiddleware)

# Health endpoints
@app.get("/health", tags=["Health"])
async def health_check():
    """Basic health check endpoint"""
    return await processing_health_service.get_simple_health()

@app.get("/api/v2/health", tags=["V2 Health"])
async def v2_health_check():
    """V2 Health check endpoint"""
    return {
        "status": "healthy",
        "service": "processing-service-v2",
        "version": API_V2_VERSION,
        "environment": environment,
        "features": [
            "JWT Authentication",
            "Correlation ID Tracking", 
            "Enhanced Error Handling"
        ]
    }


def custom_openapi():
    """Custom OpenAPI schema with security for V2 endpoints and proper server URLs"""
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    
    # Add server URLs with base path for proper OpenAPI documentation
    base_path = settings.BASE_PATH
    
    if base_path:
        # Add server with base path for server/docker environments
        openapi_schema["servers"] = [
            {
                "url": base_path,
                "description": f"Server environment ({environment})"
            },
            {
                "url": "/",
                "description": "Local development"
            }
        ]
    else:
        # Local environment
        openapi_schema["servers"] = [
            {
                "url": "/",
                "description": f"Local development ({environment})"
            }
        ]
    
    # Add security scheme for JWT Bearer token
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Enter your Bearer token for V2 API endpoints"
        }
    }
    
    # Add security to V2 endpoints only
    for path, path_item in openapi_schema["paths"].items():
        if path.startswith("/api/v2") and not path.endswith("/health"):
            for operation in path_item.values():
                if isinstance(operation, dict) and "operationId" in operation:
                    operation["security"] = [{"BearerAuth": []}]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema


# Set custom OpenAPI function
app.openapi = custom_openapi






if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.SERVICE_HOST,
        port=settings.SERVICE_PORT,
        reload=settings.DEBUG
    ) 
