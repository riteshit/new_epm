"""
Processing Service API
"""

from .v1 import router as v1_router 