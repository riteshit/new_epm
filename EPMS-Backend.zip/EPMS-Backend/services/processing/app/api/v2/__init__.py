"""
Processing Service API v2
"""

from .router import router