"""
Processing Service API v1
"""

from .router import router 