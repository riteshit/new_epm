from fastapi import APIRouter, Query, HTTPException, status
from pydantic import BaseModel, Field
from typing import Any, Dict, Optional, List
from datetime import datetime
import logging

from ....controller.dam_scheduling_controller import dam_scheduling_controller

router = APIRouter(
    prefix="/processing",
    tags=["DAM Scheduling"]
)

logger = logging.getLogger(__name__)


# ----------- Schema models (Swagger-friendly) -----------

class TimeBlockVolume(BaseModel):
    time_block: int = Field(..., ge=1, le=96, description="15-min block number (1..96)")
    volume: float = Field(..., description="Scheduled volume (MW) for this block")

class ScheduleRow(BaseModel):
    c_s: str = Field(..., description="Ownership: 'central' or 'state'")
    plant_id: str = Field(..., description="Plant identifier (e.g., 'KUDGI')")
    vc: Optional[float] = Field(None, description="Variable cost (VC) from plant_master, if available")
    biddable_price: Optional[float] = Field(None, description="PX/biddable price from plant_master, if available")
    data: List[TimeBlockVolume] = Field(
        ...,
        description="Always 96 entries, one per 15-min block; missing blocks filled with 0 volume"
    )

class DamSchedulePayload(BaseModel):
    schedule_date: List[ScheduleRow] = Field(
        ...,
        description="All plants for the requested date"
    )

class DamScheduleResponse(BaseModel):
    timestamp: str = Field(..., description="ISO formatted timestamp (UTC)")
    data: DamSchedulePayload = Field(..., description="DAM schedule payload")

    class Config:
        json_schema_extra = {
            "example": {
                "timestamp": "2025-08-30T09:00:00.000000",
                "data": {
                    "schedule_date": [
                        {
                            "c_s": "central",
                            "plant_id": "KUDGI",
                            "vc": 1.8,
                            "biddable_price": 1.0,
                            "data": [
                                {"time_block": 1, "volume": 8.08},
                                {"time_block": 2, "volume": 0.0},
                                {"time_block": 3, "volume": 0.0},
                                {"time_block": 96, "volume": 0.0}
                            ]
                        },
                        {
                            "c_s": "state",
                            "plant_id": "KGSU1AND2",
                            "vc": None,
                            "biddable_price": None,
                            "data": [
                                {"time_block": 1, "volume": 12.5},
                                {"time_block": 2, "volume": 0.0},
                                {"time_block": 96, "volume": 0.0}
                            ]
                        }
                    ]
                }
            }
        }

class ErrorResponse(BaseModel):
    detail: Any = Field(..., description="Human-readable error")

    class Config:
        json_schema_extra = {"example": {"detail": "Failed to fetch DAM schedule."}}


# ----------------------------- Routes -----------------------------

@router.get(
    "/dam-scheduling",
    response_model=DamScheduleResponse,
    responses={
        200: {"description": "OK", "model": DamScheduleResponse},
        422: {"description": "Validation Error", "model": ErrorResponse},
        500: {"description": "Server Error", "model": ErrorResponse},
    },
    status_code=status.HTTP_200_OK,
    summary="DAM schedule (all plants) for a date",
    description=(
        "Returns a single object with `schedule_date: [...]`, where each item is:\n\n"
        "```json\n"
        "{\n"
        "  \"c_s\": \"central|state\",\n"
        "  \"plant_id\": \"KUDGI\",\n"
        "  \"vc\": <number|null>,\n"
        "  \"biddable_price\": <number|null>,\n"
        "  \"data\": [{\"time_block\":1,\"volume\":..}, ..., {\"time_block\":96,\"volume\":..}]\n"
        "}\n"
        "```\n\n"
        "- **Time zone**: input `schedule_date` is interpreted in **IST (UTC+05:30)**.\n"
        "- **Blocks**: The `data` array always spans **1..96** blocks; missing blocks are filled with **0**."
    ),
    operation_id="getDamScheduleByDate",
    response_model_exclude_none=False,
)
async def dam_schedule_by_date(
    schedule_date: Optional[str] = Query(
        None,
        description="Schedule date in YYYY-MM-DD (IST). Defaults to today's date if omitted.",
        examples={
            "today": {"summary": "Use today's date (default in service)", "value": None},
            "custom": {"summary": "Specific date", "value": "2025-08-30"},
        },
        regex=r"^\d{4}-\d{2}-\d{2}$",
    ),
):
    """
    Build the DAM schedule view for a given date.
    """
    try:
        payload = dam_scheduling_controller.schedule_by_date(schedule_date)
        return DamScheduleResponse(
            timestamp=datetime.utcnow().isoformat(),
            data=payload,
        )
    except HTTPException as e:
        raise e
    except Exception:
        logger.exception("Error fetching DAM schedule by date")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch DAM schedule.",
        )
