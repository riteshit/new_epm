from typing import Optional, List
from fastapi import APIRouter, Query
from ....controller.realtimemarket_controller import realtimemarket_controller
from pydantic import BaseModel

router = APIRouter(prefix="/processing", tags=["Real-Time-Market"])

# Define request schema
class PlantModel(BaseModel):
    bid_plant_name: str
    bid_plant_key: str
    bid_plant_category: str
    bid_default_volume: int
    bid_volume: int
    bid_price: float
    bid_default_price: float
    rtm_forecast_Price: float
    buy_sell_bid_type: str

class BlockData(BaseModel):
    bid_date: str
    time_block: str
    start_time: str
    end_time: str
    block_no: int
    revision_no: int
    session_block: int
    current_user: str
    Ex_split_string: str
    buy_sell_bid: str
    buy_sell_bid_type: str
    selected_action_type: str
    bid_plant_name: List[PlantModel]

class RequestModel(BaseModel):
    current_user: str
    data: List[BlockData]



@router.get("/rtm-single-bid-garph")
async def get_rtm_single_bid_garph(
    schedule_date: Optional[str] = Query(
        None, description="YYYY-MM-DD; defaults to today's date in Asia/Kolkata"
    ),
    from_block: int = Query(1, description="Starting time block (default=1)"),
    to_block: int = Query(96, description="Ending time block (default=96)")
):
    """
    Returns market data by exchange for a given schedule_date.
    If no data exists, responds with:
      {"detail": "No data found for the requested schedule_date."}
    """
    return await realtimemarket_controller.rtm_single_bid_graph(schedule_date, from_block, to_block)

@router.get("/dam-single-bid-garph")
async def get_dam_single_bid_garph(
    schedule_date: Optional[str] = Query(
        None, description="YYYY-MM-DD; defaults to today's date in Asia/Kolkata"
    ),
   
):
    """
    Returns market data by exchange for a given schedule_date.
    If no data exists, responds with:
      {"detail": "No data found for the requested schedule_date."}
    """
    return await realtimemarket_controller.dam_single_bid_graph(schedule_date, from_block=1, to_block=96)


@router.get("/dam-single-bid-table")
async def get_dam_single_bid_table(
    schedule_date: Optional[str] = Query(
        None, description="YYYY-MM-DD; defaults to today's date in Asia/Kolkata"
    ),
    
):
    """
    Returns market data by exchange for a given schedule_date.
    If no data exists, responds with:
      {"detail": "No data found for the requested schedule_date."}
    """
    return await realtimemarket_controller.rtm_single_bid_table(schedule_date, from_block=1, to_block=96)


@router.get("/rtm-single-bid-table")
async def get_rtm_single_bid_table(
    schedule_date: Optional[str] = Query(
        None, description="YYYY-MM-DD; defaults to today's date in Asia/Kolkata"
    ),
    from_block: int = Query(1, description="Starting time block (default=1)"),
    to_block: int = Query(96, description="Ending time block (default=96)")
):
    """
    Returns market data by exchange for a given schedule_date.
    If no data exists, responds with:
      {"detail": "No data found for the requested schedule_date."}
    """
    return await realtimemarket_controller.rtm_single_bid_table(schedule_date, from_block, to_block)



@router.post("/submit_for_approval_post_data")
async def submit_for_approval_post_data(request: RequestModel):
    """
    Returns market data by exchange for a given schedule_date.
    If no data exists, responds with:
      {"detail": "No data found for the requested schedule_date."}
    """
    return await realtimemarket_controller.submit_for_approval_post_data(request.dict())


@router.get("/rtm-scheduling_table_calculation")
async def get_rtm_scheduling_table_calculation(
    schedule_date: Optional[str] = Query(
        None, description="YYYY-MM-DD; defaults to today's date in Asia/Kolkata"
    ),
   
):
    """
    Returns market data by exchange for a given schedule_date.
    If no data exists, responds with:
      {"detail": "No data found for the requested schedule_date."}
    """
    
    return await realtimemarket_controller.rtm_scheduling_cal_table(schedule_date)
