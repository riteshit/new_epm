"""
API Routes for Processing Service
"""

from fastapi import APIRouter

router = APIRouter()

# Import route modules here
# Menu functionality moved to auth service

# Include route modules
# All menu endpoints now handled by auth service

# Root endpoint removed - not required 