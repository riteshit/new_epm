"""
Authentication controller using repository pattern
"""

import logging
from typing import Dict, Any, Optional
from fastapi import HTTPException, status, Request
from services.auth.app.services.auth_service import auth_service
from services.auth.app.schemas.auth import LoginRequest, RefreshTokenRequest, ChangePasswordRequest
from services.auth.app.core.dto import AuthUserDTO
from datetime import datetime
import sys
import os

# Add project root to path for audit queue import
project_root = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..')
if project_root not in sys.path:
    sys.path.append(project_root)

from libs.audit_queue.simple_logger import audit_logger

logger = logging.getLogger(__name__)


class AuthController:
    """Authentication controller using repository pattern"""
    
    def __init__(self):
        self.auth_service = auth_service
    
    def _extract_request_info(self, request: Request) -> Dict[str, Any]:
        """Extract request information for audit logging"""
        return {
            "ip_address": request.client.host if request.client else None,
            "user_agent": request.headers.get("user-agent"),
            "method": request.method,
            "path": request.url.path,
            "timestamp": request.headers.get("x-request-timestamp")
        }
    
    async def login(self, login_data: LoginRequest, request: Request) -> Dict[str, Any]:
        """
        Handle user login
        
        Args:
            login_data: Login credentials
            request: FastAPI request object
            
        Returns:
            Login response with tokens
        """
        try:
            # Extract request info for audit
            request_info = self._extract_request_info(request)
            
            # Attempt login
            result = await self.auth_service.login(
                username=login_data.username,
                password=login_data.password,
                request_info=request_info
            )
            
            if not result:
                # Log failed login attempt with PII protection
                audit_logger.log_security_event(
                    service="auth",
                    event_type="login_failed",
                    message=f"Failed login attempt for user",
                    user_id=login_data.username,  # Will be sanitized
                    client_ip=request_info.get("ip_address"),  # Will be masked
                    success=False,
                    username=login_data.username,  # Will be sanitized
                    user_agent=request_info.get("user_agent"),
                    failure_reason="Invalid credentials",
                    login_method="password"
                )
                
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid username or password"
                )
            
            # Check if this is a temporary token response (MFA enabled user)
            if "temporary_token" in result:
                # MFA required logging handled at route layer to avoid duplication
                return result
            else:
                # Log successful login without MFA
                session_id = result.get("tokens", {}).get("access_token") and self._extract_session_id(result["tokens"]["access_token"])
                
                audit_logger.log_security_event(
                    service="auth",
                    event_type="login_success",
                    message="User authentication successful",
                    user_id=result.get("user", {}).get("id") or login_data.username,
                    client_ip=request_info.get("ip_address"),  # Will be masked
                    success=True,
                    username=login_data.username,  # Will be sanitized
                    user_email=result.get("user", {}).get("email"),  # Will be sanitized
                    user_agent=request_info.get("user_agent"),
                    login_method="password",
                    mfa_used=False,
                    session_id=session_id,
                    user_roles=result.get("user", {}).get("roles", []),
                    request_id=request_info.get("timestamp")
                )
                return result
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error("Login controller error: %s", e)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )
    
    def _extract_session_id(self, token: str) -> Optional[str]:
        """Extract session ID from JWT token"""
        try:
            from services.auth.app.services.jwt_service import jwt_service
            return jwt_service.get_session_id(token)
        except Exception:
            return None
    
    async def verify_login(self, verify_data: "VerifyLoginRequest", request: Request) -> Dict[str, Any]:
        """
        Verify login with temporary token and optional TOTP code
        
        Args:
            verify_data: Verify login request data
            request: FastAPI request object
            
        Returns:
            Login response with tokens
        """
        try:
            # Extract request info for audit
            request_info = self._extract_request_info(request)
            
            # Attempt verify login
            result = await self.auth_service.verify_login(
                temporary_token=verify_data.temporary_token,
                totp_code=verify_data.totp_code,
                request_info=request_info
            )
            
            if not result:
                # Log failed MFA verification
                audit_logger.log_security_event(
                    service="auth",
                    event_type="mfa_verification_failed",
                    message="MFA verification failed",
                    client_ip=request_info.get("ip_address"),
                    success=False,
                    user_agent=request_info.get("user_agent"),
                    failure_reason="Invalid temporary token or TOTP code",
                    login_method="password+mfa"
                )
                
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid temporary token or TOTP code"
                )
            
            # MFA login success logging handled at route layer to avoid duplication
            
            return result
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error("Verify login controller error: %s", e)
            
            # Log system error
            audit_logger.log_error_event(
                service="auth",
                error_name="VerifyLoginError",
                error_message="System error during MFA verification",
                client_ip=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                operation="verify_login"
            )
            
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )
    
    async def refresh_token(self, refresh_data: RefreshTokenRequest, request: Request) -> Dict[str, Any]:
        """
        Handle token refresh
        
        Args:
            refresh_data: Refresh token data
            request: FastAPI request object
            
        Returns:
            New access token
        """
        try:
            # Extract request info for audit
            request_info = self._extract_request_info(request)
            
            # Attempt token refresh
            result = await self.auth_service.refresh_token(
                refresh_token=refresh_data.refresh_token,
                request_info=request_info
            )
            
            if not result:
                # Log failed token refresh
                audit_logger.log_security_event(
                    service="auth",
                    event_type="token_refresh_failed",
                    message="Token refresh failed",
                    client_ip=request_info.get("ip_address"),
                    success=False,
                    user_agent=request_info.get("user_agent"),
                    failure_reason="Invalid or expired refresh token"
                )
                
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid or expired refresh token"
                )
            
            return result
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Token refresh controller error: {e}")
            
            # Log system error
            audit_logger.log_error_event(
                service="auth",
                error_name="TokenRefreshError",
                error_message="System error during token refresh",
                client_ip=request_info.get("ip_address"),
                user_agent=request_info.get("user_agent"),
                operation="token_refresh"
            )
            
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )
    
    async def logout(self, access_token: str, refresh_token: Optional[str], request: Request) -> Dict[str, Any]:
        """
        Handle user logout
        
        Args:
            access_token: JWT access token
            refresh_token: JWT refresh token (optional)
            request: FastAPI request object
            
        Returns:
            Logout confirmation
        """
        try:
            # Extract request info for audit
            request_info = self._extract_request_info(request)
            
            # Attempt logout
            success = await self.auth_service.logout(
                access_token=access_token,
                refresh_token=refresh_token,
                request_info=request_info
            )
            
            if not success:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid token"
                )
            
            return {"message": "Logged out successfully"}
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Logout controller error: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )
    
    async def get_current_user(self, token: str) -> Optional[AuthUserDTO]:
        """
        Get current user from token
        
        Args:
            token: JWT access token
            
        Returns:
            Current user information
        """
        try:
            user = await self.auth_service.get_current_user(token)
            
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid or expired token"
                )
            
            return user
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Get current user controller error: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )
    
    async def change_password(self, user_id: str, password_data: ChangePasswordRequest, request: Request) -> Dict[str, Any]:
        """
        Handle password change
        
        Args:
            token: JWT access token
            user_id: User ID
            password_data: Password change data
            request: FastAPI request object
            
        Returns:
            Password change confirmation
        """
        try:
            # Extract request info for audit
            request_info = self._extract_request_info(request)
            
            # Attempt password change
            success = await self.auth_service.change_password(
                user_id=user_id,
                current_password=password_data.current_password,
                new_password=password_data.new_password,
                request_info=request_info
            )
            
            if not success:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid current password or password requirements not met"
                )
            
            return {"message": "Password changed successfully"}
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Change password controller error: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )


# Global instance
auth_controller = AuthController() 