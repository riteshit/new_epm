"""
Role-Based Access Control (RBAC) utilities for Auth Service
Unified Menu-Endpoint Permission System
"""

from typing import List, Optional
from fastapi import HTTPException, Depends, Header
from ..services.auth_service import auth_service
from ..repository.menu_repository import MenuRepository
from ..repository.menu_role_repository import MenuRoleRepository
from ..repository.role_repository import RoleRepository
from ..core.logger import get_auth_logger

logger = get_auth_logger(__name__)

# Initialize repositories
menu_repository = MenuRepository()
menu_role_repository = MenuRoleRepository()
role_repository = RoleRepository()

def _current_user_dependency():
    """FastAPI dependency that always calls the *current* auth_service.get_current_user."""
    async def _dep(authorization: Optional[str] = Header(default=None, alias="Authorization")):
        # Extract token from "Bearer <token>" format
        if not authorization:
            raise HTTPException(
                status_code=401,
                detail="Authorization header required"
            )
        
        # Handle both "Bearer <token>" and raw token formats
        if authorization.startswith("Bearer "):
            token = authorization[7:]  # Remove "Bearer " prefix
        else:
            token = authorization
        
        user = await auth_service.get_current_user(token)
        if not user:
            raise HTTPException(
                status_code=401,
                detail="Invalid or expired token"
            )
        
        return user

    return Depends(_dep)

def require_permissions(*permissions: str):
    """Dependency to require specific permissions (menu-based)"""
    async def checker(user=_current_user_dependency()):  # type: ignore[valid-type]
        # Super-admin shortcut
        user_permissions = getattr(user, "permissions", []) or []
        if "*" in user_permissions:
            return user

        missing = [perm for perm in permissions if perm not in user_permissions]
        if missing:
            raise HTTPException(
                status_code=403,
                detail=f"Missing permissions: {', '.join(missing)}"
            )
        return user

    return checker

def require_roles(*roles: str):
    """Dependency to require specific roles"""
    async def checker(user=_current_user_dependency()):  # type: ignore[valid-type]
        user_roles = getattr(user, "roles", []) or []
        if not any(role in user_roles for role in roles):
            raise HTTPException(status_code=403, detail=f"Missing role: {roles}")
        return user

    return checker

def require_menu_access(menu_name: str, permission: str = "read"):
    """
    Unified dependency to require access to a menu and its corresponding endpoints
    
    Args:
        menu_name: Name of the menu (e.g., "Users", "Dashboard")
        permission: Required permission (default: "read")
        
    Returns:
        Dependency function that checks menu and endpoint access
    """
    async def checker(user=_current_user_dependency()):  # type: ignore[valid-type]
        # Super-admin shortcut
        user_permissions = getattr(user, "permissions", []) or []
        if "*" in user_permissions:
            return user
            
        # Check if user has the required permission on this menu
        if has_menu_permission(user, menu_name, permission):
            return user
        
        raise HTTPException(
            status_code=403,
            detail=f"Access denied to menu: {menu_name}. Required permission: {permission}"
        )
    
    return checker

def require_any_menu_access(*menu_names: str, permission: str = "read"):
    """
    Dependency to require access to any of the specified menus
    
    Args:
        menu_names: List of menu names
        permission: Required permission (default: "read")
        
    Returns:
        Dependency function that checks menu access
    """
    async def checker(user=_current_user_dependency()):  # type: ignore[valid-type]
        # Super-admin shortcut
        user_permissions = getattr(user, "permissions", []) or []
        if "*" in user_permissions:
            return user
            
        # Check if user has access to any of the required menus
        for menu_name in menu_names:
            if has_menu_permission(user, menu_name, permission):
                return user
                
        raise HTTPException(
            status_code=403,
            detail=f"Access denied. Required {permission} access to any of: {', '.join(menu_names)}"
        )
    
    return checker

def has_menu_permission(user, menu_name: str, permission: str = "read") -> bool:
    """
    Check if user has permission on a specific menu
    
    Args:
        user: User object with roles and permissions
        menu_name: Name of the menu
        permission: Required permission
        
    Returns:
        True if user has the permission, False otherwise
    """
    try:
        # Handle None user
        if user is None:
            return False
            
        # Super-admin has all permissions
        user_permissions = getattr(user, "permissions", []) or []
        if "*" in user_permissions:
            return True
            
        # Check if user has the specific permission
        permission_string = f"{menu_name.lower().replace(' ', '_')}:{permission}"
        if permission_string in user_permissions:
            return True
            
        # Check if user has any role with this menu permission
        user_roles = getattr(user, "roles", []) or []
        if not user_roles:  # Handle empty or None roles
            return False
            
        for role_name in user_roles:
            role = role_repository.get_role_by_name(role_name)
            if role:
                # Check if role has this menu permission
                role_permissions = getattr(role, "permissions", []) or []
                if permission_string in role_permissions:
                    return True
                    
                # Check menu-role assignments directly
                menu = menu_repository.get_menu_by_name(menu_name)
                if menu:
                    menu_role = menu_role_repository.get_menu_role(menu.id, role.id)
                    if menu_role:
                        menu_role_permissions = getattr(menu_role, "permissions", []) or []
                        if permission in menu_role_permissions:
                            return True
        
        return False
        
    except Exception as e:
        logger.error(f"Error checking menu permission: {e}")
        return False

def get_user_accessible_menus(user_roles: List[str]) -> List[str]:
    """
    Get list of menus that a user can access based on their roles
    
    Args:
        user_roles: List of user roles
        
    Returns:
        List of accessible menu names
    """
    try:
        accessible_menus = set()
        
        for role_name in user_roles:
            role = role_repository.get_role_by_name(role_name)
            if role:
                # Get menus assigned to this role
                role_menus = menu_role_repository.get_menus_for_role(role.id)
                for menu_id in role_menus:
                    menu = menu_repository.get_menu_by_id(menu_id)
                    if menu:
                        accessible_menus.add(menu.name)
        
        return list(accessible_menus)
        
    except Exception as e:
        logger.error(f"Error getting user accessible menus: {e}")
        return []

def get_user_menu_permissions(user_roles: List[str], menu_name: str) -> List[str]:
    """
    Get all permissions a user has on a specific menu
    
    Args:
        user_roles: List of user roles
        menu_name: Name of the menu
        
    Returns:
        List of permissions the user has on the menu
    """
    try:
        all_permissions = set()
        
        for role_name in user_roles:
            role = role_repository.get_role_by_name(role_name)
            if role:
                # Check role permissions
                permission_prefix = f"{menu_name.lower().replace(' ', '_')}:"
                role_permissions = getattr(role, "permissions", []) or []
                for permission in role_permissions:
                    if permission.startswith(permission_prefix):
                        perm_name = permission.split(":", 1)[1]
                        all_permissions.add(perm_name)
                
                # Check menu-role assignments directly
                menu = menu_repository.get_menu_by_name(menu_name)
                if menu:
                    menu_role = menu_role_repository.get_menu_role(menu.id, role.id)
                    if menu_role:
                        menu_role_permissions = getattr(menu_role, "permissions", []) or []
                        all_permissions.update(menu_role_permissions)
        
        return list(all_permissions)
        
    except Exception as e:
        logger.error(f"Error getting user menu permissions: {e}")
        return []

def validate_menu_access(user_roles: List[str], menu_name: str, permission: str = "read") -> bool:
    """
    Validate if user has access to a specific menu
    
    Args:
        user_roles: List of user roles
        menu_name: Name of the menu
        permission: Required permission (default: "read")
        
    Returns:
        True if user has access, False otherwise
    """
    # Create a mock user object for the has_menu_permission function
    class MockUser:
        def __init__(self, roles):
            self.roles = roles
            self.permissions = []
    
    mock_user = MockUser(user_roles)
    return has_menu_permission(mock_user, menu_name, permission)

# Legacy compatibility functions (deprecated but kept for backward compatibility)
def require_page_access_simple(page_name: str):
    """Legacy function - use require_menu_access instead"""
    return require_menu_access(page_name, "read")

def require_page_access(page_name: str, permissions: Optional[List[str]] = None):
    """Legacy function - use require_menu_access instead"""
    if permissions is None:
        permissions = ["read"]
    # For backward compatibility, check if user has any of the required permissions
    async def checker(user=_current_user_dependency()):  # type: ignore[valid-type]
        for permission in permissions:
            if has_menu_permission(user, page_name, permission):
                return user
        raise HTTPException(
            status_code=403,
            detail=f"Access denied to page: {page_name}. Required permissions: {', '.join(permissions)}"
        )
    return checker

def has_page_access(user_roles: List[str], page_name: str) -> bool:
    """Legacy function - use validate_menu_access instead"""
    return validate_menu_access(user_roles, page_name, "read")

def get_user_accessible_pages(user_roles: List[str]) -> List[str]:
    """Legacy function - use get_user_accessible_menus instead"""
    return get_user_accessible_menus(user_roles)

def get_user_page_permissions(user_roles: List[str], page_name: str) -> List[str]:
    """Legacy function - use get_user_menu_permissions instead"""
    return get_user_menu_permissions(user_roles, page_name)
