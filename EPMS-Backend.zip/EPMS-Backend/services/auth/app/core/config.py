"""
Configuration settings for Auth Service
"""

from typing import List
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings"""
    
    # Service Configuration
    SERVICE_NAME: str = "auth-service"
    SERVICE_PORT: int = 8001
    SERVICE_HOST: str = "0.0.0.0"
    HOST: str = "0.0.0.0"  # Alias for SERVICE_HOST
    PORT: str = "8001"  # Alias for SERVICE_PORT
    DEBUG: bool = True
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "colored"
    
    # Database Configuration
    MONGODB_URI: str = "mongodb://localhost:27017"
    MONGODB_URL: str = "mongodb://localhost:27017"  # Alias for MONGODB_URI
    AUTH_DB_NAME: str = "auth_db"
    AUDIT_DB_NAME: str = "audit_db"
    MONGODB_AUTH_COLLECTION: str = "users"
    MONGODB_SESSIONS_COLLECTION: str = "sessions"
    MONGODB_AUDIT_COLLECTION: str = "audit_logs"
    MONGODB_ROLE_COLLECTION: str = "roles"
    MONGODB_PERMISSION_COLLECTION: str = "permissions"
    
    
    # Redis Configuration
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: str = ""
    REDIS_URL: str = "redis://localhost:6379/0"  # Alias for Redis connection
    
    # Redis Blacklist Configuration
    REDIS_BLACKLIST_ENABLED: bool = True
    REDIS_BLACKLIST_DB: int = 1
    REDIS_BLACKLIST_TTL: int = 7  # Days (same as refresh token expiry)
    
    # JWT Configuration
    JWT_SECRET_KEY: str = "your-super-secret-jwt-key-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    ACCESS_TOKEN_EXPIRE_MINUTES: str = "30"  # Alias for JWT_ACCESS_TOKEN_EXPIRE_MINUTES
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # Security Configuration
    SECRET_KEY: str = "your-super-secret-key-change-in-production"
    BCRYPT_ROUNDS: int = 12
    PASSWORD_MIN_LENGTH: int = 8
    PASSWORD_MAX_LENGTH: int = 128
    
    # Password Policy Configuration
    MIN_PASSWORD_LENGTH: int = 8
    REQUIRE_UPPERCASE: bool = True
    REQUIRE_LOWERCASE: bool = True
    REQUIRE_NUMBERS: bool = True
    REQUIRE_SPECIAL_CHARS: bool = True
    PASSWORD_EXPIRY_DAYS: int = 90
    PASSWORD_HISTORY_COUNT: int = 5
    FIRST_LOGIN_PASSWORD_EXPIRY_HOURS: int = 24
    
    # Account Lockout Configuration
    MAX_LOGIN_ATTEMPTS: int = 5
    LOCKOUT_DURATION_MINUTES: int = 20
    LOCKOUT_WINDOW_HOURS: int = 24
    
    # Rate Limiting
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_WINDOW_SECONDS: int = 3600
    
    # MFA Configuration
    MFA_ENABLED: bool = True
    MFA_ISSUER: str = "EPMS"  # Can be overridden by APP_NAME env var
    MFA_ALGORITHM: str = "SHA1"
    MFA_DIGITS: int = 6
    MFA_PERIOD: int = 30
    MFA_WINDOW: int = 1  # Time window buffer for TOTP validation (±30 seconds)
    
    # App Configuration
    APP_NAME: str = "EPMS"  # Used as default MFA issuer name
    
    # Session Configuration
    SESSION_TIMEOUT_HOURS: int = 24
    MAX_SESSIONS_PER_USER: int = 5
    
    # CORS Configuration
    CORS_ORIGINS: List[str] = [
        "*",  # Allow all origins for development
        "http://localhost:3000", 
        "http://localhost:8080",
        "http://localhost:8002",  # Scheduler service (dashboard)
        "http://localhost:8003",  # Processing service
        "http://localhost:8004",  # Ingestion service
        "http://127.0.0.1:8002",  # Alternative localhost
        "http://127.0.0.1:8003",
        "http://127.0.0.1:8004",
        "https://api-dev.infiscopelabs.com"  # Production domain
    ]
    CORS_ALLOW_CREDENTIALS: bool = True
    
    # Health Check
    HEALTH_CHECK_ENABLED: bool = True
    HEALTH_CHECK_INTERVAL_SECONDS: int = 30
    
    # Default Admin Configuration
    ADMIN_USERNAME: str = "admin"
    ADMIN_EMAIL: str = "admin@epms.com"
    ADMIN_INITIAL_PASSWORD: str = "Infi@7983"
    
    class Config:
        env_file = ".env"
        case_sensitive = True
        extra = "ignore"  # Ignore extra fields from environment
        json_schema_extra = {
            "example": {
                "SERVICE_NAME": "auth-service",
                "SERVICE_PORT": 8001,
                "JWT_SECRET_KEY": "your-super-secret-jwt-key-change-in-production",
                "MONGODB_URI": "mongodb://localhost:27017",
                "ADMIN_USERNAME": "admin",
                "ADMIN_EMAIL": "admin@epms.com",
                "ADMIN_INITIAL_PASSWORD": "Admin@123"
            }
        }


# Create settings instance
settings = Settings() 
