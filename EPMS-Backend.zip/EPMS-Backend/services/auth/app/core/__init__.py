"""
Core configuration and settings for the auth service
""" 