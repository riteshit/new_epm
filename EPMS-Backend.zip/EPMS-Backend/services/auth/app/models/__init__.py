"""
Models module for Auth Service
"""

from .user import User, user_model

__all__ = ["User", "user_model"] 