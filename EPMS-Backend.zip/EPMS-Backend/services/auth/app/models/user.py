"""
User model for authentication service
"""

from datetime import datetime, timedelta
from typing import Optional, List
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database
from bson import ObjectId
import bcrypt
from ..core.config import settings
from ..core.dto import UserDTO, AuthUserDTO
from ..services.redis_blacklist import redis_blacklist_service
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
from libs.audit_queue.simple_logger import audit_logger
import logging

logger = logging.getLogger(__name__)


class User:
    """User model for authentication"""
    
    def __init__(self):
        self.client: MongoClient = MongoClient(settings.MONGODB_URI)
        self.db: Database = self.client[settings.AUTH_DB_NAME]
        self.collection: Collection = self.db[settings.MONGODB_AUTH_COLLECTION]
    
    def create_user(self, username: str, email: str, password: str, **kwargs) -> UserDTO:
        """Create a new user (case-insensitive username)"""
        # Check if user already exists (case-insensitive)
        if self.get_user_by_username(username):
            raise ValueError("Username already exists")
        
        if self.get_user_by_email(email):
            raise ValueError("Email already exists")
        
        # Hash password
        salt = bcrypt.gensalt(rounds=settings.BCRYPT_ROUNDS)
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
        
        # Create user document
        user_data = {
            "username": username,
            "email": email,
            "password_hash": hashed_password,
            "is_active": True,
            "is_verified": False,
            "is_deleted": False,  # Hidden field for soft delete
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "last_login": None,
            "login_attempts": 0,
            "locked_until": None,
            "password_changed_at": datetime.utcnow(),
            "password_expires_at": datetime.utcnow() + timedelta(days=settings.PASSWORD_EXPIRY_DAYS),
            "password_history": [],
            "roles": kwargs.get("roles", ["user"]),
            "permissions": kwargs.get("permissions", []),
            "profile": kwargs.get("profile", {}),
            "mfa_enabled": kwargs.get("mfa_enabled", False),
            "mfa_secret": kwargs.get("mfa_secret"),
            "mfa_backup_codes": kwargs.get("mfa_backup_codes", []),
            "mfa_setup_complete": kwargs.get("mfa_setup_complete", False),
            "sessions": []
        }
        
        result = self.collection.insert_one(user_data)
        user_data["_id"] = result.inserted_id
        
        # Log user creation
        audit_logger.log_user_action(
            service="auth",
            user_id=str(result.inserted_id),
            action="user_created",
            message=f"User created: {username}",
            username=username,
            email=email,
            roles=kwargs.get("roles", ["user"]),
            mfa_enabled=kwargs.get("mfa_enabled", False)
        )
        
        return UserDTO.from_db_document(user_data)
    
    def get_user_by_id(self, user_id: str) -> Optional[UserDTO]:
        """Get user by ID"""
        try:
            # Exclude deleted users
            user_doc = self.collection.find_one({
                "_id": ObjectId(user_id),
                "is_deleted": {"$ne": True}
            })
            return UserDTO.from_db_document(user_doc) if user_doc else None
        except:
            return None
    
    def get_user_by_username(self, username: str) -> Optional[UserDTO]:
        """Get user by username (case-insensitive)"""
        # Username is case-insensitive, so we use case-insensitive match
        # Exclude deleted users
        user_doc = self.collection.find_one({
            "username": {"$regex": f"^{username}$", "$options": "i"},
            "is_deleted": {"$ne": True}
        })
        return UserDTO.from_db_document(user_doc) if user_doc else None
    
    def get_user_by_email(self, email: str) -> Optional[UserDTO]:
        """Get user by email"""
        # Exclude deleted users
        user_doc = self.collection.find_one({
            "email": email,
            "is_deleted": {"$ne": True}
        })
        return UserDTO.from_db_document(user_doc) if user_doc else None
    
    def authenticate_user(self, username: str, password: str) -> Optional[AuthUserDTO]:
        """Authenticate user with username/email and password"""
        # Try to find user by username or email
        user = self.get_user_by_username(username)
        if not user:
            user = self.get_user_by_email(username)
        
        if not user:
            return None
        
        # Check if account is locked
        if user.locked_until and user.locked_until > datetime.utcnow():
            raise ValueError("Account is locked")
        
        # Check if account is active
        if not user.is_active:
            raise ValueError("Account is deactivated")
        
        # Get raw document for password verification
        user_doc = self.collection.find_one({"_id": ObjectId(user.id)})
        if not user_doc:
            return None
        
        # Verify password
        if not bcrypt.checkpw(password.encode('utf-8'), user_doc["password_hash"]):
            # Increment login attempts
            self._increment_login_attempts(ObjectId(user.id))
            
            # Failed login logging handled at route layer to avoid duplication
            return None
        
        # Reset login attempts on successful login
        self._reset_login_attempts(ObjectId(user.id))
        
        # Update last login
        self.collection.update_one(
            {"_id": ObjectId(user.id)},
            {"$set": {"last_login": datetime.utcnow()}}
        )
        
        # Update the user DTO with new last_login
        user.last_login = datetime.utcnow()
        
        # Login success logging handled at route layer to avoid duplication
        
        return AuthUserDTO.from_user_dto(user)
    
    def _increment_login_attempts(self, user_id: ObjectId):
        """Increment failed login attempts"""
        user = self.collection.find_one({"_id": user_id})
        if not user:
            return
        current_attempts = user.get("login_attempts", 0) + 1
        
        update_data = {"login_attempts": current_attempts}
        
        # Lock account if max attempts reached
        if current_attempts >= settings.MAX_LOGIN_ATTEMPTS:
            lockout_until = datetime.utcnow() + timedelta(minutes=settings.LOCKOUT_DURATION_MINUTES)
            update_data["locked_until"] = lockout_until
        
        self.collection.update_one(
            {"_id": user_id},
            {"$set": update_data}
        )
    
    def _reset_login_attempts(self, user_id: ObjectId):
        """Reset login attempts on successful login"""
        self.collection.update_one(
            {"_id": user_id},
            {"$set": {
                "login_attempts": 0,
                "locked_until": None
            }}
        )
    
    def update_user(self, user_id: str, update_data: dict) -> bool:
        """Update user data"""
        try:
            update_data["updated_at"] = datetime.utcnow()
            result = self.collection.update_one(
                {"_id": ObjectId(user_id)},
                {"$set": update_data}
            )
            
            if result.modified_count > 0:
                # Log user update
                audit_logger.log_user_action(
                    service="auth",
                    user_id=user_id,
                    action="user_updated",
                    message=f"User updated: {user_id}",
                    updated_fields=list(update_data.keys())
                )
                return True
            return False
        except Exception as e:
            # Log failed update
            audit_logger.log_user_action(
                service="auth",
                user_id=user_id,
                action="user_update_failed",
                message=f"User update failed: {str(e)}",
                success=False,
                updated_fields=list(update_data.keys()),
                exception_type=type(e).__name__
            )
            return False
    
    def delete_user(self, user_id: str) -> bool:
        """Mark user as deleted (soft delete)"""
        try:
            result = self.collection.update_one(
                {"_id": ObjectId(user_id)},
                {
                    "$set": {
                        "is_deleted": True,
                        "deleted_at": datetime.utcnow(),
                        "updated_at": datetime.utcnow()
                    }
                }
            )
            
            if result.modified_count > 0:
                # Log user deletion
                audit_logger.log_user_action(
                    service="auth",
                    user_id=user_id,
                    action="user_deleted",
                    message=f"User deleted: {user_id}",
                    deletion_type="soft_delete"
                )
                return True
            return False
        except Exception as e:
            logger.error(f"Error marking user as deleted: {e}")
            return False
    
    def add_session(self, user_id: str, session_data: dict) -> bool:
        """Add session to user (for audit purposes only)"""
        try:
            self.collection.update_one(
                {"_id": ObjectId(user_id)},
                {"$push": {"sessions": session_data}}
            )
            return True
        except:
            return False
    
    def remove_session(self, user_id: str, session_id: str) -> bool:
        """Remove session from user (for audit purposes only)"""
        try:
            self.collection.update_one(
                {"_id": ObjectId(user_id)},
                {"$pull": {"sessions": {"session_id": session_id}}}
            )
            return True
        except:
            return False
    
    def invalidate_refresh_token(self, user_id: str, refresh_token: str) -> bool:
        """Add refresh token to blacklist (hybrid approach: Redis + Database)"""
        try:
            # Try Redis first (fast)
            redis_success = redis_blacklist_service.invalidate_refresh_token(refresh_token, user_id)
            
            # Always store in database for audit (persistent)
            blacklist_collection = self.db["refresh_token_blacklist"]
            db_success = blacklist_collection.insert_one({
                "refresh_token": refresh_token,
                "user_id": user_id,
                "invalidated_at": datetime.utcnow(),
                "expires_at": datetime.utcnow() + timedelta(days=settings.JWT_REFRESH_TOKEN_EXPIRE_DAYS),
                "redis_success": redis_success
            })
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to invalidate refresh token: {e}")
            return False
    
    def is_refresh_token_blacklisted(self, refresh_token: str) -> bool:
        """Check if refresh token is blacklisted (hybrid approach: Redis first, then Database)"""
        try:
            # Check Redis first (fast)
            if redis_blacklist_service.is_refresh_token_blacklisted(refresh_token):
                return True
            
            # Fallback to database (slower but persistent)
            blacklist_collection = self.db["refresh_token_blacklist"]
            return blacklist_collection.find_one({"refresh_token": refresh_token}) is not None
            
        except Exception as e:
            logger.error(f"Failed to check blacklist: {e}")
            return False
    
    def close(self):
        """Close database connection"""
        self.client.close()


# Create global user model instance
user_model = User() 