"""
Menu-Role repository for managing menu-role relationships in the database
"""

from typing import Optional, List
from datetime import datetime
from bson import ObjectId
import logging
from .base_repository import BaseRepository
from ..models.menu_role import MenuRoleInDB, MenuRoleCreate, MenuRoleUpdate
from ..core.config import settings

logger = logging.getLogger(__name__)


class MenuRoleRepository(BaseRepository):
    """Menu-Role repository with relationship-specific database operations"""
    
    def __init__(self):
        super().__init__("menu_roles", settings.AUTH_DB_NAME)
    
    def create_menu_role(self, menu_role_data: MenuRoleCreate) -> MenuRoleInDB:
        """Create a new menu-role relationship"""
        try:
            # Check if relationship already exists
            existing = self.find_one({
                "menu_id": menu_role_data.menu_id,
                "role_id": menu_role_data.role_id,
                "is_active": True
            })
            
            if existing:
                raise ValueError("Menu-role relationship already exists")
            
            # Create menu-role document
            menu_role_doc = {
                "menu_id": menu_role_data.menu_id,
                "role_id": menu_role_data.role_id,
                "permissions": menu_role_data.permissions,
                "is_active": True,
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            
            menu_role_id = self.create(menu_role_doc)
            menu_role_doc["_id"] = str(menu_role_id)
            
            return MenuRoleInDB(**menu_role_doc)
        except Exception as e:
            logger.error(f"Error creating menu-role relationship: {e}")
            raise
    
    def get_menu_role_by_id(self, menu_role_id: str) -> Optional[MenuRoleInDB]:
        """Get menu-role relationship by ID"""
        try:
            menu_role_doc = self.find_one({
                "_id": ObjectId(menu_role_id),
                "is_active": True
            })
            if menu_role_doc:
                menu_role_doc["_id"] = str(menu_role_doc["_id"])
                return MenuRoleInDB(**menu_role_doc)
            return None
        except Exception as e:
            logger.error(f"Error getting menu-role by ID {menu_role_id}: {e}")
            return None
    
    def get_menu_roles_by_menu_id(self, menu_id: str) -> List[MenuRoleInDB]:
        """Get all role relationships for a specific menu"""
        try:
            menu_role_docs = self.find_many({
                "menu_id": menu_id,
                "is_active": True
            })
            for doc in menu_role_docs:
                doc["_id"] = str(doc["_id"])
            return [MenuRoleInDB(**doc) for doc in menu_role_docs]
        except Exception as e:
            logger.error(f"Error getting menu roles for menu {menu_id}: {e}")
            return []
    
    def get_menu_roles_by_role_id(self, role_id: str) -> List[MenuRoleInDB]:
        """Get all menu relationships for a specific role"""
        try:
            menu_role_docs = self.find_many({
                "role_id": role_id,
                "is_active": True
            })
            for doc in menu_role_docs:
                doc["_id"] = str(doc["_id"])
            return [MenuRoleInDB(**doc) for doc in menu_role_docs]
        except Exception as e:
            logger.error(f"Error getting role menus for role {role_id}: {e}")
            return []
    
    def get_menu_role(self, menu_id: str, role_id: str) -> Optional[MenuRoleInDB]:
        """Get specific menu-role relationship"""
        try:
            menu_role_doc = self.find_one({
                "menu_id": menu_id,
                "role_id": role_id,
                "is_active": True
            })
            if menu_role_doc:
                menu_role_doc["_id"] = str(menu_role_doc["_id"])
                return MenuRoleInDB(**menu_role_doc)
            return None
        except Exception as e:
            logger.error(f"Error getting menu-role relationship: {e}")
            return None
    
    def update_menu_role(self, menu_role_id: str, update_data: MenuRoleUpdate) -> bool:
        """Update menu-role relationship"""
        try:
            update_dict = update_data.dict(exclude_unset=True)
            update_dict["updated_at"] = datetime.utcnow()
            
            return self.update(menu_role_id, update_dict)
        except Exception as e:
            logger.error(f"Error updating menu-role {menu_role_id}: {e}")
            return False
    
    def delete_menu_role(self, menu_role_id: str) -> bool:
        """Soft delete menu-role relationship"""
        try:
            return self.update(menu_role_id, {
                "is_active": False,
                "updated_at": datetime.utcnow()
            })
        except Exception as e:
            logger.error(f"Error deleting menu-role {menu_role_id}: {e}")
            return False
    
    def delete_menu_role_by_ids(self, menu_id: str, role_id: str) -> bool:
        """Delete menu-role relationship by menu and role IDs"""
        try:
            menu_role = self.get_menu_role(menu_id, role_id)
            if menu_role:
                return self.delete_menu_role(menu_role.id)
            return False
        except Exception as e:
            logger.error(f"Error deleting menu-role by IDs: {e}")
            return False
    
    def get_roles_for_menu(self, menu_id: str) -> List[str]:
        """Get all role IDs that have access to a specific menu"""
        try:
            menu_roles = self.get_menu_roles_by_menu_id(menu_id)
            return [mr.role_id for mr in menu_roles]
        except Exception as e:
            logger.error(f"Error getting roles for menu {menu_id}: {e}")
            return []
    
    def get_menus_for_role(self, role_id: str) -> List[str]:
        """Get all menu IDs that a specific role has access to"""
        try:
            role_menus = self.get_menu_roles_by_role_id(role_id)
            return [rm.menu_id for rm in role_menus]
        except Exception as e:
            logger.error(f"Error getting menus for role {role_id}: {e}")
            return []
    
    def grant_role_menu_access(self, role_id: str, menu_id: str, permissions: List[str] = None) -> bool:
        """Grant a role access to a menu and sync role permissions"""
        try:
            if permissions is None:
                permissions = ["read"]
            
            # Check if relationship already exists
            existing = self.get_menu_role(menu_id, role_id)
            if existing:
                # Update existing relationship
                success = self.update_menu_role(existing.id, MenuRoleUpdate(permissions=permissions))
            else:
                # Create new relationship
                menu_role_data = MenuRoleCreate(
                    menu_id=menu_id,
                    role_id=role_id,
                    permissions=permissions
                )
                self.create_menu_role(menu_role_data)
                success = True
            
            # Sync role permissions after menu assignment change
            if success:
                self._sync_role_permissions(role_id)
            
            return success
        except Exception as e:
            logger.error(f"Error granting role menu access: {e}")
            return False
    
    def revoke_role_menu_access(self, role_id: str, menu_id: str) -> bool:
        """Revoke a role's access to a menu and sync role permissions"""
        try:
            success = self.delete_menu_role_by_ids(menu_id, role_id)
            
            # Sync role permissions after menu removal
            if success:
                self._sync_role_permissions(role_id)
            
            return success
        except Exception as e:
            logger.error(f"Error revoking role menu access: {e}")
            return False
    
    def get_user_accessible_menus(self, user_roles: List[str]) -> List[str]:
        """Get all menu IDs accessible to a user based on their roles"""
        try:
            accessible_menus = set()
            for role in user_roles:
                role_menus = self.get_menus_for_role(role)
                accessible_menus.update(role_menus)
            return list(accessible_menus)
        except Exception as e:
            logger.error(f"Error getting user accessible menus: {e}")
            return []
    
    def get_menu_permissions_for_role(self, role_id: str, menu_id: str) -> List[str]:
        """Get permissions for a specific role on a specific menu"""
        try:
            menu_role = self.get_menu_role(menu_id, role_id)
            return menu_role.permissions if menu_role else []
        except Exception as e:
            logger.error(f"Error getting menu permissions for role: {e}")
            return []
    
    def _sync_role_permissions(self, role_id: str) -> bool:
        """
        Sync role permissions based on assigned menu permissions.
        This ensures role.permissions always reflects the actual menu permissions.
        """
        try:
            from .role_repository import RoleRepository
            from .menu_repository import MenuRepository
            
            role_repo = RoleRepository()
            menu_repo = MenuRepository()
            
            # Get all menu assignments for this role
            menu_roles = self.get_menu_roles_by_role_id(role_id)
            
            # Build consolidated permission list
            all_permissions = []
            for menu_role in menu_roles:
                menu = menu_repo.get_menu_by_id(menu_role.menu_id)
                if menu:
                    # Create permission strings in format "menu_name:permission"
                    for permission in menu_role.permissions:
                        permission_string = f"{menu.name.lower().replace(' ', '_')}:{permission}"
                        all_permissions.append(permission_string)
                        
                        # Also add menu path based permissions if available
                        if menu.path:
                            path_permission = f"{menu.path.replace('/', '_').strip('_')}:{permission}"
                            all_permissions.append(path_permission)
            
            # Remove duplicates while preserving order
            unique_permissions = list(dict.fromkeys(all_permissions))
            
            # Update role permissions
            return role_repo.set_role_permissions(role_id, unique_permissions)
            
        except Exception as e:
            logger.error(f"Error syncing role permissions for role {role_id}: {e}")
            return False
