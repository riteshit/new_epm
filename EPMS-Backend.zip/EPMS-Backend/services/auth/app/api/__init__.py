"""
API module for Auth Service
"""

from . import v1

__all__ = ["v1"] 