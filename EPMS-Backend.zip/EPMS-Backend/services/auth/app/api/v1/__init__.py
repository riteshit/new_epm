"""
API v1 module for Auth Service
"""

from . import routes

__all__ = ["routes"] 