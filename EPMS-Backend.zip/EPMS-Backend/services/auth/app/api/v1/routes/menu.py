"""
Menu API routes - Only required endpoints
"""

from fastapi import APIRouter, Depends, HTTPException
from typing import List, Dict, Any
from ....core.rbac import require_menu_access, _current_user_dependency
from ....repository.menu_repository import MenuRepository
from ....core.logger import get_auth_logger
from ....core.dto import AuthUserDTO

logger = get_auth_logger(__name__)

router = APIRouter(prefix="/menu", tags=["Menu Management"])

# Initialize repository
menu_repository = MenuRepository()


@router.get("/", response_model=List[Dict[str, Any]])
async def get_assigned_menus(
    current_user: AuthUserDTO = _current_user_dependency()
):
    """
    Get assigned menus for the current user based on their roles and permissions
    
    Returns:
        Hierarchical menu tree with nested children
    """
    try:
        logger.info(f"Getting assigned menus for user: {current_user.username}")
        logger.info(f"Current user object: {current_user}")
        
        # Get user roles and permissions
        user_roles = current_user.roles
        user_permissions = current_user.permissions
        
        logger.info(f"User roles: {user_roles}")
        logger.info(f"User permissions: {user_permissions}")
        
        # Check if user has admin access (all menus)
        if "*" in user_permissions or "admin" in user_roles:
            logger.info("Admin user - returning complete menu tree")
            menu_tree = menu_repository.get_menu_tree()
            
            if not menu_tree:
                logger.warning("No menu tree returned from repository")
                return []
            
            logger.info(f"Successfully retrieved menu tree with {len(menu_tree)} root menus")
            result = [menu.model_dump() for menu in menu_tree]
            logger.info(f"Returning {len(result)} menu items")
            return result
        
        # For non-admin users, get menus based on their roles
        logger.info(f"Non-admin user - getting role-based menus")
        
        from ....repository.menu_role_repository import MenuRoleRepository
        from ....repository.role_repository import RoleRepository
        
        menu_role_repo = MenuRoleRepository()
        role_repo = RoleRepository()
        
        # Get all accessible menu IDs for the user's roles
        accessible_menu_ids = set()
        
        for role_id in user_roles:
            role = role_repo.get_role_by_id(role_id)
            if role:
                # Get menus assigned to this role
                role_menus = menu_role_repo.get_menus_for_role(role.id)
                accessible_menu_ids.update(role_menus)
        
        logger.info(f"User has access to {len(accessible_menu_ids)} menu IDs: {accessible_menu_ids}")
        
        if not accessible_menu_ids:
            logger.info("No menus assigned to user roles")
            return []
        
        # Get the complete menu tree and filter by accessible menus
        all_menus = menu_repository.get_all_active_menus()
        accessible_menus = [menu for menu in all_menus if menu.id in accessible_menu_ids]
        
        # Build hierarchical menu tree for accessible menus
        menu_tree = menu_repository.build_menu_tree(accessible_menus)
        
        logger.info(f"Successfully retrieved {len(menu_tree)} accessible root menus")
        result = [menu.model_dump() for menu in menu_tree]
        logger.info(f"Returning {len(result)} menu items")
        return result
        
    except Exception as e:
        logger.error(f"Error getting assigned menus: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to retrieve assigned menus: {str(e)}")


@router.get("/test", response_model=List[Dict[str, Any]])
async def test_menu_tree():
    """Test endpoint to check if menu tree building works"""
    try:
        logger.info("Testing menu tree building...")
        menu_tree = menu_repository.get_menu_tree()
        
        if not menu_tree:
            logger.warning("No menu tree returned from repository")
            return []
        
        logger.info(f"Successfully retrieved menu tree with {len(menu_tree)} root menus")
        result = [menu.model_dump() for menu in menu_tree]
        logger.info(f"Returning {len(result)} menu items")
        return result
        
    except Exception as e:
        logger.error(f"Error in test menu tree: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Test failed: {str(e)}")

@router.get("/list", response_model=List[Dict[str, Any]])
async def get_all_menus_for_admin(
    current_user: AuthUserDTO = Depends(require_menu_access("Admin", "read"))
):
    """
    Get all menus for admin management - used for menu assignment interface
    
    Returns:
        Flat list of all menu items in the system
    """
    try:
        logger.info(f"Admin getting all menus for assignment: {current_user.username}")
        
        # Verify admin permissions
        user_permissions = current_user.permissions
        user_roles = current_user.roles
        
        if "*" not in user_permissions and "admin" not in user_roles:
            logger.warning(f"Non-admin user {current_user.username} attempted to access admin menu list")
            raise HTTPException(status_code=403, detail="Admin access required")
        
        # Get all menus (flat list)
        all_menus = menu_repository.get_all_active_menus()
        
        logger.info(f"Admin retrieved {len(all_menus)} total menus for assignment")
        return [menu.model_dump() for menu in all_menus]
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting admin menu list: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve admin menu list")