"""
User Management Routes - Only required endpoints
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from ....core.rbac import require_menu_access
from ....services.auth_service import auth_service
from ....core.dto import UserDTO, AuthUserDTO
from ....utils.activity_logger import log_user_management, log_auth_activity

# Import secure audit logging
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..'))
from libs.audit_queue.simple_logger import audit_logger
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from datetime import datetime


# Pydantic models for user operations
class UserCreateRequest(BaseModel):
    username: str
    password: str
    email: Optional[str] = None

class UserUpdateRequest(BaseModel):
    username: Optional[str] = None
    email: Optional[str] = None
    roles: Optional[List[str]] = None
    permissions: Optional[List[str]] = None
    profile: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None
    is_verified: Optional[bool] = None

class UserResponse(BaseModel):
    id: str
    username: str
    email: Optional[str] = None 
    is_active: bool
    is_verified: bool
    roles: List[str]
    permissions: List[str]
    profile: Dict[str, Any]
    created_at: Optional[str] = None
    last_login: Optional[str] = None

class RoleAssignmentRequest(BaseModel):
    roles: List[str]

# REMOVED: PermissionAssignmentRequest - permissions come from roles only



router = APIRouter(prefix="/users", tags=["User Management"])

# User CRUD Operations
@router.get("/", response_model=List[UserResponse])
async def list_users(
    request: Request,
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of records to return"),
    role: Optional[str] = Query(None, description="Filter by role"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    current_user: AuthUserDTO = Depends(require_menu_access("Users", "read"))
) -> List[UserResponse]:
    """Get list of users with pagination and filtering"""
    try:
        from ....repository.user_repository import UserRepository
        user_repo = UserRepository()
        
        # Get users with filters
        users = user_repo.get_users_with_pagination(skip=skip, limit=limit, role_filter=role, is_active_filter=is_active)
        
        # Log user list access with secure audit logging
        client_ip = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent")
        
        audit_logger.log_user_action(
            service="auth",
            user_id=current_user.id,
            action="list_users",
            message=f"Admin accessed user list: {current_user.username}",
            client_ip=client_ip,
            username=current_user.username,
            users_returned=len(users),
            pagination={"skip": skip, "limit": limit},
            filters={"role": role, "is_active": is_active},
            user_agent=user_agent,
            success=True
        )
        
        # Convert to response format
        return [
            UserResponse(
                id=str(user.id),
                username=user.username,
                email=user.email,
                is_active=user.is_active,
                is_verified=user.is_verified,
                roles=user.roles,
                permissions=user.permissions,
                profile=user.profile,
                created_at=user.created_at.isoformat() if user.created_at else None,
                last_login=user.last_login.isoformat() if user.last_login else None
            )
            for user in users
        ]
    except Exception as e:
        # Log failed user list access with secure audit logging
        client_ip = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent")
        
        audit_logger.log_error_event(
            service="auth",
            error_name="UserListAccessError",
            error_message=f"Failed to access user list: {str(e)}",
            user_id=getattr(current_user, 'id', 'unknown'),
            client_ip=client_ip,
            username=getattr(current_user, 'username', 'unknown'),
            access_failed=True,
            exception_type=type(e).__name__,
            user_agent=user_agent
        )
        raise HTTPException(status_code=500, detail=f"Error listing users: {str(e)}")

@router.post("/", response_model=UserResponse)
async def create_user(
    request: Request,
    user_data: UserCreateRequest,
    current_user: AuthUserDTO = Depends(require_menu_access("Users", "create"))
) -> UserResponse:
    """Create a new user with username and password (email optional)"""
    try:
        from ....repository.user_repository import UserRepository
        user_repo = UserRepository()
        
        # Check if user already exists
        existing_user = user_repo.get_user_by_username(user_data.username)
        if existing_user:
            raise HTTPException(status_code=400, detail="Username already exists")
        
        # Check email uniqueness only if email is provided
        if user_data.email:
            existing_email = user_repo.get_user_by_email(user_data.email)
            if existing_email:
                raise HTTPException(status_code=400, detail="Email already exists")
        
        # Create user with simple defaults
        user = user_repo.create_user(
            username=user_data.username,
            email=user_data.email or "",  # Empty string if no email provided
            password=user_data.password,
            roles=["user"],  # Default role
            permissions=[],  # Default permissions
            profile={},  # Empty profile
            is_active=True,  # Active by default
            is_verified=False  # Not verified by default
        )
        
        # Log successful user creation with secure audit logging
        client_ip = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent")
        
        audit_logger.log_user_action(
            service="auth",
            user_id=current_user.id,
            action="create_user",
            message=f"Admin created new user: {user.username}",
            client_ip=client_ip,
            username=current_user.username,
            target_user_id=str(user.id),
            target_username=user.username,
            new_user_email=user_data.email,
            created_by_admin=True,
            default_role="user",
            user_agent=user_agent,
            success=True
        )
        
        return UserResponse(
            id=str(user.id),
            username=user.username,
            email=user.email,
            is_active=user.is_active,
            is_verified=user.is_verified,
            roles=user.roles,
            permissions=user.permissions,
            profile=user.profile,
            created_at=user.created_at.isoformat() if user.created_at else None,
            last_login=user.last_login.isoformat() if user.last_login else None
        )
    except HTTPException:
        raise
    except Exception as e:
        # Log failed user creation with secure audit logging
        client_ip = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent")
        
        audit_logger.log_error_event(
            service="auth",
            error_name="UserCreationError",
            error_message=f"Failed to create user {user_data.username}: {str(e)}",
            user_id=current_user.id,
            client_ip=client_ip,
            username=current_user.username,
            target_username=user_data.username,
            creation_failed=True,
            exception_type=type(e).__name__,
            attempted_email=user_data.email,
            user_agent=user_agent
        )
        raise HTTPException(status_code=500, detail=f"Error creating user: {str(e)}")

@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str,
    current_user = Depends(require_menu_access("Users", "read"))
) -> UserResponse:
    """Get user by ID"""
    try:
        from ....repository.user_repository import UserRepository
        user_repo = UserRepository()
        
        user: Optional[UserDTO] = user_repo.get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return UserResponse(
            id=str(user.id),
            username=user.username,
            email=user.email,
            is_active=user.is_active,
            is_verified=user.is_verified,
            roles=user.roles,
            permissions=user.permissions,
            profile=user.profile,
            created_at=user.created_at.isoformat() if user.created_at else None,
            last_login=user.last_login.isoformat() if user.last_login else None
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving user: {str(e)}")

@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: str,
    user_data: UserUpdateRequest,
    current_user = Depends(require_menu_access("Users", "write"))
) -> UserResponse:
    """Update user by ID"""
    try:
        from ....repository.user_repository import UserRepository
        user_repo = UserRepository()
        
        # Check if user exists
        user = user_repo.get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Update user
        update_data = {}
        if user_data.username is not None:
            update_data['username'] = user_data.username
        if user_data.email is not None:
            update_data['email'] = user_data.email
        if user_data.roles is not None:
            update_data['roles'] = user_data.roles
        if user_data.permissions is not None:
            update_data['permissions'] = user_data.permissions
        if user_data.profile is not None:
            update_data['profile'] = user_data.profile
        if user_data.is_active is not None:
            update_data['is_active'] = user_data.is_active
        if user_data.is_verified is not None:
            update_data['is_verified'] = user_data.is_verified
        
        success = user_repo.update_user(user_id, update_data)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to update user")
        
        # Get updated user
        updated_user = user_repo.get_user_by_id(user_id)
        
        return UserResponse(
            id=str(updated_user.id),
            username=updated_user.username,
            email=updated_user.email,
            is_active=updated_user.is_active,
            is_verified=updated_user.is_verified,
            roles=updated_user.roles,
            permissions=updated_user.permissions,
            profile=updated_user.profile,
            created_at=updated_user.created_at.isoformat() if updated_user.created_at else None,
            last_login=updated_user.last_login.isoformat() if updated_user.last_login else None
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating user: {str(e)}")

@router.delete("/{user_id}")
async def delete_user(
    user_id: str,
    current_user = Depends(require_menu_access("Users", "delete"))
):
    """Delete user by ID"""
    try:
        from ....repository.user_repository import UserRepository
        user_repo = UserRepository()
        
        # Check if user exists
        user = user_repo.get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Delete user
        success = user_repo.delete_user(user_id)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to delete user")
        
        return {"message": "User deleted successfully", "user_id": user_id}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting user: {str(e)}")

# Role and Permission Management
@router.put("/{user_id}/roles")
async def assign_roles_to_user(
    user_id: str,
    role_data: RoleAssignmentRequest,
    current_user = Depends(require_menu_access("Users", "write"))
):
    """Assign roles to user"""
    try:
        from ....repository.user_repository import UserRepository
        user_repo = UserRepository()
        
        # Check if user exists
        user = user_repo.get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Update user roles
        success = user_repo.update_user(user_id, {"roles": role_data.roles})
        if not success:
            raise HTTPException(status_code=500, detail="Failed to assign roles")
        
        return {"message": "Roles assigned successfully", "user_id": user_id, "roles": role_data.roles}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error assigning roles: {str(e)}")

@router.get("/{user_id}/roles")
async def get_user_roles(
    user_id: str,
    current_user = Depends(require_menu_access("Users", "read"))
):
    """Get user roles with detailed information"""
    try:
        from ....repository.user_repository import UserRepository
        from ....repository.role_repository import RoleRepository
        
        user_repo = UserRepository()
        role_repo = RoleRepository()
        
        user = user_repo.get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Get detailed role information
        role_details = []
        for role_name in user.roles:
            role = role_repo.get_role_by_name(role_name)
            if role:
                role_details.append({
                    "id": role.id,
                    "name": role.name,
                    "description": role.description,
                    "created_at": role.created_at.isoformat()
                })
        
        return {
            "user_id": user_id,
            "username": user.username,
            "roles": user.roles,
            "role_details": role_details
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving user roles: {str(e)}")

# Note: Direct permission assignment removed. 
# Permissions are now automatically derived from role menu assignments.
# Use: 1) Assign menus to roles, 2) Assign roles to users

@router.get("/{user_id}/accessible-menus")
async def get_user_accessible_menus(
    user_id: str,
    current_user = Depends(require_menu_access("Users", "read"))
):
    """Get all menus accessible to a user based on their roles"""
    try:
        from ....repository.user_repository import UserRepository
        from ....repository.menu_role_repository import MenuRoleRepository
        from ....repository.menu_repository import MenuRepository
        from ....repository.role_repository import RoleRepository
        
        user_repo = UserRepository()
        menu_role_repo = MenuRoleRepository()
        menu_repo = MenuRepository()
        role_repo = RoleRepository()
        
        user = user_repo.get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Get all accessible menus based on user roles
        accessible_menus = []
        menu_permissions_map = {}
        
        # Get role IDs
        role_ids = []
        for role_name in user.roles:
            role = role_repo.get_role_by_name(role_name)
            if role:
                role_ids.append(role.id)
        
        # Get menu permissions for all roles
        for role_id in role_ids:
            menu_roles = menu_role_repo.get_menu_roles_by_role_id(role_id)
            for menu_role in menu_roles:
                menu = menu_repo.get_menu_by_id(menu_role.menu_id)
                if menu:
                    if menu.id not in menu_permissions_map:
                        menu_permissions_map[menu.id] = {
                            "menu": menu,
                            "permissions": set()
                        }
                    menu_permissions_map[menu.id]["permissions"].update(menu_role.permissions)
        
        # Build response
        for menu_data in menu_permissions_map.values():
            menu = menu_data["menu"]
            permissions = list(menu_data["permissions"])
            
            accessible_menus.append({
                "menu_id": menu.id,
                "menu_name": menu.name,
                "menu_path": menu.path,
                "menu_icon": menu.icon,
                "parent_id": menu.parent_id,
                "permissions": permissions
            })
        
        return {
            "user_id": user_id,
            "username": user.username,
            "accessible_menus": accessible_menus,
            "total_accessible_menus": len(accessible_menus)
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting user accessible menus: {str(e)}")

# REMOVED: Direct user permissions endpoint
# 
# Use these endpoints instead to understand user access:
# - GET /users/{user_id}/roles → See user's assigned roles  
# - GET /users/{user_id}/accessible-menus → See user's accessible menus with permissions
# - GET /roles/{role_id}/menus → See what menus are assigned to specific roles
#
# Permissions are automatically calculated and don't need a separate endpoint.

