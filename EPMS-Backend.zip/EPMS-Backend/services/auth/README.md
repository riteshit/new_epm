# Auth Service

Authentication and Authorization service for the EPMS Backend system.

## Features

- User authentication with JWT tokens
- Multi-factor authentication (MFA)
- Role-based access control (RBAC)
- **Page-based access control** - New feature for organizing permissions by pages/controllers
- Password policies and security
- User management
- Audit logging

## Page-Based Access Control

The Auth Service now supports **page-based access control**, which organizes permissions around specific pages/controllers rather than individual endpoints. This provides a more intuitive way to manage user access to different parts of the application.

### How It Works

1. **Pages/Controllers**: Each service has pages/controllers (e.g., `user_management`, `processing`, `ingestion`)
2. **Page Permissions**: Users get access to entire pages rather than individual endpoints
3. **Role Assignment**: Roles are assigned page-level permissions (e.g., `user_management:access`)
4. **Access Control**: When a user tries to access any endpoint in a page, the system checks if they have the page permission

### Available Pages

| Page | Service | Permission | Description |
|------|---------|------------|-------------|
| `auth` | Auth | `auth:access` | Authentication endpoints (login, logout, etc.) |
| `mfa` | Auth | `mfa:access` | Multi-factor authentication |
| `user_management` | Auth | `user_management:access` | User and role management |
| `processing` | Processing | `processing:access` | Data processing operations |
| `user_processing` | Processing | `user_processing:access` | User management in processing service |
| `ingestion` | Ingestion | `ingestion:access` | Data ingestion operations |
| `scheduler` | Scheduler | `scheduler:access` | Job scheduling operations |

### Default Role Permissions

```python
ROLES_AND_PAGE_PERMISSIONS = {
    "admin": ["*"],  # Access to all pages
    "operator": [
        "auth:access",
        "mfa:access", 
        "user_management:access",
        "processing:access",
        "user_processing:access",
        "ingestion:access",
        "scheduler:access"
    ],
    "user": [
        "auth:access",
        "mfa:access",
        "processing:access",
        "ingestion:access"
    ],
    "viewer": [
        "auth:access",
        "processing:access",
        "ingestion:access"
    ]
}
```

### Using Page-Based Access Control

#### 1. In API Routes (Auth Service)

```python
from ..core.rbac import require_user_management_page

@router.get("/users")
async def list_users(
    current_user: Dict[str, Any] = Depends(require_user_management_page)
):
    """List all users - requires user_management:access permission"""
    # Implementation here
```

#### 2. In Other Services

```python
def require_processing_access():
    """Dependency to require access to processing page"""
    async def checker(current_user: Dict[str, Any] = Depends(get_current_user)):
        user_permissions = current_user.get("permissions", [])
        
        if "*" in user_permissions or "processing:access" in user_permissions:
            return current_user
        
        raise HTTPException(
            status_code=403,
            detail="Access denied to processing page. Required permission: processing:access"
        )
    
    return checker

@router.post("/data")
async def process_data(
    request: ProcessingRequest,
    current_user: Dict[str, Any] = Depends(require_processing_access())
):
    """Process data - requires processing:access permission"""
    # Implementation here
```

#### 3. Check User's Accessible Pages

```python
from ..core.rbac import get_user_accessible_pages

# Get all pages a user can access
accessible_pages = get_user_accessible_pages(user_permissions)
# Returns: ["auth", "mfa", "processing", "ingestion"]
```

#### 4. API Endpoints for Page Access

- `GET /users/me/accessible-pages` - Get user's accessible pages
- `GET /pages/{page_name}/endpoints` - Get endpoints for a specific page

### Benefits of Page-Based Access Control

1. **Simplified Management**: Assign access to entire pages rather than individual endpoints
2. **Better Organization**: Permissions are organized by functional areas
3. **Easier Frontend Integration**: Frontend can show/hide entire sections based on page permissions
4. **Reduced Complexity**: Fewer granular permissions to manage
5. **Consistent Access**: Users get access to all functionality within a page

### Migration from Granular Permissions

The system maintains backward compatibility with granular permissions while adding page-based access control. You can use both approaches:

- **Page-based**: `user_management:access` (grants access to all user management endpoints)
- **Granular**: `users:read`, `users:create`, etc. (grants access to specific operations)

### Configuration

Page definitions are stored in `app/core/constants.py`:

```python
PAGES_AND_ENDPOINTS = {
    "user_management": {
        "list_users": ["GET /users"],
        "create_user": ["POST /users"],
        "get_user": ["GET /users/{user_id}"],
        # ... more endpoints
    }
}
```

## API Endpoints

### Authentication
- `POST /auth/login` - User login
- `POST /auth/logout` - User logout
- `POST /auth/refresh` - Refresh access token
- `POST /auth/register` - User registration
- `POST /auth/verify` - Email verification

### MFA
- `POST /mfa/setup` - Setup MFA
- `POST /mfa/verify` - Verify MFA code
- `POST /mfa/disable` - Disable MFA
- `GET /mfa/backup-codes` - Get backup codes

### User Management
- `GET /users` - List users
- `POST /users` - Create user
- `GET /users/{user_id}` - Get user details
- `PUT /users/{user_id}` - Update user
- `DELETE /users/{user_id}` - Delete user
- `PUT /users/{user_id}/roles` - Assign roles to user
- `GET /me/accessible-pages` - Get user's accessible pages
- `GET /pages/{page_name}/endpoints` - Get page endpoints

### Roles and Permissions
- `GET /roles` - List roles
- `POST /roles` - Create role
- `PUT /roles/{role_id}` - Update role
- `DELETE /roles/{role_id}` - Delete role

## Environment Variables

Create a `.env` file in the auth service directory:

```env
# Database
MONGODB_URI=mongodb://localhost:27017/epms_auth
DATABASE_NAME=epms_auth

# JWT
JWT_SECRET_KEY=your-secret-key
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7

# Security
PASSWORD_SALT_ROUNDS=12
MAX_LOGIN_ATTEMPTS=5
LOCKOUT_DURATION_MINUTES=15
PASSWORD_EXPIRY_DAYS=90
PASSWORD_HISTORY_COUNT=5

# MFA
MFA_ISSUER=EPMS
MFA_ALGORITHM=SHA1
MFA_DIGITS=6
MFA_PERIOD=30

# Redis (for token blacklisting)
REDIS_URL=redis://localhost:6379/0

# Logging
LOG_LEVEL=INFO
```

## Running the Service

```bash
cd services/auth
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8001
```

## Testing

```bash
# Run tests
python -m pytest tests/

# Test specific functionality
python -m pytest tests/test_rbac.py -v
```

## Integration with Other Services

Other services can use the auth client to validate tokens and check permissions:

```python
from libs.auth_client import AuthClient

auth_client = AuthClient("http://localhost:8001")

# Validate token
user_info = await auth_client.validate_token(token)

# Check if user has page access
if "processing:access" in user_info.get("permissions", []):
    # Allow access to processing functionality
    pass
``` 