# EPMS-Backend

**EPMS-Backend** is a monorepo backend project for managing multiple microservices that support the Energy Portfolio Management System (EPMS). This project uses FastAPI, MongoDB, Redis, and follows clean architecture principles.

---

## 📦 Microservices Included

- **Auth Service**: Handles user authentication, JWT, MFA, and device tracking.
- **Ingestion Service**: Accepts and stores incoming external data.
- **Processing Service**: Validates and transforms ingested data.
- **Scheduler Service**: Manages cron jobs like retries, cleanups, and periodic syncs.

---

## 🧰 Supporting Modules

- **libs/**: Shared libraries like MongoDB connectors, JWT utilities, and logging.
- **infra/**: Contains infrastructure configs.
- **scripts/**: One-time or utility scripts for setup, health checks, mock data, etc.

---

## 🚀 Project Structure

```
EPMS/
├── services/
│   ├── auth/
│   │   └── .env
│   ├── ingestion/
│   │   └── .env
│   ├── processing/
│   │   └── .env
│   └── scheduler/
│       └── .env
├── libs/
│   ├── auth_client/
│   ├── core/
│   └── db/
├── infra/
│   └── nginx/
├── scripts/
└── README.md
```

---

## 🧪 Local Development

### ✅ Quick Setup

1. **Create and activate virtual environment**
   ```bash
   python -m venv venv
   
   # Windows CMD:
   venv\Scripts\activate.bat
   
   # PowerShell:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   venv\Scripts\Activate.ps1
   
   # macOS/Linux:
   source venv/bin/activate
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements-dev.txt
   ```

3. **Setup environment files**
   ```bash
   python setup_env.py
   ```

4. **Copy and configure environment files**
   ```bash
   # Copy .env.example to .env in each service directory
   copy services\auth\.env.example services\auth\.env
   copy services\ingestion\.env.example services\ingestion\.env
   copy services\processing\.env.example services\processing\.env
   copy services\scheduler\.env.example services\scheduler\.env
   
   # Edit each .env file with your configuration
   ```

5. **Run services**

   **Option A: Run all services together**
   ```bash
   python run_services.py all
   ```

   **Option B: Run individual services**
   ```bash
   # List available services
   python run_services.py --list
   
   # Run specific service
   python run_services.py auth
   python run_services.py ingestion
   python run_services.py processing
   python run_services.py scheduler
   ```

   **Option C: Run services separately**
   ```bash
   uvicorn services.auth.app.main:app --reload --port 8001
   uvicorn services.ingestion.app.main:app --reload --port 8002
   uvicorn services.processing.app.main:app --reload --port 8003
   uvicorn services.scheduler.app.main:app --reload --port 8004
   ```

6. **Test Endpoints**
   - Auth: http://localhost:8001
   - Ingestion: http://localhost:8002
   - Processing: http://localhost:8003
   - Scheduler: http://localhost:8004

7. **Check service health**
   ```bash
   python run_services.py --health
   ```

8. **Run tests**
   ```bash
   pytest tests/
   ```

---

## 🗂️ Directory Scaffolding
```
services/
├── auth/
│   └── .env
├── ingestion/
│   └── .env
├── processing/
│   └── .env
└── scheduler/
    └── .env

libs/
├── auth_client/
├── core/
└── db/

infra/
└── nginx/
```

---

## 🧾 Environment Files
- `services/auth/.env`
- `services/ingestion/.env`
- `services/processing/.env`
- `services/scheduler/.env`

--- 

## 📁 .gitignore
```txt
__pycache__/
*.pyc
*.pyo
venv/
.venv/
.env
.env.*
.vscode/
.idea/
```

---

## 📌 Notes

- All services are now created with basic structure and configuration.
- Each service can be run independently or together using the service runner.
- Comprehensive logging is implemented across all services.
- Test structure is in place for all services.
- Environment configuration is **service-specific** to support isolated deployments.
- Services can be run from VS Code launch configurations or command line.

---

## 🆕 New Features

### ✅ **Completed Tasks**

1. **Missing Services Created**
   - ✅ Ingestion Service (Port 8002)
   - ✅ Processing Service (Port 8003) 
   - ✅ Scheduler Service (Port 8004)

2. **Environment Configuration**
   - ✅ `.env.example` files for all services
   - ✅ Comprehensive configuration settings
   - ✅ Service-specific environment variables
   - ✅ Auth service uses `auth_db` and `audit_db` databases

3. **Logger Provision**
   - ✅ Centralized logging utility in `libs/core/logger.py`
   - ✅ Service-specific logger functions
   - ✅ Structured logging with JSON format
   - ✅ Colored console output
   - ✅ File logging support

4. **Test Structure**
   - ✅ Test files for all services
   - ✅ Health check tests
   - ✅ API endpoint tests
   - ✅ Database connection tests
   - ✅ Mock configurations

5. **Service Management**
   - ✅ `run_services.py` - Run all services or individual services
   - ✅ Service health monitoring
   - ✅ Graceful shutdown handling
   - ✅ VS Code launch configurations for all services

6. **Development Tools**
   - ✅ `setup_env.py` - Environment file setup
   - ✅ Updated VS Code workspace configuration
   - ✅ Pytest integration
   - ✅ Comprehensive requirements files
   - ✅ Database manager for auth service with dual database support

### 🚀 **Usage Examples**

```bash
# List all services
python run_services.py --list

# Check service health
python run_services.py --health

# Run all services
python run_services.py all

# Run individual service
python run_services.py auth
python run_services.py ingestion
python run_services.py processing
python run_services.py scheduler

# Run tests
pytest tests/
```

---

## 👤 Author

Sumit Jha
